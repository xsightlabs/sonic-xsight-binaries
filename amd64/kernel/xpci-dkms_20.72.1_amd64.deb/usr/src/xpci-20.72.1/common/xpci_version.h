// SPDX-License-Identifier: GPL-2.0

/*
 * Version definitions for XPCI, XPCXD and XNetDev
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCI_VERSION_H_
#define XPCI_VERSION_H_

#define XPCI_DRIVER_NAME "XPCI"

#ifndef XPCI_BUILD_GIT_COMMIT
#define XPCI_BUILD_GIT_COMMIT "unknown"
#endif

/*
 * XPCI Driver Version
 *
 * First digit is a major version.
 * Second digit is a minor version.
 * Third digit is a patch version.
 */
#ifndef XPCI_DRIVER_VERSION
#define XPCI_DRIVER_VERSION "Version 20.72.1"
#endif
#define XPCI_DRIVER_VERSION_STR "Memory hardening and xmit fix"
#define XPCI_DRIVER_GIT_COMMIT XPCI_BUILD_GIT_COMMIT
#define XPCXD_NETDEV_DRV_VERSION XPCI_DRIVER_VERSION
#define XNETDEV_DRV_VERSION XPCI_DRIVER_VERSION

#endif /* XPCI_VERSION_H_ */
