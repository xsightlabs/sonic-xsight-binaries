// SPDX-License-Identifier: GPL-2.0

/*
 * Kernel traces definition
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#if !IS_ENABLED(CONFIG_TRACEPOINTS) || defined(__CHECKER__)
#ifndef XPCI_TRACE_H_
#define XPCI_TRACE_H_
/* If the Linux kernel tracepoints are not available then the xpcxd_trace*
 * macros become nops.
 */
#define xpcxd_trace(trace_name, args...)
#define xpcxd_trace_enabled(trace_name) (0)

#define xpci_trace(trace_name, args...)
#define xpci_trace_enabled(trace_name) (0)

#endif /* ifndef XPCI_TRACE_H_ */
#else /* CONFIG_TRACEPOINTS */

/* The trace subsystem name for xpcxd will be "xpcxd".
 *
 * This file is named xpci_trace.h.
 *n
 * Since this include file's name is different from the trace
 * subsystem name, we'll have to define TRACE_INCLUDE_FILE at the end
 * of this file.
 */
#undef TRACE_SYSTEM
#define TRACE_SYSTEM xpci

#include <linux/tracepoint.h>

#define _XPCXD_TRACE_NAME(trace_name) (trace_##xpcxd##_##trace_name)
#define XPCXD_TRACE_NAME(trace_name) _XPCXD_TRACE_NAME(trace_name)

#define xpcxd_trace(trace_name, args...) XPCXD_TRACE_NAME(trace_name)(args)
#define xpcxd_trace_enabled(trace_name) XPCXD_TRACE_NAME(trace_name##_enabled)()

DECLARE_EVENT_CLASS(xpcxd_tx_event_class,
    TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(void*, skb)
        __field(uint, skb_len)
        __field(int, value1)
        __field(int, value2)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->skb = skb;
        __entry->skb_len = skb_len;
        __entry->value1 = value1;
        __entry->value2 = value2;
    ),
    TP_printk("ring_id=%d skb=%p skb_len=%d v1=0x%x v2=0x%x", 
        __entry->ring_id,
        __entry->skb, 
        __entry->skb_len,
        __entry->value1,
        __entry->value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_xmit,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt_icmp_req,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt_icmp_reply,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_db_write,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

/*
 * xpcxd_tx_db_defer: Tx doorbell deferred at end of xpcxd_xmit() because
 * netdev_xmit_more() is true (stack promises more packets). Paired with a
 * later xpcxd_tx_db_write() when the flush condition triggers (xmit_more
 * false, ring space low, or we drained the qdisc ourselves).
 *   skb      = current skb that just committed descriptors
 *   skb_len  = skb->len
 *   value1   = sub_desc_pending after this call (descriptors awaiting DB)
 *   value2   = total_desc_batch (descriptors committed by this call)
 */
DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_db_defer,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_netdev_pkt,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

/*
 * Rx ring snapshot: SubF / CmpF [HW:SW] in sub_free_hw_sw and cmpl_free_hw_sw
 * (high=HW, low=SW; HW ~0 = N/A). Cmp/Sub C:P. val_a/val_b = event-specific.
 *
 * CmpF HW is RFL engine credits from xpcxd_hw_rx_cmpl_ring_free_slots() (ceiling
 * cmp.size - 1). CmpF SW is xpcxd_get_cmpl_ring_space() (ceiling cmp.size when
 * cons == prd empty). So on a 1024-deep ring, a fully-idle pair often prints as
 * 1023:1024 — not a wrap bug
 * (which compares two HW producer sources: RFL head vs memcfg CRD_PRD_PTR).
 */
DECLARE_EVENT_CLASS(xpcxd_rx_event_class,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b),
	TP_STRUCT__entry(
		__field(int, ring_id)
		__field(u64, sub_free_hw_sw)
		__field(u64, cmpl_free_hw_sw)
		__field(u32, sub_cons)
		__field(u32, sub_prod)
		__field(u32, cmpl_cons)
		__field(u32, cmpl_prd)
		__field(u64, hw_snap_sub)
		__field(u64, hw_snap_cmpl)
		__field(int, val_a)
		__field(int, val_b)
	),
	TP_fast_assign(
		__entry->ring_id = ring_id;
		__entry->sub_free_hw_sw = sub_free_hw_sw;
		__entry->cmpl_free_hw_sw = cmpl_free_hw_sw;
		__entry->sub_cons = sub_cons;
		__entry->sub_prod = sub_prod;
		__entry->cmpl_cons = cmpl_cons;
		__entry->cmpl_prd = cmpl_prd;
		__entry->hw_snap_sub = hw_snap_sub;
		__entry->hw_snap_cmpl = hw_snap_cmpl;
		__entry->val_a = val_a;
		__entry->val_b = val_b;
	),
	TP_printk("rid=%d SubF[HW:SW]=%u:%u CmpF[HW:SW]=%u:%u Cmp[C=%u:%u,P=%u:%u] Sub[C=%u:%u,P=%u:%u] a=%d b=%d",
		  __entry->ring_id,
		  (u32)(__entry->sub_free_hw_sw >> 32), (u32)__entry->sub_free_hw_sw,
		  (u32)(__entry->cmpl_free_hw_sw >> 32), (u32)__entry->cmpl_free_hw_sw,
		  (u32)(__entry->hw_snap_cmpl >> 32), __entry->cmpl_cons,
		  (u32)__entry->hw_snap_cmpl, __entry->cmpl_prd,
		  (u32)(__entry->hw_snap_sub >> 32), __entry->sub_cons,
		  (u32)__entry->hw_snap_sub, __entry->sub_prod,
		  __entry->val_a, __entry->val_b)
);

/* val_a: poll budget (max); val_b: unused (0) */
DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_start,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_next,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_sw_desc_index,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_stop,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_mtu_too_big,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_outer_sa_tail_nonzero,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_done,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/*
 * NAPI hold boundary: emitted when xpcxd_rx_poll() returns @budget without
 * napi_complete to keep the softirq scheduled while CMPL HW credits are
 * exhausted (val_a = hw_cmpl_free, val_b = rx_pkts). The HW snapshot in
 * Cmp/Sub Cons/Prod columns is the authoritative state at the hold point;
 * the SW shadow can lag the HW producer arbitrarily here, which is exactly
 * why these holds happen — keeping both columns in one trace makes that
 * lag observable.
 */
DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_napi_hold,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_space_check,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_space_check_failed,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_fill_start,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_fill_finish,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_db_write,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/*
 * rx_cmpl_low_hw_napi_held: optional NAPI repoll when HW CMPL credits are still
 * <= hold_low_thresh after a draining poll (rx_pkts>0). Distinct from HW CMPL
 * ring full (hw_cmpl_free==0 → rx_cmpl_full_napi_held). hw_cmpl_free=~0 means
 * unavailable (non-RFL). rx_done=1 → poll ended with work left (often budget);
 * rx_done=0 → exhausted this poll — combine with rx_pkts vs budget for stall hints.
 * rx_credits/rx_credits_cap show deferred refill state to correlate hold behavior
 * with credit slash/restore activity.
 */
TRACE_EVENT(xpcxd_rx_cmpl_low_hw_napi_held,
	TP_PROTO(int ring_id, u32 hw_cmpl_free, u32 hold_low_thresh, int budget,
		 int rx_pkts, u16 cmpl_size, u32 sw_cmpl_free, int rx_done,
		 u32 rx_credits, u32 rx_credits_cap),
	TP_ARGS(ring_id, hw_cmpl_free, hold_low_thresh, budget, rx_pkts,
		cmpl_size, sw_cmpl_free, rx_done, rx_credits, rx_credits_cap),
	TP_STRUCT__entry(
		__field(int, ring_id)
		__field(u32, hw_cmpl_free)
		__field(u32, hold_low_thresh)
		__field(int, budget)
		__field(int, rx_pkts)
		__field(u16, cmpl_size)
		__field(u32, sw_cmpl_free)
		__field(int, rx_done)
		__field(u32, rx_credits)
		__field(u32, rx_credits_cap)
	),
	TP_fast_assign(
		__entry->ring_id = ring_id;
		__entry->hw_cmpl_free = hw_cmpl_free;
		__entry->hold_low_thresh = hold_low_thresh;
		__entry->budget = budget;
		__entry->rx_pkts = rx_pkts;
		__entry->cmpl_size = cmpl_size;
		__entry->sw_cmpl_free = sw_cmpl_free;
		__entry->rx_done = rx_done;
		__entry->rx_credits = rx_credits;
		__entry->rx_credits_cap = rx_credits_cap;
	),
	TP_printk("rid=%d low_hw_napi_held hw_cmpl_free=%u hold_low_thresh=%u "
		  "napi_budget=%d rx_pkts=%d cmpl_size=%u sw_cmpl_free=%u rx_done=%d "
		  "rx_credits=%u rx_credits_cap=%u",
		  __entry->ring_id, __entry->hw_cmpl_free, __entry->hold_low_thresh,
		  __entry->budget, __entry->rx_pkts, __entry->cmpl_size,
		  __entry->sw_cmpl_free, __entry->rx_done, __entry->rx_credits,
		  __entry->rx_credits_cap)
);

/*
 * Correlate Rx ring traces (e.g. Cmp/Sub all zero) with admin paths.
 * phase: 1=netdev_stop_begin (ifconfig down) 2=netdev_stop_end (rings freed)
 *       3=dev_reset 4=driver_close_begin (unload) 5=netdev_open
 *       6=svc_restart_pre_close 7=svc_restart_post_reset 8=svc_restart_post_open
 * detail: bits 0-1 running/up (see driver); bit3 stop_done at close; bit4 set on svc phase6;
 *         upper bits: errno from reset(7)/open(8) when non-zero
 */
TRACE_EVENT(xpcxd_drv_lifecycle,
	TP_PROTO(int phase, int detail, u64 ns),
	TP_ARGS(phase, detail, ns),
	TP_STRUCT__entry(
		__field(int, phase)
		__field(int, detail)
		__field(u64, ns)
	),
	TP_fast_assign(
		__entry->phase = phase;
		__entry->detail = detail;
		__entry->ns = ns;
	),
	TP_printk("lifecycle phase=%d detail=0x%x ns=%llu "
		  "(1=nd_stop_begin 2=nd_stop_end 3=dev_reset 4=drv_close "
		  "5=nd_open 6=svc_pre_close 7=svc_post_reset 8=svc_post_open)",
		  __entry->phase, __entry->detail, __entry->ns)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_napi_complete,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_napi_next,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_enable_irq,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_disable_irq,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/* val_a = period_ms; val_b = k */
DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_refill_osc_start,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/* val_a = CMPL occupied (SW); val_b = HW RFL free or -1 */
DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_refill_osc_tick,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/* Rx SUB refill doorbell skipped: val_a=fill budget passed (0); val_b=SUB free slots (SW) */
DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_sub_ring_starvation,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_credits_slash,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_credits_restore,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

/*
 * Rx xpcxd_cfg_tbl[xpcxd_rx_drop_all] / teardown paths (always-on kernel trace).
 * where: 0 = xpcxd_rx_cmpl entry, 1 = xpcxd_rx_cmpl in-poll,
 *        2 = xpcxd_rx_poll napi_complete with CMPL HW-full (ifdown or drop_all),
 *        3 = xpcxd_stop arms rx_drop_all (ring_id=-1).
 * cfg: table value (1=teardown, 2=error/debug injection, etc.).
 */
DECLARE_EVENT_CLASS(xpcxd_rx_drop_all_event_class,
	TP_PROTO(int ring_id, int where, int cfg),
	TP_ARGS(ring_id, where, cfg),
	TP_STRUCT__entry(
		__field(int, ring_id)
		__field(int, where)
		__field(int, cfg)
	),
	TP_fast_assign(
		__entry->ring_id = ring_id;
		__entry->where = where;
		__entry->cfg = cfg;
	),
	TP_printk("ring_id=%d where=%d cfg=%d",
		__entry->ring_id, __entry->where, __entry->cfg)
);

DEFINE_EVENT(xpcxd_rx_drop_all_event_class, xpcxd_rx_drop_all,
	TP_PROTO(int ring_id, int where, int cfg),
	TP_ARGS(ring_id, where, cfg)
);

/* Timing check */

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_carrier_on,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_carrier_off,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_start,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_end,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_alloc_skip,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_next,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_rx_db_ring,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_alloc_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_dma_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_tail_stop,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_close,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_stop,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_rx_disable,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_tx_disable,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_napi_disable,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_dev_alloc_page,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_start,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_page,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_recycle_page,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_done,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_trailer_seq_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_trailer_num_pkts_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_skb_alloc_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_build_skb_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_stats_err,
	TP_PROTO(int ring_id, u64 sub_free_hw_sw, u64 cmpl_free_hw_sw,
		 u32 sub_cons, u32 sub_prod, u32 cmpl_cons, u32 cmpl_prd,
		 u64 hw_snap_sub, u64 hw_snap_cmpl, int val_a, int val_b),
	TP_ARGS(ring_id, sub_free_hw_sw, cmpl_free_hw_sw, sub_cons, sub_prod,
		cmpl_cons, cmpl_prd, hw_snap_sub, hw_snap_cmpl, val_a, val_b)
);

DECLARE_EVENT_CLASS(xpcxd_rx_skb_event_class,
    TP_PROTO(int ring_id, int value1, void *skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(int, value1)
        __field(void*, skb)
        __field(int, value3)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->value1 = value1;
        __entry->skb = skb;
        __entry->value3 = value3;
    ),
    TP_printk("ring_id=%d n=%d skb=%p pfn=0x%x", __entry->ring_id, __entry->value1, __entry->skb, __entry->value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_skb_align,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_consume,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_build_err,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_page_err,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_pass_to_stack,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DECLARE_EVENT_CLASS(xpcxd_rx_fill_event_class,
    TP_PROTO(int ring_id, int prod_idx, void *sw_desc, u8 eof, u32 len, u32 lsb, u32 msb),
    TP_ARGS(ring_id, prod_idx, sw_desc, eof, len, lsb, msb),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(int, prod_idx)
        __field(void*, sw_desc)
        __field(u8, eof)
        __field(u32, len)
        __field(u32, lsb)
        __field(u32, msb)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->prod_idx = prod_idx;
        __entry->sw_desc = sw_desc;
        __entry->eof = eof;
        __entry->len = len;
        __entry->lsb = lsb;
        __entry->msb = msb;
    ),
    TP_printk("ring_id=%d prod_idx=%d sw_desc=%p eof=%u len=%d lsb=0x%x msb=0x%x", 
       	__entry->ring_id,
        __entry->prod_idx,
        __entry->sw_desc,
        __entry->eof,
        __entry->len,
        __entry->lsb,
        __entry->msb)
);

DEFINE_EVENT(xpcxd_rx_fill_event_class, xpcxd_rx_fill_bd,
	TP_PROTO(int ring_id, int prod_idx, void *sw_desc, u8 eof, u32 len, u32 lsb, u32 msb),
    TP_ARGS(ring_id, prod_idx, sw_desc, eof, len, lsb, msb)
);

/*
 * Multi-fragment RX (11 TP args — kernel BPF helpers top out at 12; do not add fields).
 * Ring snap lives on xpcxd_rx_event_class traces instead.
 */
DECLARE_EVENT_CLASS(
	xpcxd_rx_poll_frag_event_class,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size),
	TP_STRUCT__entry(
		__field(int, ring_id)
		__field(int, prod_idx)
		__field(void *, skb)
		__field(int, skb_len)
		__field(u32, num_desc)
		__field(u32, sub_desc_idx)
		__field(void *, sw_desc)
		__field(void *, page)
		__field(u32, len_left)
		__field(u32, frag_size)
	),
	TP_fast_assign(
		__entry->ring_id = ring_id;
		__entry->prod_idx = prod_idx;
		__entry->skb = skb;
		__entry->skb_len = skb_len;
		__entry->num_desc = num_desc;
		__entry->sub_desc_idx = sub_desc_idx;
		__entry->sw_desc = sw_desc;
		__entry->page = page;
		__entry->len_left = len_left;
		__entry->frag_size = frag_size;
	),
	TP_printk("ring_id=%d prod_idx=%d skb=%p skb_len=%d num_desc=%d sub_desc_idx=%d sw_desc=%p page=%p len_left=%d frag_size=%d",
		  __entry->ring_id, __entry->prod_idx, __entry->skb,
		  __entry->skb_len, __entry->num_desc, __entry->sub_desc_idx,
		  __entry->sw_desc, __entry->page, __entry->len_left,
		  __entry->frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_index_wrap,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size));

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_index_next,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size));

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_add_frag,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size));

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_new_skb,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size));

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_consume_skb,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		 u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left,
		 u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc,
		page, len_left, frag_size));

#define _XPCI_TRACE_NAME(trace_name) (trace_##xpci##_##trace_name)
#define XPCI_TRACE_NAME(trace_name) _XPCI_TRACE_NAME(trace_name)

#define xpci_trace(trace_name, args...) XPCI_TRACE_NAME(trace_name)(args)
#define xpci_trace_enabled(trace_name) XPCI_TRACE_NAME(trace_name##_enabled)()

DECLARE_EVENT_CLASS(xpci_irq_event_class,
    TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr),
    TP_STRUCT__entry(
		__field(int, irq)
        __field(void*, desc_addr)
        __field(void*, msix_table_addr)
    ),
    TP_fast_assign(
		__entry->irq = irq;
        __entry->desc_addr = desc_addr;
        __entry->msix_table_addr = msix_table_addr;
    ),
    TP_printk("irq=%d desc_addr=%p msix_table_addr=%p", __entry->irq, __entry->desc_addr, __entry->msix_table_addr)
);

DEFINE_EVENT(xpci_irq_event_class, xpci_irq_mask,
	TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr)
);

DEFINE_EVENT(xpci_irq_event_class, xpci_irq_unmask,
	TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr)
);


DECLARE_EVENT_CLASS(xpci_netdev_rx_learning_event_class,
    TP_PROTO(u32 event, u32 port_id, u16 vlan_id, unsigned char *addr),
    TP_ARGS(event, port_id, vlan_id, addr),
    TP_STRUCT__entry(
		__field(u32, event)
        __field(u32, port_id)
        __field(u16, vlan_id)
        __array(unsigned char, addr, ETH_ALEN)
    ),
    TP_fast_assign(
		__entry->event = event;
        __entry->port_id = port_id;
        __entry->vlan_id = vlan_id;
        memcpy(__entry->addr, addr, ETH_ALEN);
    ),
    TP_printk("FDB Event=%d Port=%d Vid %u Addr=[%02x:%02x:%02x:%02x:%02x:%02x]",
                __entry->event, __entry->port_id, __entry->vlan_id, __entry->addr[0],
                __entry->addr[1], __entry->addr[2], __entry->addr[3],
                __entry->addr[4], __entry->addr[5])
);

DEFINE_EVENT(xpci_netdev_rx_learning_event_class, xpci_netdev_rx_fdb_learning,
	TP_PROTO(u32 event, u32 port_id, u16 vlan_id, unsigned char *addr),
    TP_ARGS(event, port_id, vlan_id, addr)
);


#endif /* XPCI_TRACE_H_ */

/* This trace include file is not located in the .../include/trace
 * with the kernel tracepoint definitions, because we're a loadable
 * module.
 */
#undef TRACE_INCLUDE_PATH
#define TRACE_INCLUDE_PATH .
#undef TRACE_INCLUDE_FILE
#define TRACE_INCLUDE_FILE xpci_trace

#include <trace/define_trace.h>

