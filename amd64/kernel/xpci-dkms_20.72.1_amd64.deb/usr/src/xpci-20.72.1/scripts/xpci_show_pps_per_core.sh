#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.


sudo bpftrace -e '
kprobe:napi_gro_receive 
{
    @packets[cpu] = count();
}

interval:s:1
{
    print(@packets);
    clear(@packets);
}
'
