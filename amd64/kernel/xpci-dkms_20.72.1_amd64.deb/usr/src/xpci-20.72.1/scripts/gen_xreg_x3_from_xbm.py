#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
#
# Build xreg_x3.h by taking xreg_x2.h as a template and replacing
# matching #define bodies from an xbm-generated xreg.h.
#
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

from __future__ import annotations

import argparse
import pathlib
import re
import sys


DEFINE_RE = re.compile(r"^(?P<prefix>\s*#define\s+)(?P<name>[A-Za-z_]\w*)(?P<sep>\s+)(?P<body>.*)$")


def parse_defines(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in text.splitlines():
        m = DEFINE_RE.match(line)
        if not m:
            continue
        out[m.group("name")] = m.group("body")
    return out


def generate(template_text: str, source_defines: dict[str, str]) -> tuple[str, int]:
    updated_lines: list[str] = []
    replaced = 0

    for raw_line in template_text.splitlines(keepends=True):
        line = raw_line.rstrip("\n")
        m = DEFINE_RE.match(line)
        if not m:
            updated_lines.append(raw_line)
            continue

        name = m.group("name")
        if name not in source_defines:
            updated_lines.append(raw_line)
            continue

        new_body = source_defines[name]
        if new_body == m.group("body"):
            updated_lines.append(raw_line)
            continue

        replaced += 1
        updated_lines.append(f"{m.group('prefix')}{name}{m.group('sep')}{new_body}\n")

    return "".join(updated_lines), replaced


def main() -> int:
    default_x2 = "xpci_ko_src/pcxd/xreg_x2.h"
    default_src = "../../../xbm/build/X3/debug/gen-regs/xreg.h"
    default_x3 = "xpci_ko_src/pcxd/xreg_x3.h"

    parser = argparse.ArgumentParser(
        description=(
            "Create xreg_x3.h from xreg_x2.h by replacing matching #define "
            "bodies with values found in xbm-generated xreg.h."
        ),
        epilog=(
            "Defaults (from repo root): "
            f"xreg_x2={default_x2}, "
            f"xbm_xreg_h={default_src}, "
            f"xreg_x3={default_x3}"
        ),
    )
    parser.add_argument(
        "xreg_x2",
        nargs="?",
        default=default_x2,
        help="Template header (default: %(default)s)",
    )
    parser.add_argument(
        "xbm_xreg_h",
        nargs="?",
        default=default_src,
        help="Source header from XBM gen-regs (default: %(default)s)",
    )
    parser.add_argument(
        "xreg_x3",
        nargs="?",
        default=default_x3,
        help="Output path (default: %(default)s)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Fail if no matching #define names are found between template and source.",
    )
    args = parser.parse_args()

    x2_path = pathlib.Path(args.xreg_x2)
    src_path = pathlib.Path(args.xbm_xreg_h)
    out_path = pathlib.Path(args.xreg_x3)

    if not x2_path.is_file():
        print(f"ERROR: template header not found: {x2_path}", file=sys.stderr)
        return 2
    if not src_path.is_file():
        print(f"ERROR: source header not found: {src_path}", file=sys.stderr)
        return 2

    x2_text = x2_path.read_text(encoding="utf-8", errors="ignore")
    src_text = src_path.read_text(encoding="utf-8", errors="ignore")

    src_defines = parse_defines(src_text)
    x2_defines = parse_defines(x2_text)
    common = set(src_defines) & set(x2_defines)
    if args.strict and not common:
        print(
            "ERROR: no matching #define names found between template and source",
            file=sys.stderr,
        )
        return 3

    out_text, replaced = generate(x2_text, src_defines)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(out_text, encoding="utf-8")

    print(
        "Done: "
        f"template_defines={len(x2_defines)} "
        f"source_defines={len(src_defines)} "
        f"matching={len(common)} "
        f"replaced={replaced} "
        f"output={out_path}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
