#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

# List AER sysfs files for an Xsight PCI device (vendor 1e6c).
# Usage: xpci_aer_show.sh [domain:bus:dev.fn]
# If BDF is omitted, the first [1e6c:xxxx] from "lspci -Dnn" is used.

set -euo pipefail

sysfs_bdf_for() {
	local bdf=$1
	local p="/sys/bus/pci/devices/${bdf}"
	if [[ -d "$p" ]]; then
		echo "$bdf"
		return 0
	fi
	if [[ "$bdf" != *:*:*:* ]]; then
		p="/sys/bus/pci/devices/0000:${bdf}"
		if [[ -d "$p" ]]; then
			echo "0000:${bdf}"
			return 0
		fi
	fi
	return 1
}

bdf=${1:-}
if [[ -z "$bdf" ]]; then
	line=$(lspci -Dnn 2>/dev/null | grep -E '\[1e6c:[0-9a-fA-F]{4}\]' | head -1 || true)
	[[ -n "$line" ]] || {
		echo "No 1e6c:* device in lspci -Dnn; pass BDF explicitly: $0 <domain:bus:dev.fn>" >&2
		exit 1
	}
	bdf=$(awk '{print $1}' <<<"$line")
fi

sys_bdf=$(sysfs_bdf_for "$bdf") || {
	echo "No sysfs entry for PCI $bdf (under /sys/bus/pci/devices/)." >&2
	exit 1
}

aer_dir="/sys/bus/pci/devices/${sys_bdf}"
shopt -s nullglob
aer=( "${aer_dir}"/aer* )
shopt -u nullglob
if [[ ${#aer[@]} -eq 0 ]]; then
	echo "No AER sysfs nodes under ${aer_dir}/" >&2
	exit 1
fi

echo "PCI ${sys_bdf} — AER sysfs:"
ls -l "${aer_dir}"/aer*
