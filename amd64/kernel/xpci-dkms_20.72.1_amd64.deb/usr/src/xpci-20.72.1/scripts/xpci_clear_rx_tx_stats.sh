#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IFACE="${1:-xpcxd0}"

sudo ethtool --set-priv-flags "$IFACE" clear-rx-stat on
sudo ethtool --set-priv-flags "$IFACE" clear-tx-stat on
