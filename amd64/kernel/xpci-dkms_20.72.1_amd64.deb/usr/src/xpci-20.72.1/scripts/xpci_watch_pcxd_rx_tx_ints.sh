# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

watch -n0.1 "cat /proc/interrupts | grep CMP_INT"
