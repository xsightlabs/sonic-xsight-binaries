#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

#
# Short smoke-test for the xpci packaging/install lifecycle.
#
# Exercises (in this order):
#   1. make package        -> .deb artifacts only, no install side-effect
#   2. make install        -> xpci-dkms registered; module .ko present
#   3. make install-reload -> xpci-dkms still registered; module reload OK
#   4. make uninstall      -> xpci-dkms gone; no leftover .ko under /lib/modules
#
# Each step is verified, and the script aborts at the first failure.
# Designed to be invoked from `make install-test` in xdrv/xpci/xdrivers.
#

set -u
set -o pipefail

DIR=$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)
PKG=xpci-dkms
KVER=$(uname -r)
LOGTAG="[install-test]"

PASS=0
FAIL=0
PRE_PKG_VER=""

log()       { printf '%s %s\n' "$LOGTAG" "$*"; }
log_title() { printf '\n\033[1;32m%s %s\033[0m\n' "$LOGTAG" "$*"; }
log_pass()  { printf '%s PASS: %s\n' "$LOGTAG" "$*"; PASS=$((PASS + 1)); }
log_fail()  { printf '%s FAIL: %s\n' "$LOGTAG" "$*" >&2; FAIL=$((FAIL + 1)); }

run_make() {
	local target="$1"
	log "running: make -C $DIR $target"
	if ! make -C "$DIR" "$target"; then
		log_fail "make $target returned non-zero"
		return 1
	fi
	return 0
}

deb_count() {
	shopt -s nullglob
	local pkgs=("$DIR/package/"xpci*.deb)
	shopt -u nullglob
	echo "${#pkgs[@]}"
}

xpci_dkms_installed_version() {
	dpkg-query -W -f='${Version}' "$PKG" 2>/dev/null || true
}

xpci_module_present_for_running_kernel() {
	[ -f "/lib/modules/$KVER/updates/dkms/xpci.ko" ] ||
		[ -f "/lib/modules/$KVER/updates/dkms/xpci.ko.zst" ] ||
		[ -f "/lib/modules/$KVER/updates/dkms/xpci.ko.xz" ]
}

source_version() {
	make -C "$DIR" version-info 2>/dev/null | sed -n 's/^Version: //p' | head -n1
}

#
# Snapshot pre-test xpci-dkms install state. If it was installed before the
# test, we reinstall it after the uninstall step so we leave the operator's
# environment as we found it.
#
PRE_PKG_VER=$(xpci_dkms_installed_version)

#
# 1. make package: .deb artifacts must appear; xpci-dkms must NOT change state.
#
log_title "step 1: make package (.deb only, no install)"
if run_make package; then
	if [ "$(deb_count)" -gt 0 ]; then
		log_pass "package produced .deb under $DIR/package"
	else
		log_fail "package did not produce any .deb under $DIR/package"
	fi
	post_pkg_ver=$(xpci_dkms_installed_version)
	if [ "$PRE_PKG_VER" = "$post_pkg_ver" ]; then
		log_pass "package did not modify xpci-dkms install state (was: '${PRE_PKG_VER:-none}')"
	else
		log_fail "package modified xpci-dkms version: '${PRE_PKG_VER:-none}' -> '${post_pkg_ver:-none}'"
	fi
fi

#
# 2. make install: xpci-dkms must be installed; .ko must exist under /lib/modules.
#
log_title "step 2: make install"
if run_make install; then
	inst_ver=$(xpci_dkms_installed_version)
	src_ver=$(source_version)
	if [ -n "$inst_ver" ]; then
		log_pass "xpci-dkms installed: Version $inst_ver"
	else
		log_fail "xpci-dkms not registered with dpkg after install"
	fi
	if [ -n "$src_ver" ] && [ "$inst_ver" = "$src_ver" ]; then
		log_pass "installed version matches source ($src_ver)"
	else
		log_fail "installed version '$inst_ver' != source '$src_ver'"
	fi
	if xpci_module_present_for_running_kernel; then
		log_pass "xpci.ko present under /lib/modules/$KVER/updates/dkms/"
	else
		log_fail "xpci.ko missing under /lib/modules/$KVER/updates/dkms/"
	fi
fi

#
# 3. make install-reload: still installed; reload should not error out.
#
log_title "step 3: make install-reload"
if run_make install-reload; then
	inst_ver=$(xpci_dkms_installed_version)
	if [ -n "$inst_ver" ]; then
		log_pass "xpci-dkms still installed after reload: Version $inst_ver"
	else
		log_fail "xpci-dkms missing after install-reload"
	fi
	if xpci_module_present_for_running_kernel; then
		log_pass "xpci.ko still present under /lib/modules/$KVER/updates/dkms/"
	else
		log_fail "xpci.ko missing under /lib/modules/$KVER/updates/dkms/ after reload"
	fi
fi

#
# 4. make uninstall: xpci-dkms gone; no leftover .ko for running kernel.
#
log_title "step 4: make uninstall"
if run_make uninstall; then
	if [ -z "$(xpci_dkms_installed_version)" ]; then
		log_pass "xpci-dkms not installed after uninstall"
	else
		log_fail "xpci-dkms still registered after uninstall"
	fi
	if ! xpci_module_present_for_running_kernel; then
		log_pass "xpci.ko removed for running kernel"
	else
		log_fail "xpci.ko still present under /lib/modules/$KVER/updates/dkms/"
	fi
fi

#
# Post-test: if xpci-dkms was installed before the test ran, reinstall it now
# so we leave the operator's environment in the same usable state. We use
# install-reload so the running kernel picks up the freshly installed .ko,
# matching what an operator who was already using xpci would expect.
#
if [ -n "$PRE_PKG_VER" ]; then
	log_title "post-test: restoring xpci-dkms (was Version $PRE_PKG_VER before test)"
	if run_make install-reload; then
		now_ver=$(xpci_dkms_installed_version)
		if [ -n "$now_ver" ]; then
			log_pass "xpci-dkms restored: Version $now_ver"
		else
			log_fail "post-test restore did not register xpci-dkms with dpkg"
		fi
	fi
else
	log_title "post-test: xpci-dkms was not installed before; leaving system clean"
fi

#
# Summary.
#
log "----------------------------------------"
log "passed: $PASS"
log "failed: $FAIL"
log "----------------------------------------"

if [ "$FAIL" -eq 0 ]; then
	printf '\n\033[1;32m%s Test finished OK\033[0m\n' "$LOGTAG"
	exit 0
else
	printf '\n\033[1;31m%s Test failed (%d failures)\033[0m\n' "$LOGTAG" "$FAIL" >&2
	exit 1
fi
