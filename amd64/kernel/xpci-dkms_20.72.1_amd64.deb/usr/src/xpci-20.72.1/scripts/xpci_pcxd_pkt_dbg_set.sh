# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

ethtool -s xpcxd0 msglvl timer off
ethtool -s xpcxd0 msglvl tx_queued on
ethtool -s xpcxd0 msglvl pktdata on
ethtool -s xpcxd0 msglvl tx_done on
ethtool -s xpcxd0 msglvl rx_status on

ethtool -s xpcxd0 msglvl intr on
