#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.


DBG_LEVEL=4

if [ $# -eq 1 ]
  then
    DBG_LEVEL=$1
fi

# debug_level=1 - Error
# 2 - Notice
# 3 - Info
# 4 - Debug
# 5 - Debug + Registers read/write

echo ${DBG_LEVEL} > /sys/module/xpci/parameters/debug_level
echo 1 > /sys/module/xpci/parameters/pkt_trace
