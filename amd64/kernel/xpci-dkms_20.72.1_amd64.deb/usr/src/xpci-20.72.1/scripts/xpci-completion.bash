# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
#
# Bash completion for the `xpci` CLI wrapper.
# Install path: /usr/share/bash-completion/completions/xpci

_xpci_complete() {
	local cur prev cword words
	# bash-completion's _init_completion is the canonical helper; fall back manually.
	if declare -F _init_completion >/dev/null 2>&1; then
		_init_completion || return
	else
		COMPREPLY=()
		cur="${COMP_WORDS[COMP_CWORD]}"
		prev="${COMP_WORDS[COMP_CWORD-1]}"
		cword=$COMP_CWORD
		words=("${COMP_WORDS[@]}")
	fi

	local subcommands="show load reload rem stats clear_stats monitor show_dbg_lvl set_dbg_lvl set_pkt_trace help --help -h"

	# Top-level subcommand
	if [ "$cword" -eq 1 ]; then
		COMPREPLY=( $(compgen -W "$subcommands" -- "$cur") )
		return 0
	fi

	local sub="${words[1]}"
	case "$sub" in
	monitor)
		# Completion: flags and network interfaces
		if [[ "$cur" == -* ]]; then
			COMPREPLY=( $(compgen -W "-t -p -h --help" -- "$cur") )
			return 0
		fi
		local ifaces=""
		if [ -d /sys/class/net ]; then
			ifaces=$(ls /sys/class/net 2>/dev/null)
		fi
		COMPREPLY=( $(compgen -W "$ifaces" -- "$cur") )
		return 0
		;;
	clear_stats)
		# Optional interface name (default xpcxd0 in script)
		if [ "$cword" -eq 2 ]; then
			local ifaces=""
			if [ -d /sys/class/net ]; then
				ifaces=$(ls /sys/class/net 2>/dev/null)
			fi
			COMPREPLY=( $(compgen -W "$ifaces" -- "$cur") )
			return 0
		fi
		COMPREPLY=()
		return 0
		;;
	set_dbg_lvl)
		# Completion: debug level values 1..5
		if [ "$cword" -eq 2 ]; then
			COMPREPLY=( $(compgen -W "1 2 3 4 5" -- "$cur") )
			return 0
		fi
		COMPREPLY=()
		return 0
		;;
	set_pkt_trace)
		# Completion: packet trace values 0..3
		if [ "$cword" -eq 2 ]; then
			COMPREPLY=( $(compgen -W "0 1 2 3" -- "$cur") )
			return 0
		fi
		COMPREPLY=()
		return 0
		;;
	show|load|reload|rem|stats|show_dbg_lvl|help|--help|-h)
		# No further completion for these.
		COMPREPLY=()
		return 0
		;;
	*)
		COMPREPLY=( $(compgen -W "$subcommands" -- "$cur") )
		return 0
		;;
	esac
}

complete -F _xpci_complete xpci
