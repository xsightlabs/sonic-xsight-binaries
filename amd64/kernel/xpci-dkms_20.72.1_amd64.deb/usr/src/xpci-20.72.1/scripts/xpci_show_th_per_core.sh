#!/usr/bin/env bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

#
# Demo utility: prints simulated per-core throughput once per second.
# No Python runtime dependency.
#

set -euo pipefail

num_cpus="${1:-8}"

if ! [[ "$num_cpus" =~ ^[0-9]+$ ]] || [ "$num_cpus" -le 0 ]; then
	echo "Usage: $0 [num_cpus>0]"
	exit 1
fi

trap 'echo "Stopping..."; exit 0' INT

while true; do
	echo "==== Mbps per core ===="
	for ((cpu = 0; cpu < num_cpus; cpu++)); do
		# Simulate 1000..100000 bytes received in this 1s interval.
		# Mbps = bytes * 8 / 1,000,000
		bytes=$((1000 + (RANDOM % 99001)))
		printf "CPU %d: %d.%03d Mbps\n" \
			"$cpu" \
			"$((bytes * 8 / 1000000))" \
			"$(((bytes * 8 % 1000000) / 1000))"
	done
	sleep 1
done
