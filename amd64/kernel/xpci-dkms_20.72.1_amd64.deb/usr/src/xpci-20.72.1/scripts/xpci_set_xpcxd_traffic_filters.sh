#!/usr/bin/env bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

set -euo pipefail

IFACE="xpcxd0"

echo "Blocking OUTPUT (TX) MLD and LLDP on ${IFACE}..."

# ---- IPv6 MLD (ICMPv6) ----
for type in 130 131 132 143; do
  ip6tables -C OUTPUT -o "$IFACE" -p icmpv6 --icmpv6-type $type -j DROP 2>/dev/null || \
  ip6tables -A OUTPUT -o "$IFACE" -p icmpv6 --icmpv6-type $type -j DROP
done

# ---- LLDP (EtherType 0x88cc, L2) ----
# Drop untagged LLDP.
ebtables -C OUTPUT -o "$IFACE" -p 0x88cc -j DROP 2>/dev/null || \
ebtables -A OUTPUT -o "$IFACE" -p 0x88cc -j DROP

# Drop LLDP inside single-tag VLAN frames (802.1Q / C-tag).
ebtables -C OUTPUT -o "$IFACE" -p 0x8100 --vlan-encap 0x88cc -j DROP 2>/dev/null || \
ebtables -A OUTPUT -o "$IFACE" -p 0x8100 --vlan-encap 0x88cc -j DROP

# Drop LLDP inside provider-tag VLAN frames (802.1ad / S-tag).
ebtables -C OUTPUT -o "$IFACE" -p 0x88a8 --vlan-encap 0x88cc -j DROP 2>/dev/null || \
ebtables -A OUTPUT -o "$IFACE" -p 0x88a8 --vlan-encap 0x88cc -j DROP

# ---- LLDP on netdev egress (tc) ----
# Ensure clsact exists so egress filters can be attached.
tc qdisc show dev "$IFACE" | grep -q "clsact" || tc qdisc add dev "$IFACE" clsact

# Drop native LLDP at L2 egress (protocol 0x88cc).
if ! tc filter show dev "$IFACE" egress | \
  grep -A4 -E "protocol (802\\.1AB|0x88cc) .*pref 1000 .*flower" | \
  grep -q "action drop"; then
  tc filter add dev "$IFACE" egress protocol 0x88cc pref 1000 flower action drop
fi

echo "Done."
