#!/usr/bin/env python3
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.



def extract_timestamp(line):
    parts = line.split()
    try:
        timestamp = parts[2].rstrip(":")  # Remove the trailing colon
        return float(timestamp)
    except (IndexError, ValueError):
        return None  # Skip lines that don't have the expected format


def find_max_delta(filename):
    timestamps = []

    # Read the trace-cmd report file
    with open(filename) as file:
        for line in file:
            if "softirq_entry" in line or "softirq_exit" in line:
                ts = extract_timestamp(line)
                if ts is not None:
                    timestamps.append(ts)

    # Calculate deltas
    deltas = [j - i for i, j in zip(timestamps[:-1], timestamps[1:])]

    # Find the maximum delta
    if deltas:
        max_delta = max(deltas)
        print(f"Maximum delta time: {max_delta:.6f} seconds")
    else:
        print("No valid timestamps found.")


# Replace 'trace_cmd_report.txt' with the path to your trace-cmd report
find_max_delta("trace_cmd_report.txt")
