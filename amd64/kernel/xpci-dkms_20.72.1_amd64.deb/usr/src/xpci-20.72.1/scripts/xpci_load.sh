#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

# Pass -q for non-interactive use (e.g. cook_dkms.sh): skip pager on sysfs hints.
QUIET=
if [ "${1:-}" = "-q" ]; then
	QUIET=1
	shift
fi

# debug_level=1 - Error
# 2 - Notice
# 3 - Info
# 4 - Debug
# 5 - Debug with registers read/write

DBG_LEVEL=1
PKT_DBG_LEVEL=1
NUM_OF_PORTS=4

if [ $# -eq 1 ]
  then
    DBG_LEVEL=$1
fi

if [ $# -eq 2 ]
  then
    DBG_LEVEL=$1
    PKT_DBG_LEVEL=$2
fi


echo "Driver debug level: "${DBG_LEVEL}

sudo modprobe xpci attach_if="xpcxd0" num_of_ports=${NUM_OF_PORTS} debug_level=${DBG_LEVEL} pci_mode=1 netdev_mode=0 pcxd_mode=1
lsmod | grep xpci

echo "more /sys/module/xpci/parameters/debug_level"
if [ -n "$QUIET" ]; then
	cat /sys/module/xpci/parameters/debug_level 2>/dev/null || true
else
	more /sys/module/xpci/parameters/debug_level
fi
echo "more /sys/module/xpci/parameters/pkt_trace"
if [ -n "$QUIET" ]; then
	cat /sys/module/xpci/parameters/pkt_trace 2>/dev/null || true
else
	more /sys/module/xpci/parameters/pkt_trace
fi
