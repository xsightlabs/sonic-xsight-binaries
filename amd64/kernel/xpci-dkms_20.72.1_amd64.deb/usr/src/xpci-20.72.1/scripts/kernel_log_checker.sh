#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.


set -x

# Path to the log file
LOG_FILE="/var/log/kern.log"
# The string to watch for
TRIGGER_STRING="PANIC event"
#TRIGGER_STRING="HW IRQ mode"
# The script to run
#ACTION_SCRIPT="/home/swuser/kt/xdrivers.master/scripts/trace_cmd_run.cmd"

# Monitor the log file for new lines
tail -Fn0 "$LOG_FILE" | \
while read -r line; do
    if echo "$line" | grep -q "$TRIGGER_STRING"; then
        echo "Trigger detected: $line"
	echo "Running trace recorder for 20 seconds"
        #bash "$ACTION_SCRIPT"
	#timeout --signal=SIGINT 20s trace-cmd record -e irq:irq_handler_entry -e irq_handler_exit -e softirq_entry -e softirq_exit -e xpci:xpcxd_rx_poll* -e rcu:rcu_utilization -b 8192
	killall -s SIGINT trace-cmd
	echo "Trace taking finished"
	exit
    fi
done

