#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

# Show PCIe link capability/status for Xsight Labs devices (vendor 1e6c).
# Uses lspci -nn and [1e6c:xxxx] — not a fixed class/revision string (those vary by kernel/driver).

set -euo pipefail

vendor_re='\[1e6c:[0-9a-fA-F]{4}\]'

found=0
while IFS= read -r pci_line; do
	[ -z "$pci_line" ] && continue
	found=1
	pci_addr=$(echo "$pci_line" | awk '{print $1}')
	echo "Device: $pci_line"
	echo "Running lspci -s $pci_addr -vvv (link-related lines):"
	lspci -s "$pci_addr" -vvv 2>/dev/null | grep -E 'LnkSt|LnkCap' || echo "(no LnkSta/LnkCap lines)"
	echo ""
done < <(lspci -nn 2>/dev/null | grep -E "$vendor_re" || true)

if [ "$found" -eq 0 ]; then
	echo "Device not found (no 1e6c:* entry in lspci -nn)."
	exit 1
fi
