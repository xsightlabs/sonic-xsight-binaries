# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

sudo /usr/bin/trace-cmd report | awk '
/irq_handler_entry/ { ts[$4]=$2 }
/irq_handler_exit/ { 
  if (ts[$4]) {
    latency = $2 - ts[$4]
    print "IRQ:", $4, "Latency:", latency, "ms"
    delete ts[$4]
  }
}'
