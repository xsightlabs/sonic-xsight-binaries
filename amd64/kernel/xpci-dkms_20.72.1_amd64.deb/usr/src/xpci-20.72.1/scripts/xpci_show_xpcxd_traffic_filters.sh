#!/usr/bin/env bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

set -euo pipefail

IFACE="xpcxd0"

echo "=== ip6tables (IPv6 / MLD) OUTPUT rules for ${IFACE} ==="
ip6tables -L OUTPUT -v -n --line-numbers | grep "$IFACE" || echo "No rules"

echo
echo "=== ip6tables (raw format) ==="
ip6tables -S OUTPUT | grep "$IFACE" || echo "No rules"

echo
echo "=== ebtables (LLDP / L2) OUTPUT rules for ${IFACE} ==="
ebtables -L OUTPUT --Lc | grep "$IFACE" || echo "No rules"

echo
echo "=== ebtables (raw format) ==="
ebtables -L OUTPUT | grep "$IFACE" || echo "No rules"

echo
echo "=== Summary (MLD types) ==="
ip6tables -L OUTPUT -v -n | grep -E "icmpv6.*(130|131|132|143)" || echo "No MLD rules"

echo
echo "=== Summary (LLDP EtherType 0x88cc) ==="
ebtables -L OUTPUT | grep "0x88cc" || echo "No LLDP rules"

echo
echo "=== tc egress rules for ${IFACE} ==="
tc filter show dev "$IFACE" egress || echo "No tc egress filters"
