#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
#
# Throughput-only interface monitor.
#
# Throughput is computed as (delta-bytes * 8 / 1e6 / interval) and reported
# as "Mbps" (SI mega-bits per second) so values line up with iperf, ip -s,
# and line-rate references (e.g. 100 Gbps == 100000 Mbps).
#
# Counter-reset awareness: when an interface counter goes backward between
# samples (xpci clear_stats, module reload, netdev recreate, etc.), the
# delta is negative; this script prints "—" for that field and re-primes
# the baseline so the next sample is correct.
#
# Prefer xpci_if_monitor.sh / `xpci monitor -t` for new uses; this script
# is kept for backwards compatibility with existing tooling.

if [ -z "$1" ]; then
    echo "Usage: $0 <interface>"
    exit 1
fi

INTERFACE=$1
INTERVAL=1

echo "Monitoring interface: $INTERFACE"
echo "Press Ctrl+C to stop."

get_bytes() {
    cat /proc/net/dev | grep -w "$INTERFACE" | awk '{print $2, $10}'
}

read rx_prev tx_prev < <(get_bytes)

while true; do
    sleep $INTERVAL
    read rx_curr tx_curr < <(get_bytes)

    rx_bytes=$((rx_curr - rx_prev))
    tx_bytes=$((tx_curr - tx_prev))

    if [ "$rx_bytes" -lt 0 ] || [ "$tx_bytes" -lt 0 ]; then
        rx_mbps="—"
        tx_mbps="—"
    else
        rx_mbps=$(echo "scale=2; $rx_bytes * 8 / 1000000 / $INTERVAL" | bc)
        tx_mbps=$(echo "scale=2; $tx_bytes * 8 / 1000000 / $INTERVAL" | bc)
    fi

    echo "Rx: $rx_mbps Mbps | Tx: $tx_mbps Mbps"

    rx_prev=$rx_curr
    tx_prev=$tx_curr
done
