#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""
Sample /proc once per interval and print per-process CPU utilization for tasks
whose /proc/PID/stat "processor" field (CPU last run on) matches the target core.

Notes:
  - "Last CPU" is a snapshot, not affinity; short migrations may skew rows.
  - One logical CPU at 100% user+nice for 1s ~= 100% in this report.
"""
from __future__ import annotations

import argparse
import glob
import os
import sys
import time


def clk_tck() -> int:
    return os.sysconf(os.sysconf_names["SC_CLK_TCK"])


def parse_proc_pid_stat(pid: int):
    """
    Return (comm, utime+stime jiffies, last_cpu) or None.
    See proc_pid_stat(5): utime=field 14, stime=15, processor=39 (1-based full line);
    after ')' split, index = field - 3.
    """
    path = f"/proc/{pid}/stat"
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            raw = f.read()
    except OSError:
        return None
    rparen = raw.rfind(")")
    if rparen < 0:
        return None
    comm = raw[raw.find("(") + 1 : rparen]
    parts = raw[rparen + 2 :].split()
    if len(parts) < 38:
        return None
    try:
        utime = int(parts[11])
        stime = int(parts[12])
        processor = int(parts[36])
    except (ValueError, IndexError):
        return None
    return comm, utime + stime, processor


def sample_all() -> dict[int, tuple[str, int, int]]:
    out: dict[int, tuple[str, int, int]] = {}
    for p in glob.glob("/proc/[0-9]*"):
        try:
            pid = int(os.path.basename(p))
        except ValueError:
            continue
        row = parse_proc_pid_stat(pid)
        if row is not None:
            out[pid] = row
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "-c",
        "--cpu",
        type=int,
        default=7,
        metavar="N",
        help="CPU id to filter (default: 7)",
    )
    ap.add_argument(
        "-i",
        "--interval",
        type=float,
        default=1.0,
        metavar="SEC",
        help="Sampling period in seconds (default: 1.0)",
    )
    args = ap.parse_args()
    hz = clk_tck()
    target = args.cpu
    interval = args.interval
    if interval <= 0:
        print("interval must be > 0", file=sys.stderr)
        return 2

    prev_ticks: dict[int, int] = {}
    first = True

    print(
        f"# track_cpu_core_util.py: core={target}, interval={interval}s, CLK_TCK={hz}",
        flush=True,
    )

    while True:
        t0 = time.monotonic()
        time.sleep(interval)
        elapsed = time.monotonic() - t0
        if elapsed <= 0:
            elapsed = interval

        curr = sample_all()
        rows: list[tuple[float, int, str]] = []

        for pid, (comm, ticksum, last_cpu) in curr.items():
            if last_cpu != target:
                continue
            old = prev_ticks.get(pid, ticksum)
            delta = ticksum - old
            pct = 100.0 * delta / hz / elapsed
            rows.append((pct, pid, comm))

        prev_ticks = {pid: curr[pid][1] for pid in curr}

        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        rows.sort(key=lambda x: -x[0])
        print(f"=== {ts}  core {target}  ({len(rows)} tasks last seen on this CPU) ===", flush=True)
        if first:
            print("(baseline sample; %CPU from next line onward)\n", flush=True)
        elif rows:
            print(f"{'%CPU':>8}  {'PID':>8}  COMMAND", flush=True)
            for pct, pid, comm in rows:
                if pct < 0.01:
                    continue
                c = comm.replace("\n", " ")[:64]
                print(f"{pct:8.2f}  {pid:8d}  {c}", flush=True)
        else:
            print("(no tasks with last_cpu == %d)" % target, flush=True)
        print(flush=True)

        first = False


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("\n# stopped", file=sys.stderr)
        raise SystemExit(130) from None
