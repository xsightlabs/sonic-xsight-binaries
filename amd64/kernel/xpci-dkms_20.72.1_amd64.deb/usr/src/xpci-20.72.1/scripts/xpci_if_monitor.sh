#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
#
# Combined interface monitor: throughput (Mbps) and/or packets per second.
# Replaces xpci_if_th.sh and xpci_if_stat.sh.
#
# Throughput is computed as (delta-bytes * 8 / 1e6 / interval) and reported
# as "Mbps" (SI mega-bits per second) so values line up with iperf, ip -s,
# and line-rate references (e.g. 100 Gbps == 100000 Mbps).
#
# Counter-reset awareness: when an interface counter goes backward between
# samples (xpci clear_stats, module reload, netdev recreate, etc.), the
# delta is negative. Instead of dumping garbage rates into the rate row,
# the script prints "—" for that field and re-primes the baseline; the
# next sample is then correct.

INTERVAL="${INTERVAL:-1}"
MODE="all"   # all | th | stat

usage() {
    echo
    echo "Usage: $0 [-t | -p] <interface>"
    echo
    echo "  -t    throughput only (Rx/Tx Mbps, like xpci_if_th.sh)"
    echo "  -p    packets only (pkts/s, like xpci_if_stat.sh)"
    echo "  (none) both throughput and packets per second"
    echo
    echo "e.g. $0 eth0"
    echo "     $0 -t eth0"
    echo
    exit 1
}

while getopts "tp" opt; do
    case "$opt" in
        t) MODE="th" ;;
        p) MODE="stat" ;;
        *) usage ;;
    esac
done
shift $((OPTIND - 1))

if [ -z "$1" ]; then
    usage
fi

IF="$1"

# Validate interface exists
if [ ! -d "/sys/class/net/$IF" ]; then
    echo "Error: interface '$IF' not found."
    exit 1
fi

# Timestamp for each sample line only (optional: export XPCI_IF_MONITOR_DATE_FMT, e.g. '+%c')
ts() {
    if [ -n "${XPCI_IF_MONITOR_DATE_FMT:-}" ]; then
        date "$XPCI_IF_MONITOR_DATE_FMT"
    else
        date '+%Y-%m-%d %H:%M:%S'
    fi
}

get_bytes() {
    cat /proc/net/dev | grep -w "$IF" | awk '{print $2, $10}'
}

# Per-CPU line from /proc/stat: user nice system idle iowait irq softirq steal [guest guest_nice].
# guest/guest_nice must not be summed into total jiffies (already in user/nice); summing $2..$NF inflates utilization.
read_cpu_counters() {
    local pat="$1" line
    line=$(grep -E "^${pat}[[:space:]]" /proc/stat 2>/dev/null | head -n1)
    if [ -z "$line" ]; then
        echo "_none_"
        return
    fi
    echo "$line" | awk '
    {
        idle = $5 + $6
        busy = $2 + $3 + $4 + $7 + $8 + $9
        print idle, busy + idle
    }'
}

# Sets output variable with interval CPU% for the requested core label.
# Do NOT call as "$(cpu_util_pct ...)" — command substitution runs in a subshell and prev_* updates are lost.
cpu_util_pct() {
    local pat="$1" outvar="$2"
    local out idle total pct dt di
    local prev_idle_var="${pat}_prev_idle"
    local prev_total_var="${pat}_prev_total"
    local prev_idle="${!prev_idle_var:-}"
    local prev_total="${!prev_total_var:-}"

    out=$(read_cpu_counters "$pat")
    if [ "$out" = "_none_" ]; then
        printf -v "$outvar" "%s" "n/a"
        return
    fi
    read -r idle total <<<"$out"
    if [ -z "$prev_total" ] || [ -z "$prev_idle" ]; then
        printf -v "$prev_idle_var" "%s" "$idle"
        printf -v "$prev_total_var" "%s" "$total"
        printf -v "$outvar" "%s" "—"
        return
    fi
    dt=$((total - prev_total))
    di=$((idle - prev_idle))
    printf -v "$prev_idle_var" "%s" "$idle"
    printf -v "$prev_total_var" "%s" "$total"
    if [ "$dt" -le 0 ]; then
        printf -v "$outvar" "%s" "0.0"
        return
    fi
    pct=$(awk -v di="$di" -v dt="$dt" 'BEGIN {
        if (dt <= 0) { print "0.0"; exit }
        b = dt - di
        if (b < 0) b = 0
        if (b > dt) b = dt
        printf "%.1f\n", 100 * b / dt
    }')
    printf -v "$outvar" "%s" "${pct:-0.0}"
}

# Pick all CPU cores from /proc/stat (cpuN lines), e.g. cpu0 cpu1 ... cpu7.
pick_all_cpus() {
    mapfile -t _all_cpu_ids < <(awk '/^cpu[0-9]+[[:space:]]/ { print $1 }' /proc/stat)
    MON_CPU_LABELS=("${_all_cpu_ids[@]}")
}

# Build a set of CPU ids that currently host xpcxd0-RX_CMP interrupts.
# A CPU is considered hosting RX interrupts when its interrupt counter is non-zero.
refresh_rx_irq_cpus() {
    local irq_pat="xpcxd0-RX_CMP"
    local cpu_id
    declare -gA RX_IRQ_CPUS=()
    mapfile -t _rx_irq_cpu_ids < <(awk -v irq_pat="$irq_pat" '
        NR == 1 {
            cpu_cols = NF
            next
        }
        index($0, irq_pat) {
            for (i = 2; i <= cpu_cols + 1; i++) {
                if (($i + 0) > 0)
                    seen[i - 2] = 1
            }
        }
        END {
            for (c in seen)
                print c
        }
    ' /proc/interrupts 2>/dev/null | sort -n)

    for cpu_id in "${_rx_irq_cpu_ids[@]}"; do
        RX_IRQ_CPUS["$cpu_id"]=1
    done
}

echo "Monitoring interface: $IF (interval ${INTERVAL}s). Press Ctrl+C to stop."
echo

pick_all_cpus

# Initial readings for throughput
read rx_prev tx_prev < <(get_bytes 2>/dev/null || echo "0 0")
# Initial readings for packets
R1=$(cat /sys/class/net/$IF/statistics/rx_packets 2>/dev/null || echo 0)
T1=$(cat /sys/class/net/$IF/statistics/tx_packets 2>/dev/null || echo 0)
# Prime selected CPU baselines so the first line after INTERVAL shows real %.
for cpu_lbl in "${MON_CPU_LABELS[@]}"; do
    out0=$(read_cpu_counters "$cpu_lbl")
    if [ "$out0" != "_none_" ]; then
        read -r _idle _total <<<"$out0"
        printf -v "${cpu_lbl}_prev_idle" "%s" "$_idle"
        printf -v "${cpu_lbl}_prev_total" "%s" "$_total"
    fi
done

while true; do
    sleep "$INTERVAL"

    if [ "$MODE" = "th" ] || [ "$MODE" = "all" ]; then
        read rx_curr tx_curr < <(get_bytes 2>/dev/null || echo "0 0")
        rx_bytes=$((rx_curr - rx_prev))
        tx_bytes=$((tx_curr - tx_prev))
        # Counter went backward (xpci clear_stats / reload / recreate):
        # re-prime baseline and mark this sample as a reset.
        if [ "$rx_bytes" -lt 0 ] || [ "$tx_bytes" -lt 0 ]; then
            rx_mbps="—"
            tx_mbps="—"
        else
            rx_mbps=$(echo "scale=2; $rx_bytes * 8 / 1000000 / $INTERVAL" | bc 2>/dev/null || echo "0")
            tx_mbps=$(echo "scale=2; $tx_bytes * 8 / 1000000 / $INTERVAL" | bc 2>/dev/null || echo "0")
        fi
        rx_prev=$rx_curr
        tx_prev=$tx_curr
    fi

    if [ "$MODE" = "stat" ] || [ "$MODE" = "all" ]; then
        R2=$(cat /sys/class/net/$IF/statistics/rx_packets 2>/dev/null || echo 0)
        T2=$(cat /sys/class/net/$IF/statistics/tx_packets 2>/dev/null || echo 0)
        RXPPS=$((R2 - R1))
        TXPPS=$((T2 - T1))
        # Same reset guard as throughput.
        if [ "$RXPPS" -lt 0 ]; then
            RXPPS="—"
        fi
        if [ "$TXPPS" -lt 0 ]; then
            TXPPS="—"
        fi
        R1=$R2
        T1=$T2
    fi

    cpu_tail=""
    refresh_rx_irq_cpus
    for cpu_lbl in "${MON_CPU_LABELS[@]}"; do
        util_var="${cpu_lbl}_util"
        cpu_util_pct "$cpu_lbl" "$util_var"
        util_val="${!util_var}"
        cpu_id="${cpu_lbl#cpu}"
        if [ -z "${RX_IRQ_CPUS[$cpu_id]:-}" ]; then
            continue
        fi
        core_view="${cpu_id}:${util_val}%"
        if [ -z "$cpu_tail" ]; then
            cpu_tail="  cpu: ${core_view}"
        else
            cpu_tail="${cpu_tail} | ${core_view}"
        fi
    done
    if [ -z "$cpu_tail" ]; then
        cpu_tail="  cpu: none"
    fi

    case "$MODE" in
        th)   echo "Rx: $rx_mbps Mbps | Tx: $tx_mbps Mbps  |${cpu_tail}" ;;
        stat) echo "TX: $TXPPS pkts/s  RX: $RXPPS pkts/s  |${cpu_tail}" ;;
        all)  echo "Rx: $rx_mbps Mbps | Tx: $tx_mbps Mbps  |  TX: $TXPPS pkts/s  RX: $RXPPS pkts/s  |${cpu_tail}" ;;
    esac
done
