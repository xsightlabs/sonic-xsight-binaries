# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

./xpci_debug.sh 4
sudo ethtool --set-priv-flags xpcxd0 dump-rx-stat on
sudo ethtool --set-priv-flags xpcxd0 dump-tx-stat on
./xpci_debug.sh 1
