#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.


CLR_GREEN='\033[0;32m'
CLR_YELLOW='\033[1;33m'
CLR_RED='\033[0;31m'
CLR_RST='\033[0m'

echo "--- Xsight PCI devices ---"
exit_code=0
has_error=0
driver_loaded=0
vendor_id='1e6c'
# Match PCI ID [1e6c:xxxx] from lspci -nn (avoid spurious "1e6c" in unrelated text).
pic_device_lookup=$(lspci -Dnn 2>/dev/null | grep -E "\[${vendor_id}:[0-9a-fA-F]{4}\]" || true)

if [[ -n "$pic_device_lookup" ]]; then
    echo "$pic_device_lookup"
else
    echo -e "${CLR_YELLOW}ERROR:${CLR_RST} No X PCIe devices found, no PCIe link"
    exit_code=1
    has_error=1
fi

echo " "

echo "--- XPCI Driver status ---"
str='xpci'
xdriver_lookup=$(lsmod | grep "$str" || true)

if [[ "$xdriver_lookup" == *"$str"* ]]; then
    driver_loaded=1
    echo "$str Driver loaded"

    echo " "

    echo "--- XPCI Installed version ---"
    version="$(modinfo -F version xpci 2>/dev/null || true)"
    if [[ -n "$version" ]]; then
        echo "version:        $version"
    else
        echo "version:        (unknown)"
    fi

    version_str="$(modinfo -F version_str xpci 2>/dev/null || true)"
    if [[ -n "$version_str" ]]; then
        echo "version_str:    $version_str"
    else
        echo "version_str:    (unknown)"
    fi

    pkg_version=""
    if command -v dpkg-query >/dev/null 2>&1; then
        pkg_version="$(dpkg-query -W -f='${Version}\n' xpci-dkms 2>/dev/null | head -n1 || true)"
    fi
    if [[ -z "$pkg_version" ]] && command -v rpm >/dev/null 2>&1; then
        pkg_version="$(rpm -q --queryformat '%{VERSION}-%{RELEASE}\n' xpci-dkms 2>/dev/null | head -n1 || true)"
        [[ "$pkg_version" == *"is not installed"* ]] && pkg_version=""
    fi
    if [[ -n "$pkg_version" ]]; then
        echo "pkg version:    $pkg_version"
    else
        echo "pkg version:    (xpci-dkms not registered with the package manager)"
    fi

    src_version=""
    for _src_hdr in /usr/src/xpci-*/common/xpci_version.h; do
        [[ -r "$_src_hdr" ]] || continue
        src_version="$(awk '
            /^[[:space:]]*#define[[:space:]]+XPCI_DRIVER_VERSION[[:space:]]+"/ {
                match($0, /"[^"]*"/)
                if (RSTART > 0) {
                    s = substr($0, RSTART+1, RLENGTH-2)
                    print s
                    exit
                }
            }' "$_src_hdr" 2>/dev/null)"
        [[ -n "$src_version" ]] && break
    done
    if [[ -n "$src_version" ]]; then
        echo "src version:    $src_version"
    fi

    # Highlight stale-install / pending-reload mismatches. We compare
    # the trailing "20.73.6"-style tail rather than the full string so a
    # leading "Version " prefix on the modinfo side doesn't trip the
    # comparison.
    _norm() { sed -E 's/^[[:space:]]*[Vv]ersion[[:space:]]+//; s/[[:space:]]+$//' <<<"$1"; }
    n_ver="$(_norm "$version")"
    n_pkg="$(_norm "$pkg_version")"
    n_src="$(_norm "$src_version")"
    if [[ -n "$n_ver" && -n "$n_pkg" && "$n_ver" != "$n_pkg" ]]; then
        echo -e "                ${CLR_YELLOW}WARNING:${CLR_RST} loaded .ko ($n_ver) != installed package ($n_pkg) -- reload the module to pick up the installed build."
        has_error=1
    fi
    if [[ -n "$n_ver" && -n "$n_src" && "$n_ver" != "$n_src" ]]; then
        echo -e "                ${CLR_YELLOW}WARNING:${CLR_RST} loaded .ko ($n_ver) != source on disk ($n_src) -- rebuild + reload to pick up the source bump."
        has_error=1
    fi

    # srcversion identifies the built artifact (kbuild hash). git_commit is
    # stamped at build time via MODULE_INFO(git_commit, ...) in xpci_main.c.
    # Both are surfaced via modinfo; print them in that order.
    srcversion="$(modinfo -F srcversion xpci 2>/dev/null || true)"
    if [[ -n "$srcversion" ]]; then
        echo "srcversion:     $srcversion"
    else
        echo "srcversion:     (unknown)"
    fi

    git_commit_id="$(modinfo -F git_commit xpci 2>/dev/null || true)"
    if [[ -n "$git_commit_id" ]]; then
        echo "git_commit:     $git_commit_id"
    else
        echo "git_commit:     (unknown)"
    fi

    ko_path=$(modinfo -F filename xpci 2>/dev/null)

    if [[ -n "$ko_path" && -f "$ko_path" ]]; then
        ts=$(stat -c '%Y' "$ko_path" 2>/dev/null) || ts=
        if [[ -n "$ts" ]]; then
            echo "build date:     $(date -d "@$ts" '+%Y-%m-%d %H:%M:%S')"
        else
            echo "build date:     (unknown)"
        fi
    else
        echo "(unknown — modinfo filename missing)"
    fi

    echo " "

    echo "--- XPCXD Running version ---"
    sudo ethtool -i xpcxd0 2>/dev/null | grep -vE '^(firmware-version|expansion-rom-version|bus-info|supports-statistics|supports-test|supports-eeprom-access|supports-register-dump|supports-priv-flags):'
else
    echo -e "${CLR_RED}ERROR:${CLR_RST} XPCI driver not loaded"
    exit_code=2
    has_error=1
fi

echo " "
echo "--- Latest XPCI dmesg info ---"
dmesg_last="$( (sudo dmesg 2>/dev/null || dmesg 2>/dev/null) | grep -Ei 'xpci|xpcxd' | tail -n 1 || true )"
if [[ -n "$dmesg_last" ]]; then
    echo "$dmesg_last"
    if echo "$dmesg_last" | grep -Eiq 'error|fail|warn|timeout|oops|panic'; then
        has_error=1
    fi
else
    echo "(no xpci/xpcxd messages found in dmesg)"
fi

echo " "
echo "--- XPCI Status ---"
if [[ "$driver_loaded" -eq 0 ]]; then
    echo -e "status: ${CLR_RED}not running${CLR_RST}"
elif [[ "$has_error" -eq 1 ]]; then
    echo -e "status: ${CLR_YELLOW}error${CLR_RST}"
else
    echo -e "status: ${CLR_GREEN}running${CLR_RST}"
fi
echo " "

exit $exit_code
