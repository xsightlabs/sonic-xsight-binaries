#!/usr/bin/env python3
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.



def extract_timestamp(line):
    parts = line.split()
    try:
        timestamp = parts[2].rstrip(":")  # Remove the trailing colon
        return float(timestamp)
    except (IndexError, ValueError):
        return None


def find_max_delta_with_pair(filename):
    timestamps = []
    lines = []

    # Read the trace-cmd report file
    with open(filename) as file:
        for line in file:
            ts = extract_timestamp(line)
            if ts is not None:
                timestamps.append(ts)
                lines.append(line.strip())  # Store the full line

    # Calculate deltas and track the maximum
    max_delta = 0
    max_pair = ("", "")

    for i in range(1, len(timestamps)):
        delta = timestamps[i] - timestamps[i - 1]
        if delta > max_delta:
            max_delta = delta
            max_pair = (lines[i - 1], lines[i])

    # Output the result
    if max_pair[0] and max_pair[1]:
        print(f"Maximum delta time: {max_delta:.6f} seconds\n")
        print("Entry 1:")
        print((max_pair[0]))
        print("\nEntry 2:")
        print((max_pair[1]))
    else:
        print("Not enough data to calculate delta.")


# Replace 'trace_cmd_report.txt' with the actual file name
find_max_delta_with_pair("trace_cmd_report.txt")
