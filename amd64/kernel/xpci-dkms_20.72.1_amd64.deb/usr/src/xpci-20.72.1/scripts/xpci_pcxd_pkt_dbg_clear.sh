# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

echo 2 > /sys/module/xpci/parameters/debug_level
echo 1 > /sys/module/xpci/parameters/pkt_trace

ethtool -s xpcxd0 msglvl tx_queued off
ethtool -s xpcxd0 msglvl pktdata off
ethtool -s xpcxd0 msglvl tx_done off
ethtool -s xpcxd0 msglvl rx_status off
