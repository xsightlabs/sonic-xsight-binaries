# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.

sudo sysctl -a | grep xpci
echo ' '
sudo ethtool --show-priv-flags xpcxd0
