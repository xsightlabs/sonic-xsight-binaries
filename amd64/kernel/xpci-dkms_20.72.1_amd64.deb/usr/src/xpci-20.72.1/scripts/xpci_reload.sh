#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
#
# Unload and load xpci (also invoked by cook_dkms.sh when run as install-reload).

set -euo pipefail

DIR=$(dirname "$(readlink -f "$0")")
LOAD_SCRIPT="$DIR/xpci_load.sh"

sudo rmmod xpci 2>/dev/null || true
if [ ! -f "$LOAD_SCRIPT" ]; then
	echo "ERROR: cannot find $LOAD_SCRIPT" >&2
	exit 1
fi

sudo bash "$LOAD_SCRIPT" -q
