// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver common definitions
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCXD_H_
#define XPCXD_H_

#include <asm/byteorder.h>
#include <linux/netdevice.h>
#include <linux/hrtimer.h>
#include "xpcxd_regs.h"
#include "xpcxd_dbg.h"
#include "xnetdev_common.h"

#ifndef __LITTLE_ENDIAN
#define __LITTLE_ENDIAN -1
#endif
#define __BYTE_ORDER __LITTLE_ENDIAN

typedef uint64_t xpcxd_ring_handle_t; /**< Type definition for XPCXD ring handle */

#define XPCXD_NETDEV_DRV_NAME "xpcxd_netdev" /**< Name of the XPCXD network device driver */

#define MAX_CFG_ITEM_LEN 32 /**< Maximum length of a configuration item */

#define XPCXD_NET_DEV_NAME_SIZE 64 /**< Size of the XPCXD network device name */
#define XPCXD_IF_NAME_SIZE 64 /**< Size of the XPCXD interface name */

#define XPCXD_DEFAULT_RING_SIZE 256 /**< Default size of the XPCXD ring */
#define XPCXD_MAX_RING_NUM 8 /**< Maximum number of XPCXD rings */
#define XPCXD_TX_SBM_RFL_MODE_DEFAULT 1
#define XPCXD_TX_CMP_RFL_MODE_DEFAULT 1
#define XPCXD_TX_COALES_MODE_DEFAULT 1
#define XPCXD_RX_COALES_MODE_DEFAULT 1

#define XPCXD_NO_LIMIT 0 /**< No limit value */

#define XPCXD_RING_DSC_BUFFERS 256 /**< Number of ring descriptor buffers */

#define XPCXD_HW_SHIM_SIZE 3 /**< Size of the hardware shim header */

#define XPCXD_NUM_OF_RSS_QUEUES 8 /**< Number of RSS queues */
#define XPCXD_RSS_SECRET_KEY_SIZE 40 /**< Size of the RSS secret key */

/**
 * @brief Netlink parameters to create PCXD netdev.
 * ip link add NAME type pcxd
 */
enum xpcxd_spec {
	IFLA_XPCXD_UNSPEC, /**< Unspecified parameter */
	IFLA_XPCXD_IF_CFG, /**< Interface configuration */
	IFLA_XPCXD_IF_OP, /**< Interface operation */
	IFLA_XPCXD_IF_NAME, /**< Interface name */
	IFLA_XPCXD_IF_STATE, /**< Interface state */
	IFLA_XPCXD_IF_MODE, /**< Interface mode */
	IFLA_XPCXD_CFG_NUM_OF_RINGS, /**< Number of rings in the configuration */
	IFLA_XPCXD_CFG_TX_RING_SIZE, /**< Transmit ring size in the configuration */
	IFLA_XPCXD_CFG_RX_RING_SIZE, /**< Receive ring size in the configuration */

	__IFLA_XPCXD_MAX
};
#define IFLA_XPCXD_MAX (__IFLA_XPCXD_MAX - 1) /**< Maximum value of xpcxd_spec */

/**
 * @brief Packet over PCI (PCXD) interface operations: ADD/DELETE/UPDATE
 */
enum xpcxd_if_op {
	XPCXD_IF_OP_UNKNOWN = 0, /**< Unknown interface operation */
	XPCXD_IF_OP_ADD = 1, /**< Add interface */
	XPCXD_IF_OP_UPDATE = 2, /**< Update interface */
	XPCXD_IF_OP_DEL = 3, /**< Delete interface */
	XPCXD_IF_OP_MAX = XPCXD_IF_OP_DEL /**< Maximum value of xpcxd_if_op */
};

/**
 * @brief Interface operational state
 */
enum xpcxd_if_state {
	XPCXD_IF_UNCHANGED, /**< Interface state unchanged */
	XPCXD_IF_UP, /**< Interface up */
	XPCXD_IF_DOWN /**< Interface down */
};

/**
 * @brief Interface mode
 */
enum xpcxd_mode {
	XPCXD_MODE_UNKNOWN, /**< Unknown mode */
	XPCXD_MODE_INIT, /**< Initialization mode */
	XPCXD_MODE_STOP, /**< Stop mode */
	XPCXD_MODE_RESUME, /**< Resume mode */
	XPCXD_MODE_SHUTDOWN /**< Shutdown mode */
};

#define XPCXD_NAPI_POLL_WEIGHT 8 /**< NAPI poll weight */

#define XPCXD_MAX_RING_SIZE 32768 /**< Maximum ring size */
#define XPCXD_NUM_TXD_PER_PKT 2 /**< Number of transmit descriptors per packet */
#define XPCXD_TX_STOP_THOLD XPCXD_NUM_TXD_PER_PKT /**< Transmit stop threshold */

/*
 * Pre-mapped Tx DMA buffer pool slot geometry.
 *
 * Sized at ring setup as:
 *
 *   slot_size = clamp(ALIGN(tx_buf_size, XPCXD_TX_POOL_SLOT_ALIGN),
 *                     XPCXD_TX_POOL_SLOT_MIN,
 *                     XPCXD_TX_POOL_SLOT_MAX)
 *
 * Rationale for a 4 KiB ceiling:
 *   - Default MTU is 10200 B (jumbo). With ring depth 1024, an MTU-
 *     sized slot would produce ~10 MiB/ring × 8 rings ≈ 80 MiB of
 *     persistently-mapped Tx buffers. On SWIOTLB systems (x86 without
 *     IOMMU / ARM bounce) that is > 32k slots - exceeds the default
 *     64 MiB swiotlb pool and starves per-packet dma_map_single(),
 *     producing "swiotlb buffer is full (sz: 256 bytes)" failures
 *     on the Tx hot path.
 *   - Typical stack Tx is either <= 1500 B (standard MTU) or small
 *     control / ACK traffic (64..256 B). A 4 KiB slot covers all of
 *     that with headroom; the infrequent jumbo packets fall through
 *     to the legacy dma_map_single() path (see xpcxd_xmit()), so
 *     they only consume SWIOTLB slots while the descriptor is in
 *     flight (map -> unmap on CMPL), not persistently.
 *
 * Policy:
 *   If ALIGN(tx_buf_size, ..) would exceed XPCXD_TX_POOL_SLOT_MAX,
 *   slot_size is capped at XPCXD_TX_POOL_SLOT_MAX and larger
 *   packets are routed to the legacy path per-packet. If the pool
 *   dma_alloc_coherent() itself fails (very large ring, low memory)
 *   xpcxd_ring_tx_pool_alloc() sets tx_pool.vaddr = NULL and the
 *   ring uses the legacy path for every packet.
 *
 * Memory footprint per ring = slot_size * ring_size. Examples:
 *   MTU 1500 / ring 1024 -> slot 1536 ->  1.5 MiB / ring
 *   MTU 9000 / ring 1024 -> slot 4096 ->  4.0 MiB / ring (jumbo -> legacy)
 *   MTU 10200/ ring 1024 -> slot 4096 ->  4.0 MiB / ring (jumbo -> legacy)
 * At 8 rings the default jumbo config peaks at 32 MiB total - fits
 * comfortably in a 64 MiB SWIOTLB without starving per-packet Tx
 * mappings or the RX page_pool (PP_FLAG_DMA_MAP).
 */
#define XPCXD_TX_POOL_SLOT_MIN   2048  /* floor: headers + shim */
#define XPCXD_TX_POOL_SLOT_MAX   4096  /* ceiling: SWIOTLB-safe; jumbo -> legacy dma_map_single() */
#define XPCXD_TX_POOL_SLOT_ALIGN XPCXD_ALIGNMENT_256 /* HW BD alignment requirement */

#define XPCXD_SKB_DATA_SIZE 1536 /**< Size of the SKB data */

#define RX_OFFSET xpcxd_loopback ? 0 : XSW_RX_SHIM_HDR_SIZE /**< Receive offset */
#define TX_OFFSET xpcxd_loopback ? 0 : XSW_TX_SHIM_HDR_SIZE /**< Transmit offset */

#define XPCXD_ALIGNMENT_64 64 /**< 64-byte alignment */
#define XPCXD_ALIGNMENT_256 256 /**< 256-byte alignment */
#define XPCXD_SKB_RX_HEADROOM SKB_DATA_ALIGN(/*NET_SKB_PAD + */ NET_IP_ALIGN) /**< SKB receive headroom */
#define XPCXD_SKB_SHINFO_SIZE (SKB_DATA_ALIGN(sizeof(struct skb_shared_info))) /**< Size of the SKB shared info */
#define XPCXD_SKB_TAIL_ROOM (XPCXD_SKB_SHINFO_SIZE) /**< SKB tail room */

#define XPCXD_FRAG_OFFSET (XPCXD_SKB_RX_HEADROOM) /**< Fragment offset */
#define XPCXD_FRAG_DATA_SIZE SKB_DATA_ALIGN(PAGE_SIZE - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM) /**< Fragment data size */

#define XPCXD_DEFAULT_MTU_SIZE 10200 /**< Default MTU size */
#define XPCXD_MAX_MTU_SIZE ((PAGE_SIZE * 4) - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM) /**< Maximum MTU size */

#define XPCXD_MAX_RX_BUF_SIZE (XPCXD_MAX_MTU_SIZE + XPCXD_SKB_RX_HEADROOM + XPCXD_SKB_TAIL_ROOM) /**< Maximum receive buffer size */

/**
 * @struct xpcxd_sw_desc
 * @brief Enumeration representing the state of a page in the xpcxd module.
 */
enum xpcxd_page_state {
	XPCXD_PAGE_INIT = 0, /**< Page initialization state */
	XPCXD_PAGE_FREE = 1, /**< Page free state */
	XPCXD_PAGE_ALLOCATED = 2, /**< Page allocated state */
	XPCXD_PAGE_PASSED_TO_STACK = 3 /**< Page passed to stack state */
};

struct xdp_frame;

/**
 * @struct xpcxd_sw_desc
 * @brief EStructure representing a software descriptor used in the xpcxd driver.
 */
/*
 * Layout note: fields are clustered by access pattern so each fastpath
 * (RX or TX) touches a single 64B line per slot.
 *
 *   RX hot prefix (rx_fill / rx_cmpl read+write): page, addr,
 *   page_state, prod_idx, dma_err. Two adjacent slots fit in one
 *   64B line on x86, so the existing prefetch(&sub.sw[next]) in
 *   xpcxd_rx_fill() warms two slots per fetch.
 *
 *   TX hot middle (xmit / tx_cmpl read+write): skb, sw_dma_addr,
 *   dma_len, plus the is_xdp flag clustered up next to dma_err so
 *   the bool fits the same line as the RX prefix without growing
 *   the slot. xpcxd_xmit() touches this line only; the previous
 *   layout split TX hot fields across two cache lines and dirtied
 *   the XDP-only line with `xpdf = NULL` on every non-XDP TX.
 *
 *   XDP cold tail (xdp_xmit / tx_cmpl XDP branch only): xdpf is the
 *   only field down here. Non-XDP TX and all RX never touch it,
 *   so the line stays out of cache for normal traffic.
 *
 *   usg_cnt is a debug counter; placed in the gap between the RX
 *   prefix and the TX block so neither hot path takes a write hit
 *   on it (only the dump/diag paths touch it).
 *
 * Field order is the only contract that matters here: callers
 * reference members by name, so this reorder is ABI-safe within
 * the module. Do not insert a hot field between two cold ones; it
 * defeats the cache-line packing.
 */

/**
 * Tx descriptor source: how a queued Tx descriptor got its payload, and
 * therefore how xpcxd_tx_cmpl() must reclaim it. Stored per-sw_desc.
 */
enum xpcxd_tx_src {
	XPCXD_TX_SRC_NONE      = 0, /* slot idle / consumed */
	/*
	 * Payload was memcpy'd into ring->tx_pool (pre-DMA-mapped). No
	 * dma_unmap, no skb to free - CMPL just accounts stats and advances.
	 */
	XPCXD_TX_SRC_POOL      = 1,
	/*
	 * Legacy path: skb->data was dma_map_single'd; sw_dma_addr / dma_len
	 * valid. CMPL must dma_unmap_single() and dev_kfree_skb() the sw_desc->skb.
	 */
	XPCXD_TX_SRC_MAPPED    = 2,
	/*
	 * XDP redirect path: xdpf was dma_map_single'd. CMPL must
	 * dma_unmap_single() and xdp_return_frame(sw_desc->xdpf).
	 */
	XPCXD_TX_SRC_XDP       = 3,
};

struct xpcxd_sw_desc {
	/* --- RX fastpath (xpcxd_rx_fill, xpcxd_rx_cmpl) --- */
	struct page *page; /**< Page pointer (RX hot) */
	dma_addr_t addr; /**< DMA address (RX hot) */
	enum xpcxd_page_state page_state; /**< Page state (RX hot) */
	u32 prod_idx; /**< Producer index (RX hot) */
	bool dma_err; /**< DMA error flag (RX/TX cold-ish; kept here so the alloc-error tail in rx_fill stays in the hot line) */
	bool is_xdp; /**< True if this descriptor holds an XDP frame (xdpf valid) — clustered with dma_err so non-XDP TX doesn't touch the xdpf line */
	u8 tx_src; /**< enum xpcxd_tx_src; how CMPL must reclaim this Tx descriptor */

	/* --- Cold: debug counter (touched only on dump/diag paths) --- */
	u32 usg_cnt; /**< Descriptor usage count */

	/* --- TX hot (xpcxd_xmit, xpcxd_tx_cmpl) --- */
	struct sk_buff *skb; /**< SKB pointer (TX, XPCXD_TX_SRC_MAPPED only) */
	DEFINE_DMA_UNMAP_ADDR(sw_dma_addr); /**< DMA unmap address (TX, MAPPED/XDP only) */
	DEFINE_DMA_UNMAP_LEN(dma_len); /**< DMA length (TX: unmap len for MAPPED/XDP; byte count for POOL stats) */

	/* --- XDP-only cold tail; only touched when is_xdp == true --- */
	struct xdp_frame *xdpf; /**< XDP frame for XDP redirect Tx completion */
};

/**
 * @struct xpcxd_submit_ring
 * @brief Represents a submit ring for the XPCXD driver.
 *
 * TX producer hot fields (prod, sub_cns_ptr, size, mask, desc, sw)
 * sit at the head and fit on the producer-hot cache line in the
 * outer xpcxd_ring layout; cons is consumer-side (written by
 * xpcxd_tx_cmpl on a different CPU under mq + XPS) and is kept
 * later so producer ++/== never pulls it. The previously declared
 * sub_cns_ptr_prev field was unused — removed to avoid future
 * landings on this hot line.
 */
struct xpcxd_submit_ring {
	struct xpcxd_desc *desc; /**< Submit and completion descriptors */
	struct xpcxd_sw_desc *sw; /**< Software descriptors */
	u16 size; /**< Ring size */
	u16 mask; /**< Mask */
	u16 prod; /**< Producer index */
	u16 sub_cns_ptr; /**< Submission consumer pointer (cached HW cns) */
	u16 cons; /**< Consumer index (cmpl-side; cross-CPU vs producer) */
	struct xpcxd_doorbell *db; /**< Doorbell */
	dma_addr_t dma_addr; /**< DMA address */
	size_t dma_size; /**< DMA size */
	struct xpcxd_atomic_fifo_ctrl *rfl_cns; /**< Receive FIFO control */
	dma_addr_t rfl_cns_dma_addr; /**< DMA address of receive FIFO control */
	size_t rfl_cns_dma_size; /**< DMA size of receive FIFO control */
};

/**
 * @struct xpcxd_tx_pool
 * @brief Pre-mapped Tx DMA buffer pool (one per Tx ring).
 *
 * At ring setup we allocate a single contiguous dma_alloc_coherent()
 * region sliced into @nslots fixed-size, naturally-aligned slots. On
 * xmit we memcpy skb->data into the slot indexed by the descriptor's
 * producer position and use the precomputed DMA address in the BD,
 * skipping dma_map_single()/dma_unmap_single() and the 256-byte
 * realignment via netdev_alloc_skb()+skb_copy_from_linear_data() for
 * the vast majority of packets.
 *
 * Packets whose length exceeds @slot_size (e.g. jumbo > 2 KB) fall back
 * to the legacy dma_map_single() path for that packet only.
 */
struct xpcxd_tx_pool {
	void          *vaddr;      /**< CPU-visible base of the pool */
	dma_addr_t     daddr;      /**< DMA base of the pool */
	u32            slot_size;  /**< Per-slot buffer size, 256-byte aligned */
	u32            nslots;     /**< Number of slots (== sub.size) */
	size_t         alloc_size; /**< slot_size * nslots, for dma_free_coherent() */
};

/**
 * @struct xpcxd_compl_ring
 * @brief Structure representing a completion ring in the xpcxd driver.
 */
struct xpcxd_compl_ring {
	struct xpcxd_desc *desc; /**< Completion descriptors */
	dma_addr_t dma_addr; /**< DMA address */
	size_t dma_size; /**< DMA size */
	struct xpcxd_atomic_fifo_ctrl *rfl_prd; /**< Receive FIFO control */
	dma_addr_t rfl_prd_dma_addr; /**< DMA address of receive FIFO control */
	size_t rfl_prd_dma_size; /**< DMA size of receive FIFO control */
	u16 size; /**< Ring size */
	u16 mask; /**< Mask */
	u16 cons; /**< Consumer index */
	u16 cmpl_prd_ptr; /**< Completion production pointer */
	u16 cmpl_prd_ptr_prev; /**< Previous completion production pointer */
	u32 round_cnt; /**< Round count */
};

/**
 * @struct xpcxd_stats
 * @brief Structure representing statistics for the XPCXD driver.
 *
 * Layout is split into three cache-line-isolated regions so that
 * the producer (xmit), the IRQ handler, and the NAPI poll do not
 * cause MESI ping-pong on shared cache lines:
 *
 *   1. TX-producer-hot block at the head — written from xpcxd_xmit()
 *      / xpcxd_xdp_xmit_frame() under txr->tx_lock, on the producer
 *      CPU (typically pinned by XPS). Aggregated lock-free into
 *      rtnl_link_stats64 by xpcxd_get_stats64().
 *
 *   2. IRQ-CPU-hot block (____cacheline_aligned) — written by the
 *      MSI-X handler (cmpl_irq_cnt, cmpl_irq_last_jiffy, int_enabled
 *      false) and by the NAPI tail (int_enabled true). Holds also
 *      diag fields (prev_packets, rx_prev_jiffy, ...) that the
 *      time-ISR / service task touches. Isolating this block keeps
 *      the IRQ-CPU's writes off the producer's hot line.
 *
 *   3. RX NAPI-hot block (____cacheline_aligned) — all rx_* counters
 *      and the per-poll diagnostic histograms; written only from the
 *      NAPI poll on the cmpl-CPU.
 *
 * The pre-split layout interleaved producer-CPU writes
 * (dropped, tx_unicast, tx_sub_threshold, ...) with IRQ-CPU writes
 * (cmpl_irq_cnt, int_enabled) and NAPI-CPU writes (rx_*) on the same
 * cache lines — every xmit / IRQ / NAPI iteration could ping the
 * other CPU's L1.
 */
struct xpcxd_stats {
	/* ===== TX producer-CPU hot (xmit / xdp_xmit) ===== */
	u64 packets; /**< Number of packets (TX on TX rings, RX on RX rings) */
	u64 bytes; /**< Number of bytes */
	u64 errors; /**< Number of errors */
	u64 dropped; /**< Number of dropped packets */
	u64 fifo_errors; /**< Number of FIFO errors */
	u64 tx_multicast; /**< Number of transmitted multicast packets */
	u64 tx_broadcast; /**< Number of transmitted broadcast packets */
	u64 tx_unicast; /**< Number of transmitted unicast packets */
	u64 tx_vlan_packets; /**< Number of transmitted VLAN packets */
	u64 tx_sub_threshold; /**< Number of transmit sub-threshold events */
	u64 tx_alignment_error; /**< Number of transmit alignment errors */
	u64 tx_underflow_events; /**< Number of transmit underflow events */
	u64 tx_xdp_packets; /**< Number of packets transmitted via XDP redirect */
	u64 tx_xdp_bytes; /**< Number of bytes transmitted via XDP redirect */
	u64 tx_cmpl_threshold; /**< Number of transmit completion threshold events */
	/**
	 * Number of SKBs that were not 256B aligned on entry to
	 * xpcxd_xmit() and had to be replaced with a newly allocated,
	 * 256B-aligned SKB (payload memcpy + free of the original).
	 * High values indicate the upper stack is handing us badly
	 * aligned buffers; each occurrence pays alloc + memcpy + free.
	 */
	u64 tx_skb_realigned_256b;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	/**
	 * TX packet size histogram (bytes, skb->len at xmit).
	 * Buckets:
	 *   [64,128)  - small (e.g. ACKs, keepalives, control)
	 *   [128,256) - medium-small (typical control / VoIP)
	 *   [256,  ]  - everything else, up to jumbo
	 * Packets < 64B are rare (pre-padded by stack to ETH_ZLEN=60,
	 * and padded to ETH_ZLEN by xpcxd_xmit()); they fall into the
	 * 64..128 bucket after pad.
	 */
	u64 tx_pkt_size_64_128;
	u64 tx_pkt_size_128_256;
	u64 tx_pkt_size_256_plus;
#endif /* __XPCXD_TX_PKT_SIZE_HISTOGRAM__ */
	unsigned long xmit_prev_jiffy; /**< Previous transmit jiffy */

	/* ===== IRQ-CPU writes ===== */
	/** Aligned to keep IRQ-handler writes off the producer's last hot line. */
	u32 cmpl_irq_cnt ____cacheline_aligned; /**< Completion IRQ count */
	u32 prev_cmpl_irq_cnt; /**< Previous completion IRQ count */
	u32 prev_packets; /**< Previous packet count (service task) */
	/** Max jiffies between consecutive Rx CMPL MSIX entries for this ring (since last ring stats reset) */
	u32 rx_cmpl_irq_max_delta_jiffies;
	unsigned long cmpl_irq_last_jiffy; /**< jiffies when this ring's CMPL MSIX handler last ran */
	unsigned long cmpl_prev_jiffy; /**< Previous completion jiffy */
	unsigned long rx_prev_jiffy; /**< Previous receive jiffy (timer / service path) */
	bool int_enabled; /**< Interrupt enabled flag */

	/* ===== RX NAPI-CPU hot ===== */
	u64 rx_multicast ____cacheline_aligned; /**< Number of received multicast packets */
	u64 rx_broadcast; /**< Number of received broadcast packets */
	u64 rx_unicast; /**< Number of received unicast packets */
	u64 rx_vlan_packets; /**< Number of received VLAN packets (not supported yet) */
	u64 rx_drop_events; /**< Number of receive drop events */
	u64 rx_underflow_events; /**< Number of receive underflow events */
	u64 hw_csum_rx_error; /**< Number of hardware checksum receive errors */
	u64 rx_l3_csm_err; /**< Number of receive L3 checksum errors */
	u64 rx_l4_csm_err; /**< Number of receive L4 checksum errors */
	u64 rx_sub_threshold; /**< Number of receive sub-threshold events */
	/** Rx refill: capped by pcxd_rx_sub_reserve_pct / pcxd_rx_fill_max_desc (carried in rx_credits) */
	u64 rx_sub_refill_throttle;
	/** Rx refill: 0 SUB descriptors doorbelled (no free SUB slots — ring full from driver view) */
	u64 rx_sub_ring_starve_no_db;
	/** Refill-osc idle path: rx_fill primed SUB (true empty: posted==returned, not full-wrap) */
	u64 rx_osc_empty_sub_prime;
	u64 rx_cmpl_threshold; /**< Number of receive completion threshold events */
	u64 rx_sw_sub_posted_hw; /**< Cumulative submit SW descriptors doorbelled to HW */
	u64 rx_sw_cmpl_returned; /**< Cumulative submit SW descriptors released via CMPL path */
	/** HW CMPL ring still full (RFL credits 0): avoided napi_complete so softirq keeps draining (no new MSI-X) */
	u64 rx_cmpl_full_napi_held;
	/** RFL: avoided napi_complete when credits were low-but-nonzero after draining (tunable hold) */
	u64 rx_cmpl_low_hw_napi_held;
	/** Rx rx_credits trimmed by pcxd_rx_credits_slash_pct when SUB free
	 *  slots fall below pcxd_rx_sub_low_free_pct of the ring (anti-osc).
	 */
	u64 rx_credits_slash;
	/** Rx rx_credits stepped toward rx_credits_cap (SUB has headroom) */
	u64 rx_credits_restore;
	u64 rx_page_alloc_err; /**< Number of receive page allocation errors */
	u64 rx_dma_get_err; /**< Number of receive DMA get errors */
	u64 rx_wrong_page_state; /**< Number of receive wrong page state events */
	u64 rx_swdesc_err; /**< Number of receive software descriptor errors */
	u64 rx_page_err; /**< Receive page pointer errors */
	u64 rx_state_err; /**< Receive page state errors */
	u64 rx_page_state_les_then_free_err; /**< Number of receive page state less than free errors */
	u64 rx_swdesc_addr_err; /**< Number of receive software descriptor address errors */
	u64 rx_free_ref_cnt_0_page; /**< Number of times we attempted to release a page with ref count == 0 */
	u64 rx_mtu_exceeded; /**< Number of packets dropped due to exceeding MTU */
	/** Outer Eth SA octets [3..5] non-zero when stamp path expected them zero */
	u64 rx_outer_sa_tail_nonzero;
	/** Rx path aborted / NAPI stopped: explicit teardown or unrecoverable resource errors */
	u64 rx_stop_drop_all; /**< Stopped by rx_drop_all (teardown or error injection) */
	u64 rx_stop_packets_stop; /**< Stopped by xpcxd_rx_packets_stop */
	u64 rx_stop_build_skb; /**< napi_build_skb/build_skb failed; NAPI completes */
	u64 rx_stop_add_frag_failed; /**< Multi-page xpcxd_add_fragments failed; packet dropped */
	u64 rx_fill_sw_desc_null; /**< rx_fill: null sw_desc (bug); fill aborted */
	u64 rx_fill_fatal_oom; /**< rx_fill: page alloc failed at init (db_write=0); global rx_drop_all */
	u64 rx_stop_dbg_rx_abort; /**< __DEBUG__: dbg path stopped NAPI (bad page state / page ref / dbg sw_desc) */
#ifdef __XPCXD_RX_PKT_SIZE_HISTOGRAM__
	/** RX packet size histogram (bytes): 0-255, 256-511, 512-1023, 1024-4095, 4096-8191, >8192 */
	u64 rx_pkt_size_0_255;
	u64 rx_pkt_size_256_511;
	u64 rx_pkt_size_512_1023;
	u64 rx_pkt_size_1024_4095;
	u64 rx_pkt_size_4096_8191;
	u64 rx_pkt_size_8192_plus;
#endif /* __XPCXD_RX_PKT_SIZE_HISTOGRAM__ */
	/** Last xpcxd_rx_db_write() count (descriptors) in most recent rx_fill or rx_db_init that doorbelled */
	u32 rx_last_db_desc_cnt;
	/**
	 * Last 3 xpcxd_rx_cmpl() polls: CMPL ring slots consumed (k) per poll.
	 * [0] = newest, [1] = previous, [2] = oldest. Rx only; cleared with ring stats.
	 */
	u16 rx_cmpl_poll_hist[3];
	/**
	 * Jiffies from previous xpcxd_rx_cmpl() return to this call's entry, parallel to
	 * rx_cmpl_poll_hist[]. [0] = newest, [1] / [2] = older. 0 if no prior poll since reset.
	 */
	u32 rx_cmpl_poll_hist_delta_jiffies[3];
	/** jiffies when last xpcxd_rx_cmpl() finished (hist update); used for delta above */
	unsigned long rx_cmpl_poll_prev_jiffy;
};

/**
 * @enum xpcxd_ring_type
 * @brief Enumeration for the types of XPCXD rings.
 */
enum xpcxd_ring_type {
	XPCXD_RING_RX = 1, /**< Receive ring */
	XPCXD_RING_TX = 2, /**< Transmit ring */
};

/**
 * @struct xpcxd_ring
 * @brief Structure representing an XPCXD ring.
 *
 * Layout note: cache-line clusters by access pattern.
 *
 *   Producer-hot prefix — every xpcxd_xmit() touches: tx_lock,
 *   sub.{prod, sub_cns_ptr, size, mask, desc, sw, rfl_cns},
 *   db_count, queue, ring_id, type, xd. Packed at the head so
 *   the producer fetches the single hot line per packet.
 *
 *   Completion / NAPI / IRQ region — cmp ring and napi struct
 *   are ____cacheline_aligned to keep IRQ-CPU writes (cmp pointer
 *   updates, napi state) off the producer's hot line.
 *
 *   Stats — ____cacheline_aligned; xpcxd_stats itself is split
 *   internally into producer / IRQ / RX-NAPI cache-line-isolated
 *   sub-blocks (see comment on struct xpcxd_stats).
 *
 *   Cold tail — hrtimers, restart flags, RX refill bookkeeping;
 *   never touched on the steady-state per-packet path.
 */
struct xpcxd_ring {
	/* ===== Producer hot (xpcxd_xmit / TX path) ===== */
	spinlock_t tx_lock; /**< Spinlock for transmit operations */
	struct xpcxd_submit_ring sub; /**< Submission ring (prod/sub_cns_ptr hot) */
	u16 db_count; /**< Doorbell count (++ per xmit, == 0 on db) */
	/**
	 * Descriptors published to the ring (sub.prod advanced) but not yet
	 * doorbelled. Carried across xpcxd_xmit() calls so a single DB can
	 * cover a stack-batch signalled via netdev_xmit_more().
	 * Updated/read under tx_lock; flushed by xpcxd_tx_db_flush_locked().
	 */
	u16 sub_desc_pending;
	/**
	 * Pre-mapped Tx DMA buffer pool. Populated by xpcxd_ring_setup() for
	 * TX rings only; tx_pool.vaddr == NULL means "pool disabled, always
	 * use dma_map_single() legacy path".
	 */
	struct xpcxd_tx_pool tx_pool;
	struct netdev_queue *queue; /**< Network device queue (NOLOCK qdisc batch) */
	u32 ring_id; /**< Ring ID */
	enum xpcxd_ring_type type; /**< Type of the ring */
	struct xpcxd_priv *xd; /**< Back-pointer to xpcxd_priv (used in RX trace helpers) */

	/* ===== Completion / NAPI hot (separate cache line) ===== */
	struct xpcxd_compl_ring cmp ____cacheline_aligned; /**< Completion ring */
	struct napi_struct napi ____cacheline_aligned; /**< NAPI structure */
	u16 cmpl_thold; /**< Completion threshold */
	struct page_pool *page_pool; /**< Page pool (RX completion side) */

	/* ===== Stats (internally cache-line split for producer / IRQ / NAPI) ===== */
	struct u64_stats_sync syncp; /**< Synchronization point for statistics (RX path) */
	struct xpcxd_stats stats ____cacheline_aligned; /**< Statistics per ring */

	/* ===== Cold tail: timers, restart flags, RX refill bookkeeping ===== */
	struct hrtimer time_isr; /**< Timer for interrupt service routine */
	struct hrtimer tx_coales_isr; /**< Timer for transmit coalescing interrupt service routine */
	struct hrtimer rx_refill_osc_timer; /**< Rx: one-shot 2 ms NAPI kick when rx_credits still hold deferred refill */
	bool tx_rx_enabled; /**< Flag indicating if transmit/receive is enabled */
	/** Refill-osc vs CMPL MSI-X: streak when cmpl_irq_cnt unchanged since last tick; >10 mutes traces */
	u8 rx_refill_osc_irq_streak;
	u32 rx_refill_osc_irq_snap; /**< stats.cmpl_irq_cnt snapshot at last osc tick / arm */
	unsigned long rx_refill_osc_last_arm_jiffy; /**< throttle osc arms (module param) */
	/* Credits are calculated as delta between rx_fill budget and actual number of BDs that we succseeded to fill */
	/* Those credits will be used on next rx_fill as an addition to the budget */
	u32 rx_credits;
	/** Deferred refill target after last accounting (merge / rx_fill partial). Restore creeps rx_credits toward this when SUB has room; slash does not lower cap. */
	u32 rx_credits_cap;
	/* Descriptors filled in last rx_fill when doorbell was deferred (open path); consumed by rx_db_init */
	u16 rx_last_fill_cnt;
	/** Last jiffies SUB-full/no-CMPL idle stall netdev_warn (NAPI repoll can hit this every ~µs) */
	unsigned long rx_sub_stall_warn_jiffy;
	/** Last jiffies rx_cmpl_low_hw opt-trace / dbg (same NAPI hold can repoll at line rate) */
	unsigned long rx_cmpl_low_hw_trace_jiffy;
};

/**
 * @enum xpcxd_device_state
 * @brief Enumeration for the states of the XPCXD device.
 */
enum xpcxd_device_state {
	XPCXD_FLAG_DEV_ADMIN_RDY, /**< Device is administratively ready */
	XPCXD_FLAG_DEV_INIT, /**< Device is being initialized */
	XPCXD_FLAG_DEV_FAILED, /**< Device initialization failed */
	XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, /**< Device restart is in progress */
	XPCXD_FLAG_DEV_DEAD /**< Device is dead */
};

/**
 * @enum xpcxd_rss_mode
 * @brief Enumeration for the RSS (Receive Side Scaling) modes of the XPCXD device.
 */
enum xpcxd_rss_mode {
	XPCXD_RSS_MODE_EXPLICIT = 0, /**< Explicit mode */
	XPCXD_RSS_MODE_HASH_INDEX = 1, /**< Hash index mode */
	XPCXD_RSS_MODE_RSS_GROUP_ID = 2, /**< RSS group ID mode */
	XPCXD_RSS_MODE_FULL = 3 /**< Full mode (QID converted to RSS group ID) */
};

/**
 * @struct xpcxd_priv
 * @brief Structure representing the private data of the xpcxd driver.
 */
struct xpcxd_priv {
	struct net_device *netdev; /**< Pointer to the network device structure */
	struct device *hw_dev; /**< Pointer to the hardware device structure */

	union {
		u8 mac[6]; /**< MAC address */
		u64 mac_addr; /**< MAC address as a 64-bit integer */
	};
	bool up_state; /**< Flag indicating if the device is up */
	bool oper_status; /**< Flag indicating the operational status of the device */

	u16 num_rings; /**< Number of rings */

	u8 num_rx_queues; /**< Number of receive queues */
	u8 num_tx_queues; /**< Number of transmit queues */

	struct xpcxd_ring rxr[XPCXD_MAX_RING_NUM]; /**< Array of receive rings */
	struct xpcxd_ring txr[XPCXD_MAX_RING_NUM]; /**< Array of transmit rings */

	struct u64_stats_sync syncp; /**< Synchronization structure for 64-bit statistics */
	struct xpcxd_stats stats; /**< Statistics for the xpcxd driver */
	struct rtnl_link_stats64 stats64; /**< Accumulated statistics per interface */

	struct workqueue_struct *wq; /**< Workqueue structure for handling tasks */
	struct work_struct service_task; /**< Work structure for the service task */
	void __iomem *regs; /**< Pointer to the device registers */
	struct xpcxd_doorbell *rx_db; /**< Pointer to the receive doorbell */
	struct xpcxd_doorbell *tx_db; /**< Pointer to the transmit doorbell */
	unsigned long dev_flags; /**< Flags for device configuration */
	u16 num_rx_desc; /**< Number of receive descriptors */
	u16 num_tx_desc; /**< Number of transmit descriptors */
	int irq; /**< Interrupt number */

#define XPCXD_FLAG_DUMP_TX_STAT			(u32)(1 << 0)	/* Dump all Tx related counters */
#define XPCXD_FLAG_DUMP_RX_STAT			(u32)(1 << 1)	/* Dump all Rx related counters*/
#define XPCXD_FLAG_CLEAR_TX_STAT		(u32)(1 << 2)	/* Clear all Tx related counters */
#define XPCXD_FLAG_CLEAR_RX_STAT		(u32)(1 << 3)	/* Clear all Rx related counters*/
#define XPCXD_FLAG_ENABLE_TX_ERR_INT	(u32)(1 << 4)	/* Enable Tx error interrupt */
#define XPCXD_FLAG_ENABLE_RX_ERR_INT	(u32)(1 << 5)	/* Enable Rx error interrupt */
#define XPCXD_FLAG_DUMP_RX_DESC_STATUS		(u32)(1 << 6)	/* Dump Rx descriptor/ring status on demand */
#define XPCXD_FLAG_DUMP_TX_DESC_STATUS		(u32)(1 << 7)	/* Dump Tx descriptor/ring status on demand */
#define XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW	(u32)(1 << 8)	/* Apply rx_cmpl_napi_hold_low_hw_credits % of CMPL ring as low-credit thresh */
#ifdef __XPCXD_DEBUG__CT__
#define XPCXD_FLAG_STOP_ON_NEXT_TX		(u32)(1 << 9)	/* Raise trigger and stop all Tx/Rx on next Tx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_RX		(u32)(1 << 10)	/* Raise trigger and stop all Tx/Rx on next Rx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_ISR		(u32)(1 << 11)	/* Raise trigger and stop on next timer isr */
#define XPCXD_FLAG_DROP_ALL_TX			(u32)(1 << 12)	/* Set drop before sending to NIC for all Tx packets */
#define XPCXD_FLAG_DROP_ALL_RX			(u32)(1 << 13)	/* Set drop before receiving from NIC for all Rx packets */
#define XPCXD_FLAG_IGNORE_RX_L3_CHKSUM	(u32)(1 << 14)	/* Ignore error print and count on L3 checksum error */
#define XPCXD_FLAG_IGNORE_RX_L4_CHKSUM	(u32)(1 << 15)	/* Ignore error print and count on L4 checksum error */
#define XPCXD_FLAG_STOP_ON_RX_THRESHOLD	(u32)(1 << 16)	/* Stop on ring space threshold */
#define XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR	(u32)(1 << 17)	/* Drop badly aligned Tx packets */
#else
#define XPCXD_FLAG_STOP_ON_NEXT_TX		(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_STOP_ON_NEXT_RX		(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_STOP_ON_NEXT_ISR		(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_DROP_ALL_TX			(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_DROP_ALL_RX			(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_IGNORE_RX_L3_CHKSUM	(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_IGNORE_RX_L4_CHKSUM	(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_STOP_ON_RX_THRESHOLD	(u32)0	/* Debug-only private flag */
#define XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR	(u32)0	/* Debug-only private flag */
#endif
#ifdef __XPCXD_DEBUG__CT__
#define XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM	(u32)(1 << 18)	/* Drop Tx LLDP packets unless outer ethertype is XSW_SHIM_HEADER_ETHTYPE_EGRESS/INJECT */
#define XPCXD_FLAG_DROP_TX_MLD_NON_SHIM		(u32)(1 << 19)	/* Drop Tx IPv6 MLD packets unless outer ethertype is XSW_SHIM_HEADER_ETHTYPE_EGRESS/INJECT */
#else
#define XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM	(u32)(1 << 9)	/* Drop Tx LLDP packets unless outer ethertype is XSW_SHIM_HEADER_ETHTYPE_EGRESS/INJECT */
#define XPCXD_FLAG_DROP_TX_MLD_NON_SHIM		(u32)(1 << 10)	/* Drop Tx IPv6 MLD packets unless outer ethertype is XSW_SHIM_HEADER_ETHTYPE_EGRESS/INJECT */
#endif
#ifdef __XPCXD_CMD_TRACES__
#ifdef __XPCXD_DEBUG__CT__
#define XPCXD_FLAG_EVENT_TRACE			(u32)(1 << 20)	/* Gate xpcxd_opt_trace (pcxd_event_trace); keep last to avoid shifting other flags */
#else
#define XPCXD_FLAG_EVENT_TRACE			(u32)(1 << 11)	/* Gate xpcxd_opt_trace (pcxd_event_trace); keep last visible flag */
#endif
#endif

	u32 priv_flags; /**< Private flags */

	u32 rx_buf_size; /**< Size of the receive buffer */
	u32 tx_buf_size; /**< Size of the transmit buffer */
};

extern int xpcxd_rx_sub_low_free_pct; /* module param pcxd_rx_sub_low_free_pct */

/*
 * Module-param-backed: returns the slash trigger threshold as a percent
 * of the SUB ring depth. Zero is the documented disable signal — both
 * slash arms (xpcxd_rx_credits_adjust_for_sub_free() dispatcher and the
 * post-cap retry in xpcxd_rx_cmpl()) treat 0 as "no anti-oscillation
 * damping" and skip xpcxd_rx_credits_apply_slash() entirely. Out-of-range
 * inputs (< 0 or > 100) fall back to 15 to guard against operator typos
 * silently disabling the feature.
 */
static inline u32 xpcxd_rx_sub_low_free_thresh_pct(void)
{
	int v = READ_ONCE(xpcxd_rx_sub_low_free_pct);

	if (v == 0)
		return 0U;
	if (v < 0 || v > 100)
		return 15U;
	return (u32)v;
}

/**
 * @brief RSS Qid Table structure
 */
struct xpcxd_rss_qid_tbl {
	u8 group_base;
	u8 group_size;
};

/** 
 * @brief Spare register write values 
 */
typedef enum {
	g_cnt_init_done = 0x1,
	g_cnt_if_up = 0x2,
	g_cnt_packet_tx = 0x4,
	g_cnt_packet_rx_fill = 0x8,
	g_cnt_tx_stop = 0x10,
} dbg_cnt_t;

/**
 * @brief Enumeration of configuration items for XPCXD.
 */
typedef enum {
	xpcxd_tx_coales_size = 0, /**< Number of packets in a Tx batch */
	xpcxd_tx_coales_time = 1, /**< Time in X2 cycles for Tx coalescing */
	xpcxd_rx_coales_size = 2, /**< Number of packets in an Rx batch */
	xpcxd_rx_coales_time = 3, /**< Time in X2 cycles for Rx coalescing */
	xpcxd_int_enable = 4, /**< Interrupt enable flag */

	xpcxd_rx_drop_all = 5, /**< Drop all received packets flag */
	xpcxd_tx_drop_all = 6, /**< Drop all transmitted packets flag */
	xpcxd_tx_checksum_bypass = 7, /**< Bypass Tx checksum calculation flag */
	xpcxd_rx_checksum_bypass = 8, /**< Bypass Rx checksum verification flag */
	xpcxd_check_l3_checksum = 9, /**< Check L3 checksum flag */
	xpcxd_check_l4_checksum = 10, /**< Check L4 checksum flag */
	xpcxd_rx_shaper = 11, /**< Rx shaper configuration */
	xpcxd_enable_tx_err_int = 12, /**< Enable Tx error interrupt flag */
	xpcxd_enable_rx_err_int = 13, /**< Enable Rx error interrupt flag */
	xpcxd_event_trace = 14, /**< Event trace configuration */

	xpcxd_last_cfg_item = xpcxd_event_trace + 1 /**< Last configuration item */
} xpcxd_config_item_t;

/**
 * @brief Enumeration representing the bypass modes for xpcxd.
 */
enum xpcxd_bypass_mode {
	xpcxd_no_bypass = 0,            /**< No bypass mode */
	xpcxd_selective_bypass = 1,     /**< Selective bypass mode */
	xpcxd_global_bypass = 2         /**< Global bypass mode */
};

/**
 * Initializes the xpcxd driver.
 *
 * @param _pxdev A pointer to the device structure.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_init(void *_pxdev);

/**
 * Closes the xpcxd driver.
 *
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_close(void);

/**
 * Registers a network device with the xpcxd driver.
 *
 * @param if_name The name of the network interface.
 * @param do_rtnl_lock Whether to acquire the rtnl lock.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_register_netdev(char *if_name, bool do_rtnl_lock);

/**
 * Unregisters a network device from the xpcxd driver.
 *
 * @param netdev The network device to unregister.
 * @param do_rtnl_lock Whether to acquire the rtnl lock.
 */
void xpcxd_unregister_netdev(struct net_device *netdev, bool do_rtnl_lock);

/**
 * Initializes the hardware for the xpcxd driver.
 *
 * @param num_of_rings The number of rings to initialize.
 * @param tx_ring_size The size of the transmit ring.
 * @param rx_ring_size The size of the receive ring.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_hw_init(u32 num_of_rings, u16 tx_ring_size, u16 rx_ring_size);

/**
 * Optionally enable threaded NAPI before netif_napi_add(): dev_set_threaded() on
 * kernel < 6.17, netif_threaded_enable() on 6.17+. Caller must supply any required
 * rtnl/netdev locking for the active kernel; this helper does not lock.
 */
void xpcxd_netif_init_threaded_napi(struct net_device *netdev);

/**
 * Activates or deactivates the hardware for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate the hardware.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_hw_activate(bool activate);

/**
 * Registers the network link with the rtnetlink subsystem.
 *
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rtnl_link_register(void);

/**
 * Unregisters the network link from the rtnetlink subsystem.
 */
void xpcxd_rtnl_link_unregister(void);

/**
 * Sets the state of the network interface.
 *
 * @param netdev The network device.
 * @param status The desired state of the interface.
 * @param carrier_state The desired carrier state of the interface.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_set_if_state(struct net_device *netdev, bool status, bool carrier_state);

/**
 * Sets the ethtool operations for the network device.
 *
 * @param netdev The network device.
 */
void xpcxd_set_ethtool_ops(struct net_device *netdev);

/**
 * Gets the available space in the transmit sub-ring.
 *
 * @param ring The transmit ring.
 * @return The available space in the sub-ring.
 */
u32 xpcxd_get_tx_sub_ring_space(struct xpcxd_ring *ring);

/**
 * Gets the available space in the receive sub-ring.
 *
 * @param ring The receive ring.
 * @return The available space in the sub-ring.
 */
u32 xpcxd_get_rx_sub_ring_space(struct xpcxd_ring *ring);

/**
 * Gets the available space in the completion ring.
 *
 * @param ring The completion ring.
 * @return The available space in the ring.
 */
u32 xpcxd_get_cmpl_ring_space(struct xpcxd_ring *ring);

/**
 * Dump Rx descriptor/ring status for all Rx rings (on-demand via ethtool private flag).
 *
 * @param netdev The network device.
 * @return 0 on success.
 */
int xpcxd_rx_desc_status_dump(struct net_device *netdev);

/**
 * Dump Tx descriptor/ring status for all Tx rings (on-demand via ethtool private flag).
 *
 * @param netdev The network device.
 * @return 0 on success.
 */
int xpcxd_tx_desc_status_dump(struct net_device *netdev);

/**
 * Disables receive processing for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to disable.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_rx_disable(struct net_device *netdev, u32 ring_id);

/**
 * Activates or deactivates receive processing for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate receive processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_activate(bool activate);

/**
 * Activates or deactivates transmit processing for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate transmit processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_activate(bool activate);

/**
 * Disables transmit processing for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to disable.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_tx_disable(struct net_device *netdev, u32 ring_id);

/**
 * Enables receive processing for the network device.
 *
 * @param netdev The network device.
 * @param rx_activate Whether to activate receive processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_rx_enable(struct net_device *netdev, bool rx_activate);

/**
 * Enables transmit processing for the network device.
 *
 * @param netdev The network device.
 * @param tx_activate Whether to activate transmit processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_tx_enable(struct net_device *netdev, bool tx_activate);

/**
 * Writes the RSS hash key for the xpcxd driver.
 */
void xpcxd_rss_hash_key_write(void);

/**
 * Clears the transmit statistics registers for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_clear_regs(struct net_device *netdev);

/**
 * Clears the transmit statistics for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to clear the statistics for.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id);

/**
 * Dumps the short transmit statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_dump_short(struct net_device *netdev);

/**
 * Dumps the transmit statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_dump(struct net_device *netdev);

/**
 * Clears the receive statistics registers for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_clear_regs(struct net_device *netdev);

/**
 * Clears the receive statistics for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to clear the statistics for.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id);

/**
 * Dumps the short receive statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_dump_short(struct net_device *netdev);

/**
 * Dumps the receive statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_dump(struct net_device *netdev);

/**
 * Dump per-ring driver statistics (RX then TX for each active ring).
 * Counters that ethtool -S lists once in the aggregate prefix (netdev stats plus
 * the same global xpcxd names: unicast/multicast/broadcast, vlan, drop_events,
 * etc.) are omitted from this per-ring listing.
 */
int xpcxd_ring_stats_dump_per_ring(struct net_device *netdev);

/**
 * Aligns the skb buffer to the specified alignment.
 *
 * @param skb The skb buffer to align.
 * @param align The alignment value.
 */
void xpcxd_skb_align(struct sk_buff *skb, int align);

/**
 * Gets the 64-bit statistics for the network device.
 *
 * @param netdev The network device.
 * @param stats The structure to store the statistics.
 */
void xpcxd_get_stats64(struct net_device *netdev, struct rtnl_link_stats64 *stats);

/**
 * Transmits an skb buffer through the network device.
 *
 * @param skb The skb buffer to transmit.
 * @param netdev The network device.
 * @return The transmission status.
 */
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev);

#if IS_ENABLED(CONFIG_BPF_SYSCALL)
int xpcxd_xdp_xmit(struct net_device *netdev, int n, struct xdp_frame **frames, u32 flags);
#endif

/**
 * Gets the underflow count for receive processing.
 *
 * @return The underflow count.
 */
int xpcxd_rx_get_underflow_cnt(void);

/**
 * Gets the underflow count for transmit processing.
 *
 * @return The underflow count.
 */
int xpcxd_tx_get_underflow_cnt(void);

/**
 * Interrupt service routine for the transmit coalescing timer.
 *
 * @param timer The hrtimer structure.
 * @return The hrtimer restart value.
 */
enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer);

/**
 * Increment packet statistics for the given ring.
 *
 * Called only from the TX hot path (xpcxd_xmit / xpcxd_xdp_xmit_frame)
 * under txr->tx_lock, so the producer is the only writer. Readers
 * (xpcxd_get_stats64) are 64-bit-atomic on supported archs and tolerate
 * a one-poll skew on 32-bit. The previous u64_stats_update_begin/end
 * pair imposed an unnecessary seqcount fence on every TX packet.
 *
 * @param ring The xpcxd_ring structure representing the ring.
 * @param len The length of the packet.
 */
static inline void xpcxd_pkt_stats_inc(struct xpcxd_ring *ring, u32 len)
{
	ring->stats.packets++;
	ring->stats.bytes += len;
}

#if __has_include(<net/page_pool.h>)
#include <net/page_pool.h>
#define __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
#else
#include <net/page_pool/types.h>
#include <net/page_pool/helpers.h>
#endif

#ifdef __XPCXD_PAGE_POOL_PERF__

/**
 * Create a page pool with the given parameters.
 *
 * @param params The parameters for creating the page pool.
 * @return The created page pool.
 */
static inline struct page_pool *xpcxd_page_pool_create(const struct page_pool_params *params)
{
	return page_pool_create(params);
}

/**
 * Allocate pages from the device-specific page pool.
 *
 * @param pool The page pool from which to allocate pages.
 * @return The allocated page.
 */
static inline struct page *xpcxd_page_pool_dev_alloc_pages(struct page_pool *pool)
{
	return page_pool_dev_alloc_pages(pool);
}

/**
 * Get the DMA address of the given page.
 *
 * @param page The page for which to get the DMA address.
 * @return The DMA address of the page.
 */
static inline dma_addr_t xpcxd_page_pool_get_dma_addr(struct page *page)
{
	// xpcxd_trace_printk("page_pool_get_dma_addr: %lu", page_to_pfn(page));
	return page_pool_get_dma_addr(page);
}

/**
 * Recycle a page directly to the page pool.
 *
 * @param pool The page pool to which the page should be recycled.
 * @param page The page to be recycled.
 */
static inline int xpcxd_page_pool_recycle_direct(struct page_pool *pool, struct page *page)
{
	// xpcxd_trace_printk("page_pool_recycle_direct: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_recycle_direct(pool, page);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt: page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

/**
 * Put a full page into the page pool.
 *
 * @param pool The page pool to which the page should be put.
 * @param page The page to be put.
 * @param allow_direct Whether direct recycling is allowed.
 */
static inline int xpcxd_page_pool_put_full_page(struct page_pool *pool,
				      struct page *page, bool allow_direct)
{
	// xpcxd_trace_printk("page_pool_put_full_page: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_put_full_page(pool, page, allow_direct);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt on page_pool_put_full_page(): page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

/**
 * Release a page back to the page pool.
 *
 * @param pool The page pool to which the page should be released.
 * @param page The page to be released.
 * @return 0 on success, or a non-zero error code on failure.
 */
static inline int xpcxd_page_pool_release_page(struct page_pool *pool,
				      struct page *page)
{
	// xpcxd_trace_printk("page_pool_put_full_page: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
#ifdef __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
		page_pool_release_page(pool, page);
#else
		page_pool_put_full_page(pool, page, false);
#endif
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt on page_pool_release_page(): page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

#else
#define xpcxd_page_pool_create page_pool_create
#define xpcxd_page_pool_dev_alloc_pages page_pool_dev_alloc_pages
#define xpcxd_page_pool_get_dma_addr page_pool_get_dma_addr
// #define xpcxd_page_pool_recycle_direct page_pool_recycle_direct
#define xpcxd_page_pool_put_full_page page_pool_put_full_page
#ifdef __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
#define xpcxd_page_pool_release_page(pool, page) page_pool_release_page(pool, page)
#else
#define xpcxd_page_pool_release_page(pool, page) page_pool_put_full_page(pool, page, false)
#endif

/**
 * Recycle a page directly to the page pool.
 *
 * @param pool The page pool to which the page should be recycled.
 * @param page The page to be recycled.
 */
static inline int xpcxd_page_pool_recycle_direct(struct page_pool *pool, struct page *page)
{
	// xpcxd_trace_printk("page_pool_recycle_direct: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_recycle_direct(pool, page);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt: page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

#endif

/*
 * Gated tracepoints: expand to xpcxd_trace() (declared in xpci_trace.h).
 * Translation units that call xpcxd_opt_trace must include xpci_trace.h before
 * this header (see xpcxd_main.c / xpcxd_tx.c / xpcxd_dbg.c).
 */
extern uint xpcxd_cfg_tbl[];

#ifdef __XPCXD_CMD_TRACES__
#define xpcxd_opt_trace(...)						\
	do {								\
		if (xpcxd_cfg_tbl[xpcxd_event_trace])			\
			xpcxd_trace(__VA_ARGS__);			\
	} while (0)
#else
#define xpcxd_opt_trace(...) ((void)0)
#endif

#endif /* XPCXD_H_ */
