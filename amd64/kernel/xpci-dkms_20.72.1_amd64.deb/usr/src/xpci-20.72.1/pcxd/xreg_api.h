/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Unified PCXD register headers for the kernel driver:
 *   - xreg_dynamic.h — enum xreg_id, per-silicon layout, xreg_read/write, field helpers
 *   - generated/xreg_field_indices_x2.h — XREG_FIELD_<reg>_<field>, XREG_NC_<reg> (generated)
 *   - generated/xreg_chip_consts_x2.h — block addr, memcfg MSEL tables (generated from chip DB header)
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 * Regenerate: make gen-xreg (XREG_GEN_HEADER=xreg_x3.h for another silicon DB file).
 */

#ifndef XREG_API_H_
#define XREG_API_H_

#include "xreg_dynamic.h"
#include "generated/xreg_field_indices_x2.h"
#include "generated/xreg_chip_consts_x2.h"

static inline const struct xreg_desc *xreg_desc(enum xreg_id id)
{
	const struct xreg_profile *p = xreg_get_profile();

	if (!p || (unsigned int)id >= p->count) {
		xpci_err("xreg_desc: invalid profile/id (id=%u)", (unsigned int)id);
		return NULL;
	}
	return &p->table[id];
}

static inline u32 xreg_desc_bytes(enum xreg_id id)
{
	const struct xreg_desc *d = xreg_desc(id);
	const struct xreg_profile *p = xreg_get_profile();

	if (d)
		return d->reg_size_bytes;
	/* Profile may be set later during probe; keep width sane meanwhile. */
	if (!p)
		p = &xreg_profile_x2;
	if ((unsigned int)id < p->count)
		return p->table[id].reg_size_bytes;
	xpci_err("xreg_desc_bytes: invalid id=%u; fallback to 8 bytes",
		 (unsigned int)id);
	return 8U;
}

#endif /* XREG_API_H_ */
