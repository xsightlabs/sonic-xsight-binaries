// SPDX-License-Identifier: GPL-2.0

/*
 * Dynamic register access using per-silicon layouts (generated from the chip xreg_*.h).
 *
 * Copyright (c) Xsight Labs Ltd.
 */

#include "xreg_dynamic.h"
#include "xpci_common.h"
#include <linux/atomic.h>
#include <linux/compiler.h>
#include <linux/errno.h>

static const struct xreg_profile *xreg_cur_profile;
static atomic_t xreg_profile_users = ATOMIC_INIT(0);

int xreg_set_profile(const struct xreg_profile *p)
{
	const struct xreg_profile *cur;

	if (!p)
		return -EINVAL;

	cur = READ_ONCE(xreg_cur_profile);
	if (!cur) {
		WRITE_ONCE(xreg_cur_profile, p);
		cur = p;
	}

	if (cur != p)
		return -EOPNOTSUPP;

	atomic_inc(&xreg_profile_users);
	return 0;
}

void xreg_put_profile(const struct xreg_profile *p)
{
	if (!p)
		return;

	if (READ_ONCE(xreg_cur_profile) != p)
		return;

	if (atomic_dec_if_positive(&xreg_profile_users) == 0)
		WRITE_ONCE(xreg_cur_profile, NULL);
}

const struct xreg_profile *xreg_get_profile(void)
{
	const struct xreg_profile *p = READ_ONCE(xreg_cur_profile);

	if (!p)
		return &xreg_profile_x2;
	return p;
}

u32 xreg_abs_off(const struct xreg_desc *d, unsigned int inst,
		 unsigned int reg_within_block)
{
	return d->base_addr + inst * d->block_stride_bytes +
	       reg_within_block * d->reg_size_bytes;
}

u32 xreg_addr(const struct xreg_profile *p, enum xreg_id id,
	      unsigned int inst, unsigned int reg_within_block)
{
	const struct xreg_desc *d;

	if (!p || id >= p->count) {
		xpci_err("xreg_addr: invalid profile/id (id=%u)", (unsigned int)id);
		return 0;
	}
	d = &p->table[id];
	if (d->flags & XREG_DESC_F_ABSENT)
		return 0;
	if (inst >= d->num_copies) {
		xpci_err("xreg_addr: instance out of range (id=%u inst=%u max=%u)",
			 (unsigned int)id, inst, d->num_copies);
		return 0;
	}
	return xreg_abs_off(d, inst, reg_within_block);
}

u64 xreg_read(const struct xreg_profile *p, enum xreg_id id,
	      unsigned int inst, unsigned int reg_within_block, bool log)
{
	const struct xreg_desc *d;
	u32 addr;
	const char *nm = NULL;

	if (!p || id >= p->count) {
		xpci_err("xreg_read: invalid profile/id (id=%u)", (unsigned int)id);
		return 0;
	}
	d = &p->table[id];
	if (d->flags & XREG_DESC_F_ABSENT)
		return 0;
	if (inst >= d->num_copies) {
		xpci_err("xreg_read: instance out of range (id=%u inst=%u max=%u)",
			 (unsigned int)id, inst, d->num_copies);
		return 0;
	}
	addr = xreg_abs_off(d, inst, reg_within_block);
	if (p->id_names && (unsigned int)id < p->count)
		nm = p->id_names[id];

	if (d->reg_size_bytes == 4)
		return (u64)xpci_readl_fast(addr);

	return xpci_read64(nm ? (char *)nm : "xreg", addr, log);
}

void xreg_write(const struct xreg_profile *p, enum xreg_id id,
		  unsigned int inst, unsigned int reg_within_block, u64 val)
{
	const struct xreg_desc *d;
	u32 addr;
	const char *nm = NULL;

	if (!p || id >= p->count) {
		xpci_err("xreg_write: invalid profile/id (id=%u)", (unsigned int)id);
		return;
	}
	d = &p->table[id];
	if (d->flags & XREG_DESC_F_ABSENT)
		return;
	if (inst >= d->num_copies) {
		xpci_err("xreg_write: instance out of range (id=%u inst=%u max=%u)",
			 (unsigned int)id, inst, d->num_copies);
		return;
	}
	addr = xreg_abs_off(d, inst, reg_within_block);
	if (p->id_names && (unsigned int)id < p->count)
		nm = p->id_names[id];

	if (d->reg_size_bytes == 4) {
		xpci_writel_fast(addr, (u32)val);
		return;
	}
	xpci_write64(nm ? (char *)nm : "xreg", addr, val);
}

u64 xreg_field_read_rm(const struct xreg_profile *p, enum xreg_id id,
			unsigned int inst, unsigned int reg_within_block,
			unsigned int field_idx, bool log)
{
	const struct xreg_desc *d;
	u64 v;

	if (!p || id >= p->count) {
		xpci_err("xreg_field_read_rm: invalid profile/id (id=%u)",
			 (unsigned int)id);
		return 0;
	}
	d = &p->table[id];
	if (d->flags & XREG_DESC_F_ABSENT)
		return 0;
	if (!d->fields || field_idx >= d->num_fields) {
		xpci_err("xreg_field_read_rm: invalid field index (id=%u idx=%u count=%u)",
			 (unsigned int)id, field_idx, d->num_fields);
		return 0;
	}
	v = xreg_read(p, id, inst, reg_within_block, log);
	return xreg_field_u64(v, &d->fields[field_idx]);
}

void xreg_field_write_rm(const struct xreg_profile *p, enum xreg_id id,
			 unsigned int inst, unsigned int reg_within_block,
			 unsigned int field_idx, u64 val)
{
	const struct xreg_desc *d;
	u64 v;

	if (!p || id >= p->count) {
		xpci_err("xreg_field_write_rm: invalid profile/id (id=%u)",
			 (unsigned int)id);
		return;
	}
	d = &p->table[id];
	if (d->flags & XREG_DESC_F_ABSENT)
		return;
	if (!d->fields || field_idx >= d->num_fields) {
		xpci_err("xreg_field_write_rm: invalid field index (id=%u idx=%u count=%u)",
			 (unsigned int)id, field_idx, d->num_fields);
		return;
	}
	v = xreg_read(p, id, inst, reg_within_block, false);
	xreg_field_put_u64(&v, &d->fields[field_idx], val);
	xreg_write(p, id, inst, reg_within_block, v);
}
