/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Indirect MEMCFG SRAM selector (MSEL) per enum xreg_id — declaration only.
 * Definition: generated/xreg_memcfg_msel_x2.c (avoids duplicate static inlines when
 * multiple silicon objects are linked).
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#ifndef XREG_MEMCFG_MSEL_MAP_X2_H_
#define XREG_MEMCFG_MSEL_MAP_X2_H_

#include <linux/types.h>

/*
 * Forward declaration only: do not include xreg_layout_ids_x2.h here — that would
 * redefine enum xreg_id when multiple layout tags are linked. Include the driver’s
 * canonical xreg_layout_ids_*.h before this header.
 */
enum xreg_id;

u32 xreg_memcfg_msel_x2(enum xreg_id id);

#endif /* XREG_MEMCFG_MSEL_MAP_X2_H_ */
