/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Auto-generated — do not edit.
 * Silicon profile: base
 * Address delta: 0x0
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#include <linux/types.h>
#include "generated/xreg_layout_ids_x3.h"

extern const char *const xreg_id_names_x3[XREG_ID__COUNT];
u32 xreg_memcfg_msel_x3(enum xreg_id id);

#define XREG_LAYOUT_BLOCK_STRIDE_DEFAULT (32768U)
#define XREG_LAYOUT_REG_SIZE_DEFAULT (8U)

static const struct xreg_field_desc xreg_fields_x3_0[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_1[] = {
	{ .lo = 0U, .width = 20U, ._pad = 0 },
	{ .lo = 31U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_2[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_3[] = {
	{ .lo = 0U, .width = 32U, ._pad = 0 },
	{ .lo = 40U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_4[] = {
	{ .lo = 15U, .width = 12U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_5[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
	{ .lo = 10U, .width = 10U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_6[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_7[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_8[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_9[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_10[] = {
	{ .lo = 0U, .width = 7U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_11[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_12[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 7U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 63U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_13[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_14[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_15[] = {
	{ .lo = 0U, .width = 7U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_16[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_17[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_18[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_19[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_20[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_21[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_22[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_23[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_24[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_25[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_26[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_27[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 4U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 4U, ._pad = 0 },
	{ .lo = 16U, .width = 4U, ._pad = 0 },
	{ .lo = 20U, .width = 4U, ._pad = 0 },
	{ .lo = 24U, .width = 4U, ._pad = 0 },
	{ .lo = 28U, .width = 4U, ._pad = 0 },
	{ .lo = 32U, .width = 4U, ._pad = 0 },
	{ .lo = 36U, .width = 4U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 4U, ._pad = 0 },
	{ .lo = 48U, .width = 4U, ._pad = 0 },
	{ .lo = 52U, .width = 4U, ._pad = 0 },
	{ .lo = 56U, .width = 4U, ._pad = 0 },
	{ .lo = 60U, .width = 4U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_28[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_29[] = {
	{ .lo = 0U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_30[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_31[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_32[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_33[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 2U, ._pad = 0 },
	{ .lo = 4U, .width = 3U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 6U, ._pad = 0 },
	{ .lo = 18U, .width = 6U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 2U, ._pad = 0 },
	{ .lo = 36U, .width = 3U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 6U, ._pad = 0 },
	{ .lo = 50U, .width = 6U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_34[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 2U, ._pad = 0 },
	{ .lo = 4U, .width = 3U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 6U, ._pad = 0 },
	{ .lo = 18U, .width = 6U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 2U, ._pad = 0 },
	{ .lo = 36U, .width = 3U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 6U, ._pad = 0 },
	{ .lo = 50U, .width = 6U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_35[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_36[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_37[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_38[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_39[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 6U, ._pad = 0 },
	{ .lo = 16U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 1U, ._pad = 0 },
	{ .lo = 35U, .width = 1U, ._pad = 0 },
	{ .lo = 36U, .width = 1U, ._pad = 0 },
	{ .lo = 37U, .width = 1U, ._pad = 0 },
	{ .lo = 38U, .width = 1U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 6U, ._pad = 0 },
	{ .lo = 48U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_40[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 6U, ._pad = 0 },
	{ .lo = 16U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 1U, ._pad = 0 },
	{ .lo = 35U, .width = 1U, ._pad = 0 },
	{ .lo = 36U, .width = 1U, ._pad = 0 },
	{ .lo = 37U, .width = 1U, ._pad = 0 },
	{ .lo = 38U, .width = 1U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 6U, ._pad = 0 },
	{ .lo = 48U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_41[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_42[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_43[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 16U, .width = 1U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 40U, .width = 1U, ._pad = 0 },
	{ .lo = 48U, .width = 2U, ._pad = 0 },
	{ .lo = 56U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_44[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_45[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_46[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 3U, ._pad = 0 },
	{ .lo = 4U, .width = 9U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_47[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_48[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_49[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 1U, ._pad = 0 },
	{ .lo = 10U, .width = 1U, ._pad = 0 },
	{ .lo = 11U, .width = 1U, ._pad = 0 },
	{ .lo = 12U, .width = 1U, ._pad = 0 },
	{ .lo = 13U, .width = 1U, ._pad = 0 },
	{ .lo = 14U, .width = 1U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_50[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_51[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_52[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_53[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
	{ .lo = 16U, .width = 8U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 8U, ._pad = 0 },
	{ .lo = 40U, .width = 8U, ._pad = 0 },
	{ .lo = 48U, .width = 8U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_54[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_55[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_56[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_57[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_58[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 5U, ._pad = 0 },
	{ .lo = 8U, .width = 3U, ._pad = 0 },
	{ .lo = 11U, .width = 5U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
	{ .lo = 19U, .width = 5U, ._pad = 0 },
	{ .lo = 24U, .width = 3U, ._pad = 0 },
	{ .lo = 27U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 3U, ._pad = 0 },
	{ .lo = 35U, .width = 5U, ._pad = 0 },
	{ .lo = 40U, .width = 3U, ._pad = 0 },
	{ .lo = 43U, .width = 5U, ._pad = 0 },
	{ .lo = 48U, .width = 3U, ._pad = 0 },
	{ .lo = 51U, .width = 5U, ._pad = 0 },
	{ .lo = 56U, .width = 3U, ._pad = 0 },
	{ .lo = 59U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_59[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 2U, ._pad = 0 },
	{ .lo = 5U, .width = 3U, ._pad = 0 },
	{ .lo = 8U, .width = 3U, ._pad = 0 },
	{ .lo = 11U, .width = 2U, ._pad = 0 },
	{ .lo = 13U, .width = 3U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
	{ .lo = 19U, .width = 2U, ._pad = 0 },
	{ .lo = 21U, .width = 3U, ._pad = 0 },
	{ .lo = 24U, .width = 3U, ._pad = 0 },
	{ .lo = 27U, .width = 2U, ._pad = 0 },
	{ .lo = 29U, .width = 3U, ._pad = 0 },
	{ .lo = 32U, .width = 3U, ._pad = 0 },
	{ .lo = 35U, .width = 2U, ._pad = 0 },
	{ .lo = 37U, .width = 3U, ._pad = 0 },
	{ .lo = 40U, .width = 3U, ._pad = 0 },
	{ .lo = 43U, .width = 2U, ._pad = 0 },
	{ .lo = 45U, .width = 3U, ._pad = 0 },
	{ .lo = 48U, .width = 3U, ._pad = 0 },
	{ .lo = 51U, .width = 2U, ._pad = 0 },
	{ .lo = 53U, .width = 3U, ._pad = 0 },
	{ .lo = 56U, .width = 3U, ._pad = 0 },
	{ .lo = 59U, .width = 2U, ._pad = 0 },
	{ .lo = 61U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_60[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_61[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_62[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_63[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_64[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_65[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_66[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_67[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_68[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_69[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_70[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_71[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_72[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 32U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_73[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_74[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_75[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_76[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_77[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_78[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_79[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_80[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_81[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_82[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
	{ .lo = 10U, .width = 3U, ._pad = 0 },
	{ .lo = 13U, .width = 3U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_83[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_84[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 3U, ._pad = 0 },
	{ .lo = 4U, .width = 9U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_85[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_86[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_87[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 1U, ._pad = 0 },
	{ .lo = 10U, .width = 1U, ._pad = 0 },
	{ .lo = 11U, .width = 1U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_88[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_89[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_90[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_91[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_92[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_93[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_94[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_95[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_96[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_97[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_98[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_99[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_100[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_101[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_102[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_103[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_104[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_105[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_106[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_107[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_108[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_116[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_117[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_118[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 1U, ._pad = 0 },
	{ .lo = 81U, .width = 1U, ._pad = 0 },
	{ .lo = 82U, .width = 1U, ._pad = 0 },
	{ .lo = 83U, .width = 1U, ._pad = 0 },
	{ .lo = 84U, .width = 1U, ._pad = 0 },
	{ .lo = 85U, .width = 1U, ._pad = 0 },
	{ .lo = 86U, .width = 4U, ._pad = 0 },
	{ .lo = 90U, .width = 16U, ._pad = 0 },
	{ .lo = 106U, .width = 1U, ._pad = 0 },
	{ .lo = 107U, .width = 2U, ._pad = 0 },
	{ .lo = 109U, .width = 1U, ._pad = 0 },
	{ .lo = 110U, .width = 1U, ._pad = 0 },
	{ .lo = 111U, .width = 1U, ._pad = 0 },
	{ .lo = 112U, .width = 8U, ._pad = 0 },
	{ .lo = 120U, .width = 1U, ._pad = 0 },
	{ .lo = 121U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_119[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_120[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 3U, ._pad = 0 },
	{ .lo = 6U, .width = 12U, ._pad = 0 },
	{ .lo = 18U, .width = 12U, ._pad = 0 },
	{ .lo = 30U, .width = 16U, ._pad = 0 },
	{ .lo = 46U, .width = 1U, ._pad = 0 },
	{ .lo = 47U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_121[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_122[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_123[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 16U, ._pad = 0 },
	{ .lo = 25U, .width = 1U, ._pad = 0 },
	{ .lo = 26U, .width = 1U, ._pad = 0 },
	{ .lo = 27U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_124[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 2U, ._pad = 0 },
	{ .lo = 18U, .width = 16U, ._pad = 0 },
	{ .lo = 34U, .width = 16U, ._pad = 0 },
	{ .lo = 50U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_125[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 16U, ._pad = 0 },
	{ .lo = 96U, .width = 16U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_126[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_127[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_128[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_129[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_130[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_131[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_132[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_133[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_134[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_135[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_136[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 8U, ._pad = 0 },
	{ .lo = 13U, .width = 2U, ._pad = 0 },
	{ .lo = 15U, .width = 8U, ._pad = 0 },
	{ .lo = 23U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_137[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_138[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_139[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 1U, ._pad = 0 },
	{ .lo = 81U, .width = 1U, ._pad = 0 },
	{ .lo = 82U, .width = 1U, ._pad = 0 },
	{ .lo = 83U, .width = 1U, ._pad = 0 },
	{ .lo = 84U, .width = 1U, ._pad = 0 },
	{ .lo = 85U, .width = 1U, ._pad = 0 },
	{ .lo = 86U, .width = 4U, ._pad = 0 },
	{ .lo = 90U, .width = 16U, ._pad = 0 },
	{ .lo = 106U, .width = 1U, ._pad = 0 },
	{ .lo = 107U, .width = 2U, ._pad = 0 },
	{ .lo = 109U, .width = 1U, ._pad = 0 },
	{ .lo = 110U, .width = 1U, ._pad = 0 },
	{ .lo = 111U, .width = 1U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 8U, ._pad = 0 },
	{ .lo = 121U, .width = 1U, ._pad = 0 },
	{ .lo = 122U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_140[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_141[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 3U, ._pad = 0 },
	{ .lo = 6U, .width = 12U, ._pad = 0 },
	{ .lo = 18U, .width = 12U, ._pad = 0 },
	{ .lo = 30U, .width = 16U, ._pad = 0 },
	{ .lo = 46U, .width = 1U, ._pad = 0 },
	{ .lo = 47U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_142[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_143[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_144[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_145[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_146[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 16U, ._pad = 0 },
	{ .lo = 25U, .width = 1U, ._pad = 0 },
	{ .lo = 26U, .width = 1U, ._pad = 0 },
	{ .lo = 27U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_147[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 2U, ._pad = 0 },
	{ .lo = 18U, .width = 16U, ._pad = 0 },
	{ .lo = 34U, .width = 16U, ._pad = 0 },
	{ .lo = 50U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_148[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 16U, ._pad = 0 },
	{ .lo = 96U, .width = 16U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_149[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_150[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_151[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_152[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_153[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_154[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_155[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_156[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_157[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_158[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_159[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x3_160[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

const struct xreg_desc xreg_layout_table_x3[XREG_ID__COUNT] = {
	{ .base_addr = 0x3d18288U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_0 },
	{ .base_addr = 0x3d18308U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000800fffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_1 },
	{ .base_addr = 0x3d18310U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_2 },
	{ .base_addr = 0x3d18318U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000100ffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_3 },
	{ .base_addr = 0x3d30000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000007ff8000ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_4 },
	{ .base_addr = 0x3d30c10U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_5 },
	{ .base_addr = 0x3d30c18U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_6 },
	{ .base_addr = 0x3d30460U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_7 },
	{ .base_addr = 0x3d30040U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_8 },
	{ .base_addr = 0x3d30078U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_9 },
	{ .base_addr = 0x3d30018U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000007fULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_10 },
	{ .base_addr = 0x3d30058U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_11 },
	{ .base_addr = 0x3d30028U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x8000ffff007fffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_12 },
	{ .base_addr = 0x3d30068U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_13 },
	{ .base_addr = 0x3d30020U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_14 },
	{ .base_addr = 0x3d30010U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000007fULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_15 },
	{ .base_addr = 0x3d30048U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_16 },
	{ .base_addr = 0x3d301c0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000037ULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_17 },
	{ .base_addr = 0x3d30420U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_18 },
	{ .base_addr = 0x3d30110U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ff03ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_19 },
	{ .base_addr = 0x3d30108U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ff03ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_20 },
	{ .base_addr = 0x3d30128U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_21 },
	{ .base_addr = 0x3d30118U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_22 },
	{ .base_addr = 0x3d30120U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000007ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_23 },
	{ .base_addr = 0x3d30170U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_24 },
	{ .base_addr = 0x3d30168U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_25 },
	{ .base_addr = 0x3d30180U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_26 },
	{ .base_addr = 0x3d30178U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 16U, ._pad2 = 0,
	  .fields = xreg_fields_x3_27 },
	{ .base_addr = 0x3d30190U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_28 },
	{ .base_addr = 0x3d30228U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_29 },
	{ .base_addr = 0x3d30240U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 8U, ._pad2 = 0,
	  .fields = xreg_fields_x3_30 },
	{ .base_addr = 0x3d30d30U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_31 },
	{ .base_addr = 0x3d30e30U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_32 },
	{ .base_addr = 0x3d30d08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x3_33 },
	{ .base_addr = 0x3d30e08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x3_34 },
	{ .base_addr = 0x3d30d20U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_35 },
	{ .base_addr = 0x3d30e20U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_36 },
	{ .base_addr = 0x3d30d10U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_37 },
	{ .base_addr = 0x3d30e10U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_38 },
	{ .base_addr = 0x3d30d00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x803f3fff803f3fffULL, .num_fields = 20U, ._pad2 = 0,
	  .fields = xreg_fields_x3_39 },
	{ .base_addr = 0x3d30e00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x803f3fff803f3fffULL, .num_fields = 20U, ._pad2 = 0,
	  .fields = xreg_fields_x3_40 },
	{ .base_addr = 0x3d30d40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_41 },
	{ .base_addr = 0x3d30e40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_42 },
	{ .base_addr = 0x3d30008U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x87fdff7fdff7fdffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x3_43 },
	{ .base_addr = 0x3d30440U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_44 },
	{ .base_addr = 0x3d30218U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_45 },
	{ .base_addr = 0x3d307a0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_46 },
	{ .base_addr = 0x3d307a8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_47 },
	{ .base_addr = 0x3d307b0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_48 },
	{ .base_addr = 0x3d30798U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 17U, ._pad2 = 0,
	  .fields = xreg_fields_x3_49 },
	{ .base_addr = 0x3d30208U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_50 },
	{ .base_addr = 0x3d30c20U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_51 },
	{ .base_addr = 0x3d30238U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_52 },
	{ .base_addr = 0x3d30400U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 8U, ._pad2 = 0,
	  .fields = xreg_fields_x3_53 },
	{ .base_addr = 0x3d302c0U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_54 },
	{ .base_addr = 0x3d30280U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_55 },
	{ .base_addr = 0x3d30470U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_56 },
	{ .base_addr = 0x3d303e8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_57 },
	{ .base_addr = 0x3d30300U, .num_copies = 16U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 16U, ._pad2 = 0,
	  .fields = xreg_fields_x3_58 },
	{ .base_addr = 0x3d30380U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 24U, ._pad2 = 0,
	  .fields = xreg_fields_x3_59 },
	{ .base_addr = 0x3d303c0U, .num_copies = 5U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_60 },
	{ .base_addr = 0x3d30c00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_61 },
	{ .base_addr = 0x3d30750U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_62 },
	{ .base_addr = 0x3d30728U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_63 },
	{ .base_addr = 0x3d30718U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_64 },
	{ .base_addr = 0x3d30720U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_65 },
	{ .base_addr = 0x3d30710U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_66 },
	{ .base_addr = 0x3d30748U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_67 },
	{ .base_addr = 0x3d30730U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_68 },
	{ .base_addr = 0x3d30738U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_69 },
	{ .base_addr = 0x3d30740U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_70 },
	{ .base_addr = 0x3d30778U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_71 },
	{ .base_addr = 0x3d30780U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_72 },
	{ .base_addr = 0x3d30788U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_73 },
	{ .base_addr = 0x3d30790U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_74 },
	{ .base_addr = 0x3d30700U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_75 },
	{ .base_addr = 0x3d30708U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_76 },
	{ .base_addr = 0x3d30768U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_77 },
	{ .base_addr = 0x3d30760U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_78 },
	{ .base_addr = 0x3d30770U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_79 },
	{ .base_addr = 0x3d30758U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_80 },
	{ .base_addr = 0x3d301f0U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_81 },
	{ .base_addr = 0x3d30450U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_82 },
	{ .base_addr = 0x3d30210U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_83 },
	{ .base_addr = 0x3d30bc0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_84 },
	{ .base_addr = 0x3d30bc8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_85 },
	{ .base_addr = 0x3d30bd0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_86 },
	{ .base_addr = 0x3d30bb8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 14U, ._pad2 = 0,
	  .fields = xreg_fields_x3_87 },
	{ .base_addr = 0x3d30200U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_88 },
	{ .base_addr = 0x3d30c28U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_89 },
	{ .base_addr = 0x3d30230U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_90 },
	{ .base_addr = 0x3d30480U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_91 },
	{ .base_addr = 0x3d30c08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_92 },
	{ .base_addr = 0x3d30b88U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_93 },
	{ .base_addr = 0x3d30b90U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_94 },
	{ .base_addr = 0x3d30b68U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_95 },
	{ .base_addr = 0x3d30b58U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_96 },
	{ .base_addr = 0x3d30b60U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_97 },
	{ .base_addr = 0x3d30b50U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_98 },
	{ .base_addr = 0x3d30b70U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_99 },
	{ .base_addr = 0x3d30b78U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_100 },
	{ .base_addr = 0x3d30b80U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_101 },
	{ .base_addr = 0x3d30b98U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_102 },
	{ .base_addr = 0x3d30ba0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_103 },
	{ .base_addr = 0x3d30ba8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_104 },
	{ .base_addr = 0x3d30bb0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x3_105 },
	{ .base_addr = 0x3d30b40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_106 },
	{ .base_addr = 0x3d30b48U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_107 },
	{ .base_addr = 0x3d303f0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x3_108 },
	{ .base_addr = 0x13d30002U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30004U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30005U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30001U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30006U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13d30003U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x23eb2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_116 },
	{ .base_addr = 0x23eb0000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_117 },
	{ .base_addr = 0x23eac000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x3_118 },
	{ .base_addr = 0x23eb1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_119 },
	{ .base_addr = 0x23eab000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 7U, ._pad2 = 0,
	  .fields = xreg_fields_x3_120 },
	{ .base_addr = 0x23ea9000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_121 },
	{ .base_addr = 0x23ead000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_122 },
	{ .base_addr = 0x23eae000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x3_123 },
	{ .base_addr = 0x23eaf000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_124 },
	{ .base_addr = 0x23eaa000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x3_125 },
	{ .base_addr = 0x23ec4000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_126 },
	{ .base_addr = 0x23ec2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_127 },
	{ .base_addr = 0x23ec3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_128 },
	{ .base_addr = 0x23ec7000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_129 },
	{ .base_addr = 0x23ec5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_130 },
	{ .base_addr = 0x23ec6000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_131 },
	{ .base_addr = 0x23ec8000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_132 },
	{ .base_addr = 0x23ebf000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_133 },
	{ .base_addr = 0x23ec0000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_134 },
	{ .base_addr = 0x23ec1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_135 },
	{ .base_addr = 0x23ed5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 9U, ._pad2 = 0,
	  .fields = xreg_fields_x3_136 },
	{ .base_addr = 0x23ebe000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_137 },
	{ .base_addr = 0x23eba000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_138 },
	{ .base_addr = 0x23eb6000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 19U, ._pad2 = 0,
	  .fields = xreg_fields_x3_139 },
	{ .base_addr = 0x23ebd000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_140 },
	{ .base_addr = 0x23eb5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 7U, ._pad2 = 0,
	  .fields = xreg_fields_x3_141 },
	{ .base_addr = 0x23eb3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_142 },
	{ .base_addr = 0x23ebb000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_143 },
	{ .base_addr = 0x23ebc000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_144 },
	{ .base_addr = 0x23eb7000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x3_145 },
	{ .base_addr = 0x23eb8000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x3_146 },
	{ .base_addr = 0x23eb9000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x3_147 },
	{ .base_addr = 0x23eb4000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x3_148 },
	{ .base_addr = 0x23ed4000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_149 },
	{ .base_addr = 0x23ecf000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_150 },
	{ .base_addr = 0x23ecd000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_151 },
	{ .base_addr = 0x23ece000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_152 },
	{ .base_addr = 0x23ecc000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_153 },
	{ .base_addr = 0x23ed2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_154 },
	{ .base_addr = 0x23ed0000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_155 },
	{ .base_addr = 0x23ed1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_156 },
	{ .base_addr = 0x23ed3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_157 },
	{ .base_addr = 0x23ec9000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_158 },
	{ .base_addr = 0x23eca000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_159 },
	{ .base_addr = 0x23ecb000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x3_160 },
};

const struct xreg_profile xreg_profile_x3 = {
	.name = "base",
	.table = xreg_layout_table_x3,
	.count = XREG_ID__COUNT,
	.memcfg_block_base = 0x23ea8000U,
	.id_names = xreg_id_names_x3,
	.memcfg_msel = xreg_memcfg_msel_x3,
};
