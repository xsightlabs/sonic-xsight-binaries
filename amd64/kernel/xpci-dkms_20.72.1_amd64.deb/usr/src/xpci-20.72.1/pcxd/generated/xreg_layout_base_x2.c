/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Auto-generated — do not edit.
 * Silicon profile: base
 * Address delta: 0x0
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#include <linux/types.h>
#include "generated/xreg_layout_ids_x2.h"

extern const char *const xreg_id_names_x2[XREG_ID__COUNT];
u32 xreg_memcfg_msel_x2(enum xreg_id id);

#define XREG_LAYOUT_BLOCK_STRIDE_DEFAULT (32768U)
#define XREG_LAYOUT_REG_SIZE_DEFAULT (8U)

static const struct xreg_field_desc xreg_fields_x2_0[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_1[] = {
	{ .lo = 0U, .width = 20U, ._pad = 0 },
	{ .lo = 31U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_2[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_3[] = {
	{ .lo = 0U, .width = 32U, ._pad = 0 },
	{ .lo = 40U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_4[] = {
	{ .lo = 15U, .width = 12U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_5[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
	{ .lo = 10U, .width = 10U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_6[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_7[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_8[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_9[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_10[] = {
	{ .lo = 0U, .width = 7U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_11[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_12[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 7U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 63U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_13[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_14[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_15[] = {
	{ .lo = 0U, .width = 7U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_16[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_17[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_18[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_19[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_20[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_21[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_22[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_23[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_24[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_25[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_26[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_27[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 4U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 4U, ._pad = 0 },
	{ .lo = 16U, .width = 4U, ._pad = 0 },
	{ .lo = 20U, .width = 4U, ._pad = 0 },
	{ .lo = 24U, .width = 4U, ._pad = 0 },
	{ .lo = 28U, .width = 4U, ._pad = 0 },
	{ .lo = 32U, .width = 4U, ._pad = 0 },
	{ .lo = 36U, .width = 4U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 4U, ._pad = 0 },
	{ .lo = 48U, .width = 4U, ._pad = 0 },
	{ .lo = 52U, .width = 4U, ._pad = 0 },
	{ .lo = 56U, .width = 4U, ._pad = 0 },
	{ .lo = 60U, .width = 4U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_28[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_29[] = {
	{ .lo = 0U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_30[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_31[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_32[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_33[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 2U, ._pad = 0 },
	{ .lo = 4U, .width = 3U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 6U, ._pad = 0 },
	{ .lo = 18U, .width = 6U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 2U, ._pad = 0 },
	{ .lo = 36U, .width = 3U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 6U, ._pad = 0 },
	{ .lo = 50U, .width = 6U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_34[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 2U, ._pad = 0 },
	{ .lo = 4U, .width = 3U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 4U, ._pad = 0 },
	{ .lo = 12U, .width = 6U, ._pad = 0 },
	{ .lo = 18U, .width = 6U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 2U, ._pad = 0 },
	{ .lo = 36U, .width = 3U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 4U, ._pad = 0 },
	{ .lo = 44U, .width = 6U, ._pad = 0 },
	{ .lo = 50U, .width = 6U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_35[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_36[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_37[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_38[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_39[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 6U, ._pad = 0 },
	{ .lo = 16U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 1U, ._pad = 0 },
	{ .lo = 35U, .width = 1U, ._pad = 0 },
	{ .lo = 36U, .width = 1U, ._pad = 0 },
	{ .lo = 37U, .width = 1U, ._pad = 0 },
	{ .lo = 38U, .width = 1U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 6U, ._pad = 0 },
	{ .lo = 48U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_40[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 6U, ._pad = 0 },
	{ .lo = 16U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 1U, ._pad = 0 },
	{ .lo = 33U, .width = 1U, ._pad = 0 },
	{ .lo = 34U, .width = 1U, ._pad = 0 },
	{ .lo = 35U, .width = 1U, ._pad = 0 },
	{ .lo = 36U, .width = 1U, ._pad = 0 },
	{ .lo = 37U, .width = 1U, ._pad = 0 },
	{ .lo = 38U, .width = 1U, ._pad = 0 },
	{ .lo = 39U, .width = 1U, ._pad = 0 },
	{ .lo = 40U, .width = 6U, ._pad = 0 },
	{ .lo = 48U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_41[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_42[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_43[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 16U, .width = 1U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 40U, .width = 1U, ._pad = 0 },
	{ .lo = 48U, .width = 2U, ._pad = 0 },
	{ .lo = 56U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_44[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_45[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_46[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 3U, ._pad = 0 },
	{ .lo = 4U, .width = 9U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_47[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_48[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_49[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 1U, ._pad = 0 },
	{ .lo = 10U, .width = 1U, ._pad = 0 },
	{ .lo = 11U, .width = 1U, ._pad = 0 },
	{ .lo = 12U, .width = 1U, ._pad = 0 },
	{ .lo = 13U, .width = 1U, ._pad = 0 },
	{ .lo = 14U, .width = 1U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_50[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_51[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_52[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_53[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 8U, ._pad = 0 },
	{ .lo = 16U, .width = 8U, ._pad = 0 },
	{ .lo = 24U, .width = 8U, ._pad = 0 },
	{ .lo = 32U, .width = 8U, ._pad = 0 },
	{ .lo = 40U, .width = 8U, ._pad = 0 },
	{ .lo = 48U, .width = 8U, ._pad = 0 },
	{ .lo = 56U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_54[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_55[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_56[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_57[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_58[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 5U, ._pad = 0 },
	{ .lo = 8U, .width = 3U, ._pad = 0 },
	{ .lo = 11U, .width = 5U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
	{ .lo = 19U, .width = 5U, ._pad = 0 },
	{ .lo = 24U, .width = 3U, ._pad = 0 },
	{ .lo = 27U, .width = 5U, ._pad = 0 },
	{ .lo = 32U, .width = 3U, ._pad = 0 },
	{ .lo = 35U, .width = 5U, ._pad = 0 },
	{ .lo = 40U, .width = 3U, ._pad = 0 },
	{ .lo = 43U, .width = 5U, ._pad = 0 },
	{ .lo = 48U, .width = 3U, ._pad = 0 },
	{ .lo = 51U, .width = 5U, ._pad = 0 },
	{ .lo = 56U, .width = 3U, ._pad = 0 },
	{ .lo = 59U, .width = 5U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_59[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 2U, ._pad = 0 },
	{ .lo = 5U, .width = 3U, ._pad = 0 },
	{ .lo = 8U, .width = 3U, ._pad = 0 },
	{ .lo = 11U, .width = 2U, ._pad = 0 },
	{ .lo = 13U, .width = 3U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
	{ .lo = 19U, .width = 2U, ._pad = 0 },
	{ .lo = 21U, .width = 3U, ._pad = 0 },
	{ .lo = 24U, .width = 3U, ._pad = 0 },
	{ .lo = 27U, .width = 2U, ._pad = 0 },
	{ .lo = 29U, .width = 3U, ._pad = 0 },
	{ .lo = 32U, .width = 3U, ._pad = 0 },
	{ .lo = 35U, .width = 2U, ._pad = 0 },
	{ .lo = 37U, .width = 3U, ._pad = 0 },
	{ .lo = 40U, .width = 3U, ._pad = 0 },
	{ .lo = 43U, .width = 2U, ._pad = 0 },
	{ .lo = 45U, .width = 3U, ._pad = 0 },
	{ .lo = 48U, .width = 3U, ._pad = 0 },
	{ .lo = 51U, .width = 2U, ._pad = 0 },
	{ .lo = 53U, .width = 3U, ._pad = 0 },
	{ .lo = 56U, .width = 3U, ._pad = 0 },
	{ .lo = 59U, .width = 2U, ._pad = 0 },
	{ .lo = 61U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_60[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_61[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_62[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_63[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_64[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_65[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_66[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_67[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_68[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_69[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_70[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_71[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_72[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 32U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_73[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_74[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_75[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_76[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_77[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_78[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_79[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_80[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_81[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_82[] = {
	{ .lo = 0U, .width = 10U, ._pad = 0 },
	{ .lo = 10U, .width = 3U, ._pad = 0 },
	{ .lo = 13U, .width = 3U, ._pad = 0 },
	{ .lo = 16U, .width = 3U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_83[] = {
	{ .lo = 0U, .width = 4U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_84[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 3U, ._pad = 0 },
	{ .lo = 4U, .width = 9U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_85[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_86[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_87[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 1U, ._pad = 0 },
	{ .lo = 6U, .width = 1U, ._pad = 0 },
	{ .lo = 7U, .width = 1U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 1U, ._pad = 0 },
	{ .lo = 10U, .width = 1U, ._pad = 0 },
	{ .lo = 11U, .width = 1U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_88[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_89[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_90[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_91[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_92[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_93[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_94[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_95[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_96[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_97[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_98[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_99[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_100[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_101[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_102[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_103[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_104[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_105[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
	{ .lo = 48U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_106[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_107[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_108[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 16U, ._pad = 0 },
	{ .lo = 32U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_116[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_117[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_118[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 1U, ._pad = 0 },
	{ .lo = 81U, .width = 1U, ._pad = 0 },
	{ .lo = 82U, .width = 1U, ._pad = 0 },
	{ .lo = 83U, .width = 1U, ._pad = 0 },
	{ .lo = 84U, .width = 1U, ._pad = 0 },
	{ .lo = 85U, .width = 1U, ._pad = 0 },
	{ .lo = 86U, .width = 4U, ._pad = 0 },
	{ .lo = 90U, .width = 16U, ._pad = 0 },
	{ .lo = 106U, .width = 1U, ._pad = 0 },
	{ .lo = 107U, .width = 2U, ._pad = 0 },
	{ .lo = 109U, .width = 1U, ._pad = 0 },
	{ .lo = 110U, .width = 1U, ._pad = 0 },
	{ .lo = 111U, .width = 1U, ._pad = 0 },
	{ .lo = 112U, .width = 8U, ._pad = 0 },
	{ .lo = 120U, .width = 1U, ._pad = 0 },
	{ .lo = 121U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_119[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_120[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 3U, ._pad = 0 },
	{ .lo = 6U, .width = 12U, ._pad = 0 },
	{ .lo = 18U, .width = 12U, ._pad = 0 },
	{ .lo = 30U, .width = 16U, ._pad = 0 },
	{ .lo = 46U, .width = 1U, ._pad = 0 },
	{ .lo = 47U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_121[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_122[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_123[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 16U, ._pad = 0 },
	{ .lo = 25U, .width = 1U, ._pad = 0 },
	{ .lo = 26U, .width = 1U, ._pad = 0 },
	{ .lo = 27U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_124[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 2U, ._pad = 0 },
	{ .lo = 18U, .width = 16U, ._pad = 0 },
	{ .lo = 34U, .width = 16U, ._pad = 0 },
	{ .lo = 50U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_125[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 16U, ._pad = 0 },
	{ .lo = 96U, .width = 16U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_126[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_127[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_128[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_129[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_130[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_131[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_132[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_133[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_134[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_135[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_136[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
	{ .lo = 1U, .width = 1U, ._pad = 0 },
	{ .lo = 2U, .width = 1U, ._pad = 0 },
	{ .lo = 3U, .width = 1U, ._pad = 0 },
	{ .lo = 4U, .width = 1U, ._pad = 0 },
	{ .lo = 5U, .width = 8U, ._pad = 0 },
	{ .lo = 13U, .width = 2U, ._pad = 0 },
	{ .lo = 15U, .width = 8U, ._pad = 0 },
	{ .lo = 23U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_137[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_138[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_139[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 1U, ._pad = 0 },
	{ .lo = 81U, .width = 1U, ._pad = 0 },
	{ .lo = 82U, .width = 1U, ._pad = 0 },
	{ .lo = 83U, .width = 1U, ._pad = 0 },
	{ .lo = 84U, .width = 1U, ._pad = 0 },
	{ .lo = 85U, .width = 1U, ._pad = 0 },
	{ .lo = 86U, .width = 4U, ._pad = 0 },
	{ .lo = 90U, .width = 16U, ._pad = 0 },
	{ .lo = 106U, .width = 1U, ._pad = 0 },
	{ .lo = 107U, .width = 2U, ._pad = 0 },
	{ .lo = 109U, .width = 1U, ._pad = 0 },
	{ .lo = 110U, .width = 1U, ._pad = 0 },
	{ .lo = 111U, .width = 1U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 8U, ._pad = 0 },
	{ .lo = 121U, .width = 1U, ._pad = 0 },
	{ .lo = 122U, .width = 2U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_140[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_141[] = {
	{ .lo = 0U, .width = 3U, ._pad = 0 },
	{ .lo = 3U, .width = 3U, ._pad = 0 },
	{ .lo = 6U, .width = 12U, ._pad = 0 },
	{ .lo = 18U, .width = 12U, ._pad = 0 },
	{ .lo = 30U, .width = 16U, ._pad = 0 },
	{ .lo = 46U, .width = 1U, ._pad = 0 },
	{ .lo = 47U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_142[] = {
	{ .lo = 0U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_143[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_144[] = {
	{ .lo = 0U, .width = 9U, ._pad = 0 },
	{ .lo = 9U, .width = 9U, ._pad = 0 },
	{ .lo = 18U, .width = 10U, ._pad = 0 },
	{ .lo = 28U, .width = 1U, ._pad = 0 },
	{ .lo = 29U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_145[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_146[] = {
	{ .lo = 0U, .width = 8U, ._pad = 0 },
	{ .lo = 8U, .width = 1U, ._pad = 0 },
	{ .lo = 9U, .width = 16U, ._pad = 0 },
	{ .lo = 25U, .width = 1U, ._pad = 0 },
	{ .lo = 26U, .width = 1U, ._pad = 0 },
	{ .lo = 27U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_147[] = {
	{ .lo = 0U, .width = 16U, ._pad = 0 },
	{ .lo = 16U, .width = 2U, ._pad = 0 },
	{ .lo = 18U, .width = 16U, ._pad = 0 },
	{ .lo = 34U, .width = 16U, ._pad = 0 },
	{ .lo = 50U, .width = 16U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_148[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
	{ .lo = 64U, .width = 16U, ._pad = 0 },
	{ .lo = 80U, .width = 16U, ._pad = 0 },
	{ .lo = 96U, .width = 16U, ._pad = 0 },
	{ .lo = 112U, .width = 1U, ._pad = 0 },
	{ .lo = 113U, .width = 1U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_149[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_150[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_151[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_152[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_153[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_154[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_155[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_156[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_157[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_158[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_159[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

static const struct xreg_field_desc xreg_fields_x2_160[] = {
	{ .lo = 0U, .width = 64U, ._pad = 0 },
};

const struct xreg_desc xreg_layout_table_x2[XREG_ID__COUNT] = {
	{ .base_addr = 0x3e90288U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_0 },
	{ .base_addr = 0x3e90308U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000800fffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_1 },
	{ .base_addr = 0x3e90310U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_2 },
	{ .base_addr = 0x3e90318U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000100ffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_3 },
	{ .base_addr = 0x3ea8000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000007ff8000ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_4 },
	{ .base_addr = 0x3ea8c10U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000fffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_5 },
	{ .base_addr = 0x3ea8c18U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_6 },
	{ .base_addr = 0x3ea8460U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000003ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_7 },
	{ .base_addr = 0x3ea8040U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_8 },
	{ .base_addr = 0x3ea8078U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_9 },
	{ .base_addr = 0x3ea8018U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000007fULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_10 },
	{ .base_addr = 0x3ea8058U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_11 },
	{ .base_addr = 0x3ea8028U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x8000ffff007fffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_12 },
	{ .base_addr = 0x3ea8068U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_13 },
	{ .base_addr = 0x3ea8020U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_14 },
	{ .base_addr = 0x3ea8010U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000007fULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_15 },
	{ .base_addr = 0x3ea8048U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_16 },
	{ .base_addr = 0x3ea81c0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000037ULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_17 },
	{ .base_addr = 0x3ea8420U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000001fULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_18 },
	{ .base_addr = 0x3ea8110U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ff03ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_19 },
	{ .base_addr = 0x3ea8108U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ff03ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_20 },
	{ .base_addr = 0x3ea8128U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_21 },
	{ .base_addr = 0x3ea8118U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_22 },
	{ .base_addr = 0x3ea8120U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000007ULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_23 },
	{ .base_addr = 0x3ea8170U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_24 },
	{ .base_addr = 0x3ea8168U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_25 },
	{ .base_addr = 0x3ea8180U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_26 },
	{ .base_addr = 0x3ea8178U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 16U, ._pad2 = 0,
	  .fields = xreg_fields_x2_27 },
	{ .base_addr = 0x3ea8190U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_28 },
	{ .base_addr = 0x3ea8228U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000003ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_29 },
	{ .base_addr = 0x3ea8240U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 8U, ._pad2 = 0,
	  .fields = xreg_fields_x2_30 },
	{ .base_addr = 0x3ea8d30U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_31 },
	{ .base_addr = 0x3ea8e30U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_32 },
	{ .base_addr = 0x3ea8d08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x2_33 },
	{ .base_addr = 0x3ea8e08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x2_34 },
	{ .base_addr = 0x3ea8d20U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_35 },
	{ .base_addr = 0x3ea8e20U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_36 },
	{ .base_addr = 0x3ea8d10U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_37 },
	{ .base_addr = 0x3ea8e10U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_38 },
	{ .base_addr = 0x3ea8d00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x001f3fff001f3fffULL, .num_fields = 20U, ._pad2 = 0,
	  .fields = xreg_fields_x2_39 },
	{ .base_addr = 0x3ea8e00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x001f3fff001f3fffULL, .num_fields = 20U, ._pad2 = 0,
	  .fields = xreg_fields_x2_40 },
	{ .base_addr = 0x3ea8d40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_41 },
	{ .base_addr = 0x3ea8e40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_42 },
	{ .base_addr = 0x3ea8008U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x01030100ff0100ffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x2_43 },
	{ .base_addr = 0x3ea8440U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000000fULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_44 },
	{ .base_addr = 0x3ea8218U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000001fffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_45 },
	{ .base_addr = 0x3ea87a0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000001fffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_46 },
	{ .base_addr = 0x3ea87a8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_47 },
	{ .base_addr = 0x3ea87b0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000003ULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_48 },
	{ .base_addr = 0x3ea8798U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000ffffffff7fffULL, .num_fields = 17U, ._pad2 = 0,
	  .fields = xreg_fields_x2_49 },
	{ .base_addr = 0x3ea8208U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_50 },
	{ .base_addr = 0x3ea8c20U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_51 },
	{ .base_addr = 0x3ea8238U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_52 },
	{ .base_addr = 0x3ea8400U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 8U, ._pad2 = 0,
	  .fields = xreg_fields_x2_53 },
	{ .base_addr = 0x3ea82c0U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_54 },
	{ .base_addr = 0x3ea8280U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000000ffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_55 },
	{ .base_addr = 0x3ea8470U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000003ULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_56 },
	{ .base_addr = 0x3ea83e8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000007ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_57 },
	{ .base_addr = 0x3ea8300U, .num_copies = 16U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 16U, ._pad2 = 0,
	  .fields = xreg_fields_x2_58 },
	{ .base_addr = 0x3ea8380U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 24U, ._pad2 = 0,
	  .fields = xreg_fields_x2_59 },
	{ .base_addr = 0x3ea83c0U, .num_copies = 5U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_60 },
	{ .base_addr = 0x3ea8c00U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_61 },
	{ .base_addr = 0x3ea8750U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_62 },
	{ .base_addr = 0x3ea8728U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_63 },
	{ .base_addr = 0x3ea8718U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_64 },
	{ .base_addr = 0x3ea8720U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_65 },
	{ .base_addr = 0x3ea8710U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_66 },
	{ .base_addr = 0x3ea8748U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_67 },
	{ .base_addr = 0x3ea8730U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_68 },
	{ .base_addr = 0x3ea8738U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_69 },
	{ .base_addr = 0x3ea8740U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_70 },
	{ .base_addr = 0x3ea8778U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_71 },
	{ .base_addr = 0x3ea8780U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_72 },
	{ .base_addr = 0x3ea8788U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_73 },
	{ .base_addr = 0x3ea8790U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_74 },
	{ .base_addr = 0x3ea8700U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_75 },
	{ .base_addr = 0x3ea8708U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_76 },
	{ .base_addr = 0x3ea8768U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_77 },
	{ .base_addr = 0x3ea8760U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_78 },
	{ .base_addr = 0x3ea8770U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_79 },
	{ .base_addr = 0x3ea8758U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_80 },
	{ .base_addr = 0x3ea81f0U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_81 },
	{ .base_addr = 0x3ea8450U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x000000000007ffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_82 },
	{ .base_addr = 0x3ea8210U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000001fffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_83 },
	{ .base_addr = 0x3ea8bc0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000001fffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_84 },
	{ .base_addr = 0x3ea8bc8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_85 },
	{ .base_addr = 0x3ea8bd0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000003ULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_86 },
	{ .base_addr = 0x3ea8bb8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000ffffffff0fffULL, .num_fields = 14U, ._pad2 = 0,
	  .fields = xreg_fields_x2_87 },
	{ .base_addr = 0x3ea8200U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_88 },
	{ .base_addr = 0x3ea8c28U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_89 },
	{ .base_addr = 0x3ea8230U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000000000ffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_90 },
	{ .base_addr = 0x3ea8480U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000003ULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_91 },
	{ .base_addr = 0x3ea8c08U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000000000000001ULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_92 },
	{ .base_addr = 0x3ea8b88U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_93 },
	{ .base_addr = 0x3ea8b90U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_94 },
	{ .base_addr = 0x3ea8b68U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_95 },
	{ .base_addr = 0x3ea8b58U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_96 },
	{ .base_addr = 0x3ea8b60U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_97 },
	{ .base_addr = 0x3ea8b50U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_98 },
	{ .base_addr = 0x3ea8b70U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_99 },
	{ .base_addr = 0x3ea8b78U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_100 },
	{ .base_addr = 0x3ea8b80U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_101 },
	{ .base_addr = 0x3ea8b98U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000ffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_102 },
	{ .base_addr = 0x3ea8ba0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x00000000ffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_103 },
	{ .base_addr = 0x3ea8ba8U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_104 },
	{ .base_addr = 0x3ea8bb0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 4U, ._pad2 = 0,
	  .fields = xreg_fields_x2_105 },
	{ .base_addr = 0x3ea8b40U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_106 },
	{ .base_addr = 0x3ea8b48U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_107 },
	{ .base_addr = 0x3ea83f0U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0x0000ffff00ffffffULL, .num_fields = 3U, ._pad2 = 0,
	  .fields = xreg_fields_x2_108 },
	{ .base_addr = 0x13ea8002U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8004U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8005U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8001U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8006U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x13ea8003U, .num_copies = 2U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 0U, ._pad2 = 0,
	  .fields = NULL },
	{ .base_addr = 0x23eb2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_116 },
	{ .base_addr = 0x23eb0000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_117 },
	{ .base_addr = 0x23eac000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 18U, ._pad2 = 0,
	  .fields = xreg_fields_x2_118 },
	{ .base_addr = 0x23eb1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_119 },
	{ .base_addr = 0x23eab000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 7U, ._pad2 = 0,
	  .fields = xreg_fields_x2_120 },
	{ .base_addr = 0x23ea9000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_121 },
	{ .base_addr = 0x23ead000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_122 },
	{ .base_addr = 0x23eae000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x2_123 },
	{ .base_addr = 0x23eaf000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_124 },
	{ .base_addr = 0x23eaa000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x2_125 },
	{ .base_addr = 0x23ec4000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_126 },
	{ .base_addr = 0x23ec2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_127 },
	{ .base_addr = 0x23ec3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_128 },
	{ .base_addr = 0x23ec7000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_129 },
	{ .base_addr = 0x23ec5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_130 },
	{ .base_addr = 0x23ec6000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_131 },
	{ .base_addr = 0x23ec8000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_132 },
	{ .base_addr = 0x23ebf000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_133 },
	{ .base_addr = 0x23ec0000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_134 },
	{ .base_addr = 0x23ec1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_135 },
	{ .base_addr = 0x23ed5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 9U, ._pad2 = 0,
	  .fields = xreg_fields_x2_136 },
	{ .base_addr = 0x23ebe000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_137 },
	{ .base_addr = 0x23eba000U, .num_copies = 1U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_138 },
	{ .base_addr = 0x23eb6000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 19U, ._pad2 = 0,
	  .fields = xreg_fields_x2_139 },
	{ .base_addr = 0x23ebd000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_140 },
	{ .base_addr = 0x23eb5000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 7U, ._pad2 = 0,
	  .fields = xreg_fields_x2_141 },
	{ .base_addr = 0x23eb3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_142 },
	{ .base_addr = 0x23ebb000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_143 },
	{ .base_addr = 0x23ebc000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_144 },
	{ .base_addr = 0x23eb7000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 2U, ._pad2 = 0,
	  .fields = xreg_fields_x2_145 },
	{ .base_addr = 0x23eb8000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x2_146 },
	{ .base_addr = 0x23eb9000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 5U, ._pad2 = 0,
	  .fields = xreg_fields_x2_147 },
	{ .base_addr = 0x23eb4000U, .num_copies = 8U, .reg_size_bytes = 16U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 6U, ._pad2 = 0,
	  .fields = xreg_fields_x2_148 },
	{ .base_addr = 0x23ed4000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_149 },
	{ .base_addr = 0x23ecf000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_150 },
	{ .base_addr = 0x23ecd000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_151 },
	{ .base_addr = 0x23ece000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_152 },
	{ .base_addr = 0x23ecc000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_153 },
	{ .base_addr = 0x23ed2000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_154 },
	{ .base_addr = 0x23ed0000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_155 },
	{ .base_addr = 0x23ed1000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_156 },
	{ .base_addr = 0x23ed3000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_157 },
	{ .base_addr = 0x23ec9000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_158 },
	{ .base_addr = 0x23eca000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_159 },
	{ .base_addr = 0x23ecb000U, .num_copies = 8U, .reg_size_bytes = 8U,
	  ._pad = 0, .block_stride_bytes = 0x8000U, .flags = 0x0U,
	  .usage_mask = 0xffffffffffffffffULL, .num_fields = 1U, ._pad2 = 0,
	  .fields = xreg_fields_x2_160 },
};

const struct xreg_profile xreg_profile_x2 = {
	.name = "base",
	.table = xreg_layout_table_x2,
	.count = XREG_ID__COUNT,
	.memcfg_block_base = 0x23ea8000U,
	.id_names = xreg_id_names_x2,
	.memcfg_msel = xreg_memcfg_msel_x2,
};
