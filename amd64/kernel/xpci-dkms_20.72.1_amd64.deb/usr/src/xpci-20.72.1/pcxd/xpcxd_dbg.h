// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI driver debug definitions
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCI_PCXD_DBG_H_
#define XPCI_PCXD_DBG_H_

#include "xpci_dbg.h"

extern int xpci_debug_level;
extern int xpcxd_msglvl_level;

#define __XPCI_DEV_PRINTS__
#ifdef __XPCI_DEV_PRINTS__

#define __FL__ "F:[%-24s] L:[%-4d]"

// - NETIF_MSG_DRV
// - NETIF_MSG_PROBE
// - NETIF_MSG_LINK
// - NETIF_MSG_TIMER
// - NETIF_MSG_IFDOWN
// - NETIF_MSG_IFUP
// - NETIF_MSG_RX_ERR
// - NETIF_MSG_TX_ERR
// - NETIF_MSG_TX_QUEUED
// - NETIF_MSG_INTR
// - NETIF_MSG_TX_DONE
// - NETIF_MSG_RX_STATUS
// - NETIF_MSG_PKTDATA
// - NETIF_MSG_HW
// - NETIF_MSG_WOL

#define XPCXD_NETIF_MSG_DEFAULT (NETIF_MSG_DRV | \
 NETIF_MSG_IFUP | \
 NETIF_MSG_IFDOWN | \
 NETIF_MSG_RX_ERR | \
 NETIF_MSG_TX_ERR | \
 NETIF_MSG_TIMER)
#define XPCXD_NETIF_MSG_ALL 0xFFFFFFFF

#define xpcxd_set_msglvl_all() xpcxd_msglvl_level = XPCXD_NETIF_MSG_ALL;

/* error conditions */
#define xpcxd_err(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__ERR) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_err("ERR:XPCIDEV | "__FL__" | " fmt "\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_err_netdev(msglvl, netdev,fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__ERR) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_ERR, \
					netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#ifdef __XPCXD_DEBUG_NOTICE_LVL__
/* normal but significant condition */
#define xpcxd_notice(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_notice(	\
				"XPCIDEV | " fmt	\
				"\n",	\
				##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_NOTICE, netdev, \
				"XPCIDEV | " fmt  \
				"\n",	\
				##__VA_ARGS__);	\
		}	\
	}
#else
#define xpcxd_notice(msglvl, fmt, ...)
#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)
#endif /* __XPCXD_DEBUG_NOTICE_LVL__ */

#ifdef __XPCXD_DEBUG_INFO_LVL__
/* informational */
#define xpcxd_info(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__INFO) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_info(	\
				"XPCIDEV | " fmt	\
				"\n",	\
				##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_info_netdev(msglvl, dev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__INFO) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_INFO, netdev, \
				"XPCIDEV | " fmt  \
				"\n",	\
				##__VA_ARGS__);	\
		}	\
	}
#else
#define xpcxd_info(msglvl, fmt, ...)
#define xpcxd_info_netdev(msglvl, dev, fmt, ...)
#endif /* __XPCXD_DEBUG_INFO_LVL__ */

#ifdef __XPCXD_DEBUG_DBG_LVL__
/* debug-level messages */
#define xpcxd_dbg(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__DBG) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_info("XPCIDEV | "__FL__" | " fmt	\
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__DBG) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_DEBUG, netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}
#else 
#define xpcxd_dbg(msglvl, fmt, ...)
#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)
#endif /* __XPCXD_DEBUG_DBG_LVL__ */

#define xpcxd_msg(str) pr_info("---:XPCIDEV | "__FL__" | %s\n", str);
#else
#define xpcxd_err(msglvl, fmt, args...)
#define xpcxd_err_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_notice(msglvl, fmt, args...)
#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_info(msglvl, fmt, args...)
#define xpcxd_info_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_dbg(msglvl, fmt, args...)
#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)
#endif


#define xpcxd_trace_printk(...)
	

#ifdef __XPCXD_TRACE_MEMAVAIL__
static inline void xpcxd_memavail_impl(int line, char *msg)
{
	static unsigned long prev_avail_kb = 0;
	long avail_pages = si_mem_available(); // pages
	unsigned long avail_kb = (unsigned long)avail_pages
				 << (PAGE_SHIFT - 10);
	unsigned long delta =
		avail_kb > prev_avail_kb ?
			((unsigned long)avail_kb - prev_avail_kb) :
			((unsigned long)prev_avail_kb - avail_kb);
	const char *delta_sign = avail_kb > prev_avail_kb ? "+" : "-";

	if (delta)
		xpcxd_err(
			NETIF_MSG_DRV,
			"[%s:%4d] %lu (%sDELTA: %lu) kB",
			msg, line, avail_kb, delta_sign, delta);

	prev_avail_kb = avail_kb;
}
#define xpcxd_memavail(msg) xpcxd_memavail_impl(__LINE__, msg)
#else
#define xpcxd_memavail(msg)
#endif

#ifdef __XPCXD_DEBUG__
void xpcxd_intg_spare_write(u16 cnt);
#else
static inline void xpcxd_intg_spare_write(u16 cnt) { (void)cnt; }
#endif

#ifdef __XPCXD_DEBUG__
struct xpcxd_ring;
struct xpcxd_desc;
struct xpcxd_sw_desc;
struct xpcxd_compl_ring;
void xpcxd_consume_skb(struct net_device *netdev, struct sk_buff *skb);
void xpcxd_print_multipage_skb_data(char *msg, struct net_device *netdev, struct sk_buff *skb);
bool xpcxd_dbg_rx_page_state_check(struct net_device *netdev, u32 ring_id,
				   struct xpcxd_ring *rxr,
				   const struct xpcxd_compl_ring *rxcr,
				   const struct xpcxd_sw_desc *sw_desc,
				   const struct xpcxd_desc *cmpl,
				   u16 cmpl_idx, u16 cmpl_prd_ptr);
bool xpcxd_dbg_rx_drop_all_handle(struct net_device *netdev, u32 ring_id,
				  struct xpcxd_ring *rxr,
				  struct xpcxd_sw_desc *sw_desc,
				  struct sk_buff *skb);
bool xpcxd_dbg_rx_packets_stop_handle(struct net_device *netdev, u32 ring_id,
				      struct xpcxd_ring *rxr,
				      const struct xpcxd_compl_ring *rxcr,
				      struct xpcxd_sw_desc *sw_desc,
				      struct sk_buff *skb,
				      const struct xpcxd_desc *cmpl,
				      u16 cmpl_prd_ptr);
bool xpcxd_dbg_rx_page_ref_check(struct net_device *netdev, u32 ring_id,
				 struct xpcxd_ring *rxr,
				 struct xpcxd_sw_desc *sw_desc,
				 struct sk_buff *skb);
void xpcxd_dbg_page_ring_push(struct page *page);
void xpcxd_dbg_dump_page(struct page *page, const char *msg);
int xpcxd_dump_pages(struct net_device *netdev, bool all_pages);
#endif /* __XPCXD_DEBUG__ */

#endif /* XPCI_DBG_H_ */
