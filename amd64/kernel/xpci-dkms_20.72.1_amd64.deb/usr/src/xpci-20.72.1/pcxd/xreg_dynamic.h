/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Dynamic register access using per-silicon layouts (generated from the chip xreg_*.h).
 *
 * Layout tables: pcxd/scripts/gen_xreg_layout.py → pcxd/generated/xreg_*_<chip>.{h,c}
 *   --extra-xreg FILE     merge additional registers into enum
 *   --absent-on-base      (with --extra-xreg) mark extra-only regs absent on this profile
 *   --overlay FILE.json   per-silicon overrides (width, fields, addr, extra_registers)
 *
 * Copyright (c) Xsight Labs Ltd.
 */

#ifndef XREG_DYNAMIC_H_
#define XREG_DYNAMIC_H_

#include <linux/printk.h>
#include <linux/types.h>

#include "xpci_dbg.h"
#include "generated/xreg_layout_ids_x2.h"
#include "generated/xreg_memcfg_msel_map_x2.h"
#include "generated/xreg_memcfg_msel_map_x3.h"

extern const struct xreg_profile xreg_profile_x2;
extern const struct xreg_profile xreg_profile_x3;

int xreg_set_profile(const struct xreg_profile *p);
void xreg_put_profile(const struct xreg_profile *p);
const struct xreg_profile *xreg_get_profile(void);

/** Register name string for debug (current PCI device profile). */
static inline const char *xreg_id_name(enum xreg_id id)
{
	const struct xreg_profile *p = xreg_get_profile();

	if (!p)
		p = &xreg_profile_x2;
	if (p->id_names && (unsigned int)id < p->count)
		return p->id_names[id];
	return NULL;
}

/** MEMCFG MSEL for @id on the current PCI device profile. */
static inline u32 xreg_memcfg_msel(enum xreg_id id)
{
	const struct xreg_profile *p = xreg_get_profile();

	if (!p)
		p = &xreg_profile_x2;
	if (p->memcfg_msel)
		return p->memcfg_msel(id);
	return (u32)-1;
}

u32 xreg_abs_off(const struct xreg_desc *d, unsigned int inst,
		 unsigned int reg_within_block);

u32 xreg_addr(const struct xreg_profile *p, enum xreg_id id,
	      unsigned int inst, unsigned int reg_within_block);

/**
 * Read raw register value (32- or 64-bit per layout->reg_size_bytes).
 */
u64 xreg_read(const struct xreg_profile *p, enum xreg_id id,
	      unsigned int inst, unsigned int reg_within_block, bool log);

void xreg_write(const struct xreg_profile *p, enum xreg_id id,
		unsigned int inst, unsigned int reg_within_block, u64 val);

static inline u64 xreg_field_bits_mask(const struct xreg_field_desc *f)
{
	if (!f || f->width == 0 || f->width > 64)
		return 0;
	if (f->width >= 64)
		return ~0ULL;
	return (1ULL << f->width) - 1ULL;
}

/** Extract field from raw value (lo/width from layout fields). */
static inline u64 xreg_field_u64(u64 raw, const struct xreg_field_desc *f)
{
	if (!f || f->width == 0 || f->width > 64)
		return 0;
	/* Shifts by >= 64 on u64 are undefined; field must fit in 64 bits. */
	if (f->lo >= 64 || f->lo + f->width > 64) {
		xpci_err("xpci: xreg_field_u64: invalid field lo=%u width=%u\n",
			     (unsigned int)f->lo, (unsigned int)f->width);
		return 0;
	}
	if (f->width == 64)
		return raw >> f->lo;
	return (raw >> f->lo) & xreg_field_bits_mask(f);
}

/** Merge one field into a raw register value (device-independent packing). */
static inline void xreg_field_put_u64(u64 *raw, const struct xreg_field_desc *f,
				      u64 val)
{
	u64 m;

	if (!f || !raw || f->width == 0 || f->width > 64)
		return;
	if (f->lo >= 64 || f->lo + f->width > 64) {
		xpci_err("xpci: xreg_field_put_u64: invalid field lo=%u width=%u\n",
			     (unsigned int)f->lo, (unsigned int)f->width);
		return;
	}
	m = xreg_field_bits_mask(f);
	*raw &= ~(m << f->lo);
	*raw |= (val & m) << f->lo;
}

/** Field by index in layout->fields[] (replaces XREG_*_FIELD_SET on a staging u64). */
static inline bool xreg_field_put_idx(u64 *raw, const struct xreg_desc *d,
					unsigned int idx, u64 val)
{
	if (!d || !raw || !d->fields || idx >= d->num_fields)
		return false;
	xreg_field_put_u64(raw, &d->fields[idx], val);
	return true;
}

/**
 * Pack one field into a 128-bit logical row (two little-endian u64 lanes: qw[0]=bits 0..63,
 * qw[1]=bits 64..127). Use for MEMCFG rows whose layout fields use lo up to 127.
 */
static inline bool xreg_field_put_idx_2q(u64 qw[2], const struct xreg_desc *d,
					 unsigned int idx, u64 val)
{
	const struct xreg_field_desc *f;
	struct xreg_field_desc fa;

	if (!d || !qw || !d->fields || idx >= d->num_fields)
		return false;
	f = &d->fields[idx];
	if (f->width == 0 || f->width > 64)
		return false;

	if (f->lo + f->width <= 64) {
		xreg_field_put_u64(&qw[0], f, val);
		return true;
	}
	if (f->lo >= 64 && f->lo + f->width <= 128) {
		fa = *f;
		fa.lo = (u16)(f->lo - 64U);
		xreg_field_put_u64(&qw[1], &fa, val);
		return true;
	}
	xpci_err("xpci: xreg_field_put_idx_2q: invalid span lo=%u w=%u\n",
		 (unsigned int)f->lo, (unsigned int)f->width);
	return false;
}

/** Extract field from a 128-bit row (same lane mapping as xreg_field_put_idx_2q). */
static inline u64 xreg_field_get_idx_2q(const u64 qw[2], const struct xreg_desc *d,
					unsigned int idx)
{
	const struct xreg_field_desc *f;
	struct xreg_field_desc fa;

	if (!d || !qw || !d->fields || idx >= d->num_fields)
		return 0;
	f = &d->fields[idx];
	if (f->width == 0 || f->width > 64)
		return 0;
	if (f->lo + f->width <= 64)
		return xreg_field_u64(qw[0], f);
	if (f->lo >= 64 && f->lo + f->width <= 128) {
		fa = *f;
		fa.lo = (u16)(f->lo - 64U);
		return xreg_field_u64(qw[1], &fa);
	}
	return 0;
}

static inline u64 xreg_field_get_idx_u64(u64 raw, const struct xreg_desc *d,
					 unsigned int idx)
{
	if (!d || !d->fields || idx >= d->num_fields)
		return 0;
	return xreg_field_u64(raw, &d->fields[idx]);
}

u64 xreg_field_read_rm(const struct xreg_profile *p, enum xreg_id id,
			unsigned int inst, unsigned int reg_within_block,
			unsigned int field_idx, bool log);

void xreg_field_write_rm(const struct xreg_profile *p, enum xreg_id id,
			 unsigned int inst, unsigned int reg_within_block,
			 unsigned int field_idx, u64 val);

#endif /* XREG_DYNAMIC_H_ */
