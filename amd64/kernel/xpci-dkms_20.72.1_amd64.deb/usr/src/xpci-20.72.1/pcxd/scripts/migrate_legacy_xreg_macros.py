#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""One-off helper: map XREG_FIELD_* -> XREG_ID_* from xreg_field_indices_x2.h"""
import re
import sys


def parse_field_indices(path):
    cur_id = None
    field_to_reg = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = re.search(r"/\*\s*(XREG_ID_\w+)\s*\*/", line)
            if m:
                cur_id = m.group(1)
                continue
            m = re.match(r"#define\s+(XREG_FIELD_\w+)\s+", line)
            if m and cur_id:
                field_to_reg[m.group(1)] = cur_id
    return field_to_reg


def set_name_to_field(macro: str) -> str:
    """XREG_PCXD_FOO_BAR_SET -> XREG_FIELD_PCXD_FOO_BAR"""
    if not macro.startswith("XREG_"):
        return ""
    s = "XREG_FIELD_" + macro[5:]
    if s.endswith("_SET"):
        s = s[:-4]
    return s


def get_name_to_field(macro: str) -> str:
    """XREG_PCXD_FOO_BAR_GET -> XREG_FIELD_PCXD_FOO_BAR (field extract)"""
    if not macro.startswith("XREG_"):
        return ""
    s = "XREG_FIELD_" + macro[5:]
    if s.endswith("_GET"):
        s = s[:-4]
    return s


if __name__ == "__main__":
    idx = sys.argv[1] if len(sys.argv) > 1 else "../generated/xreg_field_indices_x2.h"
    ft = parse_field_indices(idx)
    for arg in sys.argv[2:]:
        print(arg, "->", set_name_to_field(arg), "reg:", ft.get(set_name_to_field(arg), "?"))
