#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
#
# Parse a chip register header (e.g. pcxd/xreg_x2.h, xreg_x3.h) (+ optional merge/overlay).
# Default output: pcxd/generated (./generated relative to pcxd/). Emitted #includes use "generated/…"
# so sources stay clearly under that tree (build: -I $(MOD_PWD)/pcxd).
#
# Multi-silicon workflow (same enum in xreg_layout_ids_<chip>.h per DB file):
#   1) Use the same --extra-xreg (and any overlay that adds extra_registers) for every
#      run so the register list and enum stay identical.
#   2) Generate "base" with --absent-on-base so registers that exist only in the
#      extra file are marked XREG_DESC_F_ABSENT on legacy silicon.
#   3) Generate "X2" (or other) without --absent-on-base, with --overlay for different
#      base_addr, reg_size_bytes, block_stride_bytes, or replacement fields[].
#
# Supports:
#   - Extra registers (--extra-xreg): merged into enum; optional --absent-on-base marks
#     those rows absent on the "base" silicon profile.
#   - Per-silicon overrides (--overlay JSON): reg_size_bytes, num_copies, base_addr,
#     block_stride_bytes, fields (replace field layout for that chip).
#   - Field metadata parsed from xreg.h bitfield structs (start offset comments).
#
# Copyright (c) Xsight Labs Ltd.

from __future__ import annotations

import argparse
import json
import os
import re
import sys

# Must match xreg.h
XREG_BLOCK_IN_BYTES = 4 * 1024 * 8
XREG_REG_SIZE = 8

# All generator outputs live under pcxd/generated/; includes use this path from -I $(MOD_PWD)/pcxd.
GEN_INC = "generated/"


def _sanitize_file_tag(tag: str) -> str:
    t = tag.strip().lower()
    return re.sub(r"[^a-z0-9_]", "_", t)


def _file_suffix_part(tag: str) -> str:
    """'' or '_x2' for basename xreg_layout_ids + part + .h"""
    return f"_{tag}" if tag else ""


def _guard_token(tag: str) -> str:
    """'' or '_X2' appended inside include-guard identifiers."""
    return f"_{tag.upper()}" if tag else ""


def _layout_ctag(file_tag: str, silicon_safe: str) -> str:
    """C identifier suffix for globals linked together (x2 vs x3). When legacy (no tag), use silicon."""
    if file_tag:
        t = re.sub(r"[^0-9a-zA-Z_]", "_", file_tag)
        if t and t[0].isdigit():
            t = "t_" + t
        return t
    return silicon_safe


def derive_file_suffix_from_xreg_path(xreg_path: str) -> str:
    """xreg_x2.h -> x2; xreg_x3.h -> x3."""
    base = os.path.basename(xreg_path)
    m = re.match(r"(?i)xreg_([a-z0-9]+)\.h$", base)
    if m:
        return _sanitize_file_tag(m.group(1))
    return "x2"


def _enum_suffix(reg_name: str) -> str:
    if reg_name.startswith("XREG_"):
        return reg_name[5:]
    return reg_name


def _field_macro_from_fname(fname: str) -> str:
    if fname.startswith("f_"):
        fname = fname[2:]
    parts = fname.split("_")
    return "_".join(p.upper() for p in parts)


def parse_fields(body: str) -> list[dict]:
    """Extract f_* bitfields; prefer 'start offset N' from xreg.h comments."""
    fields: list[dict] = []
    pat = re.compile(
        r"(?:uint64_t|__uint128_t)\s+(f_\w+)\s*:\s*(\d+)\s*;"
        r"\s*(?:/\*\*<[^*]*?start offset (\d+)[^*]*\*/)?",
        re.MULTILINE,
    )
    for m in pat.finditer(body):
        name, width_s, lo_s = m.group(1), m.group(2), m.group(3)
        width = int(width_s)
        if lo_s is not None:
            lo = int(lo_s)
        else:
            lo = None
        if "rsrvd" in name.lower():
            continue
        fields.append({"name": name, "lo": lo, "width": width})
    # Fill missing lo by packing in declaration order (best-effort).
    cur = 0
    for f in fields:
        if f["lo"] is None:
            f["lo"] = cur
        cur = f["lo"] + f["width"]
    return fields


def parse_xreg_h(text: str) -> list[dict]:
    parts = re.split(r"/[\*]{50,}\s*\n\* REGISTER\s+:\s*(XREG_\w+)", text)
    out: list[dict] = []
    it = iter(parts[1:])
    for name, body in zip(it, it):
        nc = re.search(
            r"#define\s+" + re.escape(name) + r"_NUM_OF_COPIES\s+\((\d+)\)", body
        )
        ad = re.search(
            r"#define\s+" + re.escape(name) + r"_ADDR\s+\(0x([0-9a-fA-F]+)\)", body
        )
        um = re.search(
            r"#define\s+"
            + re.escape(name)
            + r"_USAGE_MASK\s+\(0x([0-9a-fA-F]+)L?\)",
            body,
        )
        if not nc or not ad:
            raise ValueError(f"Missing NUM_OF_COPIES or ADDR for {name}")
        usage = 0
        if um:
            usage = int(um.group(1), 16)
        fields = parse_fields(body)
        out.append(
            {
                "name": name,
                "enum_suffix": _enum_suffix(name),
                "num_copies": int(nc.group(1)),
                "base_addr": int(ad.group(1), 16),
                "usage_mask": usage,
                "reg_size_bytes": XREG_REG_SIZE,
                "block_stride_bytes": XREG_BLOCK_IN_BYTES,
                "fields": fields,
            }
        )
    return out


def merge_reg_lists(primary: list[dict], extra: list[dict]) -> tuple[list[dict], set[str]]:
    """Append registers that appear only in extra. Returns (merged_list, extra_only_names)."""
    by_name = {r["name"]: r for r in primary}
    extra_only: set[str] = set()
    out = list(primary)
    for r in extra:
        if r["name"] not in by_name:
            out.append(r)
            by_name[r["name"]] = r
            extra_only.add(r["name"])
    return out, extra_only


def load_overlay(path: str) -> dict:
    with open(path, encoding="utf-8") as fp:
        return json.load(fp)


def expand_reg_size_for_field_span(regs: list[dict]) -> None:
    """Widen reg_size_bytes when fields span more than one 64-bit lane (e.g. __uint128_t rows)."""
    for r in regs:
        flds = r.get("fields") or []
        if not flds:
            continue
        max_end = max(fd["lo"] + fd["width"] for fd in flds)
        need = ((max_end + 63) // 64) * 8
        cur = int(r.get("reg_size_bytes", XREG_REG_SIZE))
        if need > cur:
            r["reg_size_bytes"] = need


def apply_overlay(regs: list[dict], overlay: dict) -> None:
    """In-place: registers by name, extra_registers appended."""
    by_name = {r["name"]: r for r in regs}

    for name, ovr in overlay.get("registers", {}).items():
        if name not in by_name:
            sys.stderr.write(f"overlay: unknown register {name}, skip\n")
            continue
        r = by_name[name]
        if "base_addr" in ovr:
            r["base_addr"] = int(str(ovr["base_addr"]), 0)
        if "num_copies" in ovr:
            r["num_copies"] = int(ovr["num_copies"])
        if "reg_size_bytes" in ovr:
            r["reg_size_bytes"] = int(ovr["reg_size_bytes"])
        if "block_stride_bytes" in ovr:
            r["block_stride_bytes"] = int(ovr["block_stride_bytes"])
        if "usage_mask" in ovr:
            r["usage_mask"] = int(str(ovr["usage_mask"]), 0)
        if "fields" in ovr:
            r["fields"] = []
            for fd in ovr["fields"]:
                r["fields"].append(
                    {
                        "name": fd["name"],
                        "lo": int(fd["lo"]),
                        "width": int(fd["width"]),
                    }
                )

    for er in overlay.get("extra_registers", []):
        name = er["name"]
        if name in by_name:
            sys.stderr.write(f"overlay: extra_registers duplicate {name}, skip\n")
            continue
        reg = {
            "name": name,
            "enum_suffix": _enum_suffix(name),
            "num_copies": int(er.get("num_copies", 1)),
            "base_addr": int(str(er["base_addr"]), 0),
            "usage_mask": int(str(er.get("usage_mask", "0")), 0),
            "reg_size_bytes": int(er.get("reg_size_bytes", XREG_REG_SIZE)),
            "block_stride_bytes": int(er.get("block_stride_bytes", XREG_BLOCK_IN_BYTES)),
            "fields": [],
        }
        for fd in er.get("fields", []):
            reg["fields"].append(
                {
                    "name": fd["name"],
                    "lo": int(fd["lo"]),
                    "width": int(fd["width"]),
                }
            )
        regs.append(reg)
        by_name[name] = reg


def emit_ids_h(regs: list[dict], f, file_tag: str) -> None:
    gt = _guard_token(file_tag)
    f.write(
        f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Auto-generated from xreg.h — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#ifndef XREG_LAYOUT_IDS{gt}_H_
#define XREG_LAYOUT_IDS{gt}_H_

#include <linux/types.h>

/** Register not implemented on this silicon (hole in address map). */
#define XREG_DESC_F_ABSENT	(1U << 0)

struct xreg_field_desc {{
	u16 lo;		/* bit offset in raw register value */
	u8 width;	/* field width in bits */
	u8 _pad;
}};

enum xreg_id {{
"""
    )
    for r in regs:
        f.write(f"\tXREG_ID_{r['enum_suffix']},\n")
    f.write(
        f"""\tXREG_ID__COUNT
}};

struct xreg_desc {{
	u32 base_addr;
	u16 num_copies;
	u8 reg_size_bytes;	/* access width: 4 or 8 typical */
	u8 _pad;
	u32 block_stride_bytes;
	u32 flags;		/* XREG_DESC_F_* */
	u64 usage_mask;
	u16 num_fields;
	u16 _pad2;
	const struct xreg_field_desc *fields; /* NULL or points to profile-specific table */
}};

struct xreg_profile {{
	const char *name;
	const struct xreg_desc *table;
	unsigned int count;
	u32 memcfg_block_base; /* XREG_PCXD_MEMCFG_BLOCK_ADDR — indirect MEMCFG SRAM */
	const char *const *id_names; /* xreg_layout_strings_<tag>.c */
	u32 (*memcfg_msel)(enum xreg_id id); /* xreg_memcfg_msel_<tag> */
}};

#endif /* XREG_LAYOUT_IDS{gt}_H_ */
"""
    )


def emit_field_indices_h(regs: list[dict], f, file_tag: str) -> None:
    gt = _guard_token(file_tag)
    f.write(
        f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Per-register field indices for xreg_field_put_idx / xreg_field_read_rm (0-based).
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#ifndef XREG_FIELD_INDICES{gt}_H_
#define XREG_FIELD_INDICES{gt}_H_

"""
    )
    for r in regs:
        es = r["enum_suffix"]
        f.write(f"/* XREG_ID_{es} */\n")
        f.write(f"#define XREG_NC_{es} ({r['num_copies']}u)\n")
        flds = r.get("fields") or []
        for idx, fd in enumerate(flds):
            fm = _field_macro_from_fname(fd["name"])
            f.write(f"#define XREG_FIELD_{es}_{fm} ({idx}u)\n")
        f.write("\n")
    f.write(f"#endif /* XREG_FIELD_INDICES{gt}_H_ */\n")


def emit_chip_consts_h(text: str, f, file_tag: str) -> None:
    """Emit XREG_REG_SIZE / BLOCK_*, MEMCFG block addr, and memcfg MSEL tables from chip header."""
    gt = _guard_token(file_tag)
    f.write(
        f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Chip-wide constants (block addr, memcfg MSEL tables) extracted from the
 * register database header — not register union types or field SET/GET macros.
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#ifndef XREG_CHIP_CONSTS{gt}_H_
#define XREG_CHIP_CONSTS{gt}_H_

"""
    )
    f.write(f"#define XREG_REG_SIZE ({XREG_REG_SIZE}U)\n")
    f.write("#define XREG_BLOCK_SIZE (4U * 1024U)\n")
    f.write("#define XREG_BLOCK_IN_BYTES (XREG_BLOCK_SIZE * XREG_REG_SIZE)\n\n")

    m = re.search(r"#define XREG_PCXD_MEMCFG_BLOCK_ADDR \(0x[0-9a-fA-F]+\)\n", text)
    if m:
        f.write(m.group(0) + "\n")

    start = text.find("#define XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL_MSEL_ID")
    end = text.find("typedef enum  xreg_memcfg_block_id", start)
    if start >= 0 and end > start:
        f.write("\n")
        f.write(text[start:end].rstrip())
        f.write("\n\n")

    f.write(f"#endif /* XREG_CHIP_CONSTS{gt}_H_ */\n")


def _memcfg_msel_build_switch(regs: list[dict], msel_map: dict[str, int]) -> str:
    lines: list[str] = []
    for r in regs:
        name = r["name"]
        if name in msel_map:
            lines.append(
                f"\tcase XREG_ID_{r['enum_suffix']}: return {msel_map[name]}u;\n"
            )
    return "".join(lines)


def emit_memcfg_msel_map_h(f, file_tag: str, silicon: str) -> None:
    """Declare xreg_memcfg_msel_<tag>(enum xreg_id); definition is in xreg_memcfg_msel_<tag>.c."""
    gt = _guard_token(file_tag)
    sp = _file_suffix_part(file_tag)
    sym = re.sub(r"[^0-9a-zA-Z_]", "_", silicon)
    ctag = _layout_ctag(file_tag, sym)
    f.write(
        f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Indirect MEMCFG SRAM selector (MSEL) per enum xreg_id — declaration only.
 * Definition: generated/xreg_memcfg_msel{sp}.c (avoids duplicate static inlines when
 * multiple silicon objects are linked).
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#ifndef XREG_MEMCFG_MSEL_MAP{gt}_H_
#define XREG_MEMCFG_MSEL_MAP{gt}_H_

#include <linux/types.h>

/*
 * Forward declaration only: do not include xreg_layout_ids{sp}.h here — that would
 * redefine enum xreg_id when multiple layout tags are linked. Include the driver’s
 * canonical xreg_layout_ids_*.h before this header.
 */
enum xreg_id;

u32 xreg_memcfg_msel_{ctag}(enum xreg_id id);

#endif /* XREG_MEMCFG_MSEL_MAP{gt}_H_ */
"""
    )


def emit_memcfg_msel_c(
    regs: list[dict], text: str, out_dir: str, file_tag: str, silicon: str
) -> str:
    """Emit xreg_memcfg_msel_<tag>.c from *_MSEL_ID lines in chip header."""
    sp = _file_suffix_part(file_tag)
    sym = re.sub(r"[^0-9a-zA-Z_]", "_", silicon)
    ctag = _layout_ctag(file_tag, sym)
    msel_map: dict[str, int] = {}
    for m in re.finditer(
        r"#define (XREG_PCXD_[A-Z0-9_]+)_MSEL_ID\s+\((\d+)\)", text
    ):
        msel_map[m.group(1)] = int(m.group(2))

    sw = _memcfg_msel_build_switch(regs, msel_map)
    path = os.path.join(out_dir, f"xreg_memcfg_msel{sp}.c")
    with open(path, "w", encoding="utf-8") as f:
        f.write(
            f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Indirect MEMCFG SRAM selector (MSEL) per enum xreg_id.
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#include <linux/types.h>
#include "{GEN_INC}xreg_layout_ids{sp}.h"

u32 xreg_memcfg_msel_{ctag}(enum xreg_id id)
{{
	switch (id) {{
"""
        )
        f.write(sw)
        f.write(
            """	default:
		return (u32)-1;
	}
}
"""
        )
    return path


def emit_layout_c(
    regs: list[dict],
    silicon: str,
    addr_delta: int,
    absent_names: set[str],
    memcfg_block_base: int,
    f,
    file_tag: str,
) -> None:
    sym = re.sub(r"[^0-9a-zA-Z_]", "_", silicon)
    ctag = _layout_ctag(file_tag, sym)
    sp = _file_suffix_part(file_tag)
    f.write(
        f"""/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Auto-generated — do not edit.
 * Silicon profile: {silicon}
 * Address delta: 0x{addr_delta:x}
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#include <linux/types.h>
#include "{GEN_INC}xreg_layout_ids{sp}.h"

extern const char *const xreg_id_names_{ctag}[XREG_ID__COUNT];
u32 xreg_memcfg_msel_{ctag}(enum xreg_id id);

#define XREG_LAYOUT_BLOCK_STRIDE_DEFAULT ({XREG_BLOCK_IN_BYTES}U)
#define XREG_LAYOUT_REG_SIZE_DEFAULT ({XREG_REG_SIZE}U)

"""
    )

    for i, r in enumerate(regs):
        flds = r.get("fields") or []
        if not flds or r["name"] in absent_names:
            continue
        f.write(f"static const struct xreg_field_desc xreg_fields_{ctag}_{i}[] = {{\n")
        for fd in flds:
            f.write(
                "\t{ .lo = %uU, .width = %uU, ._pad = 0 },\n"
                % (fd["lo"], fd["width"])
            )
        f.write("};\n\n")

    f.write(f"const struct xreg_desc xreg_layout_table_{ctag}[XREG_ID__COUNT] = {{\n")
    for i, r in enumerate(regs):
        base = r["base_addr"] + addr_delta
        um = r["usage_mask"] & 0xFFFFFFFFFFFFFFFF
        flags = 0
        if r["name"] in absent_names:
            flags |= 1  # XREG_DESC_F_ABSENT
            base = 0
        num_copies = 0 if r["name"] in absent_names else r["num_copies"]
        rsz = r.get("reg_size_bytes", XREG_REG_SIZE)
        bstride = r.get("block_stride_bytes", XREG_BLOCK_IN_BYTES)
        flds = r.get("fields") or []
        if r["name"] in absent_names:
            nf = 0
            fptr = "NULL"
        elif flds:
            nf = len(flds)
            fptr = f"xreg_fields_{ctag}_{i}"
        else:
            nf = 0
            fptr = "NULL"
        f.write(
            "\t{ .base_addr = 0x%xU, .num_copies = %uU, .reg_size_bytes = %uU,\n"
            "\t  ._pad = 0, .block_stride_bytes = 0x%xU, .flags = 0x%xU,\n"
            "\t  .usage_mask = 0x%016xULL, .num_fields = %uU, ._pad2 = 0,\n"
            "\t  .fields = %s },\n"
            % (base, num_copies, rsz, bstride, flags, um, nf, fptr)
        )
    f.write("};\n\n")

    f.write(
        f"""const struct xreg_profile xreg_profile_{ctag} = {{
\t.name = "{silicon}",
\t.table = xreg_layout_table_{ctag},
\t.count = XREG_ID__COUNT,
\t.memcfg_block_base = 0x{memcfg_block_base:x}U,
\t.id_names = xreg_id_names_{ctag},
\t.memcfg_msel = xreg_memcfg_msel_{ctag},
}};
"""
    )


def emit_strings_c(
    regs: list[dict], out_dir: str, file_tag: str, silicon: str
) -> str:
    sp = _file_suffix_part(file_tag)
    sym = re.sub(r"[^0-9a-zA-Z_]", "_", silicon)
    ctag = _layout_ctag(file_tag, sym)
    path = os.path.join(out_dir, f"xreg_layout_strings{sp}.c")
    with open(path, "w", encoding="utf-8") as f:
        f.write(
            f"""/* SPDX-License-Identifier: GPL-2.0 */
/* Auto-generated — do not edit. */
#include <linux/types.h>
#include "{GEN_INC}xreg_layout_ids{sp}.h"

const char *const xreg_id_names_{ctag}[XREG_ID__COUNT] = {{
"""
        )
        for r in regs:
            f.write(f'\t"{r["name"]}",\n')
        f.write("};\n")
    return path


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Generate xreg_layout_ids_<tag>.h, xreg_layout_<silicon>_<tag>.c, "
        "and related headers from a chip xreg_*.h (default tag from basename, e.g. xreg_x2.h → x2)."
    )
    ap.add_argument(
        "xreg_h",
        nargs="?",
        default=None,
        help="Path to chip xreg header (default: ../xreg_x2.h next to this script)",
    )
    ap.add_argument(
        "-o",
        "--output-dir",
        default=None,
        help="Output directory (default: ../generated = pcxd/generated). Keep all outputs here.",
    )
    ap.add_argument(
        "--silicon",
        default="base",
        help="Silicon profile name (symbol xreg_profile_<name>; avoid C keyword 'default')",
    )
    ap.add_argument(
        "--addr-delta",
        type=lambda x: int(x, 0),
        default=0,
        help="Add to every base_addr",
    )
    ap.add_argument(
        "--extra-xreg",
        default=None,
        help="Optional second xreg-style header: extra registers merged into enum",
    )
    ap.add_argument(
        "--absent-on-base",
        action="store_true",
        help="With --extra-xreg: mark registers that exist only in --extra-xreg as "
        "XREG_DESC_F_ABSENT on this profile (for generating base silicon vs add-on file)",
    )
    ap.add_argument(
        "--overlay",
        default=None,
        help="JSON file: registers{}, extra_registers[] — overrides for this silicon",
    )
    ap.add_argument(
        "--file-suffix",
        default=None,
        metavar="TAG",
        help="Suffix for generated filenames (xreg_layout_ids_<TAG>.h, …). "
        "Default: from input path (xreg_x2.h → x2). Ignored if --legacy-filenames.",
    )
    ap.add_argument(
        "--legacy-filenames",
        action="store_true",
        help="Emit xreg_layout_ids.h etc. with no _<tag> suffix (old layout).",
    )
    args = ap.parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    xreg_path = args.xreg_h or os.path.join(script_dir, "..", "xreg_x2.h")
    out_dir = args.output_dir or os.path.join(script_dir, "..", "generated")
    os.makedirs(out_dir, exist_ok=True)

    if args.legacy_filenames:
        file_tag = ""
    elif args.file_suffix is not None:
        file_tag = _sanitize_file_tag(args.file_suffix)
    else:
        file_tag = derive_file_suffix_from_xreg_path(xreg_path)
    sp = _file_suffix_part(file_tag)

    with open(xreg_path, encoding="utf-8", errors="replace") as fp:
        text = fp.read()

    regs = parse_xreg_h(text)
    extra_only: set[str] = set()

    if args.extra_xreg:
        with open(args.extra_xreg, encoding="utf-8", errors="replace") as fp:
            etext = fp.read()
        extra_regs = parse_xreg_h(etext)
        regs, extra_only = merge_reg_lists(regs, extra_regs)

    if args.overlay:
        apply_overlay(regs, load_overlay(args.overlay))

    expand_reg_size_for_field_span(regs)

    if not regs:
        print("No registers parsed", file=sys.stderr)
        return 1

    memcfg_block_base = 0
    mb = re.search(
        r"#define XREG_PCXD_MEMCFG_BLOCK_ADDR \(0x([0-9a-fA-F]+)\)", text
    )
    if mb:
        memcfg_block_base = int(mb.group(1), 16)

    absent_names: set[str] = set()
    if args.absent_on_base and extra_only:
        absent_names = set(extra_only)

    ids_path = os.path.join(out_dir, f"xreg_layout_ids{sp}.h")
    silicon_safe = re.sub(r"[^0-9a-zA-Z_]", "_", args.silicon)
    layout_path = os.path.join(out_dir, f"xreg_layout_{silicon_safe}{sp}.c")

    with open(ids_path, "w", encoding="utf-8") as f:
        emit_ids_h(regs, f, file_tag)

    field_idx_path = os.path.join(out_dir, f"xreg_field_indices{sp}.h")
    with open(field_idx_path, "w", encoding="utf-8") as f:
        emit_field_indices_h(regs, f, file_tag)

    chip_consts_path = os.path.join(out_dir, f"xreg_chip_consts{sp}.h")
    with open(chip_consts_path, "w", encoding="utf-8") as f:
        emit_chip_consts_h(text, f, file_tag)

    memcfg_msel_path = os.path.join(out_dir, f"xreg_memcfg_msel_map{sp}.h")
    with open(memcfg_msel_path, "w", encoding="utf-8") as f:
        emit_memcfg_msel_map_h(f, file_tag, args.silicon)

    memcfg_c_path = emit_memcfg_msel_c(
        regs, text, out_dir, file_tag, args.silicon
    )

    with open(layout_path, "w", encoding="utf-8") as f:
        emit_layout_c(
            regs,
            args.silicon,
            args.addr_delta,
            absent_names,
            memcfg_block_base,
            f,
            file_tag,
        )

    str_path = emit_strings_c(regs, out_dir, file_tag, args.silicon)

    print(f"Wrote {ids_path}")
    print(f"Wrote {field_idx_path}")
    print(f"Wrote {chip_consts_path}")
    print(f"Wrote {memcfg_msel_path}")
    print(f"Wrote {memcfg_c_path}")
    print(f"Wrote {str_path}")
    print(f"Wrote {layout_path} ({len(regs)} registers, file_tag={file_tag!r})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
