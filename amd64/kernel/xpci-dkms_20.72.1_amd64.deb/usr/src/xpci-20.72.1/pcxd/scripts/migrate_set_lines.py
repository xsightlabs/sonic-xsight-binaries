#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Replace XREG_*_SET(...) with xreg_field_put_idx(&v, &p->table[id], XREG_FIELD_*, ...).

Requires each affected function to declare:
	const struct xreg_profile *p = xreg_get_profile();
	u64 v;
"""
import re
import sys


def parse_field_indices(path):
    cur_id = None
    field_to_reg = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = re.search(r"/\*\s*(XREG_ID_\w+)\s*\*/", line)
            if m:
                cur_id = m.group(1)
                continue
            m = re.match(r"#define\s+(XREG_FIELD_\w+)\s+", line)
            if m and cur_id:
                field_to_reg[m.group(1)] = cur_id
    return field_to_reg


def macro_to_field(macro_name, field_to_reg):
    if not macro_name.endswith("_SET"):
        return None
    rest = macro_name[:-4][5:]  # after XREG_
    f1 = "XREG_FIELD_" + rest
    if f1 in field_to_reg:
        return f1
    f2 = f1 + "_DATA"
    if f2 in field_to_reg:
        return f2
    return None


def migrate(text, field_to_reg):
    lines = text.splitlines(keepends=True)
    out = []
    prev_reg = None
    func_start = re.compile(
        r"^\s*(static\s+)?(inline\s+)?(void|int|bool|u\d+|unsigned|long|struct)\s+\w+\s*\("
    )

    for line in lines:
        if func_start.match(line):
            prev_reg = None
        if any(
            k in line
            for k in (
                "xdrv_mem_ind_write",
                "xdrv_mem_ind_read",
                "xpci_write64",
                "xpci_write64_fast",
                "xreg_write",
            )
        ):
            prev_reg = None

        m = re.match(r"^(\s*)XREG_([A-Z0-9_]+_SET)\(([^,]+),\s*", line)
        if not m:
            out.append(line)
            continue

        indent, _set_suffix, _first = m.groups()
        full_macro = "XREG_" + _set_suffix
        field = macro_to_field(full_macro, field_to_reg)
        if not field:
            out.append(line)
            continue
        reg = field_to_reg[field]
        rest = line[m.end() :]

        if prev_reg != reg:
            out.append(f"{indent}v = 0;\n")
            prev_reg = reg

        out.append(
            f"{indent}xreg_field_put_idx(&v, &p->table[{reg}], {field}, {rest}"
        )

    return "".join(out)


def main():
    if len(sys.argv) < 3:
        print(
            "usage: migrate_set_lines.py xreg_field_indices_x2.h file.c",
            file=sys.stderr,
        )
        return 1
    idx = sys.argv[1]
    path = sys.argv[2]
    ft = parse_field_indices(idx)
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    new = migrate(text, ft)
    with open(path, "w", encoding="utf-8") as f:
        f.write(new)
    return 0


if __name__ == "__main__":
    sys.exit(main())
