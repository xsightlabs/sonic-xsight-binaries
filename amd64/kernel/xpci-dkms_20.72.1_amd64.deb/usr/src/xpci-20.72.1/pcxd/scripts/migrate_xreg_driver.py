#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Replace legacy xreg_x2.h macros in driver .c files (use xreg_api.h only)."""
from __future__ import annotations

import re
import sys


def load_xreg_ids(layout_ids_path: str) -> set[str]:
    ids: set[str] = set()
    with open(layout_ids_path, encoding="utf-8", errors="replace") as f:
        for line in f:
            for m in re.finditer(r"\b(XREG_ID_[A-Z0-9_]+)\b", line):
                ids.add(m.group(1))
    return ids


def parse_field_indices(path: str) -> tuple[dict[str, str], set[str]]:
    """Map XREG_FIELD_* macro name -> XREG_ID_* enum; collect all field macro names."""
    cur_id = None
    field_to_reg: dict[str, str] = {}
    field_names: set[str] = set()
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = re.search(r"/\*\s*(XREG_ID_\w+)\s*\*/", line)
            if m:
                cur_id = m.group(1)
                continue
            m = re.match(r"#define\s+(XREG_FIELD_\w+)\s+", line)
            if m and cur_id:
                fn = m.group(1)
                field_to_reg[fn] = cur_id
                field_names.add(fn)
    return field_to_reg, field_names


def set_macro_to_field(name: str) -> str:
    """Map XREG_*_SET macro name to XREG_FIELD_* (strip leading XREG_ and trailing _SET)."""
    if not name.startswith("XREG_") or not name.endswith("_SET"):
        return ""
    return "XREG_FIELD_" + name[5:-4]


def typ_to_id(typename: str) -> str | None:
    m = re.match(r"xreg_(pcxb|pcxd)_(.+)_t$", typename)
    if not m:
        return None
    return "XREG_ID_" + m.group(1).upper() + "_" + m.group(2).upper()


def replace_sizeof(text: str) -> str:
    def repl(m: re.Match[str]) -> str:
        tid = typ_to_id(m.group(1))
        if not tid:
            return m.group(0)
        return f"xreg_desc_bytes({tid})"

    return re.sub(
        r"sizeof\s*\(\s*(xreg_(?:pcxb|pcxd)_[a-z0-9_]+_t)\s*\)", repl, text
    )


def replace_num_copies(text: str) -> str:
    return re.sub(
        r"\bXREG_([A-Z0-9_]+)_NUM_OF_COPIES\b", r"XREG_NC_\1", text
    )


def replace_addr_inst_offset(text: str) -> str:
    return re.sub(
        r"\bXREG_([A-Z0-9_]+)_ADDR_INST_OFFSET\(",
        r"xreg_abs_off(xreg_desc(XREG_ID_\1), ",
        text,
    )


def replace_addr(text: str) -> str:
    return re.sub(
        r"\bXREG_([A-Z0-9_]+)_ADDR\b",
        r"xreg_addr(xreg_get_profile(), XREG_ID_\1, 0, 0)",
        text,
    )


def _find_matching_paren(text: str, open_idx: int) -> int:
    """Index of closing ')' matching '(' at open_idx."""
    depth = 0
    i = open_idx
    while i < len(text):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def _split_first_comma_top(s: str) -> tuple[str, str] | tuple[None, None]:
    depth = 0
    for i, c in enumerate(s):
        if c == "(":
            depth += 1
        elif c == ")":
            depth -= 1
        elif c == "," and depth == 0:
            return s[:i].strip(), s[i + 1 :].strip()
    return None, None


def replace_set_macros_balanced(
    text: str,
    field_to_reg: dict[str, str],
    field_names: set[str],
    ids: set[str],
) -> str:
    """Replace XREG_*_SET(...) including multi-line; field SET -> xreg_field_put_idx, else var = val."""
    pos = 0
    out: list[str] = []
    last_reg: str | None = None
    last_var: str | None = None
    while pos < len(text):
        m = re.search(r"\bXREG_([A-Z0-9_]+)_SET\s*\(", text[pos:])
        if not m:
            out.append(text[pos:])
            break
        abs_m = pos + m.start()
        open_paren = pos + m.end() - 1
        close_paren = _find_matching_paren(text, open_paren)
        if close_paren < 0:
            out.append(text[pos : abs_m + len(m.group(0))])
            pos = abs_m + len(m.group(0))
            continue
        stem = m.group(1)
        full_set = "XREG_" + stem + "_SET"
        inner = text[open_paren + 1 : close_paren]
        first, rest = _split_first_comma_top(inner)
        if not first or rest is None:
            out.append(text[pos : close_paren + 1])
            pos = close_paren + 1
            continue
        indent_m = re.match(r"^(\s*)", text[abs_m:])
        indent = indent_m.group(1) if indent_m else "\t"
        field = set_macro_to_field(full_set)
        semi = ";"
        if close_paren + 1 < len(text) and text[close_paren + 1] == ";":
            end = close_paren + 2
        else:
            end = close_paren + 1
            semi = ""
        out.append(text[pos:abs_m])
        if field and field in field_to_reg:
            reg = field_to_reg[field]
            if reg != last_reg or first.strip() != last_var:
                out.append(f"{indent}{first.strip()} = 0;\n{indent}")
                last_reg = reg
                last_var = first.strip()
            else:
                out.append(indent)
            out.append(
                f"xreg_field_put_idx(&{first.strip()}, "
                f"xreg_desc({reg}), {field}, {rest}){semi}\n"
            )
        else:
            fmacro = "XREG_FIELD_" + stem
            if fmacro in field_names:
                out.append(text[abs_m:end])
            else:
                xid = "XREG_ID_" + stem
                if xid in ids:
                    out.append(f"{first.strip()} = {rest}{semi}\n")
                else:
                    out.append(text[abs_m:end])
        pos = end
    return "".join(out)


def replace_get_macros(text: str, field_to_reg: dict[str, str], field_names: set[str]) -> str:
    """Replace XREG_*_GET(x) with field extract or bare x."""

    def repl(m: re.Match[str]) -> str:
        full = m.group(1)
        arg = m.group(2)
        if not full.endswith("_GET"):
            return m.group(0)
        stem = full[4:-4]  # drop XREG_ and _GET
        field = "XREG_FIELD_" + stem
        if field in field_names and field in field_to_reg:
            rid = field_to_reg[field]
            return (
                f"xreg_field_get_idx_u64({arg}, xreg_desc({rid}), {field})"
            )
        return arg

    return re.sub(
        r"\b(XREG_[A-Z0-9_]+_GET)\s*\(\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\)",
        repl,
        text,
    )


def strip_xreg_h(text: str) -> str:
    text = re.sub(r'^\s*#include\s+"xreg\.h"\s*\n', "", text, flags=re.MULTILINE)
    return text


def replace_union_locals(text: str) -> str:
    def repl(m: re.Match[str]) -> str:
        return f"u64 {m.group(2)} = 0;"

    return re.sub(
        r"xreg_(pcxb|pcxd)_[a-z0-9_]+_t\s+(\w+)\s*=\s*\{[^}]*\}\s*;",
        repl,
        text,
    )


def main() -> int:
    if len(sys.argv) < 4:
        print(
            "usage: migrate_xreg_driver.py path/to/xreg_field_indices_x2.h "
            "path/to/xreg_layout_ids_x2.h file.c",
            file=sys.stderr,
        )
        return 1
    idx_path = sys.argv[1]
    layout_ids_path = sys.argv[2]
    path = sys.argv[3]
    field_to_reg, field_names = parse_field_indices(idx_path)
    ids = load_xreg_ids(layout_ids_path)
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    text = strip_xreg_h(text)
    text = replace_union_locals(text)
    text = replace_sizeof(text)
    text = replace_num_copies(text)
    text = replace_addr_inst_offset(text)
    text = replace_addr(text)
    text = replace_set_macros_balanced(text, field_to_reg, field_names, ids)
    text = replace_get_macros(text, field_to_reg, field_names)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
