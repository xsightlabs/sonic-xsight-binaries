#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Replace legacy xreg_x2.h sizeof() and XREG_*_SET/GET patterns in driver .c files."""
from __future__ import annotations

import re
import sys


def parse_field_indices(path: str) -> dict[str, str]:
    cur_id = None
    field_to_reg: dict[str, str] = {}
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = re.search(r"/\*\s*(XREG_ID_\w+)\s*\*/", line)
            if m:
                cur_id = m.group(1)
                continue
            m = re.match(r"#define\s+(XREG_FIELD_\w+)\s+", line)
            if m and cur_id:
                field_to_reg[m.group(1)] = cur_id
    return field_to_reg


def set_macro_to_field(name: str) -> str:
    if not name.startswith("XREG_") or not name.endswith("_SET"):
        return ""
    return "XREG_FIELD_" + name[5:-4]


def field_get_macro_to_field(name: str) -> str:
    if not name.startswith("XREG_") or not name.endswith("_GET"):
        return ""
    return "XREG_FIELD_" + name[5:-4]


def typ_to_id(typename: str) -> str | None:
    m = re.match(r"xreg_(pcxb|pcxd)_(.+)_t$", typename)
    if not m:
        return None
    return "XREG_ID_" + m.group(1).upper() + "_" + m.group(2).upper()


def replace_sizeof(text: str) -> str:
    def repl(m: re.Match[str]) -> str:
        tid = typ_to_id(m.group(1))
        if not tid:
            return m.group(0)
        return f"xreg_desc_bytes({tid})"

    return re.sub(r"sizeof\s*\(\s*(xreg_(?:pcxb|pcxd)_[a-z0-9_]+_t)\s*\)", repl, text)


def replace_set_lines(text: str, field_to_reg: dict[str, str]) -> str:
    out_lines = []
    last_reg: str | None = None
    for line in text.splitlines(keepends=True):
        m = re.match(
            r"^(\s*)XREG_([A-Z0-9_]+_SET)\(([^,]+),\s*",
            line,
        )
        if not m:
            out_lines.append(line)
            continue
        indent, set_name, first_arg = m.groups()
        full = "XREG_" + set_name
        field = set_macro_to_field(full)
        if not field or field not in field_to_reg:
            out_lines.append(line)
            continue
        reg = field_to_reg[field]
        if reg != last_reg:
            out_lines.append(f"{indent}v = 0;\n")
            last_reg = reg
        rest = line[m.end() :]
        out_lines.append(
            f"{indent}xreg_field_put_idx(&v, &p->table[{reg}], {field}, {rest}"
        )
    return "".join(out_lines)


def main() -> int:
    if len(sys.argv) < 3:
        print(
            "usage: apply_xreg_migration.py xreg_field_indices_x2.h file.c",
            file=sys.stderr,
        )
        return 1
    idx_path = sys.argv[1]
    path = sys.argv[2]
    field_to_reg = parse_field_indices(idx_path)
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    text = replace_sizeof(text)
    text = replace_set_lines(text, field_to_reg)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
