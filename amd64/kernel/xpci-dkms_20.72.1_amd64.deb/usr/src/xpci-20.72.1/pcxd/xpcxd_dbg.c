// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI PCXD debug helpers (RX debug code moved from xpcxd_main.c)
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 */

#include <linux/netdevice.h>
#include <linux/skbuff.h>
#include <linux/mm.h>
#include <linux/if_ether.h>
#include <net/ip.h>
#if defined(CONFIG_PAGE_POOL_STATS) && __has_include(<net/page_pool.h>)
#include <net/page_pool.h>
#endif

#include "xpci_common.h"
#include "xpcxd_dbg.h"
#include "xpci_trace.h"
#include "xpcxd.h"
#include "xpcxd_regs.h"

#ifdef __XPCXD_DEBUG__
extern u32 g_error;

void xpcxd_intg_spare_write(u16 cnt)
{
	u64 intg_spare = 0;

	xreg_field_put_idx(&intg_spare, xreg_desc(XREG_ID_PCXD_INTG_SPARE),
			   XREG_FIELD_PCXD_INTG_SPARE_SPARE, cnt);

	xpci_write64("XREG_PCXD_INTG_SPARE", xreg_addr(xreg_get_profile(), XREG_ID_PCXD_INTG_SPARE, 0, 0),
		     intg_spare);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

bool xpcxd_dbg_rx_page_state_check(struct net_device *netdev, u32 ring_id,
				   struct xpcxd_ring *rxr,
				   const struct xpcxd_compl_ring *rxcr,
				   const struct xpcxd_sw_desc *sw_desc,
				   const struct xpcxd_desc *cmpl,
				   u16 cmpl_idx, u16 cmpl_prd_ptr)
{
	if (!unlikely(sw_desc->page_state <= XPCXD_PAGE_FREE))
		return false;

	xpcxd_trace_printk("---> [%d] PCXD CMPL RX: -ERR-: sw_desc->page_state [%d] is NOT correct",
		ring_id, sw_desc->page_state);

	xpcxd_err_netdev(
		NETIF_MSG_RX_ERR, netdev,
		"---> [%d] PCXD CMPL RX: -ERR-: sw_desc->page_state [%d] is NOT correct",
		ring_id, sw_desc->page_state);
	xpcxd_err_netdev(
		NETIF_MSG_RX_ERR, netdev,
		"---> [%d] [rnd:%d] PCXD CMPL RX: -ERR-: cmp_ctrl_valid: 0x%x cmpl_idx:%d cmpl_prd_ptr:%d rxcr->cons: %d rxcr->mask: %d",
		ring_id, rxcr->round_cnt,
		cmpl->rxc.cmp_ctrl_valid, cmpl_idx, cmpl_prd_ptr,
		rxcr->cons, rxcr->mask);

	rxr->stats.rx_page_state_les_then_free_err++;
	rxr->stats.errors++;

	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
	g_error = 1;

	return true; /* goto error */
}

bool xpcxd_dbg_rx_drop_all_handle(struct net_device *netdev, u32 ring_id,
				  struct xpcxd_ring *rxr,
				  struct xpcxd_sw_desc *sw_desc,
				  struct sk_buff *skb)
{
	if (!unlikely(xpcxd_cfg_tbl[xpcxd_rx_drop_all]))
		return false;

	xpcxd_info_netdev(
		NETIF_MSG_RX_STATUS, netdev,
		"---> [%d] PCXD CMPL RX: --> packet drop (by xpcxd_rx_drop_all)", ring_id);

	if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
		xpcxd_print_multipage_skb_data("--- RX DATA ---", netdev, skb);

	rxr->stats.dropped++;

	xpcxd_consume_skb(netdev, skb);

	xpcxd_opt_trace(rx_skb_consume, ring_id, 0, skb, 0);

	sw_desc->page_state = XPCXD_PAGE_FREE;

	return true; /* goto next */
}

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx);
extern int xpcxd_loopback;
extern int xpcxd_rx_packets_stop;

bool xpcxd_dbg_rx_packets_stop_handle(struct net_device *netdev, u32 ring_id,
				      struct xpcxd_ring *rxr,
				      const struct xpcxd_compl_ring *rxcr,
				      struct xpcxd_sw_desc *sw_desc,
				      struct sk_buff *skb,
				      const struct xpcxd_desc *cmpl,
				      u16 cmpl_prd_ptr)
{
	if (!unlikely(xpcxd_rx_packets_stop))
		return false;

	xprint_hex_dump(netdev, "--- RX Cmpl W[0] STOP ---",
			DUMP_PREFIX_OFFSET, 16, 1, &cmpl->w64[0],
			sizeof(u64), true);
	xprint_hex_dump(netdev, "--- RX Cmpl W[1] STOP ---",
			DUMP_PREFIX_OFFSET, 16, 1, &cmpl->w64[1],
			sizeof(u64), true);
	xprint_hex_dump(netdev, "--- RX STOP ---",
			DUMP_PREFIX_OFFSET, 16, 1, skb->data,
			skb->len, true);

	xpcxd_err_netdev(NETIF_MSG_RX_ERR, netdev,
		"---> [%d] PCXD CMPL RX: STOP: cmpl_prd_ptr: %d rxcr->cons: %d rxcr->size: %d",
		ring_id, cmpl_prd_ptr, rxcr->cons, rxcr->size);
	xpci_print_pkt("RX STOP", netdev, skb, RX_OFFSET, xpci_rx);

	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
	g_error = 1;
	xpcxd_intg_spare_write(g_cnt_init_done);

	xpcxd_info_netdev(
		NETIF_MSG_RX_STATUS, netdev,
		"---> [%d] PCXD CMPL RX: --> packet drop (by xpcxd_rx_packets_stop)", ring_id);

	rxr->stats.dropped++;
	rxr->stats.rx_drop_events++;

	xpcxd_consume_skb(netdev, skb);
	sw_desc->page_state = XPCXD_PAGE_FREE;
	return true; /* goto next */
}

bool xpcxd_dbg_rx_page_ref_check(struct net_device *netdev, u32 ring_id,
				 struct xpcxd_ring *rxr,
				 struct xpcxd_sw_desc *sw_desc,
				 struct sk_buff *skb)
{
	if ((page_ref_count(sw_desc->page) == 1) &&
	    (sw_desc->page_state == XPCXD_PAGE_ALLOCATED))
		return false;

	xpcxd_err_netdev(
		NETIF_MSG_RX_ERR, netdev,
		"---> [%d] PCXD CMPL RX: REF CNT -PCXDERR-: skb: [%p] sw_desc->page: [%p] sw_desc->addr: [%lld] page refcnt: [%d]",
		ring_id, skb, sw_desc->page, sw_desc->addr, page_ref_count(sw_desc->page));

	rxr->stats.errors++;

	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
	g_error = 1;

	xpcxd_opt_trace(rx_skb_page_err, ring_id, 0, skb, page_to_pfn(sw_desc->page));

	return true; /* goto error */
}

#define MAX_PAGE_POOL_RING 16

struct xpcxd_page_dsc {
	struct page *page;
};

static struct xpcxd_page_dsc xpcxd_page_ring[MAX_PAGE_POOL_RING];
static u16 xpcxd_page_ring_idx;
static u16 xpcxd_page_ring_last_idx;

void xpcxd_dbg_page_ring_push(struct page *page)
{
	xpcxd_page_ring[xpcxd_page_ring_idx].page = page;
	xpcxd_page_ring_last_idx = xpcxd_page_ring_idx;
	xpcxd_page_ring_idx++;
	if (xpcxd_page_ring_idx >= MAX_PAGE_POOL_RING)
		xpcxd_page_ring_idx = 0;
}

void xpcxd_dbg_dump_page(struct page *page, const char *msg)
{
	if (page)
		dump_page(page, msg);
}

int xpcxd_dump_pages(struct net_device *netdev, bool all_pages)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *ring = NULL;
	int i;
	u32 ring_id;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_rx_stat_dump_short(netdev);
	xpcxd_tx_stat_dump_short(netdev);

	if (net_priv->num_rings < 2) {
		if (xpcxd_page_ring[xpcxd_page_ring_last_idx].page)
			xpcxd_dbg_netdev(
				NETIF_MSG_DRV, netdev,
				"Last Used Rx page: [%p] pfn: [%lu]",
				xpcxd_page_ring[xpcxd_page_ring_last_idx].page,
				page_to_pfn(xpcxd_page_ring[xpcxd_page_ring_last_idx].page));

		if (all_pages) {
			for (i = 0; i < MAX_PAGE_POOL_RING; i++) {
				if (xpcxd_page_ring[i].page)
					dump_page(xpcxd_page_ring[i].page, "rx page ring page");
			}
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		ring = &net_priv->rxr[ring_id];

#ifdef CONFIG_PAGE_POOL_STATS
		{
			struct page_pool_stats pool_stats = {};

			page_pool_get_stats(ring->page_pool, &pool_stats);

			xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				"POOL ALLOC STATS: fast: [%llu] slow: [%llu] slow_high_order: [%llu] empty: [%llu] refill: [%llu] waive: [%llu]",
				pool_stats.alloc_stats.fast,
				pool_stats.alloc_stats.slow,
				pool_stats.alloc_stats.slow_high_order,
				pool_stats.alloc_stats.empty,
				pool_stats.alloc_stats.refill,
				pool_stats.alloc_stats.waive);

			xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				"POOL RECYCLE STATS: cached: [%llu] cache_full: [%llu] ring: [%llu] ring_full: [%llu] released_refcnt: [%llu]",
				pool_stats.recycle_stats.cached,
				pool_stats.recycle_stats.cache_full,
				pool_stats.recycle_stats.ring,
				pool_stats.recycle_stats.ring_full,
				pool_stats.recycle_stats.released_refcnt);
		}
#endif

		for (i = 0; i < net_priv->num_rx_desc; i++) {
			struct xpcxd_sw_desc *sw_desc = &ring->sub.sw[i];

			if (!sw_desc)
				continue;

			if ((sw_desc->page_state == XPCXD_PAGE_ALLOCATED) && !all_pages)
				continue;

			xpcxd_dbg_netdev(
				NETIF_MSG_DRV, netdev,
				"Ring: [%d] Dsc: [%d] Page: [%p] pfn: [%lu] State: [%d]",
				ring_id, i, sw_desc->page,
				page_to_pfn(sw_desc->page),
				sw_desc->page_state);
		}
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}
#endif /* __XPCXD_DEBUG__ */
