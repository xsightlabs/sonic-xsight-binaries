// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI ethtool callbacks
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license
 * agreement entered into with Xsight Labs Ltd.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/string.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/jiffies.h>
#include <linux/ethtool.h>
#include <linux/string.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>

#include "xpci_version.h"
#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xnetdev_common.h"
#include "xpcxd.h"

extern int xpcxd_rx_enabled;
extern int xpcxd_tx_enabled;
extern int xpcxd_rss_enabled;
extern u8 rss_secret_key[XPCXD_RSS_SECRET_KEY_SIZE];

extern int xpcxd_tx_packets_stop;
extern int xpcxd_rx_packets_stop;
extern int xpcxd_stop_on_next_isr;
extern int xpcxd_rx_ignore_l3_checksum_err;
extern int xpcxd_rx_ignore_l4_checksum_err;
extern int xpcxd_rx_ring_threshold_stop;
extern unsigned int xpcxd_rx_cmpl_napi_hold_low_hw_credits;
extern int xpcxd_enable_tx_err_interrupt;
extern int xpcxd_enable_rx_err_interrupt;
extern int xpcxd_tx_drop_on_alignment_err;

extern uint xpcxd_cfg_tbl[xpcxd_last_cfg_item];
extern int xpcxd_event_trace_cmd;

/* MMIO + MEMCFG stats use xreg_get_profile() (set at PCI probe per device). */
static u64 xpcxd_xreg_read_mmio(enum xreg_id id)
{
	const struct xreg_profile *p = xreg_get_profile();

	if (!p || (unsigned int)id >= p->count) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_xreg_read_mmio: invalid profile/id (id=%u)",
			  (unsigned int)id);
		return 0;
	}
	return xpci_read64(
		(id < XREG_ID__COUNT) ? (char *)xreg_id_name(id) : NULL,
		xreg_addr(p, id, 0, 0), true);
}

static void xpcxd_xreg_write_mmio(enum xreg_id id, u64 val)
{
	const struct xreg_profile *p = xreg_get_profile();

	if (!p || (unsigned int)id >= p->count) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_xreg_write_mmio: invalid profile/id (id=%u)",
			  (unsigned int)id);
		return;
	}
	xpci_write64((id < XREG_ID__COUNT) ? (char *)xreg_id_name(id) : NULL,
		     xreg_addr(p, id, 0, 0), val);
}

static int xpcxd_memcfg_stat_raw(enum xreg_id id, u32 ring, u8 *buf, u32 buflen)
{
	const struct xreg_profile *p = xreg_get_profile();
	u32 msel;
	u32 sz;

	if (!p || (unsigned int)id >= p->count) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_memcfg_stat_raw: invalid profile/id (id=%u)",
			  (unsigned int)id);
		return -1;
	}
	msel = xreg_memcfg_msel(id);
	if (msel == (u32)-1) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_memcfg_stat_raw: no memcfg msel for id=%u",
			  (unsigned int)id);
		return -1;
	}
	sz = xreg_desc_bytes(id);
	if (sz == 0 || sz > buflen) {
		xpcxd_err(NETIF_MSG_DRV,
			  "xpcxd_memcfg_stat_raw: invalid size=%u for id=%u (buflen=%u)",
			  sz, (unsigned int)id, buflen);
		return -1;
	}
	return xdrv_mem_ind_read(
		(id < XREG_ID__COUNT) ? (char *)xreg_id_name(id) : NULL,
		msel, ring, sz, buf);
}

static u64 xpcxd_memcfg_stat_u64(enum xreg_id id, u32 ring)
{
	u8 buf[16];
	const struct xreg_desc *d = xreg_desc(id);
	u32 sz;

	if (!d || d->reg_size_bytes > sizeof(buf)) {
		xpcxd_err(NETIF_MSG_DRV,
			  "xpcxd_memcfg_stat_u64: invalid desc/size for id=%u (reg_size=%u)",
			  (unsigned int)id, d ? (unsigned int)d->reg_size_bytes : 0U);
		return 0;
	}
	if (xpcxd_memcfg_stat_raw(id, ring, buf, sizeof(buf))) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_memcfg_stat_u64: failed raw read (id=%u ring=%u)",
			  (unsigned int)id, ring);
		return 0;
	}
	sz = d->reg_size_bytes;
	if (sz <= 8) {
		u64 raw = 0;

		memcpy(&raw, buf, sz);
		return xreg_field_get_idx_u64(raw, d, 0);
	}
	{
		u64 qw[2];

		memcpy(qw, buf, sizeof(qw));
		return xreg_field_get_idx_2q(qw, d, 0);
	}
}

enum { NETDEV_STATS, XPCXD_STATS, XPCXD_STATS64 };

struct xpcxd_queue_stats {
	u64 packets;
	u64 bytes;
};

struct xpcxd_eth_stats {
	char stat_string[ETH_GSTRING_LEN];
	int type;
	int sizeof_stat;
	int stat_offset;
};

#define XPCXD_STAT(m)                                                          \
	XPCXD_STATS, sizeof(((struct xpcxd_stats *)0)->m),                     \
		offsetof(struct xpcxd_stats, m)
#define XPCXD_NETDEV_STAT(m)                                                   \
	NETDEV_STATS, sizeof(((struct rtnl_link_stats64 *)0)->m),              \
		offsetof(struct rtnl_link_stats64, m)

static const struct xpcxd_eth_stats xpcxd_gstrings_stats[] = {
	{ "rx_packets",
	  XPCXD_NETDEV_STAT(
		  rx_packets) }, /* total packets received		*/
	{ "tx_packets",
	  XPCXD_NETDEV_STAT(tx_packets) }, /* total packets transmitted	*/
	{ "rx_bytes",
	  XPCXD_NETDEV_STAT(
		  rx_bytes) }, /* total bytes received 		*/
	{ "tx_bytes",
	  XPCXD_NETDEV_STAT(
		  tx_bytes) }, /* total bytes transmitted		*/
	{ "rx_errors",
	  XPCXD_NETDEV_STAT(
		  rx_errors) }, /* bad packets received			*/
	{ "tx_errors",
	  XPCXD_NETDEV_STAT(
		  tx_errors) }, /* packet transmit problems		*/
	{ "rx_dropped",
	  XPCXD_NETDEV_STAT(rx_dropped) }, /* no space in linux buffers	*/
	{ "tx_dropped",
	  XPCXD_NETDEV_STAT(tx_dropped) }, /* no space in linux buffers */

	{ "rx_multicast",
	  XPCXD_NETDEV_STAT(multicast) }, /* multicast packets received	*/
	{ "rx_broadcast", XPCXD_STAT(rx_broadcast) },
	{ "rx_unicast", XPCXD_STAT(rx_unicast) },
	{ "tx_multicast", XPCXD_STAT(tx_multicast) },
	{ "tx_broadcast", XPCXD_STAT(tx_broadcast) },
	{ "tx_unicast", XPCXD_STAT(tx_unicast) },
	{ "rx_vlan_packets", XPCXD_STAT(rx_vlan_packets) },
	{ "tx_vlan_packets", XPCXD_STAT(tx_vlan_packets) },
	{ "rx_over_errors",
	  XPCXD_NETDEV_STAT(
		  rx_over_errors) }, /* receiver ring buff overflow	*/
	{ "rx_crc_errors",
	  XPCXD_NETDEV_STAT(
		  rx_crc_errors) }, /* recved pkt with crc error	*/
	{ "rx_fifo_errors",
	  XPCXD_NETDEV_STAT(rx_fifo_errors) }, /* Same as rx_over_errors */

	{ "rx_underflow_events",
	  XPCXD_STAT(rx_underflow_events) }, /* Rx underflow events count */

	{ "rx_l3_csm_err",
	  XPCXD_STAT(rx_l3_csm_err) }, /* Rx L3 checksum errors count */
	{ "rx_l4_csm_err",
	  XPCXD_STAT(rx_l4_csm_err) }, /* Rx L4 checksum errors count */

	{ "rx_page_alloc_err",
	  XPCXD_STAT(rx_page_alloc_err) }, /* Rx page allocation errors count */
	{ "rx_dma_get_err",
	  XPCXD_STAT(
		  rx_dma_get_err) }, /* Rx DMA mapping error */
	{ "rx_swdesc_err",
	  XPCXD_STAT(rx_swdesc_err) }, /* Rx completion: NULL sw_desc */
	{ "rx_page_err",
	  XPCXD_STAT(rx_page_err) }, /* Rx skb build: NULL page */
	{ "rx_state_err",
	  XPCXD_STAT(rx_state_err) }, /* Rx skb build: bad page_state */
	{ "rx_page_state_le_free_err",
	  XPCXD_STAT(
		  rx_page_state_les_then_free_err) }, /* DEBUG ps<=FREE */
	{ "rx_swdesc_addr_err",
	  XPCXD_STAT(rx_swdesc_addr_err) }, /* Rx sw_desc DMA addr invalid */
	{ "rx_free_ref_cnt_0_page",
	  XPCXD_STAT(rx_free_ref_cnt_0_page) }, /* Rx page recycle bad refcnt */
	{ "rx_hw_csum_err",
	  XPCXD_STAT(
		  hw_csum_rx_error) }, /* Rx HW checksum err */
	{ "rx_ring_errors", XPCXD_STAT(errors) }, /* Rx ring total errors */
	{ "rx_ring_dropped", XPCXD_STAT(dropped) }, /* Rx ring total dropped */
	{ "rx_drop_events",
	  XPCXD_STAT(rx_drop_events) }, /* Rx drop events (per RX drop path) */
	{ "rx_sw_sub_posted_hw",
	  XPCXD_STAT(
		  rx_sw_sub_posted_hw) }, /* Rx submit descs doorbelled to HW */
	{ "rx_sw_cmpl_returned",
	  XPCXD_STAT(
		  rx_sw_cmpl_returned) }, /* Rx sub descs released (CMPL) */
	{ "rx_cmpl_irq_cnt",
	  XPCXD_STAT(
		  cmpl_irq_cnt) }, /* Rx CMPL MSI-X handler count (sum rings) */
	{ "rx_wrong_page_state",
	  XPCXD_STAT(
		  rx_wrong_page_state) }, /* Rx bad page ref at poll */

	{ "rx_sub_threshold",
	  XPCXD_STAT(
		  rx_sub_threshold) }, /* Rx sub ring threshold count */
	{ "rx_sub_refill_throttle",
	  XPCXD_STAT(
		  rx_sub_refill_throttle) }, /* Rx refill capped by reserve% / max_desc */
	{ "rx_sub_ring_starve_no_db",
	  XPCXD_STAT(
		  rx_sub_ring_starve_no_db) }, /* Rx refill: 0 SUB desc doorbelled (no free SUB slots) */
	{ "rx_osc_empty_sub_prime",
	  XPCXD_STAT(
		  rx_osc_empty_sub_prime) }, /* Refill-osc idle: primed truly empty SUB (posted==returned) */
	{ "rx_cmpl_threshold",
	  XPCXD_STAT(
		  rx_cmpl_threshold) }, /* Rx cmpl ring threshold count */

	{ "rx_cmpl_full_napi_held",
	  XPCXD_STAT(
		  rx_cmpl_full_napi_held) }, /* Rx: napi_complete skipped, CMPL HW full */
	{ "rx_cmpl_low_hw_napi_held",
	  XPCXD_STAT(
		  rx_cmpl_low_hw_napi_held) }, /* Rx: napi_complete skipped, CMPL HW credits low */
	{ "rx_credits_slash",
	  XPCXD_STAT(rx_credits_slash) }, /* Rx: rx_credits trimmed by
					   * pcxd_rx_credits_slash_pct when
					   * SUB free < pcxd_rx_sub_low_free_pct
					   */
	{ "rx_credits_restore",
	  XPCXD_STAT(
		  rx_credits_restore) }, /* Rx: rx_credits step toward cap */
	{ "rx_mtu_exceeded",
	  XPCXD_STAT(
		  rx_mtu_exceeded) }, /* Rx MTU exceeded */
	{ "rx_stop_drop_all",
	  XPCXD_STAT(
		  rx_stop_drop_all) }, /* Rx stop: rx_drop_all */
	{ "rx_stop_packets_stop",
	  XPCXD_STAT(
		  rx_stop_packets_stop) }, /* Rx stop: rx_packets_stop */
	{ "rx_build_skb_err",
	  XPCXD_STAT(
		  rx_stop_build_skb) }, /* Rx stop: build_skb */
	{ "rx_add_frag_failed_err",
	  XPCXD_STAT(
		  rx_stop_add_frag_failed) }, /* Rx stop: add_frag */
	{ "rx_fill_sw_desc_null",
	  XPCXD_STAT(rx_fill_sw_desc_null) }, /* Rx fill: null sw_desc */
	{ "rx_fill_fatal_oom",
	  XPCXD_STAT(
		  rx_fill_fatal_oom) }, /* Rx fill fatal OOM */
	{ "rx_stop_dbg_rx_abort",
	  XPCXD_STAT(rx_stop_dbg_rx_abort) }, /* Rx: DEBUG path aborted NAPI */
#ifdef __XPCXD_RX_PKT_SIZE_HISTOGRAM__
	{ "rx_pkt_size_0_255",
	  XPCXD_STAT(
		  rx_pkt_size_0_255) }, /* Rx pkt size 0..255 */
	{ "rx_pkt_size_256_511",
	  XPCXD_STAT(
		  rx_pkt_size_256_511) }, /* Rx pkt size 256..511 */
	{ "rx_pkt_size_512_1023",
	  XPCXD_STAT(
		  rx_pkt_size_512_1023) }, /* Rx pkt size 512..1023 */
	{ "rx_pkt_size_1024_4095",
	  XPCXD_STAT(
		  rx_pkt_size_1024_4095) }, /* Rx pkt size 1024..4095 */
	{ "rx_pkt_size_4096_8191",
	  XPCXD_STAT(
		  rx_pkt_size_4096_8191) }, /* Rx pkt size 4096..8191 */
	{ "rx_pkt_size_8192_plus",
	  XPCXD_STAT(
		  rx_pkt_size_8192_plus) }, /* Rx pkt size >8192 */
#endif /* __XPCXD_RX_PKT_SIZE_HISTOGRAM__ */
	{ "tx_underflow_events",
	  XPCXD_STAT(tx_underflow_events) }, /* Tx underflow events count */

	{ "tx_sub_threshold",
	  XPCXD_STAT(
		  tx_sub_threshold) }, /* Tx sub ring threshold count */
	{ "tx_cmpl_threshold",
	  XPCXD_STAT(
		  tx_cmpl_threshold) }, /* Tx cmpl ring threshold count */

	{ "tx_alignment_error",
	  XPCXD_STAT(
		  tx_alignment_error) }, /* Tx 64/256B align err */
	{ "tx_skb_realigned_256b",
	  XPCXD_STAT(
		  tx_skb_realigned_256b) }, /* Tx SKBs replaced due to !256B align (alloc+memcpy+free) */
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	{ "tx_pkt_size_64_128",
	  XPCXD_STAT(
		  tx_pkt_size_64_128) }, /* Tx pkt size 64..127 */
	{ "tx_pkt_size_128_256",
	  XPCXD_STAT(
		  tx_pkt_size_128_256) }, /* Tx pkt size 128..255 */
	{ "tx_pkt_size_256_plus",
	  XPCXD_STAT(
		  tx_pkt_size_256_plus) }, /* Tx pkt size >=256 (up to jumbo) */
#endif /* __XPCXD_TX_PKT_SIZE_HISTOGRAM__ */
	{ "tx_xdp_packets",
	  XPCXD_STAT(
		  tx_xdp_packets) }, /* Tx XDP redirect pkts */
	{ "tx_xdp_bytes",
	  XPCXD_STAT(
		  tx_xdp_bytes) }, /* Tx XDP redirect bytes */
};

#define XPCXD_GLOBAL_STATS_LEN ARRAY_SIZE(xpcxd_gstrings_stats)
#define XPCXD_GSTRING_STATS_LEN XPCXD_GLOBAL_STATS_LEN
#define XPCXD_STATS_LEN (XPCXD_GLOBAL_STATS_LEN)

/* Names that appear once in ethtool -S (netdev or aggregated); others repeat per ring. */
static bool xpcxd_ethtool_stat_is_global(const char *name)
{
	static const char *const global[] = {
		"rx_packets", "rx_bytes", "rx_errors", "rx_dropped",
		"rx_multicast", "rx_broadcast", "rx_unicast", "rx_vlan_packets",
		"rx_drop_events", "rx_over_errors", "rx_crc_errors",
		"tx_packets", "tx_bytes", "tx_errors", "tx_dropped",
		"tx_multicast", "tx_broadcast", "tx_unicast", "tx_vlan_packets",
	};
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(global); i++) {
		if (strcmp(name, global[i]) == 0)
			return true;
	}
	return false;
}

/* Active = ring enabled and netdev up (ring stats dump only; ethtool lists all rings). */
static bool xpcxd_ring_sw_active(struct xpcxd_priv *np, u32 ring_id,
				 struct net_device *netdev)
{
	if (ring_id >= np->num_rings)
		return false;
	return np->rxr[ring_id].tx_rx_enabled && netif_running(netdev);
}

#ifdef __XPCXD_STATS64__
/* Netdev + global XPCXD_STATS first; remaining XPCXD_STATS as ring0/… ring1/… (ethtool -S). */
static void xpcxd_ethtool_ring_stat_name(char *dst, unsigned int ring,
					 const char *base)
{
	int n;

	n = snprintf(dst, ETH_GSTRING_LEN, "%u/", ring);
	if (n < 0 || n >= ETH_GSTRING_LEN)
		return;
	strlcpy(dst + (size_t)n, base, ETH_GSTRING_LEN - (size_t)n);
}

static struct xpcxd_stats *xpcxd_ethtool_ring_stats(struct xpcxd_priv *np,
						    unsigned int ring,
						    const char *name)
{
	if (strncmp(name, "tx_", 3) == 0)
		return &np->txr[ring].stats;
	return &np->rxr[ring].stats;
}

static u64 xpcxd_ethtool_read_xstat(struct xpcxd_priv *np, unsigned int ring,
				    const struct xpcxd_eth_stats *st)
{
	struct xpcxd_stats *rs =
		xpcxd_ethtool_ring_stats(np, ring, st->stat_string);
	void *p = (char *)rs + st->stat_offset;

	return st->sizeof_stat == sizeof(u64) ? *(u64 *)p : *(u32 *)p;
}

static unsigned int xpcxd_ethtool_stats_count(struct net_device *netdev)
{
	struct xpcxd_priv *np = netdev_priv(netdev);
	unsigned int n = 0;
	unsigned int i, r;

	r = np->num_rings;
	for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
		if (xpcxd_gstrings_stats[i].type == NETDEV_STATS) {
			n++;
		} else if (xpcxd_gstrings_stats[i].type == XPCXD_STATS) {
			if (xpcxd_ethtool_stat_is_global(
				    xpcxd_gstrings_stats[i].stat_string))
				n++;
			else
				n += r;
		}
	}
	return n;
}
#endif /* __XPCXD_STATS64__ */

static const char xpcxd_priv_flags_strings[][ETH_GSTRING_LEN] = {
	"dump-tx-stat",
	"dump-rx-stat",
	"clear-tx-stat",
	"clear-rx-stat",
	"enable-tx-err-interrupt",
	"enable-rx-err-interrupt",
	"dump-rx-desc-status",
	"dump-tx-desc-status",
	"rx-cmpl-napi-hold-low-hw",
#ifdef __XPCXD_DEBUG__CT__
	"stop-on-next-tx",
	"stop-on-next-rx",
	"stop-on-next-isr",
	"drop-all-tx",
	"drop-all-rx",
	"ignore-rx-l3-checksum-err",
	"ignore-rx-l4-checksum-err",
	"stop-on-rx-ring-space-threshold",
	"drop-on-tx-alignment-err",
#endif
	"drop-tx-lldp-non-shim",
	"drop-tx-mld-non-shim",
#ifdef __XPCXD_CMD_TRACES__
	"event-trace"
#endif
};

#define XPCXD_PRIV_FLAGS_STR_LEN ARRAY_SIZE(xpcxd_priv_flags_strings)

static u16 xpcxd_err_int_coales_val = 1; /* TODO: Check the real value */
static u16 xpcxd_err_int_timeout_val = 1; /* TODO: Check the real value */

static void xpcxd_get_drvinfo(struct net_device *netdev,
			      struct ethtool_drvinfo *info)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0)
	strscpy(info->driver, XPCXD_NETDEV_DRV_NAME, sizeof(info->driver));
	strscpy(info->version, XPCXD_NETDEV_DRV_VERSION,
		sizeof(info->version));
#else
	strlcpy(info->driver, XPCXD_NETDEV_DRV_NAME, sizeof(info->driver));
	strlcpy(info->version, XPCXD_NETDEV_DRV_VERSION, sizeof(info->version));
#endif
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)) ||                        \
	(defined __XPCI_ETHTOOL_NEW_API__)
static void xpcxd_get_ringparam(struct net_device *netdev,
				struct ethtool_ringparam *ring,
				struct kernel_ethtool_ringparam *kernel_ring,
				struct netlink_ext_ack *ext_ack)
#else
static void xpcxd_get_ringparam(struct net_device *netdev,
				struct ethtool_ringparam *ring)
#endif
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	ring->rx_max_pending = net_priv->rxr[0].cmp.size;
	ring->tx_max_pending = net_priv->txr[0].sub.size;
	ring->rx_mini_max_pending = 0;
	ring->rx_jumbo_max_pending = 0;
	ring->rx_pending = xpcxd_get_cmpl_ring_space(&net_priv->rxr[0]);
	ring->tx_pending = xpcxd_get_tx_sub_ring_space(&net_priv->txr[0]);
	ring->rx_mini_pending = 0;
	ring->rx_jumbo_pending = 0;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)) ||                        \
	(defined __XPCI_ETHTOOL_NEW_API__)
static int xpcxd_set_ringparam(struct net_device *netdev,
			       struct ethtool_ringparam *ring,
			       struct kernel_ethtool_ringparam *kernel_ring,
			       struct netlink_ext_ack *ext_ack)
#else
static int xpcxd_set_ringparam(struct net_device *netdev,
			       struct ethtool_ringparam *ring)
#endif
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "IN: Change ring parameter is not implemented yet");

	return 0;
}

static void xpcxd_get_pauseparam(struct net_device *netdev,
				 struct ethtool_pauseparam *pause)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	pause->autoneg = 0;

	pause->rx_pause = xpcxd_rx_enabled;
	pause->tx_pause = xpcxd_tx_enabled;

	xpcxd_dbg_netdev(
		NETIF_MSG_DRV, netdev,
		"IN: [Rx: enabled:%d| pause:%d Tx: enabled:%d| pause:%d]",
		xpcxd_rx_enabled, pause->rx_pause, xpcxd_tx_enabled,
		pause->tx_pause);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static int xpcxd_set_pauseparam(struct net_device *netdev,
				struct ethtool_pauseparam *pause)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;
	int ret = 0;

	xpcxd_dbg_netdev(
		NETIF_MSG_DRV, netdev,
		"IN: [Rx: enabled:%d| pause:%d Tx: enabled:%d| pause:%d]",
		xpcxd_rx_enabled, pause->rx_pause, xpcxd_tx_enabled,
		pause->tx_pause);

	if (!pause->rx_pause && xpcxd_rx_enabled) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Disabling RX");

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_dev_rx_disable(netdev, ring_id);
			if (ret) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						 "Ring Rx disable failed: %d",
						 ret);
				return -EAGAIN;
			}
		}

		xpcxd_rx_activate(false);

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device RX disabled");

		/* Rx On/Off per ring is not supported in ethtool interface */
		/* So, we update rx_enable per ring, but set it also device-wide */

		xpcxd_rx_enabled = false;
	}

	if (!pause->tx_pause && xpcxd_tx_enabled) {
		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_dev_tx_disable(netdev, ring_id);
			if (ret) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						 "Ring Tx disable failed: %d",
						 ret);
				return -EAGAIN;
			}
		}

		xpcxd_tx_activate(false);

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device TX disabled");
		xpcxd_tx_enabled = false;
	}

	if (pause->rx_pause && !xpcxd_rx_enabled) {
		ret = xpcxd_dev_rx_enable(netdev, true);
		if (ret) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Ring device Rx enable failed: %d",
					 ret);
			return -EAGAIN;
		}

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device RX enabled");
		xpcxd_rx_enabled = true;
	}

	if (pause->tx_pause && !xpcxd_tx_enabled) {
		ret = xpcxd_dev_tx_enable(netdev, true);
		if (ret) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Ring device Tx enable failed: %d",
					 ret);
			return -EAGAIN;
		}

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device TX enabled");
		xpcxd_tx_enabled = true;
	}

	return 0;
}

/*
	msglvl N
	msglvl type on|off ...
			Sets the driver message type flags by name or number.
			type names the type of message to enable or disable; N
			specifies the new flags numerically. The defined type
			names and numbers are:

			drv         0x0001  General driver status
			probe       0x0002  Hardware probing
			link        0x0004  Link state
			timer       0x0008  Periodic status check
			ifdown      0x0010  Interface being brought down
			ifup        0x0020  Interface being brought up
			rx_err      0x0040  Receive error
			tx_err      0x0080  Transmit error
			tx_queued   0x0100  Transmit queueing
			intr        0x0200  Interrupt handling
			tx_done     0x0400  Transmit completion
			rx_status   0x0800  Receive completion
			pktdata     0x1000  Packet contents
			hw          0x2000  Hardware status
			wol         0x4000  Wake-on-LAN status

			The precise meanings of these type flags differ
			between drivers.
*/

static u32 xpcxd_get_msglevel(struct net_device *netdev)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return xpcxd_msglvl_level;
}

static void xpcxd_set_msglevel(struct net_device *netdev, u32 data)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_msglvl_level = data;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"New msglevel setting is data: 0x%x xpcxd_msglvl_level: 0x%x",
		data, xpcxd_msglvl_level);

	if (xpcxd_msglvl_level & NETIF_MSG_LINK)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_LINK is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TIMER)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_TIMER is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_INTR)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_INTR is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_RX_STATUS)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_RX_STATUS is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_PKTDATA)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_PKTDATA is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TX_DONE)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_TX_DONE is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Message level NETIF_MSG_TX_QUEUED is ON");
}

static u32 xpcxd_rss_indir_size(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return xreg_desc_bytes(XREG_ID_PCXD_RX_RSS_INDRCT_TBL);
}

static u32 xpcxd_get_rxfh_key_size(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return XPCXD_RSS_SECRET_KEY_SIZE;
}

#if (defined __XPCI_ETHTOOL_NEW_API__) || (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 8, 0))
static int xpcxd_get_rxfh(struct net_device *netdev, struct ethtool_rxfh_param *rxfh_param)
{
	return 0;
}

static int xpcxd_set_rxfh(struct net_device *netdev,
			  struct ethtool_rxfh_param *rxfh_param,
			  struct netlink_ext_ack *extack)
{
	return 0;
}
#else
static int xpcxd_get_rxfh(struct net_device *netdev, u32 *indir, u8 *key,
			  u8 *hfunc)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (key)
		memcpy(key, rss_secret_key, xpcxd_get_rxfh_key_size(netdev));

	return 0;
}

static int xpcxd_set_rxfh(struct net_device *netdev, const u32 *indir,
			  const u8 *key, const u8 hfunc)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Fill out the rss hash key */
	if (key) {
		memcpy(rss_secret_key, key, xpcxd_get_rxfh_key_size(netdev));
		xpcxd_rss_hash_key_write();
	}

	return 0;
}
#endif

#ifdef __XPCXD_STATS64__
/* Calculate and fill ethtool strings array with statistics */
static void xpcxd_get_ethtool_stats(struct net_device *netdev,
				    struct ethtool_stats *estats, u64 *data)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	unsigned int si;
	unsigned int out = 0;
	struct rtnl_link_stats64 net_stats;
	struct rtnl_link_stats64 *pnet_stats = &net_stats;
	struct xpcxd_stats *pstats = &net_priv->stats;
	char *p = NULL;
	uint32_t ring_id = 0;

	xpcxd_get_stats64(netdev, pnet_stats);

	/* Recompute aggregate driver stats from per-ring stats per read */
	memset(&net_priv->stats, 0, sizeof(net_priv->stats));

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		net_priv->stats.rx_unicast +=
			net_priv->txr[ring_id].stats.rx_unicast;
		net_priv->stats.rx_broadcast +=
			net_priv->txr[ring_id].stats.rx_broadcast;

		net_priv->stats.rx_underflow_events +=
			net_priv->rxr[ring_id].stats.rx_underflow_events,
			net_priv->stats.rx_sub_threshold +=
			net_priv->rxr[ring_id].stats.rx_sub_threshold,
			net_priv->stats.rx_sub_refill_throttle +=
			net_priv->rxr[ring_id].stats.rx_sub_refill_throttle,
			net_priv->stats.rx_sub_ring_starve_no_db +=
			net_priv->rxr[ring_id].stats.rx_sub_ring_starve_no_db,
			net_priv->stats.rx_osc_empty_sub_prime +=
			net_priv->rxr[ring_id].stats.rx_osc_empty_sub_prime,
			net_priv->stats.rx_cmpl_threshold +=
			net_priv->rxr[ring_id].stats.rx_cmpl_threshold,
			net_priv->stats.rx_cmpl_full_napi_held +=
			net_priv->rxr[ring_id].stats.rx_cmpl_full_napi_held,
			net_priv->stats.rx_cmpl_low_hw_napi_held +=
			net_priv->rxr[ring_id].stats.rx_cmpl_low_hw_napi_held,
			net_priv->stats.rx_credits_slash +=
			net_priv->rxr[ring_id].stats.rx_credits_slash,
			net_priv->stats.rx_credits_restore +=
			net_priv->rxr[ring_id].stats.rx_credits_restore;

		net_priv->stats.rx_page_alloc_err +=
			net_priv->rxr[ring_id].stats.rx_page_alloc_err;

		net_priv->stats.rx_l3_csm_err +=
			net_priv->rxr[ring_id].stats.rx_l3_csm_err;
		net_priv->stats.rx_l4_csm_err +=
			net_priv->rxr[ring_id].stats.rx_l4_csm_err;

		net_priv->stats.rx_dma_get_err +=
			net_priv->rxr[ring_id].stats.rx_dma_get_err;
		net_priv->stats.rx_swdesc_err +=
			net_priv->rxr[ring_id].stats.rx_swdesc_err;
		net_priv->stats.rx_page_err +=
			net_priv->rxr[ring_id].stats.rx_page_err;
		net_priv->stats.rx_state_err +=
			net_priv->rxr[ring_id].stats.rx_state_err;
		net_priv->stats.rx_page_state_les_then_free_err +=
			net_priv->rxr[ring_id]
				.stats.rx_page_state_les_then_free_err;
		net_priv->stats.rx_swdesc_addr_err +=
			net_priv->rxr[ring_id].stats.rx_swdesc_addr_err;
		net_priv->stats.rx_free_ref_cnt_0_page +=
			net_priv->rxr[ring_id].stats.rx_free_ref_cnt_0_page;
		net_priv->stats.hw_csum_rx_error +=
			net_priv->rxr[ring_id].stats.hw_csum_rx_error;
		net_priv->stats.errors += net_priv->rxr[ring_id].stats.errors;
		net_priv->stats.dropped += net_priv->rxr[ring_id].stats.dropped;
		net_priv->stats.rx_drop_events +=
			net_priv->rxr[ring_id].stats.rx_drop_events;
		net_priv->stats.rx_sw_sub_posted_hw +=
			net_priv->rxr[ring_id].stats.rx_sw_sub_posted_hw;
		net_priv->stats.rx_sw_cmpl_returned +=
			net_priv->rxr[ring_id].stats.rx_sw_cmpl_returned;
		net_priv->stats.cmpl_irq_cnt +=
			net_priv->rxr[ring_id].stats.cmpl_irq_cnt;

		net_priv->stats.rx_wrong_page_state +=
			net_priv->rxr[ring_id].stats.rx_wrong_page_state;
		net_priv->stats.rx_mtu_exceeded +=
			net_priv->rxr[ring_id].stats.rx_mtu_exceeded;
		net_priv->stats.rx_stop_drop_all +=
			net_priv->rxr[ring_id].stats.rx_stop_drop_all;
		net_priv->stats.rx_stop_packets_stop +=
			net_priv->rxr[ring_id].stats.rx_stop_packets_stop;
		net_priv->stats.rx_stop_build_skb +=
			net_priv->rxr[ring_id].stats.rx_stop_build_skb;
		net_priv->stats.rx_stop_add_frag_failed +=
			net_priv->rxr[ring_id].stats.rx_stop_add_frag_failed;
		net_priv->stats.rx_fill_sw_desc_null +=
			net_priv->rxr[ring_id].stats.rx_fill_sw_desc_null;
		net_priv->stats.rx_fill_fatal_oom +=
			net_priv->rxr[ring_id].stats.rx_fill_fatal_oom;
		net_priv->stats.rx_stop_dbg_rx_abort +=
			net_priv->rxr[ring_id].stats.rx_stop_dbg_rx_abort;
#ifdef __XPCXD_RX_PKT_SIZE_HISTOGRAM__
		net_priv->stats.rx_pkt_size_0_255 +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_0_255;
		net_priv->stats.rx_pkt_size_256_511 +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_256_511;
		net_priv->stats.rx_pkt_size_512_1023 +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_512_1023;
		net_priv->stats.rx_pkt_size_1024_4095 +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_1024_4095;
		net_priv->stats.rx_pkt_size_4096_8191 +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_4096_8191;
		net_priv->stats.rx_pkt_size_8192_plus +=
			net_priv->rxr[ring_id].stats.rx_pkt_size_8192_plus;
#endif /* __XPCXD_RX_PKT_SIZE_HISTOGRAM__ */
		net_priv->stats.tx_unicast +=
			net_priv->txr[ring_id].stats.tx_unicast;
		net_priv->stats.tx_multicast +=
			net_priv->txr[ring_id].stats.tx_multicast;
		net_priv->stats.tx_broadcast +=
			net_priv->txr[ring_id].stats.tx_broadcast;

		net_priv->stats.tx_underflow_events +=
			net_priv->txr[ring_id].stats.tx_underflow_events,
			net_priv->stats.tx_sub_threshold +=
			net_priv->txr[ring_id].stats.tx_sub_threshold,
			net_priv->stats.tx_cmpl_threshold +=
			net_priv->txr[ring_id].stats.tx_cmpl_threshold,
			net_priv->stats.tx_alignment_error +=
			net_priv->txr[ring_id].stats.tx_alignment_error;
		net_priv->stats.tx_skb_realigned_256b +=
			net_priv->txr[ring_id].stats.tx_skb_realigned_256b;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
		net_priv->stats.tx_pkt_size_64_128 +=
			net_priv->txr[ring_id].stats.tx_pkt_size_64_128;
		net_priv->stats.tx_pkt_size_128_256 +=
			net_priv->txr[ring_id].stats.tx_pkt_size_128_256;
		net_priv->stats.tx_pkt_size_256_plus +=
			net_priv->txr[ring_id].stats.tx_pkt_size_256_plus;
#endif /* __XPCXD_TX_PKT_SIZE_HISTOGRAM__ */
		net_priv->stats.tx_xdp_packets +=
			net_priv->txr[ring_id].stats.tx_xdp_packets;
		net_priv->stats.tx_xdp_bytes +=
			net_priv->txr[ring_id].stats.tx_xdp_bytes;
		net_priv->stats.tx_vlan_packets +=
			net_priv->txr[ring_id].stats.tx_vlan_packets;
	}

	for (si = 0; si < XPCXD_GLOBAL_STATS_LEN; si++) {
		const struct xpcxd_eth_stats *st = &xpcxd_gstrings_stats[si];

		switch (st->type) {
		case NETDEV_STATS:
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
					 "NETDEV_STATS: %s | %d",
					 st->stat_string, st->stat_offset);
			p = (char *)pnet_stats + st->stat_offset;
			data[out++] = (st->sizeof_stat == sizeof(u64)) ?
					      *(u64 *)p :
					      *(u32 *)p;
			break;
		case XPCXD_STATS:
			if (xpcxd_ethtool_stat_is_global(st->stat_string)) {
				xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
						 "XPCXD_STATS (agg): %s | %d",
						 st->stat_string, st->stat_offset);
				p = (char *)pstats + st->stat_offset;
				data[out++] =
					(st->sizeof_stat == sizeof(u64)) ?
						*(u64 *)p :
						*(u32 *)p;
			}
			break;
		default:
			break;
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		for (si = 0; si < XPCXD_GLOBAL_STATS_LEN; si++) {
			const struct xpcxd_eth_stats *st = &xpcxd_gstrings_stats[si];

			if (st->type != XPCXD_STATS ||
			    xpcxd_ethtool_stat_is_global(st->stat_string))
				continue;
			data[out++] = xpcxd_ethtool_read_xstat(net_priv, ring_id,
							       st);
			// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			// 		 "Data ring%u %s:[%lld]", ring_id,
			// 		 st->stat_string, data[out - 1]);
		}
	}
}
#endif /* __XPCXD_STATS64__ */

static void xpcxd_get_channels(struct net_device *netdev,
			       struct ethtool_channels *ch)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	/* report maximum channels */
	ch->max_combined = net_priv->num_rings;

	ch->max_rx = net_priv->num_rings;
	ch->max_tx = net_priv->num_rings;

	ch->rx_count = xpcxd_rss_enabled ? XPCXD_NUM_OF_RSS_QUEUES : 1;
	ch->tx_count = xpcxd_rss_enabled ? XPCXD_NUM_OF_RSS_QUEUES : 1;

	/* record RSS queues */
	ch->combined_count = xpcxd_rss_enabled ? XPCXD_NUM_OF_RSS_QUEUES : 1;
}

static int xpcxd_set_channels(struct net_device *netdev,
			      struct ethtool_channels *ch)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return 0;
}

/* Get ethtool statistics array and return it to user space  */
static void xpcxd_get_strings(struct net_device *netdev, u32 stringset,
			      u8 *data)
{
	char *p = (char *)data;
	int i;

	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: %d", stringset);

	switch (stringset) {
	case ETH_SS_STATS:
#ifdef __XPCXD_STATS64__
		for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
			const struct xpcxd_eth_stats *st = &xpcxd_gstrings_stats[i];

			if (st->type == NETDEV_STATS ||
			    (st->type == XPCXD_STATS &&
			     xpcxd_ethtool_stat_is_global(st->stat_string))) {
				memcpy(p, st->stat_string, ETH_GSTRING_LEN);
				// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				// 		 "STRING[%d]: [%s]", i,
				// 		 st->stat_string);
				p += ETH_GSTRING_LEN;
			}
		}
		{
			struct xpcxd_priv *np = netdev_priv(netdev);
			unsigned int r;

			for (r = 0; r < np->num_rings; r++) {
				for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
					const struct xpcxd_eth_stats *st =
						&xpcxd_gstrings_stats[i];

					if (st->type != XPCXD_STATS ||
					    xpcxd_ethtool_stat_is_global(
						    st->stat_string))
						continue;
					xpcxd_ethtool_ring_stat_name(
						p, r, st->stat_string);
					// xpcxd_dbg_netdev(
					// 	NETIF_MSG_DRV, netdev,
					// 	"STRING ring%u: [%s]", r, p);
					p += ETH_GSTRING_LEN;
				}
			}
		}
#else
		for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
			memcpy(p, xpcxd_gstrings_stats[i].stat_string,
			       ETH_GSTRING_LEN);
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
					 "STRING[%d]: [%s]", i,
					 xpcxd_gstrings_stats[i].stat_string);
			p += ETH_GSTRING_LEN;
		}
#endif /* __XPCXD_STATS64__ */
		break;
	case ETH_SS_PRIV_FLAGS:
		memcpy(data, xpcxd_priv_flags_strings,
		       XPCXD_PRIV_FLAGS_STR_LEN * ETH_GSTRING_LEN);
		break;
	}
}

static int xpcxd_get_sset_count(struct net_device *netdev, int sset)
{
	switch (sset) {
	case ETH_SS_STATS:
#ifdef __XPCXD_STATS64__
		return (int)xpcxd_ethtool_stats_count(netdev);
#else
		return XPCXD_GLOBAL_STATS_LEN;
#endif
	case ETH_SS_PRIV_FLAGS:
		return XPCXD_PRIV_FLAGS_STR_LEN;
	default:
		return -EOPNOTSUPP;
	}
}

int xpcxd_tx_stat_clear_regs(struct net_device *netdev)
{
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_DATA_RD_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_DATA_RD_RS, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_PKT_CS_OUT, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_PKT_L3_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CHL_PKT_WO_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CMP_UNIT_D_WR_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_ERR_GLB0, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_ERR_GLB1, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_ERR_PRS0, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_ERR_PRS1, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_FCH_DESC_RD_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_TX_STTS_FCH_DESC_RD_RS, 0);

	return 0;
}

int xpcxd_tx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id)
{
	u64 z[2] = { 0 };
	int ret = 0;

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DB),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DB), ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DB), (u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_PKT), ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_PKT), (u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	/*
	 * Zero the SW per-ring accumulators that xpcxd_get_stats64()
	 * sums into rtnl_link_stats64 (ifconfig / ip -s / sysfs
	 * /sys/class/net/<if>/statistics/). Without this, the priv-flag
	 * handler only zeroed HW mirror registers and netdev-level
	 * tx_packets / tx_bytes / tx_errors / tx_dropped kept showing
	 * pre-clear values. Concurrency: matches the single-writer /
	 * 64-bit-atomic-on-supported-archs assumption documented above
	 * xpcxd_pkt_stats_inc() in xpcxd.h. int_enabled is preserved so
	 * we don't lie about the current IRQ-rearm state to NAPI / IRQ
	 * paths (xpcxd_main.c xpcxd_*_napi_poll()).
	 */
	{
		struct xpcxd_priv *net_priv = netdev_priv(netdev);
		struct xpcxd_ring *ring;
		bool int_was_enabled;

		if (ring_id >= net_priv->num_rings)
			return -EINVAL;

		ring = &net_priv->txr[ring_id];
		int_was_enabled = READ_ONCE(ring->stats.int_enabled);
		memset(&ring->stats, 0, sizeof(ring->stats));
		WRITE_ONCE(ring->stats.int_enabled, int_was_enabled);
	}

	return 0;
}

static void xpcxd_dump_ring_stats_extra(struct net_device *netdev, const char *role,
					struct xpcxd_stats *st)
{
	netdev_info(netdev,
		    "xpcxd:   %s rx_last_db_desc_cnt: %u rx_cmpl_irq_max_delta_jiffies: %u",
		    role, st->rx_last_db_desc_cnt, st->rx_cmpl_irq_max_delta_jiffies);
	netdev_info(netdev,
		    "xpcxd:   %s rx_cmpl_poll_hist: %u %u %u delta_jif: %u %u %u",
		    role, st->rx_cmpl_poll_hist[0], st->rx_cmpl_poll_hist[1],
		    st->rx_cmpl_poll_hist[2], st->rx_cmpl_poll_hist_delta_jiffies[0],
		    st->rx_cmpl_poll_hist_delta_jiffies[1],
		    st->rx_cmpl_poll_hist_delta_jiffies[2]);
	netdev_info(netdev,
		    "xpcxd:   %s rx_cmpl_poll_prev_jiffy: %lu cmpl_irq_cnt: %u prev_cmpl_irq_cnt: %u prev_packets: %u",
		    role, st->rx_cmpl_poll_prev_jiffy, st->cmpl_irq_cnt,
		    st->prev_cmpl_irq_cnt, st->prev_packets);
	netdev_info(netdev,
		    "xpcxd:   %s cmpl_irq_last_jiffy: %lu cmpl_prev_jiffy: %lu xmit_prev_jiffy: %lu rx_prev_jiffy: %lu int_enabled: %d",
		    role, st->cmpl_irq_last_jiffy, st->cmpl_prev_jiffy,
		    st->xmit_prev_jiffy, st->rx_prev_jiffy, st->int_enabled);
}

static void xpcxd_dump_ring_xpcxd_stats_fields(struct net_device *netdev,
					       const char *role,
					       struct xpcxd_stats *st)
{
	unsigned int i;

	for (i = 0; i < XPCXD_GSTRING_STATS_LEN; i++) {
		const struct xpcxd_eth_stats *e = &xpcxd_gstrings_stats[i];
		unsigned long long v;

		if (e->type != XPCXD_STATS)
			continue;
		if (xpcxd_ethtool_stat_is_global(e->stat_string))
			continue;

		if (e->sizeof_stat == sizeof(u64))
			v = *(u64 *)((char *)st + e->stat_offset);
		else if (e->sizeof_stat == sizeof(u32))
			v = *(u32 *)((char *)st + e->stat_offset);
		else
			continue;

		netdev_info(netdev, "xpcxd:   %s %.*s: %llu", role,
			    ETH_GSTRING_LEN, e->stat_string, v);
	}

	if (!strcmp(role, "rx"))
		xpcxd_dump_ring_stats_extra(netdev, role, st);
}

int xpcxd_ring_stats_dump_per_ring(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id;
	unsigned int shown = 0;

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		struct xpcxd_ring *rxr = &net_priv->rxr[ring_id];

		if (!xpcxd_ring_sw_active(net_priv, ring_id, netdev))
			continue;

		shown++;
		netdev_info(
			netdev,
			"xpcxd: ======== Ring [%u] (per-queue driver stats) ========",
			ring_id);

		netdev_info(netdev, "xpcxd: --- RX ---");
		{
			u32 sub_free =
				rxr->sub.size - xpcxd_get_rx_sub_ring_space(rxr);
			u32 cmpl_free = xpcxd_get_cmpl_ring_space(rxr);

			netdev_info(
				netdev,
				"xpcxd:   sub_free: %u cmpl_free: %u sub_ring_size: %u cmpl_ring_size: %u",
				sub_free, cmpl_free, rxr->sub.size, rxr->cmp.size);
		}
		xpcxd_dump_ring_xpcxd_stats_fields(netdev, "rx", &rxr->stats);

		netdev_info(netdev, "xpcxd: --- TX ---");
		xpcxd_dump_ring_xpcxd_stats_fields(netdev, "tx",
						   &net_priv->txr[ring_id].stats);
	}

	if (!shown)
		netdev_info(
			netdev,
			"xpcxd: no active rings (need interface up and tx_rx_enabled)");

	return 0;
}

int xpcxd_tx_stat_dump_short(struct net_device *netdev)
{
	return xpcxd_ring_stats_dump_per_ring(netdev);
}

int xpcxd_tx_stat_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	const struct xreg_desc *d_glb0 =
		xreg_desc(XREG_ID_PCXD_TX_STTS_ERR_GLB0);
	const struct xreg_desc *d_glb1 =
		xreg_desc(XREG_ID_PCXD_TX_STTS_ERR_GLB1);
	const struct xreg_desc *d_prs0 =
		xreg_desc(XREG_ID_PCXD_TX_STTS_ERR_PRS0);
	const struct xreg_desc *d_prs1 =
		xreg_desc(XREG_ID_PCXD_TX_STTS_ERR_PRS1);
	uint32_t ring_id = 0;
	u64 raw;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_DATA_RD_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_DATA_RD_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_DATA_RD_RS: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_DATA_RD_RS));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_PKT_CS_OUT: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_PKT_CS_OUT));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_PKT_L3_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_PKT_L3_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_PKT_WO_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CHL_PKT_WO_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CMP_UNIT_D_WR_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CMP_UNIT_D_WR_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS));

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_TX_STTS_ERR_GLB0);
	if (d_glb0) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_GLB0_DB_ADDR_VIOLATION: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
			XREG_FIELD_PCXD_TX_STTS_ERR_GLB0_DB_ADDR_VIOLATION));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
		XREG_FIELD_PCXD_TX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_TX_STTS_ERR_GLB1);
	if (d_glb1) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_GLB1_TLP_POISON: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb1,
			XREG_FIELD_PCXD_TX_STTS_ERR_GLB1_TLP_POISON));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb1,
			XREG_FIELD_PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_TX_STTS_ERR_PRS0);
	if (d_prs0) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS0_PRS_NON_IP_PKT: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS0_PRS_NON_IP_PKT));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS_PRS0_IPV6_HDR_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_TX_STTS_ERR_PRS1);
	if (d_prs1) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
		XREG_FIELD_PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
		XREG_FIELD_PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS1_PRS_IPLEN_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS1_PRS_IPLEN_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_TX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
			XREG_FIELD_PCXD_TX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL));
	}

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_FCH_DESC_RD_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_FCH_DESC_RD_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_FCH_DESC_RD_RS: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_TX_STTS_FCH_DESC_RD_RS));

	xpcxd_tx_stat_dump_short(netdev);

	for (ring_id = 0; ring_id < XPCXD_MAX_RING_NUM; ring_id++) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"---------- Ring [%d] MEMCFG statistics ----------",
			ring_id);

		if (ring_id < net_priv->num_rings) {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"---------- Ring [%d] ACTIVE   ----------",
				ring_id);
		} else {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"---------- Ring [%d] INACTIVE ----------",
				ring_id);
		}

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_BRG_RING_PKT[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CHL_DESC_RD[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_FCH_DB[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DB, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_FCH_DESC[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DESC, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_FCH_PKT[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_PKT, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL,
				ring_id));
	}

	return 0;
}

int xpcxd_rx_stat_clear_regs(struct net_device *netdev)
{
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_GLB_MAC_PKT, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_PKT_CS_OUT, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_PKT_L3_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_PKT_WO_CS_EN, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CHL_WR_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CMP_UNIT_D_WR_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_ERR_GLB0, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_ERR_GLB1, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_ERR_PRS0, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_ERR_PRS1, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_FCH_DESC_RD_RQ, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_FCH_DESC_RD_RS, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_RSS_GRP_ID, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_RSS_INDR_TBL, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_RSS_QID_TBL, 0);
	xpcxd_xreg_write_mmio(XREG_ID_PCXD_RX_STTS_RSS_RING_ID, 0);

	return 0;
}

int xpcxd_rx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id)
{
	u64 z[2] = { 0 };
	int ret = 0;

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DB),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DB), ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DB), (u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DESC),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DESC),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DESC),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_PKT),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_PKT), ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_PKT), (u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		(char *)xreg_id_name(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL),
		xreg_memcfg_msel(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL),
		ring_id,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL),
		(u8 *)z);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	/*
	 * Zero the SW per-ring accumulators that xpcxd_get_stats64()
	 * sums into rtnl_link_stats64 (ifconfig / ip -s / sysfs
	 * /sys/class/net/<if>/statistics/). Without this, the priv-flag
	 * handler only zeroed HW mirror registers and netdev-level
	 * rx_packets / rx_bytes / rx_errors / rx_dropped / multicast /
	 * rx_crc_errors kept showing pre-clear values. Concurrency
	 * model matches xpcxd_pkt_stats_inc() in xpcxd.h. int_enabled
	 * is preserved so we don't lie about the current IRQ-rearm
	 * state to NAPI / IRQ paths (xpcxd_main.c xpcxd_rx_poll()).
	 */
	{
		struct xpcxd_priv *net_priv = netdev_priv(netdev);
		struct xpcxd_ring *ring;
		bool int_was_enabled;

		if (ring_id >= net_priv->num_rings)
			return -EINVAL;

		ring = &net_priv->rxr[ring_id];
		int_was_enabled = READ_ONCE(ring->stats.int_enabled);
		memset(&ring->stats, 0, sizeof(ring->stats));
		WRITE_ONCE(ring->stats.int_enabled, int_was_enabled);
	}

	return 0;
}

int xpcxd_rx_stat_dump_short(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");
	return xpcxd_ring_stats_dump_per_ring(netdev);
}

int xpcxd_rx_stat_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	const struct xreg_desc *d_glb0 =
		xreg_desc(XREG_ID_PCXD_RX_STTS_ERR_GLB0);
	const struct xreg_desc *d_glb1 =
		xreg_desc(XREG_ID_PCXD_RX_STTS_ERR_GLB1);
	const struct xreg_desc *d_prs0 =
		xreg_desc(XREG_ID_PCXD_RX_STTS_ERR_PRS0);
	const struct xreg_desc *d_prs1 =
		xreg_desc(XREG_ID_PCXD_RX_STTS_ERR_PRS1);
	uint32_t ring_id = 0;
	u64 raw;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_GLB_MAC_PKT: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_GLB_MAC_PKT));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_CHL_PKT_CS_OUT: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_PKT_CS_OUT));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_PKT_L3_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_PKT_L3_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_PKT_WO_CS_EN: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_PKT_WO_CS_EN));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_CHL_WR_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CHL_WR_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CMP_UNIT_D_WR_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CMP_UNIT_D_WR_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS));

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_RX_STTS_ERR_GLB0);
	if (d_glb0) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB0_DB_ADDR_VIOLATION: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB0_DB_ADDR_VIOLATION));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
		XREG_FIELD_PCXD_RX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB0_BD_LEN0: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB0_BD_LEN0));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB0_RSS_RING_ID_ERR: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb0,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB0_RSS_RING_ID_ERR));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_RX_STTS_ERR_GLB1);
	if (d_glb1) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB1_TLP_POISON: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb1,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB1_TLP_POISON));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb1,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB1_RING_UNDERFLOW));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_GLB1_CS_VALIDATION_ERR: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_glb1,
			XREG_FIELD_PCXD_RX_STTS_ERR_GLB1_CS_VALIDATION_ERR));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_RX_STTS_ERR_PRS0);
	if (d_prs0) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_PRS0_PRS_NON_IP_PKT: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS0_PRS_NON_IP_PKT));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs0,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL));
	}

	raw = xpcxd_xreg_read_mmio(XREG_ID_PCXD_RX_STTS_ERR_PRS1);
	if (d_prs1) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
		XREG_FIELD_PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_ERR_PRS1_IPV6_HDR_LEN_GT_256B_GET: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
		XREG_FIELD_PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_ERR_PRS1_IPLEN_VIOL_GET: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS1_PRS_IPLEN_VIOL));
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_RX_ERR_PRS1_IPV4_IHL_VIOL_GET: %d",
			(int)xreg_field_get_idx_u64(
			raw, d_prs1,
			XREG_FIELD_PCXD_RX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL));
	}

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_FCH_DESC_RD_RQ: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_FCH_DESC_RD_RQ));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_FCH_DESC_RD_RS: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_FCH_DESC_RD_RS));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_RSS_GRP_ID: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_RSS_GRP_ID));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_RSS_INDR_TBL: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_RSS_INDR_TBL));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_RSS_QID_TBL: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_RSS_QID_TBL));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_RX_STTS_RSS_RING_ID: [%lld]",
		(long long)xpcxd_xreg_read_mmio(
			XREG_ID_PCXD_RX_STTS_RSS_RING_ID));

	xpcxd_rx_stat_dump_short(netdev);

	for (ring_id = 0; ring_id < XPCXD_MAX_RING_NUM; ring_id++) {
		if (ring_id < net_priv->num_rings) {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"---------- Ring [%d] ACTIVE   ----------",
				ring_id);
		} else {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"---------- Ring [%d] INACTIVE ----------",
				ring_id);
		}

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CHL_DESC_RD[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_FCH_DB[%d]: [%lld]", ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DB, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_FCH_DESC[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DESC, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_FCH_PKT[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_PKT, ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL,
				ring_id));

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL[%d]: [%lld]",
			ring_id,
			(long long)xpcxd_memcfg_stat_u64(
				XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL,
				ring_id));
	}

	return 0;
}

int xpcxd_rx_get_underflow_cnt(void)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = xreg_desc(XREG_ID_PCXD_RX_STTS_ERR_GLB1);
	u64 raw;

	if (!p || !d) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_rx_get_underflow_cnt: missing profile/desc");
		return 0;
	}
	raw = xpci_read64_fast(
		xreg_addr(p, XREG_ID_PCXD_RX_STTS_ERR_GLB1, 0, 0));
	return (int)xreg_field_get_idx_u64(
		raw, d, XREG_FIELD_PCXD_RX_STTS_ERR_GLB1_TLP_POISON);
}

int xpcxd_tx_get_underflow_cnt(void)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = xreg_desc(XREG_ID_PCXD_TX_STTS_ERR_GLB1);
	u64 raw;
	int ufl;

	if (!p || !d) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_tx_get_underflow_cnt: missing profile/desc");
		return 0;
	}
	raw = xpci_read64_fast(
		xreg_addr(p, XREG_ID_PCXD_TX_STTS_ERR_GLB1, 0, 0));
	ufl = (int)xreg_field_get_idx_u64(
		raw, d, XREG_FIELD_PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW);

	xpcxd_notice(NETIF_MSG_DRV, "PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
		     ufl);

	return ufl;
}

static int xpcxd_tx_err_int(struct net_device *netdev, bool enable)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = xreg_desc(XREG_ID_PCXD_TX_ERR_INT);
	u64 v = 0;
	u64 en = enable ? 1 : 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%s]",
			 enable ? "SET" : "CLEAR");

	if (!p || !d) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_tx_err_int: missing profile/desc");
		return -1;
	}

	xreg_field_put_idx(
		&v, d, XREG_FIELD_PCXD_TX_ERR_INT_DB_ADDR_VIOL_INT_EN,
		en);
	xreg_field_put_idx(
		&v, d, XREG_FIELD_PCXD_TX_ERR_INT_DB_SIZE_VIOL_INT_EN,
		en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PKT_L4_ONLY_CS_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_PKT_NON_IP_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPV4_PROT_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPV6_NHDR_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPV6_ELEN_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPV6_HDR_TLP_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPLEN_VIOL_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_PRS_IPV4_IHL_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_ERR_INT_TLP_POISON_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_TX_ERR_INT_RING_UNDERFLOW_INT_EN, en);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_ERR_INT_INT_COALESCING,
			   xpcxd_err_int_coales_val);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_ERR_INT_INT_TIMEOUT,
			   xpcxd_err_int_timeout_val);

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_TX_ERR_INT: [%s]",
		  enable ? "SET" : "CLEAR");

	xreg_write(p, XREG_ID_PCXD_TX_ERR_INT, 0, 0, v);

	return 0;
}

static int xpcxd_rx_err_int(struct net_device *netdev, bool enable)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = xreg_desc(XREG_ID_PCXD_RX_ERR_INT);
	u64 v = 0;
	u64 en = enable ? 1 : 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%s]",
			 enable ? "SET" : "CLEAR");

	if (!p || !d) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_rx_err_int: missing profile/desc");
		return -1;
	}

	xreg_field_put_idx(
		&v, d, XREG_FIELD_PCXD_RX_ERR_INT_DB_ADDR_VIOL_INT_EN,
		en);
	xreg_field_put_idx(
		&v, d, XREG_FIELD_PCXD_RX_ERR_INT_DB_SIZE_VIOL_INT_EN,
		en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PKT_L4_ONLY_CS_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_PKT_NON_IP_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPV4_PROT_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPV6_NHDR_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPV6_ELEN_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPV6_HDR_TLP_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPLEN_VIOL_INT_EN, en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_PRS_IPV4_IHL_VIOL_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_CS_VALIDATION_ERR_INT_EN,
			   en);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_RX_ERR_INT_TLP_POISON_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_RING_UNDERFLOW_INT_EN, en);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_RX_ERR_INT_BD_LEN0_INT_EN,
			   en);
	xreg_field_put_idx(&v, d,
		  XREG_FIELD_PCXD_RX_ERR_INT_RSS_RING_ID_ERR_INT_EN, en);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_RX_ERR_INT_INT_COALESCING,
			   xpcxd_err_int_coales_val);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_RX_ERR_INT_INT_TIMEOUT,
			   xpcxd_err_int_timeout_val);

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_RX_ERR_INT: [%s]",
		  enable ? "SET" : "CLEAR");

	xreg_write(p, XREG_ID_PCXD_RX_ERR_INT, 0, 0, v);

	return 0;
}

static u32 xpcxd_get_priv_flags(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 priv_flags = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "IN: net_priv->priv_flags: 0x%x",
			 net_priv->priv_flags);

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_TX_STAT)
		priv_flags |= XPCXD_FLAG_DUMP_TX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_RX_STAT)
		priv_flags |= XPCXD_FLAG_DUMP_RX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_CLEAR_TX_STAT)
		priv_flags |= XPCXD_FLAG_CLEAR_TX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_CLEAR_RX_STAT)
		priv_flags |= XPCXD_FLAG_CLEAR_RX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_ENABLE_TX_ERR_INT)
		priv_flags |= XPCXD_FLAG_ENABLE_TX_ERR_INT;

	if (net_priv->priv_flags & XPCXD_FLAG_ENABLE_RX_ERR_INT)
		priv_flags |= XPCXD_FLAG_ENABLE_RX_ERR_INT;

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_RX_DESC_STATUS)
		priv_flags |= XPCXD_FLAG_DUMP_RX_DESC_STATUS;

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_TX_DESC_STATUS)
		priv_flags |= XPCXD_FLAG_DUMP_TX_DESC_STATUS;

#ifdef __XPCXD_CMD_TRACES__
	if (xpcxd_cfg_tbl[xpcxd_event_trace])
		priv_flags |= XPCXD_FLAG_EVENT_TRACE;
#endif

	if (net_priv->priv_flags & XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW)
		priv_flags |= XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW;

#ifdef __XPCXD_DEBUG__CT__
	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_TX)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_TX;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_RX)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_RX;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_ISR)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_ISR;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ALL_TX)
		priv_flags |= XPCXD_FLAG_DROP_ALL_TX;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ALL_RX)
		priv_flags |= XPCXD_FLAG_DROP_ALL_RX;

	if (net_priv->priv_flags & XPCXD_FLAG_IGNORE_RX_L3_CHKSUM)
		priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_IGNORE_RX_L4_CHKSUM)
		priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_RX_THRESHOLD)
		priv_flags |= XPCXD_FLAG_STOP_ON_RX_THRESHOLD;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR)
		priv_flags |= XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;
#endif
	if (net_priv->priv_flags & XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM)
		priv_flags |= XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_TX_MLD_NON_SHIM)
		priv_flags |= XPCXD_FLAG_DROP_TX_MLD_NON_SHIM;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT: npriv_flags: 0x%x",
			 priv_flags);

	return priv_flags;
}

static int xpcxd_set_priv_flags(struct net_device *netdev, u32 priv_flags)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: 0x%x", priv_flags);

	if (priv_flags & XPCXD_FLAG_DUMP_TX_STAT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Tx statistics requested");

		xpcxd_tx_stat_dump(netdev);
	}

	if (priv_flags & XPCXD_FLAG_DUMP_RX_STAT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Rx statistics requested");

		xpcxd_rx_stat_dump(netdev);
	}

	if (priv_flags & XPCXD_FLAG_DUMP_RX_DESC_STATUS) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Rx descriptor status requested");

		xpcxd_rx_desc_status_dump(netdev);
	}

	if (priv_flags & XPCXD_FLAG_DUMP_TX_DESC_STATUS) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Tx descriptor status requested");

		xpcxd_tx_desc_status_dump(netdev);
	}

#ifdef __XPCXD_CMD_TRACES__
	/*
	 * Priv-flag "event-trace" must drive xpcxd_cfg_tbl[xpcxd_event_trace],
	 * which gates xpcxd_opt_trace (see xpcxd.h; expands to xpcxd_trace).
	 * get_priv_flags reports this bit from cfg_tbl; previously set_priv_flags
	 * never updated it, so ethtool --set-priv-flags … event-trace had no effect.
	 */
	net_priv->priv_flags &= ~XPCXD_FLAG_EVENT_TRACE;
	if (priv_flags & XPCXD_FLAG_EVENT_TRACE) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable kernel event (opt-) traces");
		xpcxd_cfg_tbl[xpcxd_event_trace] = 1;
		net_priv->priv_flags |= XPCXD_FLAG_EVENT_TRACE;
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Disable kernel event (opt-) traces");
		xpcxd_cfg_tbl[xpcxd_event_trace] = 0;
	}
#endif

	if (priv_flags & XPCXD_FLAG_CLEAR_TX_STAT) {
		int ring_id = 0;

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Clear Tx statistics requested");

		xpcxd_tx_stat_clear_regs(netdev);

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++)
			xpcxd_tx_stat_clear_per_ring(netdev, ring_id);
	}

	if (priv_flags & XPCXD_FLAG_CLEAR_RX_STAT) {
		int ring_id = 0;

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Clear Rx statistics requested");

		xpcxd_rx_stat_clear_regs(netdev);

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++)
			xpcxd_rx_stat_clear_per_ring(netdev, ring_id);
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_ENABLE_TX_ERR_INT;
	xpcxd_tx_err_int(netdev, false);
	if (priv_flags & XPCXD_FLAG_ENABLE_TX_ERR_INT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable Tx error interrupts");

		xpcxd_enable_tx_err_interrupt = 1;
		xpcxd_tx_err_int(netdev, true);

		net_priv->priv_flags |= XPCXD_FLAG_ENABLE_TX_ERR_INT;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_ENABLE_RX_ERR_INT;
	xpcxd_rx_err_int(netdev, false);
	if (priv_flags & XPCXD_FLAG_ENABLE_RX_ERR_INT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable Rx error interrupts");

		xpcxd_enable_rx_err_interrupt = 1;
		xpcxd_rx_err_int(netdev, true);

		net_priv->priv_flags |= XPCXD_FLAG_ENABLE_RX_ERR_INT;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW;
	if (priv_flags & XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW)
		net_priv->priv_flags |= XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW;

#ifdef __XPCXD_DEBUG__CT__
	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_TX;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_TX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next Tx packet");

		xpcxd_tx_packets_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_TX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_RX;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_RX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next Rx packet");

		xpcxd_rx_packets_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_RX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_ISR;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_ISR) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next timer interrupt");

		xpcxd_stop_on_next_isr = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_ISR;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ALL_TX;
	if (priv_flags & XPCXD_FLAG_DROP_ALL_TX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Drop all Tx packets");

		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ALL_TX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ALL_RX;
	if (priv_flags & XPCXD_FLAG_DROP_ALL_RX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Drop all Rx packets");

		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ALL_RX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;
	if (priv_flags & XPCXD_FLAG_IGNORE_RX_L3_CHKSUM) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"Enable ignore L3 checksum error print/count");

		xpcxd_rx_ignore_l3_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);
	if (priv_flags & XPCXD_FLAG_IGNORE_RX_L4_CHKSUM) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"Enable ignore L4 checksum error print/count");

		xpcxd_rx_ignore_l4_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_RX_THRESHOLD;
	if (priv_flags & XPCXD_FLAG_STOP_ON_RX_THRESHOLD) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Stop on Rx ring threshold");

		xpcxd_rx_ring_threshold_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_RX_THRESHOLD;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;
	if (priv_flags & XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Tx drop badly aligned packets");

		xpcxd_tx_drop_on_alignment_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;
	}
#endif
	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM;
	if (priv_flags & XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM)
		net_priv->priv_flags |= XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM;

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_TX_MLD_NON_SHIM;
	if (priv_flags & XPCXD_FLAG_DROP_TX_MLD_NON_SHIM)
		net_priv->priv_flags |= XPCXD_FLAG_DROP_TX_MLD_NON_SHIM;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

const struct ethtool_ops xpcxd_ethtool_ops = {
	.get_drvinfo = xpcxd_get_drvinfo,
#ifdef __XPCXD_STATS64__
	.get_ethtool_stats = xpcxd_get_ethtool_stats,
#endif
	.get_link = ethtool_op_get_link,
	.get_channels = xpcxd_get_channels,
	.set_channels = xpcxd_set_channels,
	.get_pauseparam = xpcxd_get_pauseparam,
	.set_pauseparam = xpcxd_set_pauseparam,
	.get_msglevel = xpcxd_get_msglevel,
	.set_msglevel = xpcxd_set_msglevel,
	.get_rxfh_indir_size = xpcxd_rss_indir_size,
	.get_rxfh_key_size = xpcxd_get_rxfh_key_size,
	.get_ringparam = xpcxd_get_ringparam,
	.set_ringparam = xpcxd_set_ringparam,
	.get_rxfh = xpcxd_get_rxfh,
	.set_rxfh = xpcxd_set_rxfh,
	.get_strings = xpcxd_get_strings,
	.get_sset_count = xpcxd_get_sset_count,
	.get_priv_flags = xpcxd_get_priv_flags,
	.set_priv_flags = xpcxd_set_priv_flags,
};

void xpcxd_set_ethtool_ops(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	netdev->ethtool_ops = &xpcxd_ethtool_ops;

	/* Configuration presets */
#ifdef __XPCXD_DEBUG__CT__
	xpcxd_rx_ignore_l3_checksum_err ?
		(net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM) :
		0;
	xpcxd_rx_ignore_l4_checksum_err ?
		(net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM) :
		0;
#endif
#ifdef __XPCXD_CMD_TRACES__
	if (xpcxd_cfg_tbl[xpcxd_event_trace])
		net_priv->priv_flags |= XPCXD_FLAG_EVENT_TRACE;
#endif
	if (xpcxd_rx_cmpl_napi_hold_low_hw_credits)
		net_priv->priv_flags |= XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW;
	net_priv->priv_flags |= XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM;
	net_priv->priv_flags |= XPCXD_FLAG_DROP_TX_MLD_NON_SHIM;
}
