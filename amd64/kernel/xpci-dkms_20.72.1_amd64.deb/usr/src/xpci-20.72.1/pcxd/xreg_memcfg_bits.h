/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Bit extraction for 128-bit memcfg RX/TX ring status rows (same layout as DB
 * header). Used where generated xreg_layout has num_fields==0 for the row.
 * Field offsets match the chip register DB (same layout as gen_xreg_layout input).
 */
#ifndef XREG_MEMCFG_BITS_H_
#define XREG_MEMCFG_BITS_H_

#include <linux/types.h>

#define XREG_MEMCFG_RNG_STTS_ROW_BYTES 16U

static inline u16 xreg_memcfg_rng_stts_crd_prd_ptr(u64 lo)
{
	return (u16)(lo & 0xFFFF);
}

/* RX/TX RNG_STTS row low 64b: f_srd_prd_ptr @ bit offset 18 (see xreg_x2/x3). */
static inline u16 xreg_memcfg_rng_stts_srd_prd_ptr(u64 lo)
{
	return (u16)((lo >> 18) & 0xFFFF);
}

static inline u16 xreg_memcfg_rng_stts_srd_cns_ptr(u64 lo)
{
	return (u16)((lo >> 34) & 0xFFFF);
}

#endif /* XREG_MEMCFG_BITS_H_ */
