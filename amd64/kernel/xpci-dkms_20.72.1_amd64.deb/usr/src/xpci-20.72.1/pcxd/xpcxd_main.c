// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver init and configuration
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
#include <linux/panic_notifier.h>
#endif
#include <linux/mm.h>
#include <linux/prefetch.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/busy_poll.h>
#if IS_ENABLED(CONFIG_BPF_SYSCALL)
#include <net/xdp.h>
#endif

#if __has_include(<net/page_pool.h>)
#include <net/page_pool.h>
#else
#include <net/page_pool/types.h>
#include <net/page_pool/helpers.h>
#endif

#include "xpcxd_dbg.h"
#include "xpci_version.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xnetdev_common.h"

/* Including xpci_trace.h with CREATE_TRACE_POINTS defined will generate the
 * xpci and xpcxd tracepoint functions. This must be done exactly once across the
 * xpci driver. Must precede xpcxd.h so xpcxd_opt_trace() can expand to xpcxd_opt_trace().
 */
#define CREATE_TRACE_POINTS
#include "xpci_trace.h"
#undef CREATE_TRACE_POINTS

#include "xpcxd.h"
#include "xpcxd_os.h"

/* Bits 0,1: netif_running, IFF_UP — for xpcxd_drv_lifecycle detail field */
static int xpcxd_drv_lifecycle_detail(struct net_device *dev)
{
	int d = 0;

	if (!dev)
		return d;
	if (netif_running(dev))
		d |= 1;
	if (dev->flags & IFF_UP)
		d |= 2;
	return d;
}

#define XPCXD_ATTACH_DEV_NAME_LEN 64

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
#define netif_tx_napi_add netif_napi_add_tx_weight
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
extern struct atomic_notifier_head panic_notifier_list;
#endif

#ifdef __XPCI_NETIF_NAPI_ADD_HAS_WEIGHT__
#define XPCI_NETIF_NAPI_ADD(dev, napi, poll, weight)                           \
	netif_napi_add_weight((dev), (napi), (poll), (weight))
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
  #define XPCI_NETIF_NAPI_ADD(dev, napi, poll, weight) netif_napi_add_weight((dev), (napi), (poll), (weight))
#else
#define XPCI_NETIF_NAPI_ADD(dev, napi, poll, weight)                           \
	netif_napi_add((dev), (napi), (poll), (weight))
#endif
#endif

#ifdef __XPCI_NETIF_NAPI_ADD_HAS_WEIGHT__
#define XPCI_NETIF_NAPI_TX_ADD(dev, napi, poll, weight)                        \
	netif_napi_add_weight((dev), (napi), (poll), (weight))
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
#define XPCI_NETIF_NAPI_TX_ADD(dev, napi, tx_poll, tx_weight)                  \
	netif_napi_add_weight((dev), (napi), (tx_poll), (tx_weight))
#else
#define XPCI_NETIF_NAPI_TX_ADD(dev, napi, tx_poll, tx_weight)                  \
	netif_napi_add((dev), (napi), (tx_poll), (tx_weight))
#endif
#endif

int xpcxd_msglvl_level = XPCXD_NETIF_MSG_DEFAULT;

/********************************/
/* sysctl changeable parameters */
/********************************/

static int xpcxd_tx_coales_size_cmd = 1;
module_param_named(pcxd_tx_coales_size, xpcxd_tx_coales_size_cmd, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_coales_size,
		 "Tx coalescing batch size: 0 - Disable, Default = 1");

static int xpcxd_tx_coales_time_cmd = 2000000;
module_param_named(pcxd_tx_coales_time, xpcxd_tx_coales_time_cmd, uint, 0644);
MODULE_PARM_DESC(
	pcxd_tx_coales_time,
	"Tx coalescing time: 0 - Disable, Default = 2000000 (1 == 256 cycles)");

static int xpcxd_rx_coales_size_cmd = 1;
module_param_named(pcxd_rx_coales_size, xpcxd_rx_coales_size_cmd, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_coales_size,
		 "Rx coalescing batch size: 0 - Disable, Default = 1");

static int xpcxd_rx_coales_time_cmd = 2000000;
module_param_named(pcxd_rx_coales_time, xpcxd_rx_coales_time_cmd, uint, 0644);
MODULE_PARM_DESC(
	pcxd_rx_coales_time,
	"Rx coalescing time: 0 - Disable, Default = 2000000 (1 == 256 cycles)");

int xpcxd_tx_drop_all_cmd = 0;
module_param_named(pcxd_tx_drop_all, xpcxd_tx_drop_all_cmd, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_drop_all,
		 "Drop all Tx packets before send: 1 - Enable, Default = 0");

int xpcxd_rx_drop_all_cmd = 0;
module_param_named(pcxd_rx_drop_all, xpcxd_rx_drop_all_cmd, uint, 0644);
MODULE_PARM_DESC(
	pcxd_rx_drop_all,
	"Drop all Rx packets (loopback tests): 1 - Enable, Default = 0");

static int xpcxd_ifdown_strict_rx_drop_cmd = 1;
module_param_named(pcxd_ifdown_strict_rx_drop, xpcxd_ifdown_strict_rx_drop_cmd,
		   uint, 0644);
MODULE_PARM_DESC(
	pcxd_ifdown_strict_rx_drop,
	"Force strict ifdown behavior in non-standalone mode: 1 - Drop Rx while down, Default = 1");

static int xpcxd_tx_checksum_bypass_cmd = 0;
module_param_named(pcxd_tx_checksum_bypass, xpcxd_tx_checksum_bypass_cmd, uint,
		   0644);
MODULE_PARM_DESC(
	pcxd_tx_checksum_bypass,
	"Check Tx checksum (Tx HW offloading bypass): "
	"2 - Global, 1 - Selective, 0 - No bypass, Default = 0");

static int xpcxd_rx_checksum_bypass_cmd = 0;
module_param_named(pcxd_rx_checksum_bypass, xpcxd_rx_checksum_bypass_cmd, uint,
		   0644);
MODULE_PARM_DESC(
	pcxd_rx_checksum_bypass,
	"Check Rx checksum (Rx HW offloading bypass): "
	"2 - Global, 1 - Selective, 0 - No bypass, Default = 0");

static int xpcxd_check_l3_checksum_cmd = 1;
module_param_named(pcxd_check_l3_checksum, xpcxd_check_l3_checksum_cmd, uint,
		   0644);
MODULE_PARM_DESC(
	pcxd_check_l3_checksum,
	"Check L3 checksum (L3 HW offloading): 1 - Enable, Default = 1");

static int xpcxd_check_l4_checksum_cmd = 1;
module_param_named(pcxd_check_l4_checksum, xpcxd_check_l4_checksum_cmd, uint,
		   0644);
MODULE_PARM_DESC(
	pcxd_check_l4_checksum,
	"Check L4 checksum (L4 HW offloading): 1 - Enable, Default = 1");

static int xpcxd_rx_shaper_cmd = 1;
module_param_named(pcxd_rx_shaper, xpcxd_rx_shaper_cmd, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_shaper, "Rx Shaper: 1 - Enable, Default = 1");

/*****************************/
/* Init time only parameters */
/*****************************/

int xpcxd_loopback = 0;
module_param_named(pcxd_loopback, xpcxd_loopback, uint, 0644);
MODULE_PARM_DESC(pcxd_loopback, "0 = disabled, 1 = enabled, Default = 0");

int xpcxd_tx_enabled = 1; /* Set by ethtool */
module_param_named(pcxd_tx_enabled, xpcxd_tx_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_enabled, "0 = disabled, 1 = enabled, Default = 1");

int xpcxd_rx_enabled = 1; /* Set by ethtool */
module_param_named(pcxd_rx_enabled, xpcxd_rx_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_enabled, "0 = disabled, 1 = enabled, Default = 1");

static int xpcxd_int_mode = 0;
module_param_named(pcxd_int_mode, xpcxd_int_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_int_mode,
		 "0 = Interrupt, 1 = Hybrid, 2 - Polling, Default = 0");

int xpcxd_rss_enabled = 1;
module_param_named(pcxd_rss_enabled, xpcxd_rss_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_rss_enabled, "1 - Enabled, Default = 0 - Disabled");

static int xpcxd_rss_mode = 3;
module_param_named(pcxd_rss_mode, xpcxd_rss_mode, uint, 0644);
MODULE_PARM_DESC(
	pcxd_rss_mode,
	"RSS Mode: 0 - Explict, 1 - Hash Index, 2 - Group ID, 3 - Full, Default = 0");

int xpcxd_pfc_enabled = 0;
module_param_named(pcxd_pfc_enabled, xpcxd_pfc_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_pfc_enabled,
		 "Rx PFC: 1 - Enabled, Default = 0 - Disabled");

static int xpcxd_tx_sbm_rfl_mode = XPCXD_TX_SBM_RFL_MODE_DEFAULT;
static int xpcxd_tx_cmp_rfl_mode = XPCXD_TX_CMP_RFL_MODE_DEFAULT;
static int xpcxd_tx_coales_mode = XPCXD_TX_COALES_MODE_DEFAULT;
static int xpcxd_rx_coales_mode = XPCXD_RX_COALES_MODE_DEFAULT;

static int xpcxd_tx_budget = 256;
module_param_named(pcxd_tx_budget, xpcxd_tx_budget, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_budget, "Tx NAPI budget: Default = 256");

static int xpcxd_rx_budget = 64;
module_param_named(pcxd_rx_budget, xpcxd_rx_budget, uint, 0644);
MODULE_PARM_DESC(
	pcxd_rx_budget,
	"Rx NAPI budget (CMPL slots per poll). Higher drains more per softirq "
	"visit. Default = 64. Some kernels cap NAPI weight at 64; do not "
	"set > 64 if traffic fails to start.");

static int xpcxd_timer_isr_mode = 0;
module_param_named(pcxd_timer_isr_mode, xpcxd_timer_isr_mode, uint, 0644);
MODULE_PARM_DESC(
	xpcxd_timer_isr_mode,
	"Use periodic timer interrupt for stats dump: Default = 0 (disabled), 1 - Enabled)");

static int xpcxd_timer_isr_wakeup_time = 200;
module_param_named(pcxd_timer_isr_wakeup_time, xpcxd_timer_isr_wakeup_time,
		   uint, 0644);
MODULE_PARM_DESC(
	xpcxd_timer_isr_wakeup_time,
	"OS timer (hrtimer) period (ms) when pcxd_timer_isr_mode is enabled. Default = 200 (ms)");

static int xpcxd_tx_coales_isr_mode = 0;
module_param_named(pcxd_tx_coales_isr_mode, xpcxd_tx_coales_isr_mode, uint,
		   0644);
MODULE_PARM_DESC(
	xpcxd_tx_coales_isr_mode,
	"Tx coalescing timer interrupt: Default = 0 (disabled), 1 - Enabled)");

static int xpcxd_tx_coales_isr_wakeup_time = 1000;
module_param_named(pcxd_tx_coales_isr_wakeup_time,
		   xpcxd_tx_coales_isr_wakeup_time, uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_coales_isr_wakeup_time,
		 "Tx coalescing timer wakeup time: Default = 1000 (ms)");

int xpcxd_ring_threshold = 20;
module_param_named(pcxd_ring_threshold, xpcxd_ring_threshold, uint, 0644);
MODULE_PARM_DESC(xpcxd_ring_threshold,
		 "Ring threshold in % (ring space left): Default = 20");

int xpcxd_rx_sub_reserve_pct = 20;
module_param_named(pcxd_rx_sub_reserve_pct, xpcxd_rx_sub_reserve_pct, int,
		   0644);
MODULE_PARM_DESC(
	xpcxd_rx_sub_reserve_pct,
	"Rx SUB refill: keep at least this %% of ring slots free (0=off). "
	"Default=35 (aggressive headroom).");

int xpcxd_rx_fill_max_desc = 128;
module_param_named(pcxd_rx_fill_max_desc, xpcxd_rx_fill_max_desc, int, 0644);
MODULE_PARM_DESC(
	xpcxd_rx_fill_max_desc,
	"Rx SUB refill: max descriptors per rx_fill doorbell (0=unlimited). Default=64.");

int xpcxd_rx_sub_low_free_pct = 15;
module_param_named(pcxd_rx_sub_low_free_pct, xpcxd_rx_sub_low_free_pct, int,
		   0644);
MODULE_PARM_DESC(
	xpcxd_rx_sub_low_free_pct,
	"Rx SUB low-free threshold: percent (0..100) of ring size. When "
	">0 and SUB free slots drop below it, "
	"xpcxd_rx_credits_apply_slash() trims rx_credits by "
	"pcxd_rx_credits_slash_pct to keep SUB headroom. 0 disables the "
	"anti-oscillation slash entirely (rx_credits debt is replayed in "
	"full whenever SUB has room — perf-optimal on healthy hardware "
	"where transient OOM/DMA errors are rare). Out-of-range values "
	"fall back to 15. Default=15.");

int xpcxd_rx_credits_slash_pct = 75;
module_param_named(pcxd_rx_credits_slash_pct, xpcxd_rx_credits_slash_pct, int,
		   0644);
MODULE_PARM_DESC(
	xpcxd_rx_credits_slash_pct,
	"Rx rx_credits slash factor as percent of previous value when SUB is "
	"tight (1..100). 100=no slash; common steps: 50=x1/2, 75=x3/4 "
	"(default), 87=x7/8.");

/*
 * Optional PCIe/PCXB relaxed-ordering attribute programming (performance /
 * platform policy). Ring handoff uses dma_wmb/dma_rmb and valid/ownership
 * rules on descriptors; not implicit PCI transaction ordering from this knob.
 */
int xpcxd_pci_relaxed_ordering = 1;
module_param_named(pci_relaxed_ordering, xpcxd_pci_relaxed_ordering, uint,
		   0644);
MODULE_PARM_DESC(
	pci_relaxed_ordering,
	"1=on (default). Non-zero: set PCIe RELAX_EN + PCXB client RO bit.");

int xpcxd_l3_loopback_offset = ETH_HLEN;
module_param_named(pcxd_l3_loopback_offset, xpcxd_l3_loopback_offset, uint,
		   0644);
MODULE_PARM_DESC(
	xpcxd_l3_loopback_offset,
	"Default offset value for L3 offset in loopback mode: Default = 14");

int xpcxd_num_of_rings = 1;
module_param_named(num_of_rings, xpcxd_num_of_rings, uint, 0644);
MODULE_PARM_DESC(xpcxd_num_of_rings,
		 "Number of rings (Standalone mode): Default = 1");

int xpcxd_tx_ring_size = 512;
module_param_named(tx_ring_size, xpcxd_tx_ring_size, uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_ring_size, "Transmit ring size: Default = 512");

int xpcxd_rx_ring_size = 512;
module_param_named(rx_ring_size, xpcxd_rx_ring_size, uint, 0644);
MODULE_PARM_DESC(
	xpcxd_rx_ring_size,
	"Rx submit+CMPL ring depth (descriptors). Larger rings tolerate longer "
	"gaps between NAPI polls (e.g. same core at 100% CPU). Default = 512.");

uint xpcxd_rx_cmpl_napi_hold_low_hw_credits = 10;
module_param_named(rx_cmpl_napi_hold_low_hw_credits,
		   xpcxd_rx_cmpl_napi_hold_low_hw_credits, uint, 0644);
MODULE_PARM_DESC(
	xpcxd_rx_cmpl_napi_hold_low_hw_credits,
	"Percent (0..100) of Rx CMPL ring size for low-HW-credit NAPI hold; "
	"0=off. When ethtool priv-flag rx-cmpl-napi-hold-low-hw is on, "
	"threshold=(cmp.size*pct)/100 (min 1 if pct>0, capped below ring "
	"size). Default=10.");

static int xpcxd_threaded_napi = 0;
module_param_named(threaded_napi, xpcxd_threaded_napi, int, 0644);
MODULE_PARM_DESC(
	threaded_napi,
	"If non-zero, enable threaded NAPI before netif_napi_add: "
	"dev_set_threaded() when kernel < 6.17, netif_threaded_enable() "
	"when >= 6.17. Default=1.");

int xpcxd_mode_standalone = 0;
module_param_named(mode_standalone, xpcxd_mode_standalone, uint, 0644);
MODULE_PARM_DESC(
	xpcxd_mode_standalone,
	"Standalone mode - PCXD NetDev and HW init without RTNL API: Default = 0");

static int xpcxd_enable_tx_err_int_cmd = 1;
module_param_named(enable_tx_err_int, xpcxd_enable_tx_err_int_cmd, uint, 0644);
MODULE_PARM_DESC(xpcxd_enable_tx_err_int_cmd,
		 "Tx error interrupt handler enabled: Default = 1");

static int xpcxd_enable_rx_err_int_cmd = 1;
module_param_named(enable_rx_err_int, xpcxd_enable_rx_err_int_cmd, uint, 0644);
MODULE_PARM_DESC(xpcxd_enable_rx_err_int_cmd,
		 "Rx error interrupt handler enabled: Default = 1");

int xpcxd_tx_drop_on_alignment_err = 0;
module_param_named(pcxd_tx_drop_on_alignment_err,
		   xpcxd_tx_drop_on_alignment_err, uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_drop_on_alignment_err,
		 "Drop Tx packets on SKB/DMA alignment error: Default = 0");

int xpcxd_default_mtu = XPCXD_DEFAULT_MTU_SIZE;
module_param_named(pcxd_default_mtu, xpcxd_default_mtu, uint, 0644);
MODULE_PARM_DESC(xpcxd_default_mtu, "Default MTU: Default = 10200");

int xpcxd_rx_fill_slow_start_coeff = 16;
module_param_named(pcxd_rx_fill_slow_start_coeff,
		   xpcxd_rx_fill_slow_start_coeff, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_fill_slow_start_coeff,
		 "Slow start cofficient after no memory event: Default = 16");

static u16 pcxd_rss_ring_ids[XPCXD_MAX_RING_NUM] = { 0, 0, 0, 0, 0, 0, 0, 0 };
static u32 pcxd_ring_count = XPCXD_MAX_RING_NUM;

module_param_array(pcxd_rss_ring_ids, short, &pcxd_ring_count, 0660);
MODULE_PARM_DESC(pcxd_rss_ring_ids, "An array RSS ring Ids");

static int xpcxd_rss_ring_ids_override = 0;
module_param_named(pcxd_rss_ring_ids_override, xpcxd_rss_ring_ids_override, int,
		   0644);
MODULE_PARM_DESC(pcxd_rss_ring_ids_override,
		 "Override internal ring ids distrubution");

int xpcxd_event_trace_cmd = 1;
module_param_named(pcxd_event_trace, xpcxd_event_trace_cmd, int, 0644);
MODULE_PARM_DESC(xpcxd_event_trace_cmd,
		 "Enable event traces: Default = 1 (disabled)");

uint xpcxd_rx_refill_osc_min_arm_jiffies;
module_param_named(pcxd_rx_refill_osc_min_arm_jiffies,
		   xpcxd_rx_refill_osc_min_arm_jiffies, uint, 0444);
MODULE_PARM_DESC(
	xpcxd_rx_refill_osc_min_arm_jiffies,
	"Min jiffies between Rx refill-osc arms on idle CMPL polls (n==0); "
	"0=off. Module load only (no runtime reconfig). Default=0.");

/*
 * Per-packet RX UC/MC/BC accounting (rx_unicast / rx_multicast /
 * rx_broadcast in struct xpcxd_stats). This runtime knob lets operators
 * flip the per-packet ETH/IPv4/IPv6/ARP parse + classify branch on the
 * rx_cmpl() hot path without a rebuild.
 *
 * Runtime-writable
 * (/sys/module/xpci/parameters/pcxd_rx_stats_uc_mc_bc).
 */
int xpcxd_rx_stats_uc_mc_bc = 0;
module_param_named(pcxd_rx_stats_uc_mc_bc, xpcxd_rx_stats_uc_mc_bc, int, 0644);
MODULE_PARM_DESC(
	xpcxd_rx_stats_uc_mc_bc,
	"Per-packet RX unicast/multicast/broadcast classify on the "
	"rx_cmpl() hot path. 1=on (preserves historical counters), "
	"0=skip parse + classify per packet (counters freeze).");

/*
 * Per-packet TX UC/MC/BC accounting (tx_unicast / tx_multicast /
 * tx_broadcast in struct xpcxd_stats). Mirrors the RX gate above.
 *
 * Runtime-writable
 * (/sys/module/xpci/parameters/pcxd_tx_stats_uc_mc_bc).
 */
int xpcxd_tx_stats_uc_mc_bc = 1;
module_param_named(pcxd_tx_stats_uc_mc_bc, xpcxd_tx_stats_uc_mc_bc, int, 0644);
MODULE_PARM_DESC(
	xpcxd_tx_stats_uc_mc_bc,
	"Per-packet TX unicast/multicast/broadcast classify on the "
	"xpcxd_xmit() hot path. 1=on (default; preserves historical counters), "
	"0=skip parse + classify per packet (counters freeze).");

int xpcxd_tx_packets_stop = 0;
int xpcxd_rx_packets_stop = 0;
int xpcxd_stop_on_next_isr = 0;
int xpcxd_rx_ignore_l3_checksum_err =
	1; /* Don't drop packet on L3 checksum error by default */
int xpcxd_rx_ignore_l4_checksum_err =
	1; /* Don't drop packet on L4 checksum error by default */
int xpcxd_rx_ring_threshold_stop = 0;
int xpcxd_enable_tx_err_interrupt =
	0; /* Place holder for various Tx interrupt enables */
int xpcxd_enable_rx_err_interrupt =
	0; /* Place holder for various Rx interrupt enables */

static struct ctl_table_header *xpcxd_netdev_sysctl_header;

static struct net_device *xpcxd_netdev = NULL;
static struct xdev *g_pxdev = NULL;

static irqreturn_t (*xpcxd_interrupt)(int irq, void *arg);

static bool arm_timer_isr = true;

static ktime_t time_isr_ktime = 0;

u32 g_error = 0;

ktime_t tx_coalescing_ktime = 0;

bool hw_ready = false;

uint xpcxd_cfg_tbl[xpcxd_last_cfg_item] = { 0 };

static bool xpcxd_close_done = false;
static bool xpcxd_close_started = false;
static bool xpcxd_stop_done = false;
/** True for the body of xpcxd_stop(): Rx NAPI must not napi_reschedule on CMPL HW-full. */
static bool xpcxd_ifdown_in_progress = false;
/* Current PCXD implementation is module-singleton. */
static bool xpcxd_singleton_active = false;

extern int xpci_debug_level;

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset,
			   enum xpci_tx_rx tx_rx);

extern u16 xpcxd_get_tx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id);

static void xpcxd_rss_indrct_tbl_write(u32 reg_offset,
				       u16 ring_id[XPCXD_MAX_RING_NUM])
{
	u64 ind_tbl = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	ind_tbl = 0;
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_0,
			   ring_id[0]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_1,
			   ring_id[1]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_2,
			   ring_id[2]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_3,
			   ring_id[3]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_4,
			   ring_id[4]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_5,
			   ring_id[5]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_6,
			   ring_id[6]);
	xreg_field_put_idx(&ind_tbl, xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL),
			   XREG_FIELD_PCXD_RX_RSS_INDRCT_TBL_RING_ID_7,
			   ring_id[7]);

	/* xpci_htobe_data((uint8_t *) &ind_tbl, sizeof(u64)); */

	xpci_write64("XREG_PCXD_RX_RSS_INDRCT_TBL",
		     xreg_abs_off(xreg_desc(XREG_ID_PCXD_RX_RSS_INDRCT_TBL), 0,
				  reg_offset),
		     ind_tbl);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_rss_qid_tbl_write(
	u32 reg_offset,
	struct xpcxd_rss_qid_tbl qid_tbl[XPCXD_NUM_OF_RSS_QUEUES])
{
	u64 qid_tbl_reg = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	qid_tbl_reg = 0;
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_0,
			   qid_tbl[0].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_0,
			   qid_tbl[0].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_1,
			   qid_tbl[1].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_1,
			   qid_tbl[1].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_2,
			   qid_tbl[2].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_2,
			   qid_tbl[2].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_3,
			   qid_tbl[3].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_3,
			   qid_tbl[3].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_4,
			   qid_tbl[4].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_4,
			   qid_tbl[4].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_5,
			   qid_tbl[5].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_5,
			   qid_tbl[5].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_6,
			   qid_tbl[6].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_6,
			   qid_tbl[6].group_size);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_BASE_7,
			   qid_tbl[7].group_base);
	xreg_field_put_idx(&qid_tbl_reg, xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL),
			   XREG_FIELD_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_7,
			   qid_tbl[7].group_size);

	xpci_write64("PCXD_RX_RSS_QID_TBL",
		     xreg_abs_off(xreg_desc(XREG_ID_PCXD_RX_RSS_QID_TBL), 0,
				  reg_offset),
		     qid_tbl_reg);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

/* MSFT Recommended secret key */
u8 rss_secret_key[XPCXD_RSS_SECRET_KEY_SIZE] = {
	0x6d, 0x5a, 0x56, 0xda, 0x25, 0x5b, 0x0e, 0xc2, 0x41, 0x67,
	0x25, 0x3d, 0x43, 0xa3, 0x8f, 0xb0, 0xd0, 0xca, 0x2b, 0xcb,
	0xae, 0x7b, 0x30, 0xb4, 0x77, 0xcb, 0x2d, 0xa3, 0x80, 0x30,
	0xf2, 0x0c, 0x6a, 0x42, 0xb7, 0x3b, 0xbe, 0xac, 0x01, 0xfa
};

void xpcxd_rss_hash_key_write(void)
{
	u64 rss_key = 0;
	u32 i = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	for (i = 0; i < XREG_NC_PCXD_RX_RSS_SECRET_KEY; i++) {
		rss_key = *((u64 *)&rss_secret_key[i * 8]);

		xpci_htobe_data((uint8_t *)&rss_key, sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RSS SECRET Key[%d]: [0x%llx]",
			  (XREG_NC_PCXD_RX_RSS_SECRET_KEY - i - 1),
			  *((u64 *)&rss_key));

		xpci_write64("XREG_PCXD_RX_RSS_SECRET_KEY",
			     xreg_addr(xreg_get_profile(),
				       XREG_ID_PCXD_RX_RSS_SECRET_KEY, 0, 0) +
				     ((XREG_NC_PCXD_RX_RSS_SECRET_KEY - i - 1) *
				      XREG_REG_SIZE),
			     rss_key);
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

#ifdef __XPCXD_RSS_STATS__
/* TODO: move to ethtool */
static void xpcxd_rss_stat(void)
{
	u64 rss_grp_id, rss_indr_tbl, rss_qid_tbl, rss_ring_id;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	rss_grp_id =
		xpci_read64("XREG_PCXD_RX_STTS_RSS_GRP_ID",
			    xreg_addr(xreg_get_profile(),
				      XREG_ID_PCXD_RX_STTS_RSS_GRP_ID, 0, 0),
			    true);
	rss_indr_tbl =
		xpci_read64("XREG_PCXD_RX_STTS_RSS_INDR_TBL",
			    xreg_addr(xreg_get_profile(),
				      XREG_ID_PCXD_RX_STTS_RSS_INDR_TBL, 0, 0),
			    true);
	rss_qid_tbl =
		xpci_read64("XREG_PCXD_RX_STTS_RSS_QID_TBL",
			    xreg_addr(xreg_get_profile(),
				      XREG_ID_PCXD_RX_STTS_RSS_QID_TBL, 0, 0),
			    true);
	rss_ring_id =
		xpci_read64("XREG_PCXD_RX_STTS_RSS_RING_ID",
			    xreg_addr(xreg_get_profile(),
				      XREG_ID_PCXD_RX_STTS_RSS_RING_ID, 0, 0),
			    true);

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"RSS counters: Group ID: %lld Indirect Tbl: %lld QID Tbl: %lld Ring ID: %lld",
		rss_grp_id, rss_indr_tbl, rss_qid_tbl, rss_ring_id);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}
#endif

#define XPCXD_RX_PFC_RP_SIZE 8

static uint8_t pcxd_rx_pfc_grp_map_tbl[XPCXD_RX_PFC_RP_SIZE] = { 0, 0, 0, 0,
								 0, 0, 0, 0 };
static uint64_t pcxd_rx_pfc_ocp_high_th_tbl[XREG_NC_PCXD_RX_PFC_OCP_HIGH_TH] = {
	0, 0, 0, 0, 0, 0, 0, 0
};
static uint64_t pcxd_rx_pfc_ocp_low_th_tbl[XREG_NC_PCXD_RX_PFC_OCP_LOW_TH] = {
	0, 0, 0, 0, 0, 0, 0, 0
};

static int xpcxd_pfc_config(void)
{
	u64 pcxd_rx_pfc_grp_map = 0;
	u64 pcxd_rx_pfc_ocp_high_th = 0;
	u64 pcxd_rx_pfc_ocp_low_th = 0;
	u32 i = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	pcxd_rx_pfc_grp_map = 0;
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_0,
			   pcxd_rx_pfc_grp_map_tbl[0]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_1,
			   pcxd_rx_pfc_grp_map_tbl[1]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_2,
			   pcxd_rx_pfc_grp_map_tbl[2]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_3,
			   pcxd_rx_pfc_grp_map_tbl[3]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_4,
			   pcxd_rx_pfc_grp_map_tbl[4]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_5,
			   pcxd_rx_pfc_grp_map_tbl[5]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_6,
			   pcxd_rx_pfc_grp_map_tbl[6]);
	xreg_field_put_idx(&pcxd_rx_pfc_grp_map,
			   xreg_desc(XREG_ID_PCXD_RX_PFC_GRP_MAP),
			   XREG_FIELD_PCXD_RX_PFC_GRP_MAP_GRP_7,
			   pcxd_rx_pfc_grp_map_tbl[7]);

	xpci_htobe_data((uint8_t *)&pcxd_rx_pfc_grp_map, sizeof(u64));

	xpcxd_dbg(NETIF_MSG_DRV, "RX PFC GRP: [0x%llx]",
		  *((u64 *)&pcxd_rx_pfc_grp_map));

	xpci_write64("XREG_PCXD_RX_PFC_GRP_MAP",
		     xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_PFC_GRP_MAP,
			       0, 0),
		     pcxd_rx_pfc_grp_map);

	for (i = 0; i < XREG_NC_PCXD_RX_PFC_OCP_HIGH_TH; i++) {
		pcxd_rx_pfc_ocp_high_th =
			*((u64 *)&pcxd_rx_pfc_ocp_high_th_tbl[i]);

		xpci_htobe_data((uint8_t *)&pcxd_rx_pfc_ocp_high_th,
				sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RX_PFC_OCP_HIGH_TH[%d]: [0x%llx]", i,
			  *((u64 *)&pcxd_rx_pfc_ocp_high_th));
	}

	for (i = 0; i < XREG_NC_PCXD_RX_PFC_OCP_LOW_TH; i++) {
		pcxd_rx_pfc_ocp_low_th =
			*((u64 *)&pcxd_rx_pfc_ocp_low_th_tbl[i]);

		xpci_htobe_data((uint8_t *)&pcxd_rx_pfc_ocp_low_th,
				sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RX_PFC_OCP_LOW_TH[%d]: [0x%llx]", i,
			  *((u64 *)&pcxd_rx_pfc_ocp_low_th));
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

#define GRP_SIZE 8
#define BASE_RING 0

static int xpcxd_rss_config(uint num_of_rings)

{
	/* Group size encoding is: 1 --> 0, 2 --> 1, 4 --> 2, 8 --> 3 */
	/**
	 * @brief Table mapping group size to the corresponding RSS queue ID.
	 */
	u8 group_size_trans_tbl[9] = { 0, 0, 1, 0, 2, 0, 0, 0, 3 };

	/**
	 * @brief Table of RSS queue IDs and their associated base ring.
	 */
	struct xpcxd_rss_qid_tbl qid_tbl[XPCXD_NUM_OF_RSS_QUEUES] = {
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] },
		{ BASE_RING, group_size_trans_tbl[GRP_SIZE] }
	}; /* TODO: Fill from configuration */
	u32 i, j;

	/**
	 * Fill the ring ID's according to the number of rings.
	 * If the xpcxd_rss_ring_ids_override flag is not set, this
	 * function fills pcxd_rss_ring_ids with ring IDs.
	 * The ring ID's are assigned in a round-robin fashion, with each ring getting a unique ID.
	 *
	 * @param num_of_rings The number of rings to be filled in the pcxd_rss_ring_ids array.
	 */
	if (!xpcxd_rss_ring_ids_override) {
		for (i = 0; i < XPCXD_MAX_RING_NUM; i += num_of_rings)
			for (j = 0; j < num_of_rings; j++)
				pcxd_rss_ring_ids[i + j] = j;
	}

	/* Iterate over the RSS Indirect Table rings and print their IDs */
	for (i = 0; i < XPCXD_MAX_RING_NUM; i++) {
		xpcxd_notice(NETIF_MSG_DRV,
			     "[%d] RSS Indirect Table ring: [%d]", i,
			     pcxd_rss_ring_ids[i]);
	}

	/* Write the RSS Indirect Table for each copy */
	for (i = 0; i < XREG_NC_PCXD_RX_RSS_INDRCT_TBL; i++) {
		xpcxd_rss_indrct_tbl_write(i, pcxd_rss_ring_ids);
	}

	/* Write the RSS QID Table for each copy */
	for (i = 0; i < XREG_NC_PCXD_RX_RSS_QID_TBL; i++) {
		xpcxd_rss_qid_tbl_write(i, qid_tbl);
	}

	xpcxd_rss_hash_key_write();

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_tx_rx_loopback_set(u32 ring_id, bool enable)
{
	u64 tx_brg_lpb = 0;
	u32 rss_value = 0;
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_TX_BRG_LPB_TX_TARGET_SET: %d <-- Loopback",
		  enable ? 1 : 0);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_TX_TARGET,
			   enable ? 1 : 0);
	/* 0 - IFU / 1 - Loopback/Bridge */
	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_TX_BRG_LPB_RX_TARGET_SET: %d <-- Loopback",
		  enable ? 0 : 1);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_RX_TARGET,
			   enable ? 0 : 1);
	/* 0 - Loopback / 1 - Bridge (Firmware complex) */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"PCXD_MEMCFG_TX_BRG_LPB_RSS_MODE_SET: %d <-- "
		"0 - Explicit, 1 - Hash index, 2 - Group ID, 3 - Full",
		xpcxd_rss_mode);
	xreg_field_put_idx(
		&tx_brg_lpb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
		XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_RSS_MODE,
		xpcxd_rss_mode); /* 0 - RSS Mode - ring_id explicitly set | 1 - hash index */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"PCXD_MEMCFG_TX_BRG_LPB_RSS_CTRL_SET: %d <-- Default RSS ring",
		ring_id);
	switch (xpcxd_rss_mode) {
	case XPCXD_RSS_MODE_EXPLICIT: /* Explicit mode */
		rss_value = ring_id;
		break;
	case XPCXD_RSS_MODE_HASH_INDEX: /* Hash index mode */
		rss_value = ring_id;
		break;
	case XPCXD_RSS_MODE_RSS_GROUP_ID: /* RSS group ID*/
		rss_value = 0x1; /* TODO: Fix according to spec*/
		break;
	case XPCXD_RSS_MODE_FULL: /* QID converted to RSS group ID */
		rss_value = 0;
		break;
	default:
		rss_value = 0;
	}
	xreg_field_put_idx(
		&tx_brg_lpb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
		XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_RSS_CTRL,
		(xpcxd_rss_enabled && xpcxd_loopback) ? ring_id : rss_value);
	/* Default - no RSS mode : RSS Ring - always 0 */

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_DO_L3_CHKS_SET: %d",
		  xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_DO_L3_CHKS,
			   xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_DO_L4_CHKS_SET: %d",
		  xpcxd_cfg_tbl[xpcxd_check_l4_checksum] & enable);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_DO_L4_CHKS,
			   xpcxd_cfg_tbl[xpcxd_check_l4_checksum] & enable);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_L3_OFF_OVRD_SET: %d",
		  /*xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable*/ 1);
	xreg_field_put_idx(
		&tx_brg_lpb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
		XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_L3_OFF_OVRD,
		/*xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable*/ 1);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_L3_OFFSET_SET: %d",
		  xpcxd_l3_loopback_offset + 3);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_L3_OFFSET,
			   xpcxd_l3_loopback_offset + 3);
	xreg_field_put_idx(&tx_brg_lpb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB),
			   XREG_FIELD_PCXD_MEMCFG_TX_BRG_LPB_TRIM_HDR, 0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_BRG_LPB",
		XREG_PCXD_MEMCFG_TX_BRG_LPB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB) /* Size */,
		(void *)&tx_brg_lpb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	ret = xdrv_mem_ind_read(
		"XREG_PCXD_MEMCFG_TX_BRG_LPB",
		XREG_PCXD_MEMCFG_TX_BRG_LPB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_BRG_LPB) /* Size */,
		(void *)&tx_brg_lpb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
		return -1;
	}

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

/*static*/ void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
				enum xpci_tx_rx tx_rx, u32 stop_val, char *msg)
{
	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpci_debug_level = XPCI_DBG_LEVEL__MAX;
	xpcxd_set_msglvl_all();

	xpcxd_err(NETIF_MSG_DRV, "<<<SET RX/TX STOP>>>");

	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "%s", msg);
	} else {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "%s", msg);
	}

	if (skb)
		xpci_print_pkt(msg, netdev, skb, RX_OFFSET, tx_rx);

	xpcxd_intg_spare_write(stop_val);

	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
	g_error = 1;

	/* Do not arm timer ISR anymore and do not poll statistics */
	arm_timer_isr = false;

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
/* Kernel 6.12+: proc_handler takes const struct ctl_table * */
static int xpcxd_tx_coales_size_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_tx_coales_size_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_tx_coales_size];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "pcxd_tx_coales_size changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_tx_coales_size]);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static int xpcxd_tx_coales_time_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_tx_coales_time_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_tx_coales_time];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "pcxd_tx_coales_time changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_tx_coales_time]);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static int xpcxd_rx_coales_size_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_rx_coales_size_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_rx_coales_size];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "pcxd_rx_coales_size changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_rx_coales_size]);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static int xpcxd_rx_coales_time_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_rx_coales_time_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_rx_coales_time];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "pcxd_rx_coales_time changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_rx_coales_time]);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static int xpcxd_check_l3_checksum_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_check_l3_checksum_proc(struct ctl_table *table, int write,
					void *buffer, size_t *lenp,
					loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_check_l3_checksum];
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = NULL;
	u32 ring_id = 0;

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "pcxd_check_l3_checksum changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_check_l3_checksum]);

	if (netdev) {
		net_priv = netdev_priv(netdev);

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_tx_rx_loopback_set(ring_id, xpcxd_loopback);
			if (unlikely(ret)) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"open: RX/TX loopback set failed: %d",
					ret);
				return -1;
			}
		}
	}

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
static int xpcxd_check_l4_checksum_proc(const struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_check_l4_checksum_proc(struct ctl_table *table, int write,
					void *buffer, size_t *lenp,
					loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_check_l4_checksum];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV,
			  "xpcxd_check_l4_checksum changed from: %d ---> %d",
			  old_value, xpcxd_cfg_tbl[xpcxd_check_l4_checksum]);

	return ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 12, 0)
/* Kernel 6.12+: proc_handler takes const struct ctl_table * */
static int
xpcxd_ifdown_strict_rx_drop_proc(const struct ctl_table *table, int write,
				 void *buffer, size_t *lenp, loff_t *ppos)
#else
static int xpcxd_ifdown_strict_rx_drop_proc(struct ctl_table *table, int write,
					    void *buffer, size_t *lenp,
					    loff_t *ppos)
#endif
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_ifdown_strict_rx_drop_cmd;

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_notice(NETIF_MSG_DRV,
			     "pcxd_ifdown_strict_rx_drop changed from: %d ---> %d",
			     old_value, xpcxd_ifdown_strict_rx_drop_cmd);

	return ret;
}

static struct ctl_table xpcxd_netdev_ctl_table[] = {
	{
		.procname = "pcxd_tx_coales_size",
		.data = &xpcxd_cfg_tbl[xpcxd_tx_coales_size],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_tx_coales_size_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_tx_coales_time",
		.data = &xpcxd_cfg_tbl[xpcxd_tx_coales_time],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_tx_coales_time_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_rx_coales_size",
		.data = &xpcxd_cfg_tbl[xpcxd_rx_coales_size],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_rx_coales_size_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_rx_coales_time",
		.data = &xpcxd_cfg_tbl[xpcxd_rx_coales_time],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_rx_coales_time_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_check_l3_checksum",
		.data = &xpcxd_cfg_tbl[xpcxd_check_l3_checksum],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_check_l3_checksum_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_ONE,
#endif
	},
	{
		.procname = "pcxd_check_l4_checksum",
		.data = &xpcxd_cfg_tbl[xpcxd_check_l4_checksum],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_check_l4_checksum_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_ONE,
#endif
	},
	{
		.procname = "pcxd_ifdown_strict_rx_drop",
		.data = &xpcxd_ifdown_strict_rx_drop_cmd,
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_ifdown_strict_rx_drop_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_ONE,
#endif
	},
	{}
};

#define XPCXB_RELAXED_ORDERING ((uint64_t)2 << 32)

static int xpcxd_relaxed_ordering(void)
{
	u64 pcxd_client_attr = 0;
	uint64_t reset_v = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	reset_v = xpci_read64("XREG_PCXB_PCXD_CLIENT_ATTR",
			      xreg_addr(xreg_get_profile(),
					XREG_ID_PCXB_PCXD_CLIENT_ATTR, 0, 0),
			      true);

	reset_v = reset_v | XPCXB_RELAXED_ORDERING;
	xpcxd_dbg(NETIF_MSG_DRV, "PCXB_PCXD_CLIENT_ATTR_SET: [%llx]", reset_v);

	pcxd_client_attr = reset_v;

	xpci_write64("XREG_PCXB_PCXD_CLIENT_ATTR",
		     xreg_addr(xreg_get_profile(),
			       XREG_ID_PCXB_PCXD_CLIENT_ATTR, 0, 0),
		     pcxd_client_attr);

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

static int xpcxd_lat_cfg(void)
{
	u64 pcxd_lat_cfg = 0;

	pcxd_lat_cfg = 0;
	xreg_field_put_idx(&pcxd_lat_cfg, xreg_desc(XREG_ID_PCXB_PCI_LAT_CFG),
			   XREG_FIELD_PCXB_PCI_LAT_CFG_EN, 1);

	xpci_write64(
		"xreg_addr(xreg_get_profile(), XREG_ID_PCXB_PCI_LAT_CFG, 0, 0)",
		xreg_addr(xreg_get_profile(), XREG_ID_PCXB_PCI_LAT_CFG, 0, 0),
		pcxd_lat_cfg);

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

static int xpcxd_netdev_sysctl_init(void)
{
	int orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__INFO;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 9, 0)
	/* 6.9+ validates every entry; sentinel has procname=NULL. Use _sz. */
	xpcxd_netdev_sysctl_header = register_net_sysctl_sz(
		&init_net, "net/xpci", xpcxd_netdev_ctl_table,
		ARRAY_SIZE(xpcxd_netdev_ctl_table) - 1);
#else
	xpcxd_netdev_sysctl_header = register_net_sysctl(
		&init_net, "net/xpci", xpcxd_netdev_ctl_table);
#endif
	if (xpcxd_netdev_sysctl_header == NULL) {
		xpcxd_err(NETIF_MSG_DRV, "Can register net_sysctl");
		return -ENOMEM;
	}

	xpcxd_cfg_tbl[xpcxd_tx_coales_size] = xpcxd_tx_coales_size_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_coales_time] = xpcxd_tx_coales_time_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_coales_size] = xpcxd_rx_coales_size_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_coales_time] = xpcxd_rx_coales_time_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = xpcxd_rx_drop_all_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = xpcxd_tx_drop_all_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] = xpcxd_tx_checksum_bypass_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] = xpcxd_rx_checksum_bypass_cmd;
	xpcxd_cfg_tbl[xpcxd_check_l3_checksum] = xpcxd_check_l3_checksum_cmd;
	xpcxd_cfg_tbl[xpcxd_check_l4_checksum] = xpcxd_check_l4_checksum_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_shaper] = xpcxd_rx_shaper_cmd;
	xpcxd_cfg_tbl[xpcxd_enable_tx_err_int] = xpcxd_enable_tx_err_int_cmd;
	xpcxd_cfg_tbl[xpcxd_enable_rx_err_int] = xpcxd_enable_rx_err_int_cmd;
	xpcxd_cfg_tbl[xpcxd_event_trace] = xpcxd_event_trace_cmd;

	xpcxd_info(NETIF_MSG_DRV,
		   "----XSIGHT PCXD NET DEV Dynamic configuration ----");
	xpcxd_info(NETIF_MSG_DRV, "Number of rings              : [%d]",
		   xpcxd_num_of_rings);
	xpcxd_info(NETIF_MSG_DRV, "Transmit ring size           : [%d]",
		   xpcxd_tx_ring_size);
	xpcxd_info(NETIF_MSG_DRV, "Receive ring size            : [%d]",
		   xpcxd_rx_ring_size);
	if (xpcxd_mode_standalone)
		xpcxd_notice(NETIF_MSG_DRV, "PCXD mode standalone     : [%s]",
			     "ENABLED");
	if (xpcxd_loopback)
		xpcxd_notice(NETIF_MSG_DRV, "PCXD loopback            : [%s]",
			     "ENABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx                      : [%s]",
		   xpcxd_tx_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx                      : [%s]",
		   xpcxd_rx_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Interrupt mode          : [%s:%d]",
		   !xpcxd_int_mode ? "INTERRUPT" : "HYBRID:1 or POLLING:2",
		   xpcxd_int_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD RSS                     : [%s]",
		   xpcxd_rss_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD RSS mode                : [%d]",
		   xpcxd_rss_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD RX PFC                  : [%s]",
		   xpcxd_pfc_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx sbm Reflection mode  : [%d]",
		   xpcxd_tx_sbm_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx sub Reflection mode  : [forced 1]");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx cmp Reflection mode  : [%d]",
		   xpcxd_tx_cmp_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx cmp Reflection mode  : [forced 1]");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx Coalescing mode      : [%s]",
		   xpcxd_tx_coales_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing size      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_tx_coales_size]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing time      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx Coalescing mode      : [%s]",
		   xpcxd_rx_coales_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx coalescing size      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_rx_coales_size]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx coalescing time      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD strict ifdown Rx drop   : [%s]",
		   xpcxd_ifdown_strict_rx_drop_cmd ? "ENABLED" : "DISABLED");
	if (xpcxd_cfg_tbl[xpcxd_rx_drop_all])
		xpcxd_notice(NETIF_MSG_DRV,
			     "PCXD Rx Drop All            : [%s ---> %d]",
			     "ENABLED", xpcxd_cfg_tbl[xpcxd_rx_drop_all]);
	if (xpcxd_cfg_tbl[xpcxd_tx_drop_all])
		xpcxd_notice(NETIF_MSG_DRV,
			     "PCXD Tx Drop All            : [%s]", "ENABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx NAPI Budget          : [%d]",
		   xpcxd_tx_budget);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx NAPI Budget          : [%d]",
		   xpcxd_rx_budget);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing SW INT    : [%s]",
		   xpcxd_tx_coales_isr_mode ? "ENABLED" : "DISABLED");
	if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass])
		xpcxd_notice(NETIF_MSG_DRV,
			     "Tx Checksum bypass: [Enabled] Mode: [%s]",
			     xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] ==
					     xpcxd_selective_bypass ?
				     "Selective" :
				     "Global");
	if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass])
		xpcxd_notice(NETIF_MSG_DRV,
			     "Rx Checksum bypass: [Enabled] Mode: [%s]",
			     xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] ==
					     xpcxd_selective_bypass ?
				     "Selective" :
				     "Global");
	xpcxd_info(NETIF_MSG_DRV, "PCXD L3 Checksum             : [%s]",
		   xpcxd_cfg_tbl[xpcxd_check_l3_checksum] ? "ON" : "OFF");
	xpcxd_info(NETIF_MSG_DRV, "PCXD L4 Checksum             : [%s]",
		   xpcxd_cfg_tbl[xpcxd_check_l4_checksum] ? "ON" : "OFF");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx Ring space threshold : [%d] percent",
		   xpcxd_ring_threshold);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Relaxed ordering        : [%s]",
		   xpcxd_pci_relaxed_ordering ? "ENABLED" : "DISABLED");
	if (xpcxd_cfg_tbl[xpcxd_rx_shaper]) {
		xpcxd_notice(NETIF_MSG_DRV,
			     "PCXD Rx Shaper               : [Enabled]");
	}
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx Error Interrupt      : [%s]",
		   xpcxd_cfg_tbl[xpcxd_enable_tx_err_int] ? "ENABLED" :
							    "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx Error Interrupt      : [%s]",
		   xpcxd_cfg_tbl[xpcxd_enable_rx_err_int] ? "ENABLED" :
							    "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "Periodic statistics dump     : [%s]",
		   xpcxd_timer_isr_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "Kernel event traces          : [%s]",
		   xpcxd_cfg_tbl[xpcxd_event_trace] ? "ENABLED" : "DISABLED");

	xpcxd_info(NETIF_MSG_DRV, "Page pool skb allocation method used");

	xpcxd_info(NETIF_MSG_DRV,
		   "---------------------------------------------");

	xpci_debug_level = orig_debug_level;

	return 0;
}

/**
 * xpcxd_get_tx_sub_ring_space - Tx submit ring free slot count.
 *
 * Occupied = (prod - sub_cns_ptr) mod size via (prod + size - sub_cns_ptr) & mask;
 * free = size - occupied (same result as the prior prod/cons split, unsigned-safe).
 */
u32 xpcxd_get_tx_sub_ring_space(struct xpcxd_ring *ring)
{
	u32 occupied = ((u32)ring->sub.prod + (u32)ring->sub.size -
			(u32)ring->sub.sub_cns_ptr) &
		       (u32)ring->sub.mask;

	return (u32)ring->sub.size - occupied;
}

/**
 * xpcxd_get_rx_sub_ring_space - Rx submit ring occupancy (used slot count).
 *
 * Returns (prod - cons) mod size via (prod + size - cons) & mask so wrap is
 * correct in unsigned arithmetic.  Callers that need free space use
 * size - xpcxd_get_rx_sub_ring_space().
 */
u32 xpcxd_get_rx_sub_ring_space(struct xpcxd_ring *ring)
{
	return ((u32)ring->sub.prod + (u32)ring->sub.size -
		(u32)ring->sub.cons) &
	       (u32)ring->sub.mask;
}

/*
 * HW completion ring free slots (engine credits): how many more completions the
 * HW may post before the CMPL ring is full.  When 0, the ring is full from the
 * HW side even if SW cons == prd_ptr (wrap), so cons==prd must not be treated
 * as an empty ring.  Returns U32_MAX when this counter is unavailable (non-RFL).
 */
static u32 xpcxd_hw_rx_cmpl_ring_free_slots(struct xpcxd_ring *ring)
{
	struct xpcxd_atomic_fifo_ctrl *rfl;
	u16 head, tail;
	u32 used, cap;

	if (!ring->cmp.rfl_prd)
		return (u32)-1;

	xpcxd_dma_rmb();
	rfl = ring->cmp.rfl_prd;
	head = (u16)(rfl->ring_index_head & ring->cmp.mask);
	tail = (u16)(rfl->ring_index_tail & ring->cmp.mask);

	used = (u32)((head - tail) & ring->cmp.mask);
	cap = (u32)ring->cmp.size - 1U;
	if (used >= cap)
		return 0;
	return cap - used;
}

/**
 * xpcxd_get_cmpl_ring_space - SW-visible free slots in the completion ring.
 *
 * Free = size - occupied, with occupied = (prd - cons) mod size using
 * (prd + size - cons) & mask so wrap is correct without relying on signed
 * (prd - cons) & mask.
 *
 * When cons == cmpl_prd_ptr, SW cannot tell an empty ring from a HW-full ring;
 * if RFL credits exist, report 0 free when HW reports no credits. If RFL is
 * disabled or unavailable (hw returns U32_MAX), SW still reports size when the
 * pointers are equal (same ambiguity as before).
 */
u32 xpcxd_get_cmpl_ring_space(struct xpcxd_ring *ring)
{
	u32 occupied = ((u32)ring->cmp.cmpl_prd_ptr + (u32)ring->cmp.size -
			(u32)ring->cmp.cons) &
		       (u32)ring->cmp.mask;
	u32 sw_free = ring->cmp.size - occupied;

	if (ring->cmp.cmpl_prd_ptr == ring->cmp.cons && ring->cmp.rfl_prd) {
		u32 hw_free = xpcxd_hw_rx_cmpl_ring_free_slots(ring);

		if (hw_free != (u32)-1 && hw_free == 0)
			return 0;
	}

	return sw_free;
}

/*
 * xpcxd_rx_event_class HW columns from RX reflection pointers only:
 *
 *   hw_sp = SW sub.prod fallback (RX SUB producer is driver-owned; HW does
 *           not expose an independent producer reflection)
 *   hw_sc = sub.rfl_cns->ring_index_tail (HW SUB consumer reflection)
 *   hw_cp = cmp.rfl_prd->ring_index_head (HW CMPL producer reflection)
 *   hw_cc = SW cmp.cons (HW does not expose a CMPL consumer pointer)
 *
 * Any field without an available source is left at ~0U ("unavailable").
 */
static void xpcxd_rx_trace_hw_ring(struct xpcxd_ring *rxr, u32 *hw_sc,
				   u32 *hw_sp, u32 *hw_cc, u32 *hw_cp)
{
	const struct xpcxd_atomic_fifo_ctrl *crfl = rxr->cmp.rfl_prd;
	const struct xpcxd_atomic_fifo_ctrl *srfl = rxr->sub.rfl_cns;

	*hw_sc = ~0U;
	*hw_sp = (u32)rxr->sub.prod & (u32)rxr->sub.mask;
	*hw_cp = ~0U;
	*hw_cc = (u32)rxr->cmp.cons & (u32)rxr->cmp.mask;

	/* Reflection pointers are DRAM-coherent; one barrier before reads. */
	if (crfl || srfl)
		xpcxd_dma_rmb();

	if (crfl)
		*hw_cp = (u32)(crfl->ring_index_head & (u32)rxr->cmp.mask);

	if (srfl) {
		*hw_sc = (u32)(srfl->ring_index_tail & (u32)rxr->sub.mask);
	}
}

/*
 * SUB ring free slots from a coherent HW pointer pair.
 * Returns size - ((hw_prod - hw_cons) & mask).
 */
static u32 xpcxd_rx_hw_sub_free_from_ptrs(struct xpcxd_ring *rxr,
					  u32 hw_sub_cons, u32 hw_sub_prod)
{
	u32 m = (u32)rxr->sub.mask;
	u32 p = hw_sub_prod & m;
	u32 hwc = hw_sub_cons & m;
	u32 occ_hw = (p + (u32)rxr->sub.size - hwc) & m;

	return (u32)rxr->sub.size - occ_hw;
}

/*
 * SW-visible RX SUB free slots for posting to HW:
 * use cached HW SUB consumer reflection (sub_cns_ptr), not sub.cons.
 */
static u32 xpcxd_rx_sub_free_slots_sw(struct xpcxd_ring *rxr)
{
	u32 m = (u32)rxr->sub.mask;
	u32 p = (u32)rxr->sub.prod & m;
	u32 c = (u32)rxr->sub.sub_cns_ptr & m;
	u32 occ = (p + (u32)rxr->sub.size - c) & m;

	return (u32)rxr->sub.size - occ;
}

/* SW ring zeros + HW snaps "unknown" (~0 in each half of packed u64). */
#define xpcxd_rx_trace_ring_zero                                               \
	0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL, 0U, 0U, 0U, 0U,          \
		0xFFFFFFFFFFFFFFFFULL, 0xFFFFFFFFFFFFFFFFULL

#define xpcxd_rx_trace_ring_emit(trmac, ev, rid, rxr, va, vb)                  \
	do {                                                                   \
		u32 __sf_sw, __sf_hw, __cf_sw, __cf_hw, __sc, __sp, __cc,      \
			__cp;                                                  \
		u32 __hsc, __hsp, __hcc, __hcp;                                \
		u64 __subf, __cmpf, __hsub, __hcmp;                            \
                                                                               \
		xpcxd_rx_trace_hw_ring((rxr), &__hsc, &__hsp, &__hcc, &__hcp); \
		__sf_sw = xpcxd_rx_sub_free_slots_sw(rxr);                    \
		__sf_hw = ~0U;                                                 \
		if (__hsc != ~0U && __hsp != ~0U)                              \
			__sf_hw = xpcxd_rx_hw_sub_free_from_ptrs(              \
				(rxr), __hsc, __hsp);                          \
		__subf = ((u64)(__sf_hw) << 32) | (u64)(__sf_sw);              \
		__cf_sw = (u32)xpcxd_get_cmpl_ring_space(rxr);                 \
		__cf_hw = xpcxd_hw_rx_cmpl_ring_free_slots(rxr);               \
		__cmpf = ((u64)(__cf_hw) << 32) | (u64)(__cf_sw);              \
		__sc = (u32)(rxr)->sub.cons & (u32)(rxr)->sub.mask;            \
		__sp = (u32)(rxr)->sub.prod & (u32)(rxr)->sub.mask;            \
		__cc = (u32)(rxr)->cmp.cons & (u32)(rxr)->cmp.mask;            \
		__cp = (u32)(rxr)->cmp.cmpl_prd_ptr & (u32)(rxr)->cmp.mask;    \
		__hsub = ((u64)(__hsc) << 32) | (u64)(__hsp);                  \
		__hcmp = ((u64)(__hcc) << 32) | (u64)(__hcp);                  \
		trmac(ev, (int)(rid), __subf, __cmpf, __sc, __sp, __cc, __cp,  \
		      __hsub, __hcmp, (int)(va), (int)(vb));                   \
	} while (0)

#ifdef __XPCXD_CMD_TRACES__
#define xpcxd_rx_opt_trace_ring(ev, rid, rxr, va, vb)                          \
	xpcxd_rx_trace_ring_emit(xpcxd_opt_trace, ev, rid, rxr, va, vb)
#else
#define xpcxd_rx_opt_trace_ring(ev, rid, rxr, va, vb) ((void)0)
#endif

#define xpcxd_rx_kern_trace_ring(ev, rid, rxr, va, vb)                         \
	xpcxd_rx_trace_ring_emit(xpcxd_trace, ev, rid, rxr, va, vb)

/*
 * Account @cnt submit SW descriptors as doorbelled to HW.
 *
 */
static __always_inline void xpcxd_rx_sw_sub_mark_posted(struct xpcxd_ring *rxr,
							u16 cnt)
{
	if (!cnt)
		return;
	rxr->stats.rx_sw_sub_posted_hw += cnt;
}

static __always_inline void
xpcxd_rx_sw_sub_cmpl_returned(struct xpcxd_ring *rxr, u16 first_idx,
			      u16 num_desc)
{
	(void)first_idx;
	if (!num_desc)
		return;
	rxr->stats.rx_sw_cmpl_returned += num_desc;
}

/* Caller must publish coherent submit-ring descriptor writes before this (dma_wmb). */
static void xpcxd_rx_db_write(struct net_device *netdev, u16 ring_id,
			      u16 prod_idx)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u64 rx_dbv = 0;
	u32 rx_db_addr;
	uint32_t rx_sub_space = 0;
	uint32_t rx_cmpl_space = 0;
	uint32_t mode = 0; /* 0 - incremental | 1 - absolute */
	struct xpcxd_ring *rxr = &net_priv->rxr[ring_id];

	rx_sub_space =
		rxr->sub.size - xpcxd_get_rx_sub_ring_space(
					rxr); /* Calculate free ring space */
	rx_cmpl_space = xpcxd_get_cmpl_ring_space(rxr);

	/*
	 * Hoist the module-param read so the two threshold checks share one
	 * READ_ONCE (operators can flip pcxd_ring_threshold via sysfs at any
	 * time — keep ordering well-defined wrt the two stat increments) and
	 * skip both checks entirely when the operator zeroed the threshold.
	 * Each "free < (size/100)*thresh" still uses the original truncating
	 * formula to preserve the historical stat thresholds bit-for-bit.
	 */
	{
		u32 ring_thresh = READ_ONCE(xpcxd_ring_threshold);

		if (likely(ring_thresh)) {
			if (rx_sub_space <
			    ((rxr->sub.size / 100U) * ring_thresh))
				rxr->stats.rx_sub_threshold++;

			if (rx_cmpl_space <
			    ((rxr->cmp.size / 100U) * ring_thresh))
				rxr->stats.rx_cmpl_threshold++;
		}
	}

	rx_dbv = 0;
	xreg_field_put_idx(&rx_dbv, xreg_desc(XREG_ID_PCXD_RX_DB),
			   XREG_FIELD_PCXD_RX_DB_RIND_ID, ring_id);
	xreg_field_put_idx(&rx_dbv, xreg_desc(XREG_ID_PCXD_RX_DB),
			   XREG_FIELD_PCXD_RX_DB_MODE, mode);
	xreg_field_put_idx(&rx_dbv, xreg_desc(XREG_ID_PCXD_RX_DB),
			   XREG_FIELD_PCXD_RX_DB_VALUE, prod_idx);

	rx_db_addr = xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_DB, 0, 0);
	xpci_write64("XREG_PCXD_RX_DB", rx_db_addr, rx_dbv);
	/* Post the doorbell to the PCI bridge (dma_rmb does not flush MMIO writes). */
	(void)xpci_read64_fast(rx_db_addr);

	/*
	 * The unified rx_db_write trace already snapshots HW Cmp/Sub
	 * Cons/Prod via xpcxd_rx_event_class — sufficient for the refill
	 * doorbell boundary; no separate rx_db_write_hw_sub is needed.
	 */
	xpcxd_rx_opt_trace_ring(rx_db_write, ring_id, rxr, prod_idx, 0);

	/* xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT"); */
}

void xpcxd_skb_align(struct sk_buff *skb, int align)
{
	int off = ((unsigned long)skb->data) & (align - 1);

	if (off) {
		xpcxd_opt_trace(skb_align, 0, align - off, 0, 0);

		skb_reserve(skb, align - off);
	}
}

#ifdef __XPCXD_RX_SUB_RFL__
static u16 xpcxd_get_rx_sub_cns_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd;

	/*
	 * dma_rmb() before reading device-owned RFL fields so prior
	 * coherent DMA writes are observed before this load. Portable
	 * across archs; does not rely on PCI transaction ordering.
	 */
	xpcxd_dma_rmb();

	rfl_prd = net_priv->rxr[ring_id].cmp.rfl_prd;

	return rfl_prd->ring_index_head & net_priv->rxr[ring_id].sub.mask;
}
#endif /* __XPCXD_RX_SUB_RFL__ */

static u16 xpcxd_get_rx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *rxr = &net_priv->rxr[ring_id];
	u8 row[XREG_MEMCFG_RNG_STTS_ROW_BYTES];
	u64 row_lo = 0;
	u16 cmpl_prd_memcfg = 0;
	u16 ret_prd = rxr->cmp.cmpl_prd_ptr;
	int ret;

	/* RFL path: completion producer from reflection only (no MEMCFG cross-read). */
	if (rxr->cmp.rfl_prd) {
		/*
		 * Pair with HW writer: dma_rmb() before reading RFL head.
		 * Portable barrier, not an arch-specific workaround.
		 */
		xpcxd_dma_rmb();
		return rxr->cmp.rfl_prd->ring_index_head & rxr->cmp.mask;
	}

	ret = xdrv_mem_ind_read(
		"XREG_PCXD_MEMCFG_RX_RNG_STTS_TBL",
		XREG_PCXD_MEMCFG_RX_RNG_STTS_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */, sizeof(row) /* Size */, row);
	if (ret) {
		xpcxd_err(
			NETIF_MSG_DRV,
			"RX_RNG_STTS xdrv_mem_ind_read() failed: %d (using cached cmpl_prd_ptr)",
			ret);
	} else {
		memcpy(&row_lo, row, sizeof(row_lo));
		/* Memcfg field is 16b; normalize to ring index (wrap e.g. 1024→0). */
		cmpl_prd_memcfg =
			(u16)(xreg_memcfg_rng_stts_crd_prd_ptr(row_lo) &
			      rxr->cmp.mask);
		ret_prd = cmpl_prd_memcfg;
	}

	return ret_prd;
}

int xpcxd_rx_desc_status_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id;
	struct xpcxd_ring *rxr;
	u16 hw_cmpl_prd;
	u32 sub_space, cmpl_space;
	u32 sub_in_use_by_hw; /* SUB descriptors posted, not yet consumed by HW (sub consumer) */
	u32 cmpl_waiting_consume; /* CMPL descriptors completed by HW, not yet consumed by driver */
	u32 n_init, n_free, n_alloc, n_passed, n_other;
	u32 n_passed_hw; /* in-flight SUB slots; derived from rx_sw_sub_posted_hw - rx_sw_cmpl_returned */
	u32 posted_drv; /* submit slots [cons, prod) handed to HW */
	u32 alloc_in_posted_win, alloc_outside_posted_win;
	u32 posted_drv_raw;
	u16 cons, prod, mask, idx, k;
	s64 sw_post_cmpl_delta;
#ifdef __XPCXD_RX_SUB_RFL__
	u16 hw_sub_live;
#endif
	int orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__NOTICE;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"========== Rx descriptor status (on-demand) ==========");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		rxr = &net_priv->rxr[ring_id];
		sub_space = xpcxd_get_rx_sub_ring_space(rxr);
		cmpl_space = xpcxd_get_cmpl_ring_space(rxr);
		hw_cmpl_prd = xpcxd_get_rx_cmpl_prod_ptr(netdev, ring_id);

		cons = rxr->sub.cons;
		prod = rxr->sub.prod;
		mask = rxr->sub.mask;
		posted_drv_raw = (prod - cons) & mask;
		posted_drv = posted_drv_raw;

#ifdef __XPCXD_RX_SUB_RFL__
		hw_sub_live = xpcxd_get_rx_sub_cns_ptr(netdev, ring_id);
		sub_in_use_by_hw = (prod - hw_sub_live) & mask;
#else
		sub_in_use_by_hw = (prod - rxr->sub.sub_cns_ptr) & mask;
#endif
		/*
		 * CMPL waiting for consume = completed by HW
		 * (cmpl_prd_ptr), not yet consumed by driver (cons).
		 */
		cmpl_waiting_consume =
			(rxr->cmp.cmpl_prd_ptr - rxr->cmp.cons) & rxr->cmp.mask;

		n_init = n_free = n_alloc = n_passed = n_other = n_passed_hw =
			0;
		alloc_in_posted_win = 0;

		/*
		 * Reconstruct the diagnostic from the counters:
		 * delta = posted_to_HW - cmpl_returned. Clamp to ring
		 * size — the slots in flight can never exceed the SUB
		 * ring; a transient counter wrap or stat reset shows up
		 * as the same MISMATCH banner the per-slot path used to
		 * emit, just keyed on the counter delta directly.
		 */
		{
			s64 inflight = (s64)rxr->stats.rx_sw_sub_posted_hw -
				       (s64)rxr->stats.rx_sw_cmpl_returned;

			if (inflight < 0)
				n_passed_hw = 0;
			else if (inflight > (s64)rxr->sub.size)
				n_passed_hw = rxr->sub.size;
			else
				n_passed_hw = (u32)inflight;
		}

		for (idx = 0; idx < rxr->sub.size; idx++) {
			switch (rxr->sub.sw[idx].page_state) {
			case XPCXD_PAGE_INIT:
				n_init++;
				break;
			case XPCXD_PAGE_FREE:
				n_free++;
				break;
			case XPCXD_PAGE_ALLOCATED:
				n_alloc++;
				break;
			case XPCXD_PAGE_PASSED_TO_STACK:
				n_passed++;
				break;
			default:
				n_other++;
				break;
			}
		}

		for (k = 0; k < posted_drv; k++) {
			idx = (cons + k) & mask;
			if (rxr->sub.sw[idx].page_state == XPCXD_PAGE_ALLOCATED)
				alloc_in_posted_win++;
		}

		if (n_alloc >= alloc_in_posted_win)
			alloc_outside_posted_win =
				n_alloc - alloc_in_posted_win;
		else
			alloc_outside_posted_win = 0;

		sw_post_cmpl_delta = (s64)rxr->stats.rx_sw_sub_posted_hw -
				     (s64)rxr->stats.rx_sw_cmpl_returned;

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				    "---------- Rx ring [%u] ----------",
				    ring_id);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: free_slots=%u  CMPL: free_slots=%u  (SW ring view; SUB size=%u CMPL size=%u)",
			rxr->sub.size - sub_space, cmpl_space, rxr->sub.size,
			rxr->cmp.size);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: prod=%u cons=%u sub_cns_ptr(stored)=%u size=%u mask=0x%x",
			prod, cons, rxr->sub.sub_cns_ptr, rxr->sub.size, mask);
#ifdef __XPCXD_RX_SUB_RFL__
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: hw_sub_cns(live)=%u in_use_by_hw=%u (prod-hw_sub) free_for_driver_post=%u",
			hw_sub_live, sub_in_use_by_hw, sub_space);
#else
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: in_use_by_hw=%u (prod-stored_sub_cns) free_for_driver_post=%u [no RFL: hw_sub N/A]",
			sub_in_use_by_hw, sub_space);
#endif
		if (posted_drv != posted_drv_raw) {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"  SUB: posted_drv adjusted %u -> %u (masked "
				"prod-cons was 0 but all %u slots ALLOC; "
				"full-ring wrap?)",
				posted_drv_raw, posted_drv, rxr->sub.size);
		}
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: posted_drv_slots[cons..prod)=%u (driver->HW window; not yet submit-released)",
			posted_drv);
		if (prod == cons && n_passed_hw > 0) {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"  NOTE: prod==cons with in-flight SUB slots>0 "
				"(delta=%u): [cons,prod) is empty in index "
				"math - ring may be full (prod wrapped) or "
				"skewed; not 'empty ring' by itself.",
				n_passed_hw);
		}
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: last doorbell descriptor count=%u (arg to "
			"last xpcxd_rx_db_write from rx_fill or rx_db_init)",
			rxr->stats.rx_last_db_desc_cnt);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SW submit/CMPL: posted_to_HW_total=%llu "
			"cmpl_returned_sub_desc=%llu "
			"delta(posted-returned)=%lld",
			(unsigned long long)rxr->stats.rx_sw_sub_posted_hw,
			(unsigned long long)rxr->stats.rx_sw_cmpl_returned,
			(long long)sw_post_cmpl_delta);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SW submit/CMPL: in_flight_slots=%u (clamped delta "
			"of posted-returned counters; per-slot flag retired)",
			n_passed_hw);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CORR: submit/CMPL SW track - in_flight=%u (delta=%lld)",
			n_passed_hw, (long long)sw_post_cmpl_delta);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SW page_state: INIT=%u FREE=%u ALLOC=%u PASSED_STACK=%u other=%u sum=%u ring_size=%u",
			n_init, n_free, n_alloc, n_passed, n_other,
			n_init + n_free + n_alloc + n_passed + n_other,
			rxr->sub.size);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CORR: ALLOC in posted window=%u / posted_drv=%u | ALLOC outside window=%u",
			alloc_in_posted_win, posted_drv,
			alloc_outside_posted_win);
		/* Braces required: xpcxd_*_netdev may expand to empty when debug level off. */
		if (posted_drv == alloc_in_posted_win &&
		    alloc_outside_posted_win == 0) {
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"  CORR: page_state vs submit ring - OK (every posted slot is ALLOCATED; no stray ALLOC)");
		} else if (posted_drv > 0 && alloc_in_posted_win < posted_drv) {
			xpcxd_err_netdev(
				NETIF_MSG_DRV, netdev,
				"  CORR: MISMATCH - posted_drv=%u but only %u ALLOC in window (missing buffers for HW?)",
				posted_drv, alloc_in_posted_win);
		} else if (alloc_outside_posted_win > 0) {
			/* prod==cons => half-open [cons,prod) has length 0: posted_drv is 0 and no
			 * index is "in window", yet every slot can be ALLOC with the entire
			 * ring still in flight to HW (full ring; counter delta == ring size).
			 * Do not report stray ALLOC in that degenerate case; see NOTE above.
			 */
			if (prod == cons && posted_drv == 0 &&
			    n_alloc == rxr->sub.size &&
			    n_passed_hw == rxr->sub.size) {
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CORR: prod==cons full submit ring - "
					"ALLOC vs [cons,prod) check N/A (all %u "
					"slots in flight)",
					rxr->sub.size);
			} else {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"  CORR: MISMATCH - %u ALLOC outside [cons,prod) (stale state or prod/cons skew)",
					alloc_outside_posted_win);
			}
		}

		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL: cons=%u cmpl_prd_ptr=%u (HW=%u) size=%u mask=0x%x",
			rxr->cmp.cons, rxr->cmp.cmpl_prd_ptr, hw_cmpl_prd,
			rxr->cmp.size, rxr->cmp.mask);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL: waiting_consume=%u (free_for_HW=%u) — completions with data not yet polled",
			cmpl_waiting_consume, cmpl_space);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL: last 3 polls compl_slots=%u %u %u "
			"delta_jiffies=%u %u %u (newest->oldest; slots per "
			"poll, delta-jiffies prior poll return->this poll "
			"entry)",
			rxr->stats.rx_cmpl_poll_hist[0],
			rxr->stats.rx_cmpl_poll_hist[1],
			rxr->stats.rx_cmpl_poll_hist[2],
			rxr->stats.rx_cmpl_poll_hist_delta_jiffies[0],
			rxr->stats.rx_cmpl_poll_hist_delta_jiffies[1],
			rxr->stats.rx_cmpl_poll_hist_delta_jiffies[2]);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL vs SW: PASSED_TO_STACK=%u (pages still owned by skb path; legacy mode may be 0)",
			n_passed);
		{
			unsigned long ago_ms = 0;
			const char *msix_state;
			unsigned long last_j =
				READ_ONCE(rxr->stats.cmpl_irq_last_jiffy);
			u32 irq_cnt = READ_ONCE(rxr->stats.cmpl_irq_cnt);

			if (last_j)
				ago_ms = jiffies_to_msecs(jiffies - last_j);
			msix_state = READ_ONCE(rxr->stats.int_enabled) ?
					     "ENABLED" :
					     "DISABLED";
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"  CMPL IRQ: MSIX %s (driver int_enabled; "
				"ENABLED=vector armed, DISABLED=masked after "
				"IRQ until napi_complete)",
				msix_state);
			/* Braces: xpcxd_notice_netdev may expand to empty when debug level off. */
			if (last_j) {
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: vec=%d handler_entries=%u last_jiffy=%lu (~%lu ms ago, HZ=%d)",
					(int)(ring_id + XPCI_X2_RX_CMP_INT_MIN),
					irq_cnt, last_j, ago_ms, HZ);
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: max_delta_jiffies=%u (~%u ms at HZ=%d) between prev and last Rx CMPL IRQ",
					rxr->stats.rx_cmpl_irq_max_delta_jiffies,
					jiffies_to_msecs(
						(unsigned long)rxr->stats
							.rx_cmpl_irq_max_delta_jiffies),
					HZ);
			} else {
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: vec=%d handler_entries=%u last_jiffy=never (no IRQ since ring init)",
					(int)(ring_id + XPCI_X2_RX_CMP_INT_MIN),
					irq_cnt);
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: max_delta_jiffies=%u (no inter-IRQ gap recorded yet)",
					rxr->stats
						.rx_cmpl_irq_max_delta_jiffies);
			}
		}
	}

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "========== end Rx descriptor status ==========");

	xpci_debug_level = orig_debug_level;

	return 0;
}

/**
 * xpcxd_tx_desc_status_dump - Dump per-ring Tx submit / completion ring status.
 *
 * Mirrors xpcxd_rx_desc_status_dump() for the Tx side. Intended for on-demand
 * inspection (ethtool private flag) and for the kernel-panic notifier so the
 * Tx ring/CMPL state survives in the panic log next to the Rx dump.
 */
int xpcxd_tx_desc_status_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id;
	struct xpcxd_ring *txr;
	u16 hw_cmpl_prd;
	u32 sub_space, cmpl_space;
	u32 sub_in_use_by_hw;
	u32 cmpl_waiting_consume;
	u32 posted_drv;
	u16 cons, prod, mask;
	int orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__NOTICE;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"========== Tx descriptor status (on-demand) ==========");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		txr = &net_priv->txr[ring_id];
		sub_space = xpcxd_get_tx_sub_ring_space(txr);
		cmpl_space = xpcxd_get_cmpl_ring_space(txr);
		hw_cmpl_prd = xpcxd_get_tx_cmpl_prod_ptr(netdev, ring_id);

		cons = txr->sub.cons;
		prod = txr->sub.prod;
		mask = txr->sub.mask;
		posted_drv = (prod - cons) & mask;
		sub_in_use_by_hw = (prod - txr->sub.sub_cns_ptr) & mask;
		cmpl_waiting_consume =
			(txr->cmp.cmpl_prd_ptr - txr->cmp.cons) &
			txr->cmp.mask;

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				    "---------- Tx ring [%u] ----------",
				    ring_id);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: free_slots=%u  CMPL: free_slots=%u  (SW ring view; SUB size=%u CMPL size=%u)",
			sub_space, cmpl_space, txr->sub.size, txr->cmp.size);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: prod=%u cons=%u sub_cns_ptr(stored)=%u size=%u mask=0x%x",
			prod, cons, txr->sub.sub_cns_ptr, txr->sub.size,
			mask);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: in_use_by_hw=%u (prod-sub_cns_ptr) posted_drv_slots[cons..prod)=%u",
			sub_in_use_by_hw, posted_drv);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  SUB: db_count=%u (xmits since last doorbell)",
			txr->db_count);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL: cons=%u cmpl_prd_ptr=%u (HW=%u) prev=%u size=%u mask=0x%x",
			txr->cmp.cons, txr->cmp.cmpl_prd_ptr, hw_cmpl_prd,
			txr->cmp.cmpl_prd_ptr_prev, txr->cmp.size,
			txr->cmp.mask);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  CMPL: waiting_consume=%u (free_for_HW=%u) - completions with data not yet polled",
			cmpl_waiting_consume, cmpl_space);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  STATS: packets=%llu bytes=%llu errors=%llu dropped=%llu fifo_errors=%llu",
			(unsigned long long)txr->stats.packets,
			(unsigned long long)txr->stats.bytes,
			(unsigned long long)txr->stats.errors,
			(unsigned long long)txr->stats.dropped,
			(unsigned long long)txr->stats.fifo_errors);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  STATS: tx_alignment_error=%llu tx_underflow_events=%llu tx_sub_threshold=%llu tx_cmpl_threshold=%llu",
			(unsigned long long)txr->stats.tx_alignment_error,
			(unsigned long long)txr->stats.tx_underflow_events,
			(unsigned long long)txr->stats.tx_sub_threshold,
			(unsigned long long)txr->stats.tx_cmpl_threshold);
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"  STATS: tx_unicast=%llu tx_multicast=%llu tx_broadcast=%llu tx_vlan_packets=%llu tx_xdp_packets=%llu",
			(unsigned long long)txr->stats.tx_unicast,
			(unsigned long long)txr->stats.tx_multicast,
			(unsigned long long)txr->stats.tx_broadcast,
			(unsigned long long)txr->stats.tx_vlan_packets,
			(unsigned long long)txr->stats.tx_xdp_packets);
		{
			unsigned long ago_ms = 0;
			const char *msix_state;
			unsigned long last_j =
				READ_ONCE(txr->stats.cmpl_irq_last_jiffy);
			u32 irq_cnt = READ_ONCE(txr->stats.cmpl_irq_cnt);

			if (last_j)
				ago_ms = jiffies_to_msecs(jiffies - last_j);
			msix_state = READ_ONCE(txr->stats.int_enabled) ?
					     "ENABLED" :
					     "DISABLED";
			xpcxd_notice_netdev(
				NETIF_MSG_DRV, netdev,
				"  CMPL IRQ: MSIX %s (driver int_enabled; "
				"ENABLED=vector armed, DISABLED=masked after "
				"IRQ until napi_complete)",
				msix_state);
			/* Braces: xpcxd_notice_netdev may expand to empty when debug level off. */
			if (last_j) {
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: vec=%d handler_entries=%u last_jiffy=%lu (~%lu ms ago, HZ=%d)",
					(int)(ring_id + XPCI_X2_TX_CMP_INT_MIN),
					irq_cnt, last_j, ago_ms, HZ);
			} else {
				xpcxd_notice_netdev(
					NETIF_MSG_DRV, netdev,
					"  CMPL IRQ: vec=%d handler_entries=%u last_jiffy=never (no IRQ since ring init)",
					(int)(ring_id + XPCI_X2_TX_CMP_INT_MIN),
					irq_cnt);
			}
		}
	}

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "========== end Tx descriptor status ==========");

	xpci_debug_level = orig_debug_level;

	return 0;
}

static int xpcxd_rx_fill(struct net_device *netdev, struct napi_struct *napi,
			 u32 ring_id, struct xpcxd_ring *rxr, u16 n,
			 u16 *processed, bool db_write)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_sw_desc *sw_desc = NULL;
	struct xpcxd_rx_bd *bd;
	u32 bd_len;
	u16 prod_idx = 0;
	u16 i = 0;
#ifdef __XPCXD_RX_SUB_RFL__
	u16 sub_cns = 0;
#endif /* __XPCXD_RX_SUB_RFL__ */

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "IN: num: %d rxr: %p", n,
			 rxr);

#ifdef __XPCXD_RX_SUB_RFL__
	sub_cns = xpcxd_get_rx_sub_cns_ptr(xpcxd_netdev, ring_id);
	(void)sub_cns;
#endif /* __XPCXD_RX_SUB_RFL__ */

	/* Hoist loop-invariant values (avoids repeated conditionals in hot path) */
	bd_len = XPCXD_FRAG_DATA_SIZE;

	if (db_write && n == 0) {
		u32 sub_free = rxr->sub.size - xpcxd_get_rx_sub_ring_space(rxr);

		rxr->stats.rx_sub_ring_starve_no_db++;
		xpcxd_rx_kern_trace_ring(rx_sub_ring_starvation, ring_id, rxr,
					 0, (int)sub_free);
	}

	xpcxd_rx_opt_trace_ring(rx_fill_start, ring_id, rxr, (int)n,
				(int)(rxr->sub.prod & rxr->sub.mask));

	for (i = 0; i < n; i++) {
		u16 next_idx;

		prod_idx = rxr->sub.prod & rxr->sub.mask;
		next_idx = (prod_idx + 1) & rxr->sub.mask;

		sw_desc = &rxr->sub.sw[prod_idx];
		/*
		 * Pipeline cache-line traffic over the page-pool alloc that
		 * follows (the alloc is the dominant per-slot cost):
		 *
		 *   prefetchw(sub.desc[prod_idx].rx_bd)
		 *       The W0..W3 stores below would miss otherwise — DMA
		 *       descriptor rings are shared with the device and the
		 *       line is rarely in our cache after the device walked
		 *       it. Issuing a write-prefetch hides the RFO latency
		 *       behind the alloc.
		 *   prefetch(sub.sw[next_idx])
		 *       Next iteration starts with a read of page_state and
		 *       a write to sw_desc fields; existing prefetch covers
		 *       the read miss.
		 *   prefetchw(sub.desc[next_idx].rx_bd)
		 *       Pre-arm next iteration's BD line for write while we
		 *       alloc + fill the current BD.
		 *
		 * On configs whose CPU lacks a real prefetchw, the kernel
		 * macro lowers to plain prefetch — still correct, just no
		 * RFO benefit.
		 */
		prefetchw(&rxr->sub.desc[prod_idx].rx_bd);
		prefetch(&rxr->sub.sw[next_idx]);
		prefetchw(&rxr->sub.desc[next_idx].rx_bd);

		/* xpcxd_opt_trace(rx_action_fill_next, ring_id, prod_idx, sw_desc->page_state); */

		/* xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, */
		/* 		 "IN [%d]: num: %d rxr: %p prod_idx: %d sub_cns: %d sw_desc: %p", ring_id, n, rxr, */
		/* 		 prod_idx, sub_cns, sw_desc); */

		if (unlikely(!sw_desc)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "sw_desc error");
			return -ENOMEM;
		}

		/* Page already posted: skip alloc, still program BD and advance prod (goto bd_fill). */
		if (sw_desc->page_state == XPCXD_PAGE_ALLOCATED) {
			xpcxd_rx_opt_trace_ring(rx_action_fill_tail_stop,
						ring_id, rxr, (int)i,
						(int)prod_idx);
			goto bd_fill;
		}

		sw_desc->page_state = XPCXD_PAGE_FREE;

		sw_desc->page = xpcxd_page_pool_dev_alloc_pages(rxr->page_pool);
		/* xpcxd_opt_trace(rx_action_end, ring_id, prod_idx, 0); */
		if (unlikely(!sw_desc->page)) {
			xpcxd_err_netdev(
				NETIF_MSG_DRV, netdev,
				"Page pool dev alloc error: sw_desc[%d]",
				prod_idx);

			rxr->stats.rx_page_alloc_err++;
			rxr->stats.errors++;

#ifdef __XPCXD_CMD_TRACES__
			xpcxd_cfg_tbl[xpcxd_event_trace] = true;
#endif

			sw_desc->page = NULL;

			rxr->rx_credits = n - i;
			rxr->rx_credits_cap = rxr->rx_credits;

			xpcxd_trace_printk("page_pool_dev_alloc_pages() error");

			/* If first Rx descriptors fiil then stop all */
			if (!db_write) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"[%d] Not enough memory - swiotlb buffer is full. All Rx/Tx is stopped",
					ring_id);

				rxr->stats.rx_fill_fatal_oom++;

				xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
				xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
				g_error = 1;

				return -ENOMEM;
			}
			xpcxd_rx_opt_trace_ring(rx_action_fill_alloc_err,
						ring_id, rxr, (int)i,
						(int)rxr->rx_credits);

			break;
		}

		sw_desc->page_state = XPCXD_PAGE_ALLOCATED;
		sw_desc->dma_err = false;
		sw_desc->usg_cnt++;

		sw_desc->addr = xpcxd_page_pool_get_dma_addr(sw_desc->page);

		if (dma_mapping_error(net_priv->hw_dev, sw_desc->addr)) {
			xpcxd_err_netdev(
				NETIF_MSG_DRV, netdev,
				"[%d] prod_idx: %d sw_desc->addr error: [%lld] pfn: [%lu",
				ring_id, prod_idx, sw_desc->addr,
				page_to_pfn(sw_desc->page));
			rxr->stats.rx_dma_get_err++;
			rxr->stats.errors++;

#ifdef __XPCXD_CMD_TRACES__
			xpcxd_cfg_tbl[xpcxd_event_trace] = true;
#endif

			xpcxd_trace_printk(
				"page_pool_get_dma_addr() error. page: [%p] pfn: [%lu]",
				sw_desc->page, page_to_pfn(sw_desc->page));

			/* xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page); */
			xpcxd_page_pool_put_full_page(rxr->page_pool,
						      sw_desc->page, false);

			sw_desc->page = NULL;
			sw_desc->page_state = XPCXD_PAGE_FREE;
			sw_desc->dma_err = true;

			rxr->rx_credits = n - i;
			rxr->rx_credits_cap = rxr->rx_credits;

			xpcxd_rx_opt_trace_ring(rx_action_fill_dma_err, ring_id,
						rxr, (int)i,
						(int)rxr->rx_credits);

			break;
		}

		/* xpcxd_opt_trace(rx_action_pool_dev_alloc_page, ring_id, i, page_to_pfn(sw_desc->page)); */

	bd_fill:
		/* Use local pointer to avoid repeated indexing (better for code gen and cache) */
		bd = &rxr->sub.desc[prod_idx].rx_bd;

		/* W0 */
		bd->ctrl_no_cpl =
			0; /* 0 - Generate completion for this frame */
		/*
		 * Rx is wired to RFL mode unconditionally; HW posts
		 * completions via the reflection pointer, no per-BD irq
		 * needed.
		 */
		bd->int_en = 0;
		bd->eof = 1; /* End of frame */

		sw_desc->prod_idx = prod_idx;

		/* W1 */
		bd->len = bd_len;

		/* W2: LSB of buffer address (with optional frag offset for page_pool path) */
		bd->dst_buf_addr_lsb =
			(u32)((u64)sw_desc->addr & 0xFFFFFFFF) +
		XPCXD_FRAG_OFFSET;

		/* W3 */
		bd->dst_buf_addr_msb = (u32)((u64)sw_desc->addr >> 32);

		/* xpcxd_opt_trace(rx_fill_bd, ring_id, prod_idx, ...); */

		/* Branchless producer wrap (mask is size-1 for power-of-2 ring) */
		rxr->sub.prod = (rxr->sub.prod + 1) & rxr->sub.mask;

		/*
		 * xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
		 * "NEXT [%d] rxr->sub.prod: %d rxr->sub.size: %d",
		 * i, rxr->sub.prod, rxr->sub.size);
		 */
	}
	if (likely(i)) {
		/* DoorBell is skipped for the first Rx fill and given later, after activation */
		if (db_write) {
			/* Finish all memory transactions before HW access the desriptors   */
			xpcxd_dma_wmb();

			xpcxd_rx_opt_trace_ring(rx_action_fill_rx_db_ring,
						ring_id, rxr, (int)i, 0);

			xpcxd_rx_db_write(netdev, ring_id, i);
			xpcxd_rx_sw_sub_mark_posted(rxr, i);
			rxr->stats.rx_last_db_desc_cnt = i;
		} else {
			rxr->rx_last_fill_cnt = i;
		}
	} else if (!db_write) {
		rxr->rx_last_fill_cnt = 0;
	}

	xpcxd_rx_opt_trace_ring(rx_fill_finish, ring_id, rxr, (int)i, 0);

	*processed = i;

	/* end: */
	/* xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT"); */

	return 0;
}

static u32 xpcxd_page_pool_free(struct net_device *netdev,
				struct xpcxd_ring *ring)
{
	struct xpcxd_sw_desc *sw_desc = NULL;
	u16 i = 0;

	xpci_debug_level = XPCI_DBG_LEVEL__DBG;

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "IN[%d]", ring->ring_id);

	xpcxd_rx_opt_trace_ring(rx_action_pool_free_start, ring->ring_id, ring,
				0, 0);

	for (i = 0; i < ring->sub.size; i++) {
		sw_desc = &ring->sub.sw[i];

		xpcxd_rx_opt_trace_ring(rx_action_pool_free_page, ring->ring_id,
					ring, (int)i, (int)sw_desc->page_state);

		if (sw_desc && sw_desc->skb) {
			dev_kfree_skb(sw_desc->skb);
		}

		if (sw_desc && ring->page_pool && sw_desc->page &&
		    (sw_desc->page_state == XPCXD_PAGE_ALLOCATED)) {
			xpcxd_page_pool_release_page(ring->page_pool,
						     sw_desc->page);

			if (page_ref_count(sw_desc->page) != 1) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"Invalid page ref count: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
					ring->ring_id, i, sw_desc->skb,
					sw_desc->page, sw_desc->page_state,
					page_ref_count(sw_desc->page));
#ifdef __XPCXD_DEBUG__
				xpcxd_dbg_dump_page(sw_desc->page,
						    "Invalid page");
#endif
			}

			if (page_count(sw_desc->page) != 1) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"Invalid compound page count: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
					ring->ring_id, i, sw_desc->skb,
					sw_desc->page, sw_desc->page_state,
					page_count(sw_desc->page));
#ifdef __XPCXD_DEBUG__
				xpcxd_dbg_dump_page(sw_desc->page,
						    "Invalid compound page");
#endif
			}
		}
	}

	xpcxd_rx_opt_trace_ring(rx_action_pool_free_done, ring->ring_id, ring,
				0, 0);

	if (ring->page_pool) {
		/*
		 * synchronize_net() above flushes any RX softirq that could
		 * be holding skbs that reference this pool's pages.
		 * page_pool_destroy() itself defers final teardown until
		 * every page held by an in-flight skb has been returned
		 * (page_pool_release_retry).
		 */
		xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
				 "Destroying Rx page pool");
		page_pool_destroy(ring->page_pool);
		ring->page_pool = NULL;
	}

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT");

	return 0;
}

static u32 xpcxd_rx_db_init(struct net_device *netdev, struct xpcxd_ring *rxr,
			    u16 ring_id)
{
	u16 nd = rxr->rx_last_fill_cnt;

	xpcxd_dbg(NETIF_MSG_DRV, "IN: ring_id: %d", ring_id);

	/* Initial fill used rx_fill(..., db_write=false); doorbell deferred until here.
	 * Doorbell count must match descriptors actually programmed (not full ring size),
	 * and coherent BD stores must be visible before MMIO doorbell (dma_wmb).
	 */
	if (!nd) {
		xpcxd_err_netdev(
			NETIF_MSG_DRV, netdev,
			"rx_db_init: ring %u: no descriptors filled (rx_last_fill_cnt=0), skip doorbell",
			(unsigned int)ring_id);
		return 0;
	}

	xpcxd_dma_wmb();

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RINGING to RX DOORBELL: descriptors: %u (sub.size=%u)",
		  (unsigned int)nd, (unsigned int)rxr->sub.size);
	xpcxd_rx_db_write(netdev, ring_id, nd);
	rxr->stats.rx_last_db_desc_cnt = nd;

	xpcxd_rx_sw_sub_mark_posted(rxr, nd);
	rxr->rx_last_fill_cnt = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

#ifdef __XPCXD_DEBUG__
void xpcxd_consume_skb(struct net_device *netdev, struct sk_buff *skb)
{
	consume_skb(skb);
}
#else
inline void xpcxd_consume_skb(struct net_device *netdev, struct sk_buff *skb)
{
	consume_skb(skb);
}
#endif

void xpcxd_print_multipage_skb_data(char *msg, struct net_device *netdev,
				    struct sk_buff *skb)
{
	struct skb_shared_info *shinfo;
	int i;

	if (!skb) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "skb is NULL");
		return;
	}

	/* Print linear part of skb */
	if (skb->len) {
		xprint_hex_dump(netdev, msg, DUMP_PREFIX_OFFSET, 16, 1,
				skb->data, skb_headlen(skb), true);
	}

	/* Get the shared info structure for the skb */
	shinfo = skb_shinfo(skb);

	/* Iterate over each fragment (page) in the skb */
	for (i = 0; i < shinfo->nr_frags; i++) {
		skb_frag_t *frag = &shinfo->frags[i];
		void *vaddr;
		unsigned int size = skb_frag_size(frag);

		/* Map the fragment to virtual address space */
		vaddr = kmap_atomic(skb_frag_page(frag));

		/* Print the fragment's data */
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Fragment %d data: ", i);
		xprint_hex_dump(
			netdev, msg, DUMP_PREFIX_OFFSET, 16, 1,
			vaddr + XPCXD_FRAG_OFFSET /*+ frag->page_offset*/, size,
			true);

		/* Unmap the fragment */
		kunmap_atomic(vaddr);
	}
}

static int xpcxd_add_fragments(struct net_device *netdev, u16 ring_id,
			       struct sk_buff *skb, struct xpcxd_ring *rxr,
			       int len, u32 cur_desc, u16 num_desc)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_submit_ring *rxsr = &net_priv->rxr[ring_id].sub;
	u32 next_desc = 1;
	int len_left = len;
	u32 frag_size = 0;
	u32 desc_index = 0;
	struct xpcxd_sw_desc *sw_desc_ptr = NULL;

	for (next_desc = 1; next_desc < num_desc; next_desc++) {
		if (unlikely(xpcxd_cfg_tbl[xpcxd_rx_drop_all])) {
			rxr->stats.rx_stop_drop_all++;
			return -EINVAL;
		}
		/* Power-of-2 ring: wrap with mask to avoid out-of-bound access */
		desc_index = (cur_desc + next_desc) & rxsr->mask;
		sw_desc_ptr = &rxr->sub.sw[desc_index];

		if (unlikely(!sw_desc_ptr->page)) {
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"multi-page frag[%u] desc_index %u has NULL page (len=%d num_desc=%u)",
				next_desc, desc_index, len, num_desc);
			return -EINVAL;
		}

		xpcxd_opt_trace(rx_poll_index_next, (int)ring_id, 0, skb,
				skb->len, num_desc, desc_index, sw_desc_ptr,
				sw_desc_ptr->page, (u32)len, frag_size);

		len_left -= XPCXD_FRAG_DATA_SIZE;
		if (len_left <= 0)
			break;
		if (len_left > XPCXD_FRAG_DATA_SIZE) {
			frag_size = XPCXD_FRAG_DATA_SIZE;
		} else {
			frag_size = (u32)len_left;
		}

		xpcxd_opt_trace(rx_poll_add_frag, (int)ring_id, 0, skb,
				skb->len, num_desc, desc_index, sw_desc_ptr,
				sw_desc_ptr->page, (u32)len, frag_size);

		/* Invalidate cache lines that may have been written to by
		 * device so that we avoid corrupting memory.
		 */
		xpcxd_dma_sync_single_range_for_cpu(net_priv->hw_dev,
						    sw_desc_ptr->addr,
						    XPCXD_FRAG_OFFSET,
						    frag_size, DMA_FROM_DEVICE);

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
		/*
		 * Kernel < 5.14: skb_mark_for_recycle() is not available, so
		 * the stack frees frag pages via __skb_frag_unref()/put_page()
		 * which bypasses page_pool DMA unmap. Release the frag page
		 * from pool tracking before transferring ownership to the SKB
		 * so the PP_FLAG_DMA_MAP mapping is unmapped and the pool's
		 * inflight counter is decremented. The page itself stays at
		 * refcount 1 and is freed by the normal SKB release path.
		 */
		xpcxd_page_pool_release_page(rxr->page_pool, sw_desc_ptr->page);
#endif

		skb_add_rx_frag(skb, skb_shinfo(skb)->nr_frags,
				sw_desc_ptr->page, XPCXD_FRAG_OFFSET, frag_size,
				XPCXD_FRAG_DATA_SIZE);

		/* Fragment page is now owned by skb - clear sw_desc so refill allocates new page */
		sw_desc_ptr->page = NULL;
		sw_desc_ptr->page_state = XPCXD_PAGE_FREE;
	}

	return 0;
}

/* Function to pad skb to the nearest multiple of 64 bytes */
int xpcxd_pad_skb_to_64(struct sk_buff *skb)
{
	unsigned int pad_len;
	unsigned int mod = skb->len % 64;

	/* Calculate the amount of padding needed */
	if (mod != 0)
		pad_len = 64 - mod;
	else
		pad_len = 0;

	/* Add padding if needed */
	if (pad_len > 0) {
		if (skb_pad(skb, pad_len)) {
			xpcxd_err(
				NETIF_MSG_RX_STATUS,
				"---> [%d] PCXD CMPL RX: SKB PUT : skb: [%p] pad_len: [%d]",
				0, skb, pad_len);

			return -ENOMEM; /* Failed to pad skb */
		}
		skb_put(skb,
			pad_len); /* Adjust the length to include padding */
	}

	return 0;
}

#ifdef __XPCXD_ICMP_TRACE__
extern void xpcxd_check_icmp_echo(struct sk_buff *skb,
				  struct net_device *netdev);
#endif

#ifdef __XPCXD_TRAILER_CHECK__
static u32 prev_trailer = 0;

void xpcxd_itg_trailer_check(struct net_device *netdev, void *data, u32 len,
			     u32 ring_id)
{
	u32 trailer = *(u32 *)(data + len - 4 /* Sequemce Number */ -
			       6 /* Time stamp */);

	trailer = htonl(trailer);

	if (((prev_trailer + 1) != trailer) && prev_trailer)
		xpcxd_rx_opt_trace_ring(rx_trailer_seq_err, ring_id, rxr,
					(int)prev_trailer, (int)trailer);
	prev_trailer = trailer;
}
#endif

/**
 * xpcxd_rx_cmpl - Handle completion of received packets on the XPCXD ring
 *
 * This function is called to handle the completion of received packets on the
 * XPCXD ring. It processes the received packets and updates the necessary
 * data structures.
 *
 * @netdev: The network device associated with the XPCXD ring
 * @napi: The NAPI structure for the XPCXD ring
 * @rxr: The XPCXD ring structure
 * @ring_id: The ID of the XPCXD ring
 * @budget: The maximum number of packets to process in this completion
 * @done_packets: Pointer to a variable to store the number of processed packets
 *
 * Completion producer (cmpl_prd_ptr) is sampled in xpcxd_rx_cmpl_intr before
 * NAPI is scheduled; this poll uses that snapshot. If the poll returns with
 * work left (budget), the producer is re-read so the next poll in the same
 * NAPI run sees HW progress without waiting for another interrupt.
 *
 * Returns:
 *  - true if there are more packets to process
 *  - false if all packets have been processed
 */
#ifdef __XPCXD_RX_PKT_SIZE_HISTOGRAM__
static void xpcxd_rx_pkt_size_histogram(struct xpcxd_ring *rxr,
					unsigned int len)
{
	if (len <= 255)
		rxr->stats.rx_pkt_size_0_255++;
	else if (len <= 511)
		rxr->stats.rx_pkt_size_256_511++;
	else if (len <= 1023)
		rxr->stats.rx_pkt_size_512_1023++;
	else if (len <= 4095)
		rxr->stats.rx_pkt_size_1024_4095++;
	else if (len <= 8191)
		rxr->stats.rx_pkt_size_4096_8191++;
	else
		rxr->stats.rx_pkt_size_8192_plus++;
}
#endif /* __XPCXD_RX_PKT_SIZE_HISTOGRAM__ */

/*
 * Submit ring index window [cons,prod) is empty ((prod-cons)&mask==0) but SW
 * accounting shows every slot still doorbelled to HW (wrap / full). CMPL
 * cons==prd matches the same ambiguity; do not stop the poll as "idle".
 */
/*
 * static bool xpcxd_rx_sub_wrapped_full(struct xpcxd_ring *rxr)
 * {
 *	u32 posted;
 *	s64 delta;
 *
 *	posted = (u32)((rxr->sub.prod - rxr->sub.cons) & rxr->sub.mask);
 *	if (posted != 0)
 *		return false;
 *	delta = (s64)rxr->stats.rx_sw_sub_posted_hw -
 *		(s64)rxr->stats.rx_sw_cmpl_returned;
 *	return delta >= (s64)rxr->sub.size;
 * }
 */

#define XPCXD_RX_REFILL_OSC_MS 1

/*
 * Slash rx_credits when the submit ring is tight. Module-param-backed:
 * pcxd_rx_credits_slash_pct (1..100; default 75). 100 = no slash.
 * Out-of-range values fall back to the historical x3/4 default so a
 * mis-set tunable can never amplify rx_credits.
 */
static void xpcxd_rx_credits_apply_slash(struct xpcxd_ring *rxr)
{
	int pct;
	u32 before, after;

	if (!rxr->rx_credits)
		return;

	pct = READ_ONCE(xpcxd_rx_credits_slash_pct);
	if (pct <= 0 || pct > 100)
		pct = 75;
	if (pct == 100)
		return; /* operator opted out of slashing */

	before = rxr->rx_credits;
	after = (u32)(((u64)before * (u32)pct) / 100U);
	if (after >= before)
		return;
	rxr->rx_credits = after;
	rxr->stats.rx_credits_slash++;
	xpcxd_rx_kern_trace_ring(rx_credits_slash, rxr->ring_id, rxr,
				 (int)before, (int)after);
}

/*
 * Slash-or-restore dispatcher. When free SUB slots fall below
 * pcxd_rx_sub_low_free_pct (the same operator-tunable threshold consulted
 * by the post-cap retry in xpcxd_rx_cmpl()), trim rx_credits by
 * pcxd_rx_credits_slash_pct via xpcxd_rx_credits_apply_slash(). Otherwise
 * creep rx_credits back toward rx_credits_cap (gap/16 step, floor 1).
 *
 * Single source of truth for the "tight SUB" threshold: the accessor
 * xpcxd_rx_sub_low_free_thresh_pct() READ_ONCE-clamps the module param
 * so both slash arms — this dispatcher and the carry-over post-mortem in
 * xpcxd_rx_cmpl() — react to the same operator-controlled point.
 *
 * low_free_pct == 0 means the operator disabled anti-oscillation
 * slashing; we skip the slash check and only run the restore creep so
 * any debt left over from earlier slash events still drains.
 */
static void xpcxd_rx_credits_adjust_for_sub_free(struct xpcxd_ring *rxr,
						 u32 rx_sub_free_space)
{
	u32 sz = rxr->sub.size;
	u32 low_free_pct;

	if (!rxr->rx_credits_cap && !rxr->rx_credits)
		return;
	if (sz < 2U)
		return;

	low_free_pct = xpcxd_rx_sub_low_free_thresh_pct();
	if (low_free_pct) {
		u32 low_free_thresh = (sz * low_free_pct) / 100U;

		if (!low_free_thresh)
			low_free_thresh = 1U;

		if (rx_sub_free_space < low_free_thresh) {
			xpcxd_rx_credits_apply_slash(rxr);
			return;
		}
	}

	if (rxr->rx_credits_cap > rxr->rx_credits) {
		u32 gap = rxr->rx_credits_cap - rxr->rx_credits;
		u32 step = gap / 16U;

		if (step < 1U)
			step = 1U;
		if (step > gap)
			step = gap;
		rxr->rx_credits += step;
		rxr->stats.rx_credits_restore++;
		xpcxd_rx_kern_trace_ring(rx_credits_restore, rxr->ring_id, rxr,
					 (int)step, (int)rxr->rx_credits);
	}
}

/*
 * Refill-oscillator ticks mean NAPI is being kicked with no completions refilling
 * submit (idle). If that continues with no RX packets for 10s, stop trace buffer
 * growth via tracing_off(); tracing_on() when packets arrive again.
 */
#if IS_ENABLED(CONFIG_TRACING)
static unsigned long xpcxd_rx_idle_trace_last_traffic_jiffies;
static bool xpcxd_rx_idle_trace_last_traffic_valid;
static bool xpcxd_rx_idle_trace_muted_by_idle;

static void xpcxd_rx_idle_trace_note_traffic(void)
{
	unsigned long j = jiffies;

	WRITE_ONCE(xpcxd_rx_idle_trace_last_traffic_jiffies, j);
	WRITE_ONCE(xpcxd_rx_idle_trace_last_traffic_valid, true);
	if (READ_ONCE(xpcxd_rx_idle_trace_muted_by_idle)) {
		tracing_on();
		WRITE_ONCE(xpcxd_rx_idle_trace_muted_by_idle, false);
	}
}

static void xpcxd_rx_idle_trace_check_mute_from_osc(void)
{
	unsigned long last;

	if (!READ_ONCE(xpcxd_rx_idle_trace_last_traffic_valid))
		return;
	last = READ_ONCE(xpcxd_rx_idle_trace_last_traffic_jiffies);
	if (time_before(jiffies, last + 10UL * HZ))
		return;
	if (!READ_ONCE(xpcxd_rx_idle_trace_muted_by_idle)) {
		tracing_off();
		WRITE_ONCE(xpcxd_rx_idle_trace_muted_by_idle, true);
	}
}

static void xpcxd_rx_idle_trace_if_up_init(void)
{
	WRITE_ONCE(xpcxd_rx_idle_trace_last_traffic_jiffies, jiffies);
	WRITE_ONCE(xpcxd_rx_idle_trace_last_traffic_valid, true);
	if (READ_ONCE(xpcxd_rx_idle_trace_muted_by_idle)) {
		tracing_on();
		WRITE_ONCE(xpcxd_rx_idle_trace_muted_by_idle, false);
	}
}

static void xpcxd_rx_idle_trace_if_down(void)
{
	if (READ_ONCE(xpcxd_rx_idle_trace_muted_by_idle)) {
		tracing_on();
		WRITE_ONCE(xpcxd_rx_idle_trace_muted_by_idle, false);
	}
	WRITE_ONCE(xpcxd_rx_idle_trace_last_traffic_valid, false);
}
#else
static inline void xpcxd_rx_idle_trace_note_traffic(void)
{
}
static inline void xpcxd_rx_idle_trace_check_mute_from_osc(void)
{
}
static inline void xpcxd_rx_idle_trace_if_up_init(void)
{
}
static inline void xpcxd_rx_idle_trace_if_down(void)
{
}
#endif

/*
 * If refill-osc runs many times with no completion MSI-X, turn off hot traces so
 * buffer growth stops; turn back on when a CMPL interrupt is serviced again.
 */
static bool xpcxd_rx_trace_muted_by_osc_streak;

static void xpcxd_rx_traces_stop_after_osc_streak(void)
{
	xpcxd_cfg_tbl[xpcxd_event_trace] = false;
#if IS_ENABLED(CONFIG_TRACING)
	tracing_off();
#endif
	xpcxd_rx_trace_muted_by_osc_streak = true;
}

static void xpcxd_rx_traces_try_unmute_after_cmpl_irq(void)
{
	if (!xpcxd_rx_trace_muted_by_osc_streak)
		return;
#if IS_ENABLED(CONFIG_TRACING)
	tracing_on();
#endif
	xpcxd_cfg_tbl[xpcxd_event_trace] = (uint)xpcxd_event_trace_cmd;
	xpcxd_rx_trace_muted_by_osc_streak = false;
}

static enum hrtimer_restart xpcxd_rx_refill_osc_timer_fn(struct hrtimer *timer)
{
	struct xpcxd_ring *ring =
		container_of(timer, struct xpcxd_ring, rx_refill_osc_timer);
	struct net_device *netdev = ring->xd ? ring->xd->netdev : xpcxd_netdev;
	u32 sw_free, occupied;
	u32 hw;
	int hw_i;

	if (ring->type != XPCXD_RING_RX || !ring->tx_rx_enabled || !netdev ||
	    !netif_running(netdev))
		return HRTIMER_NORESTART;

	sw_free = xpcxd_get_cmpl_ring_space(ring);
	if (sw_free > ring->cmp.size)
		sw_free = ring->cmp.size;
	occupied = ring->cmp.size - sw_free;

	hw = xpcxd_hw_rx_cmpl_ring_free_slots(ring);
	hw_i = (hw == (u32)-1) ? -1 : (int)hw;

	{
		u32 irq_cnt = READ_ONCE(ring->stats.cmpl_irq_cnt);

		if (!xpcxd_rx_trace_muted_by_osc_streak) {
			if (irq_cnt == ring->rx_refill_osc_irq_snap)
				ring->rx_refill_osc_irq_streak++;
			else
				ring->rx_refill_osc_irq_streak = 0;
			if (ring->rx_refill_osc_irq_streak > 10) {
				xpcxd_rx_traces_stop_after_osc_streak();
				ring->rx_refill_osc_irq_streak = 0;
			}
		}
		ring->rx_refill_osc_irq_snap = irq_cnt;
	}

	xpcxd_rx_opt_trace_ring(rx_refill_osc_tick, ring->ring_id, ring,
				(int)occupied, hw_i);

	xpcxd_rx_idle_trace_check_mute_from_osc();

	napi_schedule_irqoff(&ring->napi);
	return HRTIMER_NORESTART;
}

/*
 * Release a consumed Rx CMPL slot. Clear word 0 (which contains
 * cmp_ctrl_valid) so HW can re-arm the slot on the next ring wrap.
 * The single xpcxd_dma_wmb() at the done: label in xpcxd_rx_cmpl()
 * publishes all batched clears before any subsequent SUB doorbell
 * can return buffers to HW; on the common consume+refill path the
 * xpcxd_rx_fill() barrier ahead of xpcxd_rx_db_write() covers the
 * same ordering, so the done-label fence is redundant but cheap.
 */
static __always_inline void
xpcxd_rx_cmpl_slot_release(struct xpcxd_compl_ring *rxcr, u16 cmpl_idx)
{
	WRITE_ONCE(rxcr->desc[cmpl_idx].w64[0], 0ULL);
}

/*
 * Slow-path helpers.
 *
 * Goal: keep the steady-state per-packet branch in xpcxd_rx_cmpl()
 * compact so it fits in the L1 i-cache and the CPU's branch
 * predictor can table it cheaply. Everything that runs at most once
 * per poll (or only under teardown / desync / failure) is here,
 * marked noinline + __cold so the compiler:
 *   - emits these out-of-line
 *   - places the code in a cold text section away from the hot path
 *   - flags incoming branches as predicted-not-taken
 *
 * The control flow stays in the caller (rx_done = true; goto done)
 * so the helpers don't need to know about the rx_cmpl local state
 * machine — they just stamp the trace + counter and return a code.
 */

/*
 * Cold logging tails for the entry / in-poll teardown branches.
 * The caller still owns control flow (goto error / goto done): the
 * helpers only stamp the trace + dbg/err message + stat increments,
 * which together generate ~10 instructions per branch and would
 * otherwise sit in the steady-state path's i-cache footprint.
 */
static noinline __cold void
xpcxd_rx_cmpl_log_drop_all(struct net_device *netdev, struct xpcxd_ring *rxr,
			   u32 ring_id, uint drop_all, bool in_poll)
{
	if (in_poll) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_drop_all) [in-poll]",
			ring_id);
	} else {
		xpcxd_opt_trace(rx_drop_all, (int)ring_id, 0, (int)drop_all);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_drop_all)",
			ring_id);
	}
	rxr->stats.rx_stop_drop_all++;
	if (drop_all == 2U)
		rxr->stats.errors++;
}

static noinline __cold void
xpcxd_rx_cmpl_log_packets_stop(struct net_device *netdev,
			       struct xpcxd_ring *rxr, u32 ring_id,
			       bool in_poll)
{
	if (in_poll) {
		xpcxd_err_netdev(
			NETIF_MSG_DRV, netdev,
			"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_packets_stop) [in-poll]",
			ring_id);
	} else {
		xpcxd_err_netdev(
			NETIF_MSG_DRV, netdev,
			"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_packets_stop)",
			ring_id);
	}
	rxr->stats.rx_stop_packets_stop++;
	rxr->stats.errors++;
}

/*
 * Per-iteration teardown gate 
 */
static inline bool xpcxd_rx_cmpl_teardown_check(struct net_device *netdev,
						struct xpcxd_ring *rxr,
						u32 ring_id, bool stop_packets,
						bool in_poll)
{
	uint live_drop_all = READ_ONCE(xpcxd_cfg_tbl[xpcxd_rx_drop_all]);

	if (unlikely(live_drop_all)) {
		xpcxd_rx_cmpl_log_drop_all(netdev, rxr, ring_id, live_drop_all,
					   in_poll);
		return true;
	}

	if (unlikely(stop_packets)) {
		xpcxd_rx_cmpl_log_packets_stop(netdev, rxr, ring_id, in_poll);
		return true;
	}

	return false;
}

/*
 * Cold per-poll diagnostic tail: poll-spacing histogram, per-poll
 * size histogram, idle-trace bookkeeping, and the rx_poll_done
 * tracepoint. None of this is on a packet-fast path; pulling it out
 * shrinks the size of xpcxd_rx_cmpl() (visible to the inliner) and
 * lets the compiler keep the per-packet body compact.
 */
static noinline __cold void
xpcxd_rx_cmpl_diag_tail(struct net_device *netdev, struct xpcxd_ring *rxr,
			u32 ring_id, int n, int k,
			u32 rx_cmpl_poll_spacing_jiffies)
{
	rxr->stats.rx_cmpl_poll_hist_delta_jiffies[2] =
		rxr->stats.rx_cmpl_poll_hist_delta_jiffies[1];
	rxr->stats.rx_cmpl_poll_hist_delta_jiffies[1] =
		rxr->stats.rx_cmpl_poll_hist_delta_jiffies[0];
	rxr->stats.rx_cmpl_poll_hist_delta_jiffies[0] =
		rx_cmpl_poll_spacing_jiffies;
	rxr->stats.rx_cmpl_poll_prev_jiffy = jiffies;

	rxr->stats.rx_cmpl_poll_hist[2] = rxr->stats.rx_cmpl_poll_hist[1];
	rxr->stats.rx_cmpl_poll_hist[1] = rxr->stats.rx_cmpl_poll_hist[0];
	rxr->stats.rx_cmpl_poll_hist[0] = (u16)k;

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT");

	if (k > 0)
		xpcxd_rx_idle_trace_note_traffic();

	xpcxd_rx_opt_trace_ring(rx_poll_done, ring_id, rxr, k, n);
}

static bool xpcxd_rx_cmpl(struct net_device *netdev, struct napi_struct *napi,
			  struct xpcxd_ring *rxr, u32 ring_id, u16 budget,
			  u16 *done_packets)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_compl_ring *rxcr = &net_priv->rxr[ring_id].cmp;
	struct xpcxd_submit_ring *rxsr = &net_priv->rxr[ring_id].sub;
	struct sk_buff *skb = NULL;
	struct xpcxd_desc cmpl;
	struct xpcxd_sw_desc *sw_desc;
	u16 cmpl_prd_ptr = 0;
	u16 max = rxcr->size;
	int n = 0, k = 0, len = 0;
	int alloc_len = 0;
	bool rx_done = false;
	bool l4_csum = false;
	const struct ethhdr *eth = NULL;
	const struct iphdr *iph = NULL;
	const struct ipv6hdr *ip6h = NULL;
	u16 processed = 0;
	u16 cmpl_idx = 0;
	u16 descs_this_pkt =
		1; /* descriptors consumed by current packet (1 or num_desc for multi-page) */
	u64 local_packets = 0;
	u64 local_bytes = 0;
	u32 rx_cmpl_poll_spacing_jiffies = 0;
	unsigned long poll_in_jiffies = jiffies;
	const bool stop_packets = READ_ONCE(xpcxd_rx_packets_stop);

	if (rxr->stats.rx_cmpl_poll_prev_jiffy)
		rx_cmpl_poll_spacing_jiffies = (u32)(
			poll_in_jiffies - rxr->stats.rx_cmpl_poll_prev_jiffy);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	/* tracing_on(); */
#endif

#ifdef __XPCXD_CMD_START_END_TRACE__
	xpcxd_cfg_tbl[xpcxd_event_trace] =
		true; /* Start traces only when packets started */
#endif

	/*
	 * The per-slot cmp_ctrl_valid bit (CRD_CMP_ENG_DSC_VLD_MODE=1,
	 * hard-wired) is the authoritative consume-loop gate; the producer
	 * pointer is advisory only and never bounds packet processing.
	 */
	cmpl_prd_ptr = READ_ONCE(rxcr->cmpl_prd_ptr);

	/*
	 * Entry-site teardown gate
	 */
	if (unlikely(xpcxd_rx_cmpl_teardown_check(netdev, rxr, ring_id,
						  stop_packets, false))) {
		rx_done = true;
		goto error;
	}

	if (unlikely((budget != XPCXD_NO_LIMIT) && (budget < max)))
		max = budget;

	rxcr->round_cnt++;

	xpcxd_rx_opt_trace_ring(rx_poll_start, ring_id, rxr, (int)max, 0);

	while (k < max) {
		descs_this_pkt = 1;
		cmpl_idx = rxcr->cons & rxcr->mask;

		/* Prefetch next completion descriptor to hide memory latency (cache-friendly) */
		prefetch(&rxcr->desc[(cmpl_idx + 1) & rxcr->mask]);

		/* xpcxd_opt_trace(rx_poll_next, ring_id, n,
		 *	(int)xpcxd_get_cmpl_ring_space(rxr));
		 */

		xpcxd_dma_rmb();

		cmpl.w64[0] = rxcr->desc[cmpl_idx].w64[0];
		cmpl.w64[1] = rxcr->desc[cmpl_idx].w64[1];

		/* Per-iteration teardown gate */
		if (unlikely(xpcxd_rx_cmpl_teardown_check(
			    netdev, rxr, ring_id, stop_packets, true))) {
			rx_done = true;
			goto done;
		}

		/* Authoritative consume gate */
		if (cmpl.rxc.cmp_ctrl_valid == 0U) {
			xpcxd_rx_opt_trace_ring(rx_poll_stop, ring_id, rxr, n,
						(int)cmpl_idx);
			rx_done = true;
			goto done;
		}

		len = cmpl.rxc.len;
		descs_this_pkt = cmpl.rxc.num_desc;
		if (unlikely(!descs_this_pkt || descs_this_pkt > rxsr->size ||
			     cmpl.rxc.desc_index >= rxsr->size)) {
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"[%d] RX CMPL sanity failed: desc_index=%u num_desc=%u sub_size=%u",
				ring_id, cmpl.rxc.desc_index, descs_this_pkt,
				rxsr->size);
			xpcxd_set_error(netdev, NULL, xpci_rx,
					0x1 /*g_cnt_tx_stop*/,
					"RX ERROR: invalid completion descriptor");
			rx_done = true;
			goto done;
		}

		sw_desc = &rxr->sub.sw[cmpl.rxc.desc_index];
		/*
		 * Prefetch next sw_desc only on the steady-state single-
		 * page case.
		 */
		if (likely(descs_this_pkt == 1U))
			prefetch(&rxr->sub.sw[(cmpl.rxc.desc_index + 1) &
					      rxsr->mask]);

			/* xpcxd_opt_trace(rx_poll_sw_desc_index, ring_id, cmpl.rxc.desc_index, len); */

#ifdef __XPCXD_DEBUG__
		if (xpcxd_dbg_rx_page_state_check(netdev, ring_id, rxr, rxcr,
						  sw_desc, &cmpl, cmpl_idx,
						  cmpl_prd_ptr)) {
			rxr->stats.rx_stop_dbg_rx_abort++;
			rx_done = true;
			if (sw_desc->page && rxr->page_pool) {
				xpcxd_page_pool_recycle_direct(rxr->page_pool,
							       sw_desc->page);
				sw_desc->page_state = XPCXD_PAGE_FREE;
			}
			xpcxd_rx_sw_sub_cmpl_returned(rxr, cmpl.rxc.desc_index,
						      descs_this_pkt);
			xpcxd_rx_cmpl_slot_release(rxcr, cmpl_idx);
			rxcr->cons = (rxcr->cons + 1) & rxcr->mask;
			rxsr->cons = (rxsr->cons + descs_this_pkt) & rxsr->mask;
			n += descs_this_pkt;
			goto done;
		}
#endif

#ifdef __XPCXD_DEBUG__
		xpcxd_dbg_page_ring_push(sw_desc->page);
#endif

		if (!sw_desc->page || page_ref_count(sw_desc->page) != 1) {
			int ref = sw_desc->page ?
					  (int)page_ref_count(sw_desc->page) :
					  -1;

			rxr->stats.rx_free_ref_cnt_0_page++;
			xpcxd_trace_printk(
				"Invalid page ref_cnt: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
				ring_id, cmpl.rxc.desc_index,
				sw_desc->skb, sw_desc->page,
				sw_desc->page_state, ref);

			xpcxd_err_netdev(
				NETIF_MSG_DRV, netdev,
				"Invalid page ref_cnt: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
				ring_id, cmpl.rxc.desc_index,
				sw_desc->skb, sw_desc->page,
				sw_desc->page_state, ref);

			sw_desc->page = NULL;
			sw_desc->page_state = XPCXD_PAGE_FREE;

			goto next;
		}

		xpcxd_dma_sync_single_range_for_cpu(
			net_priv->hw_dev, sw_desc->addr, XPCXD_FRAG_OFFSET,
			len < XPCXD_FRAG_DATA_SIZE ? len :
						      XPCXD_FRAG_DATA_SIZE,
			DMA_FROM_DEVICE);

		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
			xprint_hex_dump(
				netdev, "--- RX DATA FROM PAGE ---",
				DUMP_PREFIX_OFFSET, 16, 1,
				page_address(
					sw_desc->page) /* + XPCXD_SKB_RX_HEADROOM */
				,
				len + XPCXD_SKB_RX_HEADROOM, true);
		}

/********************************************************************************
 *                         Packet structure
 * 
 *          Head Room	: XPCXD_SKB_RX_HEADROOM
 *          Data		: PAGE_SIZE - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM
 *          Tail Room	: XPCXD_SKB_SHINFO_SIZE
 *
 ********************************************************************************/

		if (len < XPCXD_FRAG_DATA_SIZE) {
			alloc_len = len + XPCXD_SKB_RX_HEADROOM +
				    XPCXD_SKB_TAIL_ROOM;
		} else {
			alloc_len = XPCXD_FRAG_DATA_SIZE +
				    XPCXD_SKB_RX_HEADROOM +
				    XPCXD_SKB_TAIL_ROOM;
		}
		alloc_len = SKB_DATA_ALIGN(alloc_len);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
		skb = napi_build_skb(page_address(sw_desc->page), alloc_len);
#else
		skb = build_skb(page_address(sw_desc->page), alloc_len);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0) */
		if (unlikely(!skb)) {
			xpcxd_trace_printk(
				"build_skb() error: skb: [%p] page: [%p] pfn: [%lu]",
				skb, sw_desc->page, page_to_pfn(sw_desc->page));

			xpcxd_page_pool_recycle_direct(rxr->page_pool,
						       sw_desc->page);
			sw_desc->page_state = XPCXD_PAGE_FREE;
			xpcxd_err_netdev(NETIF_MSG_RX_ERR, netdev,
					 "skb build failed");
			xpcxd_rx_opt_trace_ring(rx_build_skb_err, ring_id, rxr,
						n, len);
			rxr->stats.rx_stop_build_skb++;
			rxr->stats.errors++;
			xpcxd_rx_sw_sub_cmpl_returned(rxr, cmpl.rxc.desc_index,
						      descs_this_pkt);
			xpcxd_rx_cmpl_slot_release(rxcr, cmpl_idx);
			rxcr->cons = (rxcr->cons + 1) & rxcr->mask;
			rxsr->cons = (rxsr->cons + descs_this_pkt) &
				     rxsr->mask;
			n += descs_this_pkt;
			rx_done = true;
			goto done;
		}

		/* n += descs_this_pkt at next: for refill count */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0)
		skb_mark_for_recycle(skb);
#else
		/*
		 * Kernel < 5.14: skb_mark_for_recycle() is unavailable,
		 * so the stack will not return the page to page_pool when
		 * the SKB is freed (skb_free_frag() goes straight to the
		 * buddy allocator and never calls back into the pool).
		 * Release the page from pool tracking now: this unmaps the
		 * PP_FLAG_DMA_MAP mapping (DMA_ATTR_SKIP_CPU_SYNC, the CPU
		 * sync was already done above) and decrements the pool's
		 * inflight counter, while leaving the page at refcount 1 so
		 * the normal SKB release path frees it. Without this the
		 * pool leaks DMA mappings under traffic and stalls
		 * page_pool_destroy() with "page_pool_release_retry stalled
		 * pool shutdown" warnings at if-down.
		 */
		xpcxd_page_pool_release_page(rxr->page_pool, sw_desc->page);
#endif

		xpcxd_skb_align(skb, XPCXD_ALIGNMENT_256);

		skb_put(skb, len < XPCXD_FRAG_DATA_SIZE ? len :
						      XPCXD_FRAG_DATA_SIZE);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		if (unlikely(cmpl.rxc.num_desc > 1)) {
			xpcxd_dbg_netdev(
				NETIF_MSG_RX_STATUS, netdev,
				"---> [%d] PCXD RX: multi-page pkt: len=%d num_desc=%d desc_index=%d",
				ring_id, len, cmpl.rxc.num_desc,
				cmpl.rxc.desc_index);
			if (xpcxd_add_fragments(netdev, ring_id, skb, rxr, len,
						cmpl.rxc.desc_index,
						cmpl.rxc.num_desc) != 0) {
				xpcxd_consume_skb(netdev, skb);
				sw_desc->page_state = XPCXD_PAGE_FREE;
				rxr->stats.rx_stop_add_frag_failed++;
				rxr->stats.errors++;
				goto next;
			}
			n += (cmpl.rxc.num_desc - 1);
		}

		/* xpcxd_opt_trace(rx_poll_new_skb,  */
		/* 		ring_id, cmpl.rxc.desc_index, */
		/* 		skb, skb->len, */
		/* 		cmpl.rxc.num_desc, */
		/* 		cmpl.rxc.desc_index, */
		/* 		sw_desc, */
		/* 		sw_desc->page, */
		/* 		netdev->mtu, len_left */
		/* 		0); frag_size */

		if (skb->len > netdev->mtu) {
			rxr->stats.rx_drop_events++;
			xpcxd_dbg_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"---> [%d] PCXD CMPL RX: packet drop: skb->len: [%d] cmpl.len: [%d] > MTU: [%d] num_desc: [%d]",
				ring_id, skb->len, len, netdev->mtu,
				cmpl.rxc.num_desc);

			xpcxd_rx_opt_trace_ring(rx_poll_mtu_too_big, ring_id,
						rxr, n, skb->len);
			xpcxd_consume_skb(netdev, skb);

			rxr->stats.dropped++;
			rxr->stats.rx_mtu_exceeded++;

			sw_desc->page_state = XPCXD_PAGE_FREE;
			goto next;
		}

		/* Ensure skb->ip_summed is CHECKSUM_NONE. */
		skb_checksum_none_assert(skb);


		if (unlikely(cmpl.rxc.cmp_ctrl_l4_chks_err)) {
			/* Collect L4 CRC errors per ring, not per net device. */
			rxr->stats.rx_l4_csm_err++;
			rxr->stats.hw_csum_rx_error++;
			skb->ip_summed = CHECKSUM_NONE;

			/* Drop only when L4 checksum errors are not ignored. */
			if (!xpcxd_rx_ignore_l4_checksum_err) {
				rxr->stats.dropped++;
				rxr->stats.rx_drop_events++;
				xpcxd_page_pool_recycle_direct(
					rxr->page_pool, sw_desc->page);
				sw_desc->page_state = XPCXD_PAGE_FREE;
				xpcxd_consume_skb(netdev, skb);
				goto next;
			}
		} else {
			l4_csum = true;

			/* TCP or UDP packet with a valid checksum */

			/* 
			* https://elixir.bootlin.com/linux/v5.15.160/source/include/linux/skbuff.h#L889
			* 
			* CHECKSUM_UNNECESSARY:
			*
			*   The hardware you're dealing with doesn't calculate the full checksum
			*   (as in CHECKSUM_COMPLETE), but it does parse headers and verify checksums
			*   for specific protocols. For such packets it will set CHECKSUM_UNNECESSARY
			*   if their checksums are okay. skb->csum is still undefined in this case
			*   though. A driver or device must never modify the checksum field in the
			*   packet even if checksum is verified.
			*/

			skb->ip_summed = CHECKSUM_UNNECESSARY;
			skb->csum_level = 1;
		}

		if (xpcxd_num_of_rings > 1)
			skb_record_rx_queue(skb, ring_id);

		/* Below enabled RPS even if only a single ring is configured and RSS is enabled */
		if ((netdev->features & NETIF_F_RXHASH) &&
		    (xpcxd_rss_mode == XPCXD_RSS_MODE_FULL))
			skb_set_hash(skb, cmpl.rxc.rss_hash, PKT_HASH_TYPE_L4);

			/* ****************************** */
			/* TODO: REMOVE AFTER SHIM CONFIG */
			/* ****************************** */
#ifdef __XPCXD_LOOPBACK__
		if (unlikely(xpcxd_loopback)) {
			skb_pull(skb, XPCXD_HW_SHIM_SIZE);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				/* xprint_hex_dump(netdev, "--- RX DATA AFTER TRIM ---", */
				/* 		DUMP_PREFIX_OFFSET, 16, 1, skb->data, */
				/* 		skb->len, true); */
				xpcxd_print_multipage_skb_data(
					"--- RX DATA AFTER TRIM ---", netdev,
					skb);
				xpci_print_pkt("RX AFTER AFTER TRIM", netdev,
					       skb, RX_OFFSET, xpci_rx);
			}
		}
#endif /* __XPCXD_LOOPBACK__ */

		skb->protocol = eth_type_trans(skb, netdev);

		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpcxd_print_multipage_skb_data("--- RX DATA ---",
						       netdev, skb);

		/* Update statistics per ring (batched: single u64_stats update at exit) */
		local_packets++;
		local_bytes += len;

#ifdef __XPCXD_TRAILER_CHECK__
		xpcxd_itg_trailer_check(netdev, page_address(sw_desc->page),
					len, ring_id);
#endif

		/*
		 * Runtime gate around the per-packet ETH/IPv4/IPv6/ARP parse
		 * + classify; flips via /sys/module/xpci/parameters/pcxd_rx_stats_uc_mc_bc.
		 * READ_ONCE so the read isn't hoisted out of the consume loop —
		 * lets operators turn the work off/on between bursts without
		 * waiting for a fresh poll boundary.
		 */
		if (READ_ONCE(xpcxd_rx_stats_uc_mc_bc)) {
			eth = eth_hdr(skb);
			/* Calculate per packet statistics (unicast/multicast/broadcast) */
			if (likely(eth->h_proto == htons(ETH_P_IP))) {
				iph = ip_hdr(skb);
				if (iph->daddr == htonl(INADDR_BROADCAST)) {
					rxr->stats.rx_broadcast++;
				} else if (iph->daddr >= htonl(224 << 24) &&
					   iph->daddr <=
						   htonl(239 << 24 | 255 << 16 |
							 255 << 8 | 255)) {
					rxr->stats.rx_multicast++;
				} else {
					rxr->stats.rx_unicast++;
				}
			} else {
				if (likely(eth->h_proto == htons(ETH_P_IPV6))) {
					ip6h = ipv6_hdr(skb);
					if (ipv6_addr_is_multicast(
						    &ip6h->daddr)) {
						rxr->stats.rx_multicast++;
					} else {
						rxr->stats.rx_unicast++;
					}
				} else {
					if (likely(eth->h_proto ==
						   htons(ETH_P_ARP))) {
						if (is_broadcast_ether_addr(
							    eth->h_dest)) {
							rxr->stats
								.rx_broadcast++;
						} else {
							rxr->stats.rx_unicast++;
						}
					}
				}
			}
		}

#ifdef __XPCXD_DEBUG__
		if (xpcxd_dbg_rx_drop_all_handle(netdev, ring_id, rxr, sw_desc,
						 skb))
			goto next;

		if (xpcxd_dbg_rx_packets_stop_handle(netdev, ring_id, rxr, rxcr,
						     sw_desc, skb, &cmpl,
						     cmpl_prd_ptr))
			goto next;

		if (xpcxd_dbg_rx_page_ref_check(netdev, ring_id, rxr, sw_desc,
						skb)) {
			rxr->stats.rx_stop_dbg_rx_abort++;
			rx_done = true;
			xpcxd_consume_skb(netdev, skb);
			if (sw_desc->page && rxr->page_pool) {
				xpcxd_page_pool_recycle_direct(rxr->page_pool,
							       sw_desc->page);
				sw_desc->page_state = XPCXD_PAGE_FREE;
			}
			xpcxd_rx_sw_sub_cmpl_returned(rxr, cmpl.rxc.desc_index,
						      descs_this_pkt);
			xpcxd_rx_cmpl_slot_release(rxcr, cmpl_idx);
			rxcr->cons = (rxcr->cons + 1) & rxcr->mask;
			rxsr->cons = (rxsr->cons + descs_this_pkt) & rxsr->mask;
			n += descs_this_pkt;
			rx_done = true;
			goto done;
		}
#endif /* __XPCXD_DEBUG__ */

#ifdef __XPCXD_ICMP_TRACE__
		xpcxd_check_icmp_echo(skb, netdev);
#endif
		sw_desc->page_state = XPCXD_PAGE_PASSED_TO_STACK;

			/* xpcxd_trace_printk("skb passed to stack skb: [%p] page: [%p] pfn: [%lu]", */
			/* 			skb, sw_desc->page, page_to_pfn(sw_desc->page)); */

			/* xpcxd_opt_trace(rx_skb_pass_to_stack, ring_id, skb->len, skb, page_to_pfn(sw_desc->page)); */
			/* xpcxd_trace_printk("rx_skb_pass_to_stack: rind_id: %d skb: [%p] skb->len: %d pfn: [%lu]", */
			/* 	ring_id, skb, skb->len, page_to_pfn(sw_desc->page)); */

#ifdef __XPCXD_RX_PKT_SIZE_HISTOGRAM__
		xpcxd_rx_pkt_size_histogram(rxr, skb->len);
#endif
		skb_mark_napi_id(skb, napi);
		/* netif_receive_skb(skb); */
		napi_gro_receive(napi, skb);
	next:
		/* One CMPL slot consumed — must bump k here so every goto next path advances NAPI budget
		 * (k++ was previously only after MTU check, so MTU drops / early next caused k<max forever).
		 */
		k++;
		/*
		 * One completion consumed; num_desc submit descriptors
		 * consumed (multi-page uses multiple buffers).
		 */
		xpcxd_rx_sw_sub_cmpl_returned(rxr, cmpl.rxc.desc_index,
					      descs_this_pkt);
		xpcxd_rx_cmpl_slot_release(rxcr, cmpl_idx);
		rxcr->cons = (rxcr->cons + 1) & rxcr->mask;
		rxsr->cons = (rxsr->cons + descs_this_pkt) & rxsr->mask;
		n += descs_this_pkt; /* refill count: buffers freed (success or drop) */
	};

done:
	/*
	 * Publish all per-slot cmp_ctrl_valid clears with one
	 * xpcxd_dma_wmb()
	 */
	xpcxd_dma_wmb();
	{
		u32 rx_sub_free_space = 0;

		/*
		 * The credits adjuster early-returns when both rx_credits and
		 * rx_credits_cap are zero
		 */
		if (rxr->rx_credits || rxr->rx_credits_cap) {
			rx_sub_free_space = rxr->sub.size -
					    xpcxd_get_rx_sub_ring_space(rxr);
			xpcxd_rx_credits_adjust_for_sub_free(rxr,
							     rx_sub_free_space);
		}
		/* Refill when this poll freed SUB (n>0) or deferred rx_credits remain (n==0).
		 * When n==0 but rx_credits/rx_credits_cap are zero, skip this block so we do
		 * not arm the refill osc while credits could refill immediately.
		 */
		if (likely(n) || rxr->rx_credits) {
			if (rxr->rx_refill_osc_timer.function)
				hrtimer_cancel(&rxr->rx_refill_osc_timer);
			if (rxr->rx_credits) {
				u32 want = n + rxr->rx_credits;
				u32 low_free_pct =
					xpcxd_rx_sub_low_free_thresh_pct();

				/*
				 * Refill up to free space; carry over unused
				 * credits instead of halving (avoids
				 * sustained throughput drop).
				 */
				if (want <= rx_sub_free_space) {
					n = want;
					rxr->rx_credits = 0;
					rxr->rx_credits_cap = 0;
					xpcxd_rx_opt_trace_ring(
						rx_poll_space_check, ring_id,
						rxr, n, 0);
				} else {
					n = rx_sub_free_space;
					rxr->rx_credits =
						want - rx_sub_free_space;
					rxr->rx_credits_cap = rxr->rx_credits;
					xpcxd_rx_opt_trace_ring(
						rx_poll_space_check_failed,
						ring_id, rxr,
						(int)rx_sub_free_space,
						(int)rxr->rx_credits);
					if (low_free_pct) {
						u32 low_free_thresh =
							(rxr->sub.size *
							 low_free_pct) /
							100U;

						if (!low_free_thresh)
							low_free_thresh = 1U;
						if (rx_sub_free_space <
						    low_free_thresh)
							xpcxd_rx_credits_apply_slash(
								rxr);
					}
				}
			}
			if (n)
				xpcxd_rx_fill(netdev, napi, ring_id, rxr, n,
					      &processed, true);
		} else if (rxr->tx_rx_enabled && netif_running(netdev)) {
			/* n==0: no SUB descs freed this poll — one-shot NAPI kick (deferred
			 * rx_credits refill, or completions that arrive without a fresh IRQ).
			 * If SUB (prod-cons)&mask == 0 and no doorbelled SUB is still in
			 * flight with HW, the hrtimer only re-schedules NAPI — rx_fill never
			 * runs — so a never-primed ring spins idle. Prime like open().
			 *
			 * Do not use ring occupancy alone: prod==cons is also true when the
			 * ring is full (prod wrapped); priming then would call rx_fill on
			 * every idle poll and peg a CPU (same ambiguity as CMPL cons==prd).
			 */
			bool arm_osc = true;

			if (xpcxd_get_rx_sub_ring_space(rxr) == 0U &&
			    (s64)rxr->stats.rx_sw_sub_posted_hw -
					    (s64)rxr->stats.rx_sw_cmpl_returned ==
				    0 &&
			    !READ_ONCE(xpcxd_cfg_tbl[xpcxd_rx_drop_all]) &&
			    !stop_packets) {
				u32 prime_n = (u32)net_priv->num_rx_desc;

				if (prime_n > (u32)rxr->sub.size)
					prime_n = (u32)rxr->sub.size;
				rxr->stats.rx_osc_empty_sub_prime++;
				(void)xpcxd_rx_fill(netdev, napi, ring_id, rxr,
						    (u16)prime_n, &processed,
						    true);
				if (xpcxd_get_rx_sub_ring_space(rxr) != 0U ||
				    rxr->rx_credits != 0U) {
					if (rxr->rx_refill_osc_timer.function)
						hrtimer_cancel(
							&rxr->rx_refill_osc_timer);
					arm_osc = false;
				}
			}
			if (arm_osc && rxr->rx_refill_osc_timer.function &&
			    !hrtimer_active(&rxr->rx_refill_osc_timer)) {
				u32 osc_min_j =
					xpcxd_rx_refill_osc_min_arm_jiffies;
				bool osc_throttle =
					osc_min_j != 0U &&
					time_before(
						jiffies,
						rxr->rx_refill_osc_last_arm_jiffy +
							osc_min_j);

				if (!osc_throttle) {
					rxr->rx_refill_osc_irq_streak = 0;
					rxr->rx_refill_osc_irq_snap = READ_ONCE(
						rxr->stats.cmpl_irq_cnt);
					hrtimer_start(
						&rxr->rx_refill_osc_timer,
						ms_to_ktime(
							XPCXD_RX_REFILL_OSC_MS),
						HRTIMER_MODE_REL);
					rxr->rx_refill_osc_last_arm_jiffy =
						jiffies;
					xpcxd_rx_opt_trace_ring(
						rx_refill_osc_start, ring_id,
						rxr,
						(int)XPCXD_RX_REFILL_OSC_MS, k);
				}
			}
		}
	}

	xpcxd_info_netdev(NETIF_MSG_RX_STATUS, netdev,
			  "---> [%d] PCXD CMPL RX: FILL DONE", ring_id);

error:
	if (local_packets) {
		u64_stats_update_begin(&rxr->syncp);
		rxr->stats.packets += local_packets;
		rxr->stats.bytes += local_bytes;
		u64_stats_update_end(&rxr->syncp);
	}
	*done_packets = k;
	/*
	 * Per-poll diagnostic stats
	 */
	xpcxd_rx_cmpl_diag_tail(netdev, rxr, ring_id, n, k,
				rx_cmpl_poll_spacing_jiffies);

	return rx_done;
}

static bool xpcxd_tx_cmpl(struct net_device *netdev, u32 ring_id, u16 budget,
			  u16 *done_packets)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr = &net_priv->txr[ring_id];
	struct xpcxd_compl_ring *txcr = &net_priv->txr[ring_id].cmp;
	struct xpcxd_submit_ring *txsr = &net_priv->txr[ring_id].sub;
	u16 max = txcr->size;
	struct xpcxd_desc cmpl = { 0 };
	u16 i;
	u32 tx_pkts = 0, tx_bytes = 0;
	u16 cmpl_prd_ptr = 0;
	u16 tx_space = 0;
	bool tx_done = false;

	txr->cmp.cmpl_prd_ptr =
		xpcxd_get_tx_cmpl_prod_ptr(xpcxd_netdev, ring_id);

	cmpl_prd_ptr = txcr->cmpl_prd_ptr;

	if (unlikely((budget != XPCXD_NO_LIMIT) && (budget < max)))
		max = budget;

	/* Single combined entry-state dump (replaces three back-to-back
	 * dbg_netdev calls; reduces icache footprint on the cmpl path).
	 */
	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD CMPL TX: IN size:%d mask:0x%x cmpl_prd_ptr:%d cons:%d max:%d budget:%d",
		ring_id, txcr->size, txcr->mask, cmpl_prd_ptr, txcr->cons, max,
		budget);

	/* Teardown: exit TX NAPI quickly so napi_disable() cannot hang (mirror rx_drop_all path). */
	if (unlikely(xpcxd_cfg_tbl[xpcxd_tx_drop_all])) {
		tx_done = true;
		goto done;
	}

	for (i = 0; i < max; i++) {
		u16 cmpl_idx = txcr->cons & txcr->mask;
		struct xpcxd_sw_desc *sw_desc;

		if (unlikely(xpcxd_cfg_tbl[xpcxd_tx_drop_all])) {
			tx_done = true;
			goto done;
		}

		if (cmpl_idx == cmpl_prd_ptr) {
			tx_done = true;
			goto done;
		}

		/*
		 * Prefetch the next completion descriptor (read-only) and
		 * — once we've decoded cmpl.txc.desc_index below — the
		 * follow-on sw_desc, so the next iteration's loads land in
		 * L1. Also prefetchw() this iteration's sw_desc since we're
		 * about to write it (skb=NULL or xdpf=NULL + is_xdp=false).
		 * Mirrors the prefetch pattern used in the RX cmpl loop.
		 */
		prefetch(&txcr->desc[(txcr->cons + 1) & txcr->mask]);

		xpcxd_dma_rmb();
		cmpl.w64[0] = txcr->desc[cmpl_idx].w64[0];
		cmpl.w64[1] = txcr->desc[cmpl_idx].w64[1];

		if (!cmpl.txc.cmp_ctrl_valid) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD CMPL TX: VALID ERR "
				"cmp_ctrl_valid: 0x%x OR cmpl_idx:%d "
				"cmpl_prd_ptr:%d txcr->cons: %d txcr->mask: %d",
				ring_id, cmpl.txc.cmp_ctrl_valid, cmpl_idx,
				cmpl_prd_ptr, txcr->cons, txcr->mask);
		}

		/* ------------------------------------------------------ */
		/* Set completion descriptor bit invalid for future usage */
		cmpl.txc.cmp_ctrl_valid = 0;
		/* ------------------------------------------------------ */
		if (unlikely(!cmpl.txc.num_desc ||
			     cmpl.txc.num_desc > txsr->size ||
			     cmpl.txc.desc_index >= txsr->size)) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR, netdev,
				"[%d] TX CMPL sanity failed: desc_index=%u num_desc=%u sub_size=%u cmpl_idx=%u",
				ring_id, cmpl.txc.desc_index, cmpl.txc.num_desc,
				txsr->size, cmpl_idx);
			xpcxd_set_error(netdev, NULL, xpci_rx,
					0x1 /*g_cnt_tx_stop*/,
					"TX ERROR: invalid completion descriptor");
			tx_done = true;
			goto done;
		}

		sw_desc = &(txsr->sw[cmpl.txc.desc_index]);
		/* Bring the sw_desc cache line in M-state for the imminent
		 * skb=NULL / xdpf=NULL writes; warm next-iteration sw_desc.
		 */
		prefetchw(sw_desc);
		prefetch(&txsr->sw[(cmpl.txc.desc_index + 1) & txsr->mask]);

		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD CMPL TX: [%d] cmpl_idx: %d "
			"sw_desc: [%p] sw_dma_addr: [%llx] dma_len: [%d] "
			"skb: %p tx_src: %u",
			ring_id, i, cmpl_idx, sw_desc,
			dma_unmap_addr(sw_desc, sw_dma_addr),
			dma_unmap_len(sw_desc, dma_len), sw_desc->skb,
			sw_desc->tx_src);

		/*
		 * Reclaim path depends on how xpcxd_xmit()/xpcxd_xdp_xmit_frame()
		 * got the payload onto the ring:
		 *
		 *   POOL   - payload memcpy'd into tx_pool slot; skb already freed
		 *            at enqueue time. No dma_unmap (coherent slot), no free.
		 *            Byte count comes from the dma_len field (set to skb->len
		 *            at enqueue) since the skb is gone.
		 *   XDP    - xdpf DMA-mapped at enqueue; return frame + unmap.
		 *   MAPPED - legacy skb DMA-mapped at enqueue; free skb + unmap.
		 */
		switch (sw_desc->tx_src) {
		case XPCXD_TX_SRC_POOL:
			tx_pkts++;
			tx_bytes += dma_unmap_len(sw_desc, dma_len);
			/* No dma_unmap_single(); slot stays DMA-mapped for
			 * the life of the ring. sw_desc->skb was cleared at
			 * enqueue.
			 */
			break;

		case XPCXD_TX_SRC_XDP:
#if IS_ENABLED(CONFIG_BPF_SYSCALL)
			if (likely(sw_desc->xdpf)) {
				tx_pkts++;
				tx_bytes += sw_desc->xdpf->len;
				xpcxd_dma_unmap_single(
					net_priv->hw_dev,
					dma_unmap_addr(sw_desc, sw_dma_addr),
					dma_unmap_len(sw_desc, dma_len),
					DMA_TO_DEVICE);
				xdp_return_frame(sw_desc->xdpf);
				sw_desc->xdpf = NULL;
				sw_desc->is_xdp = false;
			} else {
				netdev_warn_once(
					netdev,
					"[%u] TX CMPL: XDP slot with NULL xdpf; skipping DMA unmap\n",
					ring_id);
			}
#else
			netdev_warn_once(
				netdev,
				"[%u] TX CMPL: XDP slot while CONFIG_BPF_SYSCALL is off\n",
				ring_id);
#endif
			break;

		case XPCXD_TX_SRC_NONE:
			netdev_warn_once(
				netdev,
				"[%u] TX CMPL: empty slot (tx_src=NONE); skipping\n",
				ring_id);
			break;

		case XPCXD_TX_SRC_MAPPED:
			if (likely(sw_desc->skb)) {
				tx_pkts++;
				tx_bytes += sw_desc->skb->len;
				dev_kfree_skb(sw_desc->skb);
				sw_desc->skb = NULL;
			} else {
				xpcxd_err_netdev(
					NETIF_MSG_TX_ERR, netdev,
					"---> [%d] PCXD CMPL TX: [%d] cmpl_prd_ptr: [%d] sw_desc: [%p] mapped slot has NULL skb",
					ring_id, i, cmpl_prd_ptr, sw_desc);
				xpcxd_set_error(netdev, NULL, xpci_rx,
						0x1 /*g_cnt_tx_stop*/,
						"TX ERROR: empty descrptor");
				goto done;
			}
			xpcxd_dma_unmap_single(
				net_priv->hw_dev,
				dma_unmap_addr(sw_desc, sw_dma_addr),
				dma_unmap_len(sw_desc, dma_len),
				DMA_TO_DEVICE);
			break;

		default:
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD CMPL TX: [%d] cmpl_prd_ptr: [%d] sw_desc: [%p] invalid tx_src=%u",
				ring_id, i, cmpl_prd_ptr, sw_desc,
				sw_desc->tx_src);
			xpcxd_set_error(netdev, NULL, xpci_rx,
					0x1 /*g_cnt_tx_stop*/,
					"TX ERROR: invalid tx_src");
			goto done;
		}

		/* Mark slot as reclaimed and clear stale DMA metadata. */
		dma_unmap_addr_set(sw_desc, sw_dma_addr, 0);
		dma_unmap_len_set(sw_desc, dma_len, 0);
		sw_desc->tx_src = XPCXD_TX_SRC_NONE;

		txcr->cons++;

		/* Wrap CMPL cons */
		if (unlikely(txcr->cons >= txcr->size))
			txcr->cons = 0;

		txsr->cons = txsr->cons + cmpl.txc.num_desc;
		/* Wrap SUB cons */
		if (unlikely(txsr->cons >= txsr->size))
			txsr->cons = 0;

		/* Single per-iteration trace */
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD CMPL TX: [%d] cons cmpl:%d sub:%d num_desc:%d",
			ring_id, i, txcr->cons, txsr->cons, cmpl.txc.num_desc);
	}

done:
	tx_space = xpcxd_get_tx_sub_ring_space(txr);
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			 "---> [%d] PCXD CMPL TX: Free space: %d", ring_id,
			 tx_space);

	if (likely(!READ_ONCE(xpcxd_ifdown_in_progress) &&
		   !READ_ONCE(xpcxd_close_started)) &&
	    unlikely(netif_tx_queue_stopped(txr->queue))) {
		if (likely(tx_space >= XPCXD_TX_STOP_THOLD)) {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD CMPL TX: starting tx queue",
				ring_id);
			netif_tx_wake_queue(txr->queue);
		}
	}

	xpcxd_info_netdev(NETIF_MSG_TX_QUEUED, netdev,
			  "---> [%d] PCXD CMPL TX: OUT: i: %d tx_pkts: %d",
			  ring_id, i, tx_pkts);

	*done_packets = tx_pkts;

	return tx_done;
}

static int xpcxd_rx_poll(struct napi_struct *napi, int budget)
{
	struct xpcxd_ring *rxr = container_of(napi, struct xpcxd_ring, napi);
	struct net_device *netdev = napi->dev;
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = rxr ? rxr->ring_id : 0;
	u16 rx_pkts = 0;
	int vec = ring_id + XPCI_X2_RX_CMP_INT_MIN;
	bool rx_done = false;
	u32 hw_cmpl_free;
	u32 rx_cmpl_hold_low_thresh = 0;
	u32 pct = xpcxd_rx_cmpl_napi_hold_low_hw_credits;

	if (pct > 100U)
		pct = 100U;
	if ((net_priv->priv_flags & XPCXD_FLAG_RX_CMPL_NAPI_HOLD_LOW_HW) &&
	    pct > 0U && rxr->cmp.size > 1U) {
		rx_cmpl_hold_low_thresh = ((u32)rxr->cmp.size * pct) / 100U;
		if (rx_cmpl_hold_low_thresh == 0U)
			rx_cmpl_hold_low_thresh = 1U;
		if (rx_cmpl_hold_low_thresh >= (u32)rxr->cmp.size)
			rx_cmpl_hold_low_thresh = (u32)rxr->cmp.size - 1U;
	}

	xpcxd_info_netdev(NETIF_MSG_RX_STATUS, netdev,
			  "---> [%d] PCXD NAPI RX: IN vec: %d rxr: %p", ring_id,
			  vec, rxr);

	rx_done = xpcxd_rx_cmpl(netdev, napi, rxr, ring_id, budget, &rx_pkts);
	if (unlikely(rx_done)) {
		bool force_napi_complete =
			READ_ONCE(xpcxd_ifdown_in_progress) ||
			READ_ONCE(xpcxd_close_started) ||
					   xpcxd_cfg_tbl[xpcxd_rx_drop_all];

		/*
		 * If the CMPL ring is near-empty (low HW credits), completing
		 * NAPI and re-arming MSI-X risks an Rx deadlock — HW may not
		 * fire another IRQ until a slot opens. Keep NAPI scheduled
		 * (return @budget) so softirq repolls without re-arming.
		 *
		 * Exception: on ifdown / close / rx_drop_all we must call
		 * napi_complete() so napi_disable() can finish.
		 *
		 * Optional low-credit hold: re-poll only after draining
		 * (rx_pkts > 0); skip on idle polls. Distinct from the
		 * hw_cmpl_free==0 starvation case (rx_cmpl_full_napi_held)
		 * handled above — here credits are nonzero but tight.
		 */
		hw_cmpl_free = xpcxd_hw_rx_cmpl_ring_free_slots(rxr);
		if (force_napi_complete) {
			if (unlikely(hw_cmpl_free == 0)) {
				rxr->cmp.cmpl_prd_ptr =
					xpcxd_get_rx_cmpl_prod_ptr(netdev,
								   ring_id);
				xpcxd_opt_trace(
					rx_drop_all, (int)ring_id, 2,
					(int)xpcxd_cfg_tbl[xpcxd_rx_drop_all]);
				xpcxd_dbg_netdev(
					NETIF_MSG_DRV, netdev,
					"---> [%d] PCXD NAPI RX[1]: CMPL HW full during ifdown/drop_all — napi_complete",
					ring_id);
			}
			xpcxd_rx_opt_trace_ring(rx_napi_complete, ring_id, rxr,
						(int)rx_pkts, 0);
			napi_complete(napi);
			if (!READ_ONCE(xpcxd_ifdown_in_progress) &&
			    !READ_ONCE(rxr->stats.int_enabled)) {
				xpcxd_rx_opt_trace_ring(rx_enable_irq, ring_id,
							rxr, vec, 0);
				/* int_enabled before unmask: pending MSI-X can run ISR synchronously;
				 * if it still saw false, we'd return IRQ_NONE and skip napi_schedule.
				 */
				WRITE_ONCE(rxr->stats.int_enabled, true);
				smp_wmb();
				xpci_enable_msix_interrupt(g_pxdev, vec);
			}
		} else if (unlikely(hw_cmpl_free == 0)) {
			rxr->stats.rx_cmpl_full_napi_held++;
			rxr->cmp.cmpl_prd_ptr =
				xpcxd_get_rx_cmpl_prod_ptr(netdev, ring_id);

			xpcxd_rx_opt_trace_ring(rx_napi_hold, ring_id, rxr,
						(int)hw_cmpl_free,
						(int)rx_pkts);
			xpcxd_dbg_netdev(
				NETIF_MSG_DRV, netdev,
				"---> [%d] PCXD NAPI RX[2]: CMPL HW full "
				"(0 credits) after poll - hold NAPI "
				"(return budget), IRQ stays off",
				ring_id);
			if (rxr->rx_refill_osc_timer.function)
				hrtimer_cancel(&rxr->rx_refill_osc_timer);
			/* napi_reschedule() is a no-op while NAPI_STATE_SCHED is still set during ->poll();
			 * returning budget forces __napi_poll *repoll so this napi stays on the repoll list.
			 */
			if (rxr->tx_rx_enabled && netif_running(netdev)) {
				xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
						 "OUT: budget: %d rx_pkts: %d",
						 budget, rx_pkts);
				return budget;
			}

			xpcxd_dbg_netdev(
				NETIF_MSG_DRV, netdev,
				"---> [%d] PCXD NAPI RX: HW-full hold skipped (!running or ring disabled) — napi_complete",
				ring_id);
			xpcxd_rx_opt_trace_ring(rx_napi_complete, ring_id, rxr,
						(int)rx_pkts, 0);
			napi_complete(napi);
			if (!READ_ONCE(xpcxd_ifdown_in_progress) &&
			    !READ_ONCE(xpcxd_close_started) &&
			    !READ_ONCE(rxr->stats.int_enabled)) {
				xpcxd_rx_opt_trace_ring(rx_enable_irq, ring_id,
							rxr, vec, 0);
				WRITE_ONCE(rxr->stats.int_enabled, true);
				smp_wmb();
				xpci_enable_msix_interrupt(g_pxdev, vec);
			}
			xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
					 "OUT: budget: %d rx_pkts: %d", budget,
					 rx_pkts);
			return rx_pkts;
		} else if (rx_cmpl_hold_low_thresh > 0 &&
			   hw_cmpl_free != (u32)-1 &&
			   hw_cmpl_free <= rx_cmpl_hold_low_thresh &&
			   rx_pkts > 0) {
			u32 __maybe_unused sw_cmpl_free =
				xpcxd_get_cmpl_ring_space(rxr);

			rxr->stats.rx_cmpl_low_hw_napi_held++;
			/* NAPI can repoll in a tight loop while credits stay low; rate-limit trace/dbg. */
			if (!rxr->rx_cmpl_low_hw_trace_jiffy ||
			    time_after(jiffies,
				       rxr->rx_cmpl_low_hw_trace_jiffy + HZ)) {
				rxr->rx_cmpl_low_hw_trace_jiffy = jiffies;
				xpcxd_opt_trace(rx_cmpl_low_hw_napi_held,
						(int)ring_id, hw_cmpl_free,
						rx_cmpl_hold_low_thresh, budget,
						(int)rx_pkts,
						(u16)rxr->cmp.size,
						sw_cmpl_free, (int)rx_done,
						rxr->rx_credits,
						rxr->rx_credits_cap);

				xpcxd_rx_opt_trace_ring(rx_napi_hold, ring_id,
							rxr, (int)hw_cmpl_free,
							(int)rx_pkts);
				xpcxd_dbg_netdev(
					NETIF_MSG_RX_STATUS, netdev,
					"---> [%d] PCXD NAPI RX: CMPL HW credits "
					"low (%u <= %u) after drain - hold NAPI "
					"(return budget)",
					ring_id, hw_cmpl_free,
					rx_cmpl_hold_low_thresh);
			}
			rxr->cmp.cmpl_prd_ptr =
				xpcxd_get_rx_cmpl_prod_ptr(netdev, ring_id);
			if (rxr->rx_refill_osc_timer.function)
				hrtimer_cancel(&rxr->rx_refill_osc_timer);
			if (rxr->tx_rx_enabled && netif_running(netdev)) {
				xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
						 "OUT: budget: %d rx_pkts: %d",
						 budget, rx_pkts);
				return budget;
			}
			xpcxd_dbg_netdev(
				NETIF_MSG_DRV, netdev,
				"---> [%d] PCXD NAPI RX: low-credit hold skipped (!running or ring disabled) — napi_complete",
				ring_id);
			xpcxd_rx_opt_trace_ring(rx_napi_complete, ring_id, rxr,
						(int)rx_pkts, budget);
			napi_complete(napi);
			if (!READ_ONCE(xpcxd_ifdown_in_progress) &&
			    !READ_ONCE(xpcxd_close_started) &&
			    !READ_ONCE(rxr->stats.int_enabled)) {
				xpcxd_rx_opt_trace_ring(rx_enable_irq, ring_id,
							rxr, vec, 0);
				WRITE_ONCE(rxr->stats.int_enabled, true);
				smp_wmb();
				xpci_enable_msix_interrupt(g_pxdev, vec);
			}
			xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
					 "OUT: budget: %d rx_pkts: %d", budget,
					 rx_pkts);
			return rx_pkts;
		} else {
			xpcxd_rx_opt_trace_ring(rx_napi_complete, ring_id, rxr,
						(int)rx_pkts, 0);
			napi_complete(napi);
			if (!READ_ONCE(rxr->stats.int_enabled)) {
				/* xpcxd_info_netdev(NETIF_MSG_INTR, netdev, "Interrupt Enable"); */
				xpcxd_rx_opt_trace_ring(rx_enable_irq, ring_id,
							rxr, vec, 0);
				WRITE_ONCE(rxr->stats.int_enabled, true);
				smp_wmb();
				xpci_enable_msix_interrupt(g_pxdev, vec);
			}
		}
	} else {
		xpcxd_rx_opt_trace_ring(rx_napi_next, ring_id, rxr,
					(int)rx_pkts, 0);
	}

	/* Same as TX: rx_done false after exhausting the budget strands NAPI during teardown. */
	if (unlikely(!rx_done &&
		     (READ_ONCE(xpcxd_ifdown_in_progress) ||
		      READ_ONCE(xpcxd_close_started)))) {
		xpcxd_notice_netdev(
			NETIF_MSG_IFDOWN, netdev,
			"[%d] PCXD NAPI RX: ifdown — force napi_complete (budget exit)",
			ring_id);
		napi_complete(napi);
	}

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
			 "OUT: budget: %d rx_pkts: %d", budget, rx_pkts);

	return rx_pkts;
}

static int xpcxd_tx_poll(struct napi_struct *napi, int budget)
{
	struct xpcxd_ring *txr = container_of(napi, struct xpcxd_ring, napi);
	struct net_device *netdev = napi->dev;
	/* struct xpcxd_priv *net_priv = netdev_priv(netdev); */
	u32 ring_id = txr ? txr->ring_id : 0;
	u16 tx_pkts = 0;
	int vec = ring_id + XPCI_X2_TX_CMP_INT_MIN;
	bool tx_done = false;

	xpcxd_info_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> PCXD NAPI TX: IN");

	netif_tx_lock(netdev);

	if (READ_ONCE(txr->stats.int_enabled)) {
		xpci_disable_msix_interrupt(g_pxdev, vec);
		WRITE_ONCE(txr->stats.int_enabled, false);
	}
	tx_done = xpcxd_tx_cmpl(netdev, ring_id, budget, &tx_pkts);
	if (unlikely(tx_done || READ_ONCE(xpcxd_ifdown_in_progress) ||
		     READ_ONCE(xpcxd_close_started))) {
		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"TX NAPI COMPLETE - budget of: %d tx_pkts: %d (ifdown=%d close=%d)",
			budget, tx_pkts, READ_ONCE(xpcxd_ifdown_in_progress),
			READ_ONCE(xpcxd_close_started));
		napi_complete(napi);
		if (!READ_ONCE(xpcxd_ifdown_in_progress) &&
		    !READ_ONCE(xpcxd_close_started) &&
		    !READ_ONCE(txr->stats.int_enabled)) {
			WRITE_ONCE(txr->stats.int_enabled, true);
			smp_wmb();
			xpci_enable_msix_interrupt(g_pxdev, vec);
		}
	} else {
		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"TX NAPI NEXT - budget of: %d finished tx_pkts: %d",
			budget, tx_pkts);
	}
	netif_tx_unlock(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "OUT");

	return tx_pkts;
}

static u32 db_rate_sum = 0;
static u32 db_count = 0;

static enum hrtimer_restart xpcxd_ring_time_isr(struct hrtimer *timer)
{
	struct xpcxd_ring *ring;

	/* xpcxd_dbg("IN"); */

	ring = container_of(timer, struct xpcxd_ring, time_isr);

	if (arm_timer_isr) {
		xpcxd_err(
			NETIF_MSG_TIMER,
			"[%s] Ring[%d] Pkts: [%lld] Cmpl Prd: [%d] "
			"Sub Ring Space: [%d<--|p:%d|c:%d] "
			"Cmpl Ring Space: [%d<--|p:%d|c:%d] "
			"Irq Cnt: [%d] Int: [%s] DB Rate: [%d] "
			"Status: [%s]",
			(ring->type == XPCXD_RING_TX) ? "TX" : "RX",
			ring->ring_id,
			ring->stats.packets,
			ring->cmp.cmpl_prd_ptr,
			(ring->type == XPCXD_RING_TX) ?
				xpcxd_get_tx_sub_ring_space(ring) :
				(ring->sub.size -
				 xpcxd_get_rx_sub_ring_space(ring)),
			ring->sub.prod, ring->sub.cons,
			xpcxd_get_cmpl_ring_space(ring), ring->cmp.cmpl_prd_ptr,
			ring->cmp.cons, READ_ONCE(ring->stats.cmpl_irq_cnt),
			READ_ONCE(ring->stats.int_enabled) ? "EN" : "DIS",
			(ring->type == XPCXD_RING_RX) ?
				(db_count ? (db_rate_sum / db_count) : 0) :
				0,
			g_error ? "STOPPED on ERROR" : "RUNNING");

		hrtimer_forward_now(timer, time_isr_ktime);
	}

	if (xpcxd_stop_on_next_isr) {
		xpci_debug_level = XPCI_DBG_LEVEL__DBG;
		xpcxd_set_msglvl_all();
		xpcxd_err(NETIF_MSG_DRV,
			  "STOPPED by USER: stop on next ISR requested");
		xpcxd_intg_spare_write(0x1 /*g_cnt_tx_stop*/);
		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
		g_error = 1;
	}

	/* xpcxd_dbg("OUT"); */

	if (arm_timer_isr)
		return HRTIMER_RESTART;

	return HRTIMER_NORESTART;
}

static irqreturn_t xpcxd_tx_err_intr_handler(int irq, void *xpci_irq)
{
	return xpci_handle_interrupt(irq, xpci_irq);
}

static irqreturn_t xpcxd_rx_err_intr_handler(int irq, void *xpci_irq)
{
	return xpci_handle_interrupt(irq, xpci_irq);
}

static irqreturn_t xpcxd_tx_cmpl_intr(int irq, void *xpci_irq)
{
	struct xdev *pxdev = (struct xdev *)xpci_irq;
	struct xpcxd_priv *net_priv = netdev_priv(xpcxd_netdev);
	struct xpcxd_ring *txr = NULL;
	int vec = pxdev->irq_map[irq];
	u32 ring_id = vec - XPCI_X2_TX_CMP_INT_MIN;

	txr = &net_priv->txr[ring_id];

	/*
	 * IRQ/NAPI shared: use WRITE_ONCE/READ_ONCE to prevent compiler
	 * tearing or reload; synchronization with NAPI is provided by
	 * napi_schedule_irqoff() / napi_complete() + smp_wmb() in the poll.
	 */
	WRITE_ONCE(txr->stats.cmpl_irq_last_jiffy, jiffies);
	WRITE_ONCE(txr->stats.cmpl_irq_cnt,
		   READ_ONCE(txr->stats.cmpl_irq_cnt) + 1);

	if (READ_ONCE(txr->stats.int_enabled)) {
		xpci_disable_msix_interrupt(g_pxdev, vec);
		napi_schedule_irqoff(&txr->napi);
		WRITE_ONCE(txr->stats.int_enabled, false);
		WRITE_ONCE(txr->cmp.cmpl_prd_ptr_prev,
			   READ_ONCE(txr->cmp.cmpl_prd_ptr));

		return IRQ_HANDLED;
	}

	return IRQ_NONE;
}

static irqreturn_t xpcxd_rx_cmpl_intr(int irq, void *xpci_irq)
{
	struct xdev *pxdev = (struct xdev *)xpci_irq;
	struct xpcxd_priv *net_priv = netdev_priv(xpcxd_netdev);
	struct xpcxd_ring *rxr = NULL;
	int vec = pxdev->irq_map[irq];
	u32 ring_id = vec - XPCI_X2_RX_CMP_INT_MIN;
	unsigned long now = jiffies;
	unsigned long last;
	unsigned long delta;

	rxr = &net_priv->rxr[ring_id];

	/*
	* Shared with NAPI/ethtool readers — use READ_ONCE/WRITE_ONCE
	* to avoid tearing/reload. Happens-before for the producer
	* snapshot is provided by napi_schedule_irqoff().
	*/
	last = READ_ONCE(rxr->stats.cmpl_irq_last_jiffy);
	if (last) {
		delta = now - last;
		if (delta > (unsigned long)rxr->stats
					.rx_cmpl_irq_max_delta_jiffies)
			rxr->stats.rx_cmpl_irq_max_delta_jiffies =
				(u32)delta;
	}
	WRITE_ONCE(rxr->stats.cmpl_irq_last_jiffy, now);

	WRITE_ONCE(rxr->stats.cmpl_irq_cnt,
		   READ_ONCE(rxr->stats.cmpl_irq_cnt) + 1);

	if (READ_ONCE(rxr->stats.int_enabled)) {
		rxr->rx_refill_osc_irq_streak = 0;
		rxr->rx_refill_osc_irq_snap =
			READ_ONCE(rxr->stats.cmpl_irq_cnt);
		xpcxd_rx_traces_try_unmute_after_cmpl_irq();
		xpcxd_rx_opt_trace_ring(rx_disable_irq, ring_id, rxr, vec, 0);
		xpci_disable_msix_interrupt(g_pxdev, vec);
		/*
		 * Invariant: int_enabled==false ⇒ MSI-X masked, NAPI owns
		 * re-arm. Set int_enabled=false *before* napi_schedule_irqoff()
		 * — otherwise the softirq it wakes (same-CPU run-to-completion
		 * or cross-CPU) may see int_enabled still true, take the
		 * "already armed" branch in napi_complete, skip re-enable, and
		 * leave the vector masked indefinitely.
		 *
		 * No IRQ-side cmpl_prd_ptr refresh: the consume-bit gate in
		 * xpcxd_rx_cmpl() and the poll-side on-demand refresh
		 * (xpcxd_get_rx_cmpl_prod_ptr in low-credit/full branches)
		 * keep the producer current without an MMIO-indirect read
		 * in hard IRQ context.
		 */
		WRITE_ONCE(rxr->stats.int_enabled, false);
		napi_schedule_irqoff(&rxr->napi);

		return IRQ_HANDLED;
	}

	return IRQ_NONE;
}

static void xpcxd_ring_init(struct net_device *netdev, struct xpcxd_ring *ring,
			    u16 num_desc, enum xpcxd_ring_type type)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 num_sub_desc = num_desc;
	u32 num_cmpl_desc = (type == XPCXD_RING_RX) ? num_desc : (num_desc / 2);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "IN: num_sub_desc: %d num_cmpl_desc: %d", num_sub_desc,
			 num_cmpl_desc);

	ring->xd = net_priv;

	ring->sub.size = num_sub_desc;
	ring->sub.mask = num_sub_desc - 1;
	ring->sub.prod = 0;
	ring->sub.cons = 0;

	ring->cmp.size = num_cmpl_desc;
	ring->cmp.mask = num_cmpl_desc - 1;
	ring->cmp.cons = 0;
	ring->cmp.cmpl_prd_ptr = 0;
	ring->cmp.cmpl_prd_ptr_prev = 0;
	ring->cmpl_thold = num_cmpl_desc / 2;

	ring->cmp.round_cnt = 0;

	ring->rx_credits = 0;
	ring->rx_credits_cap = 0;
	ring->rx_last_fill_cnt = 0;
	ring->rx_sub_stall_warn_jiffy = 0;
	ring->rx_cmpl_low_hw_trace_jiffy = 0;
	ring->rx_refill_osc_irq_streak = 0;
	ring->rx_refill_osc_irq_snap = 0;
	ring->rx_refill_osc_last_arm_jiffy = 0;

	memset(&ring->stats, 0, sizeof(struct xpcxd_stats));

	/* Init-time single writer; use WRITE_ONCE for symmetry with IRQ/NAPI. */
	WRITE_ONCE(ring->stats.int_enabled, true);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

/**
 * xpcxd_ring_tx_pool_free - release the pre-mapped Tx DMA buffer pool
 * @netdev: netdev owning @ring
 * @ring:   TX ring whose pool should be torn down (no-op if never allocated)
 *
 * Safe to call unconditionally from xpcxd_ring_delete() on both RX and TX
 * rings: on RX rings @tx_pool.vaddr is always NULL.
 */
static void xpcxd_ring_tx_pool_free(struct net_device *netdev,
				    struct xpcxd_ring *ring)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	if (!ring->tx_pool.vaddr)
		return;

	dma_free_coherent(net_priv->hw_dev, ring->tx_pool.alloc_size,
			  ring->tx_pool.vaddr, ring->tx_pool.daddr);

	ring->tx_pool.vaddr = NULL;
	ring->tx_pool.daddr = 0;
	ring->tx_pool.slot_size = 0;
	ring->tx_pool.nslots = 0;
	ring->tx_pool.alloc_size = 0;
}

/**
 * xpcxd_ring_tx_pool_alloc - allocate the per-TX-ring pre-mapped DMA pool
 * @netdev:   netdev owning @ring
 * @ring:     TX ring to populate
 * @num_desc: number of TX slots (== sub ring depth)
 *
 * Sized once at ring setup using the policy documented above
 * XPCXD_TX_POOL_SLOT_MIN/MAX in xpcxd.h:
 *
 *     slot_size = clamp(ALIGN(tx_buf_size, XPCXD_TX_POOL_SLOT_ALIGN),
 *                       XPCXD_TX_POOL_SLOT_MIN,
 *                       XPCXD_TX_POOL_SLOT_MAX)
 *
 * Non-fatal on failure: on dma_alloc_coherent() failure the ring keeps
 * @tx_pool.vaddr = NULL and xpcxd_xmit() silently takes the legacy
 * dma_map_single() path for every packet. Packets larger than slot_size
 * also fall back per-packet (see xpcxd_xmit()).
 */
static void xpcxd_ring_tx_pool_alloc(struct net_device *netdev,
				     struct xpcxd_ring *ring, u16 num_desc)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	size_t alloc_size;
	u32 slot_size;
	dma_addr_t daddr;
	void *vaddr;

	slot_size = clamp_t(u32,
			    ALIGN(net_priv->tx_buf_size,
				  XPCXD_TX_POOL_SLOT_ALIGN),
			    XPCXD_TX_POOL_SLOT_MIN,
			    XPCXD_TX_POOL_SLOT_MAX);
	alloc_size = (size_t)slot_size * num_desc;

	vaddr = dma_alloc_coherent(net_priv->hw_dev, alloc_size, &daddr,
				   GFP_KERNEL);
	if (!vaddr) {
		xpcxd_notice_netdev(
			NETIF_MSG_DRV, netdev,
			"[ring %u] TX pool dma_alloc_coherent(%zu) failed; falling back to per-packet dma_map_single()",
			ring->ring_id, alloc_size);
		ring->tx_pool.vaddr = NULL;
		ring->tx_pool.daddr = 0;
		ring->tx_pool.slot_size = 0;
		ring->tx_pool.nslots = 0;
		ring->tx_pool.alloc_size = 0;
		return;
	}

	ring->tx_pool.vaddr = vaddr;
	ring->tx_pool.daddr = daddr;
	ring->tx_pool.slot_size = slot_size;
	ring->tx_pool.nslots = num_desc;
	ring->tx_pool.alloc_size = alloc_size;

	xpcxd_info_netdev(
		NETIF_MSG_DRV, netdev,
		"[ring %u] TX pool: slot_size=%u nslots=%u total=%zu KiB (tx_buf_size=%u)",
		ring->ring_id, slot_size, num_desc, alloc_size / 1024,
		net_priv->tx_buf_size);
}

static void xpcxd_ring_delete(struct net_device *netdev,
			      struct xpcxd_ring *ring)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (ring->type == XPCXD_RING_RX) {
		xpcxd_page_pool_free(netdev, ring);
	} else {
		xpcxd_ring_tx_pool_free(netdev, ring);
	}

	if (ring->sub.desc) {
		dma_free_coherent(net_priv->hw_dev, ring->sub.dma_size,
				  ring->sub.desc, ring->sub.dma_addr);

		ring->sub.desc = NULL;
		ring->sub.dma_addr = 0;
		ring->sub.dma_size = 0;
	}

	if (ring->cmp.desc) {
		dma_free_coherent(net_priv->hw_dev, ring->cmp.dma_size,
				  ring->cmp.desc, ring->cmp.dma_addr);

		ring->cmp.desc = NULL;
		ring->cmp.dma_addr = 0;
		ring->cmp.dma_size = 0;
	}

	if (ring->cmp.rfl_prd) {
		dma_free_coherent(net_priv->hw_dev, ring->cmp.rfl_prd_dma_size,
				  ring->cmp.rfl_prd,
				  ring->cmp.rfl_prd_dma_addr);

		ring->cmp.rfl_prd = NULL;
		ring->cmp.rfl_prd_dma_addr = 0;
		ring->cmp.rfl_prd_dma_size = 0;
	}

	if (ring->sub.rfl_cns) {
		dma_free_coherent(net_priv->hw_dev, ring->sub.rfl_cns_dma_size,
				  ring->sub.rfl_cns,
				  ring->sub.rfl_cns_dma_addr);

		ring->sub.rfl_cns = NULL;
		ring->sub.rfl_cns_dma_addr = 0;
		ring->sub.rfl_cns_dma_size = 0;
	}

	if (ring->sub.sw) {
		kvfree(ring->sub.sw);
		ring->sub.sw = NULL;
	}

	/* Cancel hrtimers if they were started */
	if (ring->time_isr.function) {
		hrtimer_cancel(&ring->time_isr);
	}
	if (ring->tx_coales_isr.function) {
		hrtimer_cancel(&ring->tx_coales_isr);
	}
	if (ring->type == XPCXD_RING_RX && ring->rx_refill_osc_timer.function) {
		hrtimer_cancel(&ring->rx_refill_osc_timer);
		ring->rx_refill_osc_timer.function = NULL;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static int xpcxd_ring_setup(struct net_device *netdev, u32 ring_id,
			    enum xpcxd_ring_type type)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *ring = NULL;
	u16 num_desc = (type == XPCXD_RING_RX) ? net_priv->num_rx_desc :
						 net_priv->num_tx_desc;
	size_t ring_size = sizeof(struct xpcxd_desc) * num_desc;
	int err;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "IN: ring_id: %d type: %s num_desc: %d", ring_id,
			 (type == XPCXD_RING_RX ? "RX" : "TX"), num_desc);

	if (type == XPCXD_RING_RX)
		ring = &net_priv->rxr[ring_id];
	else
		ring = &net_priv->txr[ring_id];

	ring->ring_id = ring_id;
	ring->type = type;
	ring->sub.dma_size = ring_size;
	ring->tx_rx_enabled =
		(type == XPCXD_RING_RX) ? xpcxd_rx_enabled : xpcxd_tx_enabled;
	ring->db_count = 0;
	ring->sub_desc_pending = 0;

	memset(&ring->stats, 0, sizeof(struct xpcxd_stats));

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "dma_alloc_coherent(ring->sub.dma_size=%d)",
			 (int)ring->sub.dma_size);
	ring->sub.desc =
		dma_alloc_coherent(net_priv->hw_dev, ring->sub.dma_size,
				   &ring->sub.dma_addr, GFP_KERNEL);

	if (ring->sub.desc == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring->cmp.dma_size = ring_size;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "dma_alloc_coherent(ring->cmp.dma_size=%d)",
			 (int)ring->cmp.dma_size);
	ring->cmp.desc =
		dma_alloc_coherent(net_priv->hw_dev, ring->cmp.dma_size,
				   &ring->cmp.dma_addr, GFP_KERNEL);

	if (ring->cmp.desc == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	/*
	 * Force-zero the CMPL ring so cmp_ctrl_valid starts as 0 in every
	 * slot
	 */
	memset(ring->cmp.desc, 0, ring->cmp.dma_size);

	ring->cmp.rfl_prd_dma_size = sizeof(struct xpcxd_atomic_fifo_ctrl);
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "dma_alloc_coherent(cmp rfl prd dma_size=%d)",
			 (int)ring->cmp.rfl_prd_dma_size);
	ring->cmp.rfl_prd =
		dma_alloc_coherent(net_priv->hw_dev, ring->cmp.rfl_prd_dma_size,
				   &ring->cmp.rfl_prd_dma_addr, GFP_KERNEL);

	if (ring->cmp.rfl_prd == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring->sub.rfl_cns_dma_size = sizeof(struct xpcxd_atomic_fifo_ctrl);
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "dma_alloc_coherent(sub rfl cns dma_size=%d)",
			 (int)ring->sub.rfl_cns_dma_size);
	ring->sub.rfl_cns =
		dma_alloc_coherent(net_priv->hw_dev, ring->sub.rfl_cns_dma_size,
				   &ring->sub.rfl_cns_dma_addr, GFP_KERNEL);

	if (ring->sub.rfl_cns == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring_size = sizeof(struct xpcxd_sw_desc) * num_desc;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "SW descriptors ring_size(%d) (bytes)",
			 (int)ring_size);
	ring->sub.sw = kvzalloc(ring_size, GFP_KERNEL);
	if (ring->sub.sw == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "kvzalloc() ring->sub.sw: [%p]",
			 ring->sub.sw);

	ring->page_pool = NULL;

	if (type == XPCXD_RING_RX) {
		int i = 0;

		/* Create a page_pool and register it with rxq */
		struct page_pool_params pp_params = { 0 };
		/* Silently assume Rx buffers are larger than (PAGE_SIZE / 2); PAGE_SIZE is 4K on x86_64. */
		pp_params.order = 0;
		pp_params.flags = PP_FLAG_DMA_MAP;
		pp_params.pool_size = num_desc;
		pp_params.nid = NUMA_NO_NODE; /* dev_to_node(net_priv->hw_dev); */
		pp_params.dev = net_priv->hw_dev;
		pp_params.dma_dir = DMA_FROM_DEVICE;
		pp_params.offset = 0;
		pp_params.max_len =
			PAGE_SIZE;
		;

/* PAGE_POOL_NAPI_SUPPORTED: Makefile probes $(KDIR) for page_pool_params::napi.
 * Assignment shape still follows LINUX_VERSION_CODE from the same kernel headers. */
#if PAGE_POOL_NAPI_SUPPORTED
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 5, 0)
			pp_params.napi = ring->napi;
#else
			pp_params.napi = &ring->napi;
#endif
#endif

		/* page_pool can be used even when there is no rq->xdp_prog,
		 * given page_pool does not handle DMA mapping there is no
		 * required state to clear. And page_pool gracefully handle
		 * elevated refcnt.
		 */
		ring->page_pool = xpcxd_page_pool_create(&pp_params);
		if (IS_ERR(ring->page_pool)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Rx Page page_pool alloc error");
			ring->page_pool = NULL;
			err = -ENOMEM;
			goto cleanup;
		}

		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"[%d] RX xpcxd_page_pool_create(): order: %d pool_size: %d max_len: %d",
			ring_id, pp_params.order, pp_params.pool_size,
			pp_params.max_len);

		for (i = 0; i < num_desc; i++) {
			ring->sub.sw[i].page_state = XPCXD_PAGE_FREE;
			ring->sub.sw[i].dma_err = false;
			ring->sub.sw[i].usg_cnt = 0;
		}

		ring->sub.db = net_priv->rx_db;
	} else {
		ring->sub.db = net_priv->tx_db;

		spin_lock_init(&ring->tx_lock);

		/*
		 * Allocate the pre-mapped Tx DMA pool. Non-fatal on failure:
		 * xpcxd_xmit() detects tx_pool.vaddr == NULL and transparently
		 * uses the legacy dma_map_single() path for every packet.
		 */
		xpcxd_ring_tx_pool_alloc(netdev, ring, num_desc);
	}

	xpcxd_ring_init(netdev, ring, num_desc, type);

	/* Numebr of Tx descriptors is * 2 because of the pair MD/BD in each transmit */
	/* Because of that the real number of completions is / 2 (Numebr of Tx desc) */
	if (type == XPCXD_RING_TX)
		ring->cmp.mask = (num_desc / 2) - 1;

	if (xpcxd_timer_isr_mode) {
		hrtimer_init(&ring->time_isr, CLOCK_MONOTONIC,
			     HRTIMER_MODE_REL);

		ring->time_isr.function = &xpcxd_ring_time_isr;

		time_isr_ktime = ms_to_ktime(xpcxd_timer_isr_wakeup_time);

		xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "Arming Timer ISR");
		hrtimer_start(&ring->time_isr,
			      ms_to_ktime(xpcxd_timer_isr_wakeup_time),
			      HRTIMER_MODE_REL);
	}

	if (type == XPCXD_RING_RX) {
		hrtimer_init(&ring->rx_refill_osc_timer, CLOCK_MONOTONIC,
			     HRTIMER_MODE_REL);
		ring->rx_refill_osc_timer.function =
			&xpcxd_rx_refill_osc_timer_fn;
	}

	if ((type == XPCXD_RING_TX) && xpcxd_tx_coales_isr_mode) {
		hrtimer_init(&ring->tx_coales_isr, CLOCK_MONOTONIC,
			     HRTIMER_MODE_REL);

		ring->tx_coales_isr.function = &xpcxd_ring_tx_coales_isr;

		tx_coalescing_ktime =
			ms_to_ktime(xpcxd_tx_coales_isr_wakeup_time);

		xpcxd_info_netdev(NETIF_MSG_DRV, netdev,
				  "Arming Tx Coalescing ISR");
		hrtimer_start(&ring->tx_coales_isr,
			      ms_to_ktime(xpcxd_tx_coales_isr_wakeup_time),
			      HRTIMER_MODE_REL);
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
cleanup:
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "ERR OUT");

	xpcxd_ring_delete(netdev, ring);
	return err;
}

static int xpcxd_rx_ring_configure(struct net_device *netdev, u32 ring_id,
				   bool active)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u64 rx_sbm_rng_tbl[2] = { 0 };
	u64 rx_prf_rgl_rng_tbl = 0;
	u64 rx_cmp_rng_tb[2] = { 0 };
	u64 rx_rng_rfl_ctrl = 0;
	u64 rx_rng_rfl_addr[2] = { 0 };
	u16 num_desc = XPCXD_RING_DSC_BUFFERS / net_priv->num_rings;
	u16 buff_offset = ring_id * num_desc;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Granularity is in 4K Pages - TODO: Check */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"RX_SBM_RNG_TBL_SBM_RING_BASE_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].sub.desc,
		(u64)net_priv->rxr[ring_id].sub.dma_addr);
	rx_sbm_rng_tbl[0] = 0;
	rx_sbm_rng_tbl[1] = 0;
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_BASE_ADRS,
		(u64)net_priv->rxr[ring_id].sub.dma_addr);

	/* Size to be in ^2 --> see __roundup_pow_of_two() */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_SIZE[%d]: 0x%x",
		  ring_id, net_priv->rxr[ring_id].sub.size);
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_SIZE,
		net_priv->rxr[ring_id].sub.size);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET[%d]: %d", ring_id,
		  buff_offset);
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST,
		buff_offset);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET[%d]: %d", ring_id,
		  num_desc);
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE,
		num_desc);

	/* Reflection on Submit (forced on; Rx SBM is RFL-only). */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET:%d", 1);
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_RFL_EN, 1);

	/* f. set, for active ring */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET:%d",
		  active);
	xreg_field_put_idx_2q(
		rx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_ACTV_EN, active);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL) /* Size */,
		(void *)rx_sbm_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE_SET:%d", 0);
	rx_prf_rgl_rng_tbl = 0;
	xreg_field_put_idx(
		&rx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE,
		0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN_SET:%d", 0);
	xreg_field_put_idx(
		&rx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN,
		0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL_SET:%d", 0);
	xreg_field_put_idx(
		&rx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL,
		0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL) /* Size */,
		(void *)&rx_prf_rgl_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	/* Addr in 4K pages */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"RX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].cmp.desc,
		(u64)net_priv->rxr[ring_id].cmp.dma_addr);
	rx_cmp_rng_tb[0] = 0;
	rx_cmp_rng_tb[1] = 0;
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_BASE_ADRS,
		(u64)net_priv->rxr[ring_id].cmp.dma_addr);

	/* Set size in ^2 values */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_SIZE_SET[%d]: %d",
		  ring_id, net_priv->rxr[ring_id].cmp.size);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_SIZE,
		net_priv->rxr[ring_id].cmp.size);

	/* Cmpl Reflection (forced on; Rx CMPL is RFL-only). */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET[%d]: %d",
		  ring_id, 1);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_EN, 1);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET[%d]: %d", ring_id,
		  xpcxd_rx_coales_mode);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN,
		xpcxd_rx_coales_mode);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET[%d]: %d", ring_id, 1);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN, 1);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET[%d]: %d", ring_id, 0);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_HW_INT_EN, 0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET[%d]: %d", ring_id, 0);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_SW_INT_EN, 0);

	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_CLS_DSC_NUM,
		0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET[%d]: %d", ring_id,
		  xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL,
		xpcxd_cfg_tbl[xpcxd_rx_coales_time]);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET[%d]: %d", ring_id,
		  xpcxd_rx_coales_mode);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN,
		xpcxd_rx_coales_mode);

	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_ADR_ECHO_MODE,
		0);

	/*
	 * Hard-wire CRD_CMP_ENG_DSC_VLD_MODE=1: HW writes cmp_ctrl_valid=1
	 * atomically with each fresh completion, SW gates the poll loop on
	 * the bit and clears it on consume — same lifecycle as the TX CMPL
	 * ring.
	 */
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_DSC_VLD_MODE,
		1);

	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_FRM_DATA_ENDIAN_TYPE, 0);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_FRM_MDATA_ENDIAN_TYPE, 0);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_FNC_INT_CLS_MODE, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET: 0x%x",
		  0xFE);
	xreg_field_put_idx_2q(
		rx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CMP_RNG_TBL_FNC_INT_CLS_VAL, 0xFE);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL) /* Size */,
		(void *)rx_cmp_rng_tb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET:[%d]",
		  xpcxd_cfg_tbl[xpcxd_rx_coales_size]);
	rx_rng_rfl_ctrl = 0;
	xreg_field_put_idx(
		&rx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL,
		xpcxd_cfg_tbl[xpcxd_rx_coales_size]);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET:[%s]",
		  xpcxd_cfg_tbl[xpcxd_rx_coales_time] ? "ENABLED" : "DISABLED");
	xreg_field_put_idx(
		&rx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN,
		xpcxd_cfg_tbl[xpcxd_rx_coales_time] ? 1 : 0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET:[%d]",
		  xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	xreg_field_put_idx(
		&rx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL,
		xpcxd_cfg_tbl[xpcxd_rx_coales_time]);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL",
		XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL) /* Size */,
		(void *)&rx_rng_rfl_ctrl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

#ifdef __XPCXD_RX_SUB_RFL__
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"RX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].sub.rfl_cns,
		(u64)net_priv->rxr[ring_id].sub.rfl_cns_dma_addr);
	rx_rng_rfl_addr[0] = 0;
	rx_rng_rfl_addr[1] = 0;
	xreg_field_put_idx_2q(
		rx_rng_rfl_addr,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS,
		(u64)net_priv->rxr[ring_id].sub.rfl_cns_dma_addr);

#endif

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"RX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].cmp.rfl_prd,
		(u64)net_priv->rxr[ring_id].cmp.rfl_prd_dma_addr);
	xreg_field_put_idx_2q(
		rx_rng_rfl_addr,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS,
		(u64)net_priv->rxr[ring_id].cmp.rfl_prd_dma_addr);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL",
		XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL) /* Size */,
		(void *)rx_rng_rfl_addr);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]) {
		u64 rx_prsr_bypass = 0;

		if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] ==
		    xpcxd_selective_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				  "RX_PRSR_BYPASS_SELECTIVE_SET[%d]: [0x%d]",
				  ring_id,
				  xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]);
			rx_prsr_bypass = 0;
			xreg_field_put_idx(
				&rx_prsr_bypass,
				xreg_desc(XREG_ID_PCXD_RX_PRSR_BYPASS),
				XREG_FIELD_PCXD_RX_PRSR_BYPASS_SELECTIVE, 1);
		}

		if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] ==
		    xpcxd_global_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				  "RX_PRSR_BYPASS_GLOBAL_SET[%d]: [0x%d]",
				  ring_id,
				  xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]);
			xreg_field_put_idx(
				&rx_prsr_bypass,
				xreg_desc(XREG_ID_PCXD_RX_PRSR_BYPASS),
				XREG_FIELD_PCXD_RX_PRSR_BYPASS_GLOBAL, 1);
		}

		xpci_write64(
			"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_PRSR_BYPASS, 0, 0)",
			xreg_addr(xreg_get_profile(),
				  XREG_ID_PCXD_RX_PRSR_BYPASS, 0, 0),
			rx_prsr_bypass);

		xpcxd_dbg(
			NETIF_MSG_DRV,
			"-----------------------------------------------------------------");
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_rx_shaper_configure(struct net_device *netdev, bool active)
{
	u64 rx_ch_tm_shp_tb = 0;
	u64 rx_shp_glb_actv = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MAX_BURST_SIZE_SET: [0x%x]",
		  0x100);
	rx_ch_tm_shp_tb = 0;
	xreg_field_put_idx(
		&rx_ch_tm_shp_tb,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MAX_BURST_SIZE, 0x100);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_SIZE_SET: [0x%x]",
		  0x9c);
	xreg_field_put_idx(
		&rx_ch_tm_shp_tb,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_SIZE, 0x9c);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_PERIOD_SET: [0x%x]",
		  0x7D);
	xreg_field_put_idx(
		&rx_ch_tm_shp_tb,
		xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL),
		XREG_FIELD_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_PERIOD, 0x7D);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "PCXD_MEMCFG_RX_CH_TM_SHP_TBL_BYPASS_SET: [0x%d]", 0x0);
	xreg_field_put_idx(&rx_ch_tm_shp_tb,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL),
			   XREG_FIELD_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_BYPASS, 0x0);

	ret = xdrv_mem_ind_write(
		"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL, 0, 0)",
		XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MSEL_ID /* Msel */,
		0 /*ring_id*/ /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL) /* Size */,
		(void *)&rx_ch_tm_shp_tb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV, "XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_SET: [0x%llu]",
		  1ULL);
	rx_shp_glb_actv = 0;
	xreg_field_put_idx(&rx_shp_glb_actv,
			   xreg_desc(XREG_ID_PCXD_RX_SHP_GLB_ACTV),
			   XREG_FIELD_PCXD_RX_SHP_GLB_ACTV_ACTV, 1);

	xpcxd_dbg(NETIF_MSG_DRV, "XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_GET: [0x%llu]",
		  rx_shp_glb_actv);

	xpci_write64(
		"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_SHP_GLB_ACTV, 0, 0)",
		xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_SHP_GLB_ACTV, 0,
			  0),
		rx_shp_glb_actv);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

/* TODO: Remove this routine when it is removed from the PCXD block design. */
static int xpcxd_msix_control(void)
{
	u64 msix_ctrl = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MSIX_CTRL_VEC_OFFSET_SET: [%d]", 1);
	msix_ctrl = 0;
	xreg_field_put_idx(&msix_ctrl, xreg_desc(XREG_ID_PCXD_MSIX_CTRL),
			   XREG_FIELD_PCXD_MSIX_CTRL_VEC_OFFSET, 1);
	/* 2-bit field; offset is rounded to 16; must be 1. */

	xpci_write64("XREG_PCXD_MSIX_CTRL",
		     xreg_addr(xreg_get_profile(), XREG_ID_PCXD_MSIX_CTRL, 0,
			       0),
		     msix_ctrl);

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

int xpcxd_rx_activate(bool activate)
{
	u64 rx_glb_active = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	xpcxd_dbg(NETIF_MSG_DRV, "RX_GLB_ACTIVE_SET: [%s]",
		  activate ? "SET" : "CLEAR");
	rx_glb_active = activate;

	xpci_write64(
		"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_GLB_ACTIVE, 0, 0)",
		xreg_addr(xreg_get_profile(), XREG_ID_PCXD_RX_GLB_ACTIVE, 0, 0),
		rx_glb_active);

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

static int xpcxd_rx_ring_active(u32 ring_num, bool activate)
{
	u64 rx_ring_active = 0;
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "RX_RING_ACTV_TBL_ACTV_SET[%d]: [%s]",
		  ring_num, activate ? "SET" : "CLEAR");
	rx_ring_active = activate;

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL",
		XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL_MSEL_ID /* Msel */,
		ring_num /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_RING_ACTV_TBL) /* Size */,
		(void *)&rx_ring_active);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_tx_ring_configure(struct net_device *netdev, u32 ring_id,
				   bool active)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u64 tx_pause_tbl = 0;
	u64 tx_sbm_rng_tbl[2] = { 0 };
	u64 tx_prf_rgl_rng_tbl = 0;
	u64 tx_cmp_rng_tb[2] = { 0 };
	u64 tx_rng_rfl_ctrl = 0;
	u64 tx_rng_rfl_addr[2] = { 0 };
	u16 num_desc = XPCXD_RING_DSC_BUFFERS / net_priv->num_rings;
	u16 buff_offset = ring_id * num_desc;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_PAUSE_SET[%d]: %d",
		  ring_id, 0);
	tx_pause_tbl = 0;
	xreg_field_put_idx(&tx_pause_tbl,
			   xreg_desc(XREG_ID_PCXD_MEMCFG_TX_PAUSE_RING_TBL),
			   XREG_FIELD_PCXD_MEMCFG_TX_PAUSE_RING_TBL_PAUSE, 0);
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_PAUSE_RING_TBL) /* Size */,
		(void *)&tx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	/* Granularity is in 4K Pages --> TODO: Check */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"TX_SBM_RNG_TBL_SBM_RING_BASE_ADRS[%d]: [0x%llx] --> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].sub.desc,
		(u64)net_priv->txr[ring_id].sub.dma_addr);
	tx_sbm_rng_tbl[0] = 0;
	tx_sbm_rng_tbl[1] = 0;
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_BASE_ADRS,
		(u64)net_priv->txr[ring_id].sub.dma_addr);

	/* Size to be in ^2 --> see __roundup_pow_of_two() */
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_SIZE[%d]: 0x%x",
		  ring_id, net_priv->txr[ring_id].sub.size);
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_SIZE,
		net_priv->txr[ring_id].sub.size);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET[%d]: %d", ring_id,
		  buff_offset);
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST,
		buff_offset);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET[%d]: %d", ring_id,
		  num_desc);
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE,
		num_desc);

	/* e. clear */
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET:%d",
		  xpcxd_tx_sbm_rfl_mode);
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_RFL_EN,
		xpcxd_tx_sbm_rfl_mode);

	/* f. set, for active ring */
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET: %d",
		  active);
	xreg_field_put_idx_2q(
		tx_sbm_rng_tbl, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_ACTV_EN, active);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL) /* Size */,
		(void *)tx_sbm_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	tx_prf_rgl_rng_tbl = 0;
	xreg_field_put_idx(
		&tx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE,
		0);

	xreg_field_put_idx(
		&tx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN,
		0);

	xreg_field_put_idx(
		&tx_prf_rgl_rng_tbl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL,
		0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL) /* Size */,
		(void *)&tx_prf_rgl_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	/* Addr in 4K pages --> TODO: Check */
	xpcxd_dbg(
		NETIF_MSG_DRV,
		"TX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET[%d]: [0x%llx] --> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].cmp.desc,
		(u64)net_priv->txr[ring_id].cmp.dma_addr);
	tx_cmp_rng_tb[0] = 0;
	tx_cmp_rng_tb[1] = 0;
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_BASE_ADRS,
		(u64)net_priv->txr[ring_id].cmp.dma_addr);

	/* Set size in ^2 values */
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_SIZE_SET[%d]: %d",
		  ring_id, net_priv->txr[ring_id].cmp.size);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_SIZE,
		net_priv->txr[ring_id].cmp.size);

	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET[%d]: %d",
		  ring_id, xpcxd_tx_cmp_rfl_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_EN,
		xpcxd_tx_cmp_rfl_mode);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET[%d]: %d", ring_id,
		  xpcxd_tx_coales_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN,
		xpcxd_tx_coales_mode);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET[%d]: %d", ring_id,
		  xpcxd_tx_cmp_rfl_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN,
		xpcxd_tx_cmp_rfl_mode);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET[%d]: %d", ring_id,
		  !xpcxd_tx_cmp_rfl_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_HW_INT_EN,
		!xpcxd_tx_cmp_rfl_mode);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET[%d]: %d", ring_id,
		  !xpcxd_tx_cmp_rfl_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_SW_INT_EN,
		!xpcxd_tx_cmp_rfl_mode);

	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_CLS_DSC_NUM,
		0);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET[%d]: %d", ring_id,
		  xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL,
		xpcxd_cfg_tbl[xpcxd_tx_coales_time]);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET[%d]: %d", ring_id,
		  xpcxd_tx_coales_mode);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN,
		xpcxd_tx_coales_mode);

	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_ADR_ECHO_MODE,
		0);

	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_DSC_VLD_MODE,
		1);
	/* Software sets valid bit to zero each time cmpl desc consumed */
	xreg_field_put_idx_2q(tx_cmp_rng_tb,
			      xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
			      XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_TM_SHP_EN,
			      0);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_FRM_DATA_ENDIAN_TYPE, 0);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_FRM_MDATA_ENDIAN_TYPE, 0);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_FNC_INT_CLS_MODE, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET: 0x%x",
		  0xFE);
	xreg_field_put_idx_2q(
		tx_cmp_rng_tb, xreg_desc(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_CMP_RNG_TBL_FNC_INT_CLS_VAL, 0xFE);

	xpcxd_dbg(NETIF_MSG_DRV, "XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL[%d]",
		  ring_id);
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL) /* Size */,
		(void *)tx_cmp_rng_tb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET:[%d]",
		  xpcxd_cfg_tbl[xpcxd_tx_coales_size]);
	tx_rng_rfl_ctrl = 0;
	xreg_field_put_idx(
		&tx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL,
		xpcxd_cfg_tbl[xpcxd_tx_coales_size]);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET:[%s]", "ENABLED");
	xreg_field_put_idx(
		&tx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN,
		1);

	xpcxd_dbg(NETIF_MSG_DRV,
		  "TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET:[%d]",
		  xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	xreg_field_put_idx(
		&tx_rng_rfl_ctrl,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL,
		xpcxd_cfg_tbl[xpcxd_tx_coales_time]);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL",
		XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL) /* Size */,
		(void *)&tx_rng_rfl_ctrl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"TX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].cmp.rfl_prd,
		(u64)net_priv->txr[ring_id].cmp.rfl_prd_dma_addr);
	tx_rng_rfl_addr[0] = 0;
	tx_rng_rfl_addr[1] = 0;
	xreg_field_put_idx_2q(
		tx_rng_rfl_addr,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS,
		(u64)net_priv->txr[ring_id].cmp.rfl_prd_dma_addr);

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"TX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].sub.rfl_cns,
		(u64)net_priv->txr[ring_id].sub.rfl_cns_dma_addr);
	xreg_field_put_idx_2q(
		tx_rng_rfl_addr,
		xreg_desc(XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL),
		XREG_FIELD_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS,
		(u64)net_priv->txr[ring_id].sub.rfl_cns_dma_addr);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL",
		XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL) /* Size */,
		(void *)tx_rng_rfl_addr);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]) {
		u64 tx_prsr_bypass = 0;

		if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] ==
		    xpcxd_selective_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				  "TX_PRSR_BYPASS_SELECTIVE_SET[%d]: [0x%d]",
				  ring_id,
				  xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]);
#ifdef __XPCXD_TX_PRSR_BYPASS_SELECTIVE_SET__
			tx_prsr_bypass = 0;
			xreg_field_put_idx(
				&tx_prsr_bypass,
				xreg_desc(XREG_ID_PCXD_TX_PRSR_BYPASS),
				XREG_FIELD_PCXD_TX_PRSR_BYPASS_SELECTIVE, 1);

#else
			xpcxd_dbg(
				NETIF_MSG_DRV,
				"skip setting TX_PRSR_BYPASS_SELECTIVE_SET[%d]",
				ring_id);
#endif
		}

		if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] ==
		    xpcxd_global_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				  "TX_PRSR_BYPASS_GLOBAL_SET[%d]: [0x%d]",
				  ring_id,
				  xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]);
			xreg_field_put_idx(
				&tx_prsr_bypass,
				xreg_desc(XREG_ID_PCXD_TX_PRSR_BYPASS),
				XREG_FIELD_PCXD_TX_PRSR_BYPASS_GLOBAL, 1);
		}

		xpci_write64(
			"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_TX_PRSR_BYPASS, 0, 0)",
			xreg_addr(xreg_get_profile(),
				  XREG_ID_PCXD_TX_PRSR_BYPASS, 0, 0),
			tx_prsr_bypass);

		xpcxd_dbg(
			NETIF_MSG_DRV,
			"-----------------------------------------------------------------");
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_tx_activate(bool activate)
{
	u64 tx_glb_active = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	xpcxd_dbg(NETIF_MSG_DRV, "TX_GLB_ACTIVE_SET: [%s]",
		  activate ? "SET" : "CLEAR");
	tx_glb_active = activate;

	xpci_write64(
		"xreg_addr(xreg_get_profile(), XREG_ID_PCXD_TX_GLB_ACTIVE, 0, 0)",
		xreg_addr(xreg_get_profile(), XREG_ID_PCXD_TX_GLB_ACTIVE, 0, 0),
		tx_glb_active);

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

static int xpcxd_tx_ring_active(u32 ring_num, bool activate)
{
	u64 tx_ring_active = 0;
	int ret = 0;

	/* xpcxd_dbg(NETIF_MSG_DRV, "IN"); */

	xpcxd_dbg(NETIF_MSG_DRV, "TX_RING_ACTV_TBL_ACTV_SET[%d]: [%s]",
		  ring_num, activate ? "SET" : "CLEAR");
	tx_ring_active = activate;

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RING_ACTV_TBL",
		XREG_PCXD_MEMCFG_TX_RING_ACTV_TBL_MSEL_ID /* Msel */,
		ring_num /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_RING_ACTV_TBL) /* Size */,
		(void *)&tx_ring_active);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return -1;
	}

	xpcxd_dbg(
		NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	/* xpcxd_dbg(NETIF_MSG_DRV, "OUT"); */

	return 0;
}

static int xpcxd_rx_pause_set(u32 ring_id, bool set)
{
	u64 rx_pause_tbl = 0;
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_RX_PAUSE_RING_TBL_SET[%d]: [%s]",
		  ring_id, set ? "SET" : "CLEAR");
	rx_pause_tbl = set ? 1 : 0;

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_RX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_RX_PAUSE_RING_TBL) /* Size */,
		(void *)&rx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return ret;
	}

	return 0;
}

static int xpcxd_tx_pause_set(u32 ring_id, bool set)
{
	u64 tx_pause_tbl = 0;
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_PAUSE_RING_TBL_SET[%d]: [%s]",
		  ring_id, set ? "SET" : "CLEAR");
	tx_pause_tbl = set ? 1 : 0;

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		xreg_desc_bytes(
			XREG_ID_PCXD_MEMCFG_TX_PAUSE_RING_TBL) /* Size */,
		(void *)&tx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d",
			  ret);
		return ret;
	}

	return 0;
}

int xpcxd_dev_rx_disable(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u64 rx_busy_tbl = 0;
	bool busy = true;
	int i = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* 1. Set PAUSE ring bit */
	xpcxd_rx_pause_set(ring_id, true);

	/* 2. Wait for the busy ring bit */
	for (i = 0; i < 100; i++) {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_BUSY_RING_TBL",
			XREG_PCXD_MEMCFG_RX_BUSY_RING_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			xreg_desc_bytes(
				XREG_ID_PCXD_MEMCFG_RX_BUSY_RING_TBL) /* Size */,
			(void *)&rx_busy_tbl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV,
				  "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		if (!rx_busy_tbl) {
			busy = false;
			break;
		}

		xpcxd_dbg(NETIF_MSG_DRV, "Rx ring[%d] busy - waiting", ring_id);
		/*
		 * Sleep instead of busy-spin: this loop runs from process
		 * context (ndo_stop / module remove), under traffic the HW
		 * busy-bit can take a few hundred microseconds to clear, and
		 * a CPU-friendly wait avoids stalling the same core that may
		 * still be servicing softirqs / NAPI on adjacent rings.
		 */
		usleep_range(50, 150);
	}

	if (busy) {
		xpcxd_err(
			NETIF_MSG_DRV,
			"Rx ring[%d] still busy - can't perform graceful stop",
			ring_id);
	}

	/* 3. Deactivate the ring */
	xpcxd_rx_ring_active(ring_id, false);

	net_priv->rxr[ring_id].tx_rx_enabled = false;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_dev_tx_disable(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u64 tx_busy_tbl = 0;
	bool busy = true;
	int i = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* 1. Set PAUSE ring bit */
	xpcxd_tx_pause_set(ring_id, true);

	/* 2. Wait for the busy ring bit */
	for (i = 0; i < 100; i++) {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_BUSY_RING_TBL",
			XREG_PCXD_MEMCFG_TX_BUSY_RING_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			xreg_desc_bytes(
				XREG_ID_PCXD_MEMCFG_TX_BUSY_RING_TBL) /* Size */,
			(void *)&tx_busy_tbl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV,
				  "xdrv_mem_ind_read() failed: %d", ret);
			return ret;
		}

		if (!tx_busy_tbl) {
			busy = false;
			break;
		}

		/*
		 * Demoted from xpcxd_err to xpcxd_dbg: the loop polls every
		 * iteration while HW is still draining and was producing one
		 * dmesg line per 100us under load. Same usleep yield as the
		 * Rx side keeps this off the busy-spin path.
		 */
		xpcxd_dbg(NETIF_MSG_DRV, "Tx ring[%d] busy - waiting",
			  ring_id);
		usleep_range(50, 150);
	}

	if (busy) {
		xpcxd_err(NETIF_MSG_DRV,
			  "Tx ring still busy - can't perform graceful stop");
	}

	/* 3. Deactivate the ring */
	xpcxd_tx_ring_active(ring_id, false);

	net_priv->txr[ring_id].tx_rx_enabled = false;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_dev_rx_enable(struct net_device *netdev, bool rx_activate)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_rx_pause_set(ring_id, false);
		xpcxd_rx_ring_active(ring_id, true);
	}

	xpcxd_rx_activate(rx_activate);

	net_priv->rxr[ring_id].tx_rx_enabled = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_dev_tx_enable(struct net_device *netdev, bool tx_activate)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_tx_pause_set(ring_id, false);
		xpcxd_tx_ring_active(ring_id, true);
	}

	xpcxd_tx_activate(tx_activate);

	net_priv->txr[ring_id].tx_rx_enabled = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static void xpcxd_tx_graceful_stop_init(void)
{
	u64 tx_gcfl_stop_init = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	tx_gcfl_stop_init = 0;

	xpci_write64("XREG_PCXD_TX_GRACEFUL_STOP_INIT",
		     xreg_addr(xreg_get_profile(),
			       XREG_ID_PCXD_TX_GRACEFUL_STOP_INIT, 0, 0),
		     tx_gcfl_stop_init);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_rx_graceful_stop_init(void)
{
	u64 rx_gcfl_stop_init = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	rx_gcfl_stop_init = 0;

	xpci_write64("XREG_PCXD_RX_GRACEFUL_STOP_INIT",
		     xreg_addr(xreg_get_profile(),
			       XREG_ID_PCXD_RX_GRACEFUL_STOP_INIT, 0, 0),
		     rx_gcfl_stop_init);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static int xpcxd_dev_reset(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_opt_trace(drv_lifecycle, 3, xpcxd_drv_lifecycle_detail(netdev),
			ktime_get_ns());

	xpcxd_tx_graceful_stop_init();
	xpcxd_rx_graceful_stop_init();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static void xpcxd_disable_interrupts(void)
{
	int vec;

	for (vec = XPCI_X2_PCXD_INT_FIRST; vec < XPCI_X2_PCXD_INT_MAX; vec++) {
		if (!g_pxdev->irq_tbl[vec].allocated)
			continue;
		xpci_dbg("Disabling interrupt vector [%s]:%d",
			 g_pxdev->irq_tbl[vec].name, vec);
		xpci_disable_msix_interrupt(g_pxdev, vec);
	}
}

static void xpcxd_synchronize_interrupts(void)
{
	int vec;

	if (!g_pxdev)
		return;

	for (vec = XPCI_X2_PCXD_INT_FIRST; vec < XPCI_X2_PCXD_INT_MAX; vec++) {
		int irq;

		if (!g_pxdev->irq_tbl[vec].allocated)
			continue;

		irq = pci_irq_vector(g_pxdev->pdev, vec);
		if (irq < 0)
			continue;

		synchronize_irq(irq);
	}
}

void xpcxd_netif_init_threaded_napi(struct net_device *netdev)
{
	if (!netdev || !xpcxd_threaded_napi)
		return;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 17, 0)
	netif_threaded_enable(netdev);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "Threaded NAPI enabled (netif_threaded_enable)");
#elif LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	dev_set_threaded(netdev, true);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "Threaded NAPI enabled (dev_set_threaded)");
#else
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"threaded_napi=%d ignored (need kernel >= 5.15 for threaded NAPI)",
		xpcxd_threaded_napi);
#endif
}

static int xpcxd_config(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *rxr = NULL;
	u32 ring_id = 0;
	int ret = 0;
	int orig_debug_level = xpci_debug_level;
	char if_name[XPCXD_IF_NAME_SIZE] = { 0 };
	u16 processed = 0;

	/* From error level to info, but not from debug to info */
	if (xpci_debug_level != XPCI_DBG_LEVEL__DBG)
		xpci_debug_level = XPCI_DBG_LEVEL__INFO;

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev,
			  "--- Device configuration started ---");

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "IN: num_rx_desc: %d num_tx_desc:%d ",
			 net_priv->num_rx_desc, net_priv->num_tx_desc);

	net_priv->num_rx_desc = __roundup_pow_of_two(net_priv->num_rx_desc);
	if (net_priv->num_rx_desc > XPCXD_MAX_RING_SIZE)
		net_priv->num_rx_desc = XPCXD_MAX_RING_SIZE;

	net_priv->num_tx_desc = __roundup_pow_of_two(net_priv->num_tx_desc *
						     XPCXD_NUM_TXD_PER_PKT);
	if (net_priv->num_tx_desc > XPCXD_MAX_RING_SIZE)
		net_priv->num_tx_desc = XPCXD_MAX_RING_SIZE;

	if (net_priv->num_rings > XPCXD_MAX_RING_NUM) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "open: Wrong number of rings: %d MAX: %d",
				 net_priv->num_rings, XPCXD_MAX_RING_NUM);
		xpci_debug_level = orig_debug_level;
		return -EINVAL;
	}

	/* If budget > ring size then NAPI will stall */
	/* Fix the budget if needed                   */
	if (xpcxd_rx_budget > net_priv->num_rx_desc) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Rx budget adjusted: %d --> %d",
				 xpcxd_rx_budget, net_priv->num_rx_desc);
		xpcxd_rx_budget = net_priv->num_rx_desc;
	}

	if (xpcxd_tx_budget > net_priv->num_tx_desc) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Tx budget adjusted: %d --> %d",
				 xpcxd_tx_budget, net_priv->num_tx_desc);
		xpcxd_tx_budget = net_priv->num_tx_desc;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "TXR start: [%p]",
			 net_priv->txr);

	xpcxd_netif_init_threaded_napi(netdev);

	/* NAPI Add */
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"netif_napi_add() Ring[%d] Rxr: [%p] Txr: [%p]",
			ring_id, &net_priv->rxr[ring_id],
			&net_priv->txr[ring_id]);

		XPCI_NETIF_NAPI_ADD(netdev, &net_priv->rxr[ring_id].napi,
				    xpcxd_rx_poll, xpcxd_rx_budget);
		XPCI_NETIF_NAPI_TX_ADD(netdev, &net_priv->txr[ring_id].napi,
				       xpcxd_tx_poll, xpcxd_tx_budget);

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "napi_enable() Ring[%d] Rxr: [%p] Txr: [%p]",
				 ring_id, &net_priv->rxr[ring_id],
				 &net_priv->txr[ring_id]);
		napi_enable(&net_priv->rxr[ring_id].napi);
		napi_enable(&net_priv->txr[ring_id].napi);
	}

	if (xpcxd_rss_enabled) {
		ret = xpcxd_rss_config(net_priv->num_rings);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RSS Configuration failed: %d",
					 ret);
			goto cleanup;
		}
	}

	net_priv->num_rx_queues = net_priv->num_rings;
	net_priv->num_tx_queues = net_priv->num_rings;

	net_priv->rx_buf_size = xpcxd_default_mtu - XPCXD_FRAG_OFFSET;
	net_priv->tx_buf_size = xpcxd_default_mtu;

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "RX Page size: %d TX Page size: %d",
			    net_priv->rx_buf_size, net_priv->tx_buf_size);

	if (xpcxd_pfc_enabled) {
		ret = xpcxd_pfc_config();
		if (unlikely(ret)) {
			xpcxd_err_netdev(
				NETIF_MSG_DRV, netdev,
				"open: Rx PFC Configuration failed: %d", ret);
			goto cleanup;
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		rxr = &net_priv->rxr[ring_id];

		xpcxd_tx_pause_set(ring_id, false);

		ret = xpcxd_ring_setup(netdev, ring_id, XPCXD_RING_TX);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: TX ring setup failed: %d", ret);
			goto cleanup;
		}

		ret = xpcxd_tx_ring_configure(netdev, ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: TX ring configure failed: %d",
					 ret);
			goto cleanup;
		}

		ret = xpcxd_tx_stat_clear_per_ring(netdev, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring clear stat failed: %d",
					 ret);
			goto cleanup;
		}

		ret = xpcxd_tx_ring_active(ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: TX ring activate failed: %d",
					 ret);
			goto cleanup;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				    "xpcxd_ring_setup(RX) rx desc %u",
				    net_priv->num_rx_desc);

		xpcxd_rx_pause_set(ring_id, false);

		ret = xpcxd_ring_setup(netdev, ring_id, XPCXD_RING_RX);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring setup failed");
			goto cleanup;
		}

		ret = xpcxd_rx_ring_configure(netdev, ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring configure failed: %d",
					 ret);
			goto cleanup;
		}

		ret = xpcxd_rx_stat_clear_per_ring(netdev, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring clear stat failed: %d",
					 ret);
			goto cleanup;
		}

		ret = xpcxd_rx_ring_active(ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring activate failed: %d",
					 ret);
			goto cleanup;
		}

		xpcxd_rx_fill(netdev, &net_priv->rxr[ring_id].napi, ring_id,
			      rxr, net_priv->num_rx_desc, &processed, false);

		net_priv->txr[ring_id].queue =
			netdev_get_tx_queue(netdev, ring_id);

		xpcxd_interrupt = xpcxd_tx_cmpl_intr;

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				    "old state: [%s] --> UP",
				    (netdev->flags & IFF_UP) ? "UP" : "DOWN");

		ret = xpcxd_tx_rx_loopback_set(ring_id, xpcxd_loopback);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX/TX loopback set failed: %d",
					 ret);
			goto cleanup;
		}

		snprintf(if_name, sizeof(if_name), "%s-%s", xpcxd_netdev->name,
			 "RX_CMP_INT");

		/* Rx auto-affinity rule: from the highest core and decreasing */
		ret = xpci_register_interrupt(
			g_pxdev, (XPCI_X2_RX_CMP_INT_MIN + ring_id), if_name,
			xpcxd_rx_cmpl_intr,
			xpcxd_num_of_rings > 1 ? true : false, false, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Register RX_ERR_INT failed: %d", ret);
			goto cleanup;
		}

		snprintf(if_name, sizeof(if_name), "%s-%s", xpcxd_netdev->name,
			 "TX_CMP_INT");
		/* Tx auto-affinity rule: from core 0 and increasing */
		ret = xpci_register_interrupt(
			g_pxdev, (XPCI_X2_TX_CMP_INT_MIN + ring_id), if_name,
			xpcxd_tx_cmpl_intr,
			xpcxd_num_of_rings > 1 ? true : false, true, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Register TX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	if (xpcxd_cfg_tbl[xpcxd_rx_shaper]) {
		ret = xpcxd_rx_shaper_configure(netdev, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "RX ring configure failed: %d", ret);
			goto cleanup;
		}
	}

	if (xpcxd_cfg_tbl[xpcxd_enable_tx_err_int]) {
		ret = xpci_register_interrupt(g_pxdev, XPCI_X2_TX_ERR_INT,
					      "TX_ERR_INT",
					      xpcxd_tx_err_intr_handler, false,
					      false, 0);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Register TX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	if (xpcxd_cfg_tbl[xpcxd_enable_rx_err_int]) {
		ret = xpci_register_interrupt(g_pxdev, XPCI_X2_RX_ERR_INT,
					      "RX_ERR_INT",
					      xpcxd_rx_err_intr_handler, false,
					      false, 0);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Register RX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	/* Attribute / latency tuning only; ring paths use dma_wmb/dma_rmb. */
	if (xpcxd_pci_relaxed_ordering) {
		xpcxd_relaxed_ordering();
		xpcxd_lat_cfg();
	}

	xpcxd_msix_control();

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev,
			  "--- Device configuration completed ---");

	xpci_debug_level = orig_debug_level;

	return 0;

cleanup:
	/* Unregister interrupts that were successfully registered */
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		/* Unregister RX completion interrupt */
		if (g_pxdev &&
		    g_pxdev->irq_tbl[XPCI_X2_RX_CMP_INT_MIN + ring_id].allocated)
			xpci_unregister_interrupt(
				g_pxdev, XPCI_X2_RX_CMP_INT_MIN + ring_id);
		/* Unregister TX completion interrupt */
		if (g_pxdev &&
		    g_pxdev->irq_tbl[XPCI_X2_TX_CMP_INT_MIN + ring_id].allocated)
			xpci_unregister_interrupt(
				g_pxdev, XPCI_X2_TX_CMP_INT_MIN + ring_id);
	}
	/* Unregister error interrupts if they were registered */
	if (g_pxdev) {
		if (g_pxdev->irq_tbl[XPCI_X2_TX_ERR_INT].allocated)
			xpci_unregister_interrupt(g_pxdev, XPCI_X2_TX_ERR_INT);
		if (g_pxdev->irq_tbl[XPCI_X2_RX_ERR_INT].allocated)
			xpci_unregister_interrupt(g_pxdev, XPCI_X2_RX_ERR_INT);
	}

	/* Disable and remove NAPI that was added */
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		napi_disable(&net_priv->rxr[ring_id].napi);
		napi_disable(&net_priv->txr[ring_id].napi);
		netif_napi_del(&net_priv->rxr[ring_id].napi);
		netif_napi_del(&net_priv->txr[ring_id].napi);
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		if (net_priv->rxr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->rxr[ring_id]);
		if (net_priv->txr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->txr[ring_id]);
	}

	xpci_debug_level = orig_debug_level;

	return ret;
}

/* Entry point for interface activation by OS (IFF_UP): enable all DMA, Rings, etc. */
static int xpcxd_open(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_opt_trace(drv_lifecycle, 5, xpcxd_drv_lifecycle_detail(netdev),
			ktime_get_ns());

	xpcxd_stop_done = false;

	if (xpcxd_mode_standalone) {
		xpcxd_memavail("xpcxd_hw_init");

		ret = xpcxd_hw_init(xpcxd_num_of_rings, xpcxd_tx_ring_size,
				    xpcxd_rx_ring_size);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "xpcxd_hw_init() failed: %d", ret);
			return ret;
		}

		ret = xpcxd_hw_activate(true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "xpcxd_hw_activate() failed: %d", ret);
			return ret;
		}

		xpcxd_memavail("xpcxd_hw_activate");

		xpcxd_set_if_state(netdev, true, true);
	} else if (READ_ONCE(xpcxd_ifdown_in_progress)) {
		u32 ring_id;

		xpcxd_notice_netdev(NETIF_MSG_IFUP, netdev,
				    "non-standalone: clearing strict ifdown drop, kicking NAPI to resume Rx/Tx");
		net_priv->up_state = true;
		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = xpcxd_rx_drop_all_cmd;
		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = xpcxd_tx_drop_all_cmd;
		WRITE_ONCE(xpcxd_ifdown_in_progress, false);
		smp_wmb();

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			napi_schedule(&net_priv->rxr[ring_id].napi);
			napi_schedule(&net_priv->txr[ring_id].napi);
		}
	}

	xpcxd_rx_idle_trace_if_up_init();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

/* This function is called when a network device transitions to the DOWN state */
static int xpcxd_stop(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_opt_trace(drv_lifecycle, 1, xpcxd_drv_lifecycle_detail(netdev),
			ktime_get_ns());

	xpcxd_rx_idle_trace_if_down();
	xpcxd_rx_traces_try_unmute_after_cmpl_irq();

	if (net_priv->num_rings) {
		xpcxd_rx_opt_trace_ring(rx_action_stop, 0, &net_priv->rxr[0], 0,
					0);
	} else {
		xpcxd_opt_trace(rx_action_stop, 0, xpcxd_rx_trace_ring_zero, 0,
				0);
	}

	if (xpcxd_stop_done) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Already stopped");
		return 0;
	}

	if (!xpcxd_mode_standalone && !READ_ONCE(xpcxd_close_started) &&
	    !xpcxd_ifdown_strict_rx_drop_cmd) {
		xpcxd_notice_netdev(NETIF_MSG_IFDOWN, netdev,
				    "non-standalone: light quiesce on ndo_stop (HW retained for next ifup)");
		net_priv->up_state = false;
		xpcxd_opt_trace(drv_lifecycle, 2,
				xpcxd_drv_lifecycle_detail(netdev),
				ktime_get_ns());
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
		return 0;
	}

	if (!xpcxd_mode_standalone && !READ_ONCE(xpcxd_close_started) &&
	    xpcxd_ifdown_strict_rx_drop_cmd) {
		/*
		 * Strict non-standalone ifdown is a logical down only: keep HW/NAPI
		 * armed and gate traffic via rx/tx_drop_all. Full teardown is
		 * intentionally deferred to xpcxd_close(), which re-enters
		 * xpcxd_stop() with xpcxd_close_started=true and executes the
		 * quiesce path (interrupt disable, queue stop, napi_disable, ring
		 * delete) before module unload.
		 */
		xpcxd_notice_netdev(NETIF_MSG_IFDOWN, netdev,
				    "non-standalone: strict ifdown enabled (drop Rx/Tx while down, keep HW active)");
		WRITE_ONCE(xpcxd_ifdown_in_progress, true);
		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;
		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
		net_priv->up_state = false;
		xpcxd_opt_trace(rx_drop_all, -1, 3, 1);
		xpcxd_opt_trace(drv_lifecycle, 2,
				xpcxd_drv_lifecycle_detail(netdev),
				ktime_get_ns());
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
		return 0;
	}

	arm_timer_isr = false;

	/* Let Rx exit NAPI (no napi_reschedule on CMPL HW-full) and drop ingress during stop. */
	WRITE_ONCE(xpcxd_ifdown_in_progress, true);
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_opt_trace(rx_drop_all, -1, 3, 1);

	/* TODO: Much more work needed here to disable all the DMA, Rings, etc. */

	xpcxd_notice_netdev(NETIF_MSG_IFDOWN, netdev,
			    "old state: [%s] --> DOWN",
			    (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	xpcxd_disable_interrupts();
	xpcxd_synchronize_interrupts();

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_opt_trace(rx_action_tx_disable, (int)ring_id,
				xpcxd_rx_trace_ring_zero, 0, 0);

		ret = xpcxd_dev_tx_disable(netdev, ring_id);
		if (ret)
			xpcxd_err_netdev(NETIF_MSG_IFDOWN, netdev,
					 "Ring Rx disable failed: %d", ret);

		xpcxd_rx_opt_trace_ring(rx_action_rx_disable, ring_id,
					&net_priv->rxr[ring_id], 0, 0);

		ret = xpcxd_dev_rx_disable(netdev, ring_id);
		if (ret)
			xpcxd_err_netdev(NETIF_MSG_IFDOWN, netdev,
					 "Ring Tx disable failed: %d", ret);
	}

	xpcxd_tx_activate(false);
	xpcxd_rx_activate(false);

	netif_stop_queue(netdev); /* can't transmit any more */

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_rx_opt_trace_ring(rx_action_napi_disable, ring_id,
					&net_priv->rxr[ring_id], 0, 0);

		napi_disable(&net_priv->rxr[ring_id].napi);
		napi_disable(&net_priv->txr[ring_id].napi);
	}

	/* Allow in-flight RX softirq and stack processing to drain before freeing rings.
	 * Reduces risk of use-after-free when pages in SKBs are recycled after pool destroy.
	 */
	synchronize_net();

#ifdef __XPCXD_DEBUG__
	xpcxd_dump_pages(netdev, false);
#endif /* __XPCXD_DEBUG__ */

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		if (net_priv->rxr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->rxr[ring_id]);
		if (net_priv->txr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->txr[ring_id]);
	}

	net_priv->up_state = false;

	WRITE_ONCE(xpcxd_ifdown_in_progress, false);
	if (!READ_ONCE(xpcxd_close_started)) {
		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = xpcxd_rx_drop_all_cmd;
		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = xpcxd_tx_drop_all_cmd;
	}

	xpcxd_stop_done = true;

	xpcxd_memavail("xpcxd_stop");

	xpcxd_opt_trace(drv_lifecycle, 2, xpcxd_drv_lifecycle_detail(netdev),
			ktime_get_ns());

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_do_ioctl(struct net_device *netdev, struct ifreq *ifr, int cmd)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	switch (cmd) {
	/* Most of the default things are already supported in core/dev_ioctl.c */
	default:
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Operation not supported: %d", cmd);
		return -EOPNOTSUPP;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_change_mtu(struct net_device *netdev, int new_mtu)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if ((new_mtu < ETH_ZLEN) || (new_mtu > XPCXD_MAX_MTU_SIZE)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Wrong MTU value: %d",
				 new_mtu);
		return -EINVAL;
	}

	/* TODO: Check how to propagate change MTU to HW */

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "New MTU set to: %d",
			    new_mtu);
	netdev->mtu = new_mtu;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_set_mac_address(struct net_device *netdev, void *p)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct sockaddr *addr = p;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (!is_valid_ether_addr(addr->sa_data)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "MAC address not given");
		return -EADDRNOTAVAIL;
	}

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "NEW MAC address: %pM ",
			    addr->sa_data);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, addr->sa_data);
#else
	memcpy(netdev->dev_addr, addr->sa_data, netdev->addr_len);
#endif

	net_priv->mac_addr = ether_addr_to_u64(netdev->dev_addr);
	ret = eth_prepare_mac_addr_change(netdev, p);
	if (ret < 0) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Can't MAC address: %d",
				 ret);
		return ret;
	}

	eth_mac_addr(netdev, p);

	/* TODO: Check if new MAC should be set in HW */

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
void xpcxd_tx_timeout(struct net_device *netdev)
#else
void xpcxd_tx_timeout(struct net_device *netdev, unsigned int txqueue)
#endif
{
	if (unlikely(READ_ONCE(xpcxd_ifdown_in_progress) ||
		     READ_ONCE(xpcxd_close_started)))
		return;

	/* TODO : Implement together with dev->watchdog_timeot */
	xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "---> PCXD TX: Timeout");

	netif_trans_update(netdev); /* prevent tx timeout */
	netif_wake_queue(netdev);

	return;
}

void xpcxd_set_multicast_list(struct net_device *netdev)
{
	/* Empty callback just for teamd compatibility */
	/* xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "xpcxd_set_multicast_list not implemented"); */

	return;
}

#ifdef __XPCXD_STATS64__
void xpcxd_get_stats64(struct net_device *netdev,
		       struct rtnl_link_stats64 *stats)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ring_id;
	struct xpcxd_ring *ring = NULL;

	/* xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN"); */

	memset(stats, 0, sizeof(struct rtnl_link_stats64));

	rcu_read_lock();
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		ring = &net_priv->rxr[ring_id];

		if (ring) {
			stats->rx_packets += ring->stats.packets;
			stats->rx_bytes += ring->stats.bytes;
			stats->rx_errors += ring->stats.errors;
			stats->rx_dropped += ring->stats.dropped;
			stats->multicast += ring->stats.rx_multicast;
			stats->rx_crc_errors += ring->stats.hw_csum_rx_error;
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		ring = &net_priv->txr[ring_id];

		if (ring) {
			stats->tx_packets += ring->stats.packets;
			stats->tx_bytes += ring->stats.bytes;
			stats->tx_errors += ring->stats.errors;
			stats->tx_dropped += ring->stats.dropped;
		}
	}

	rcu_read_unlock();
}
#endif /* __XPCXD_STATS64__ */

static const struct net_device_ops xpcxd_ops = {
	/* .ndo_init = xpcxd_netdevice_init, Load */
	/* .ndo_uninit = xpcxd_netdevice_uninit, Unload */
	.ndo_open = xpcxd_open, /* UP */
	.ndo_stop = xpcxd_stop, /* DOWN */
	.ndo_start_xmit = xpcxd_xmit,
	.ndo_tx_timeout = xpcxd_tx_timeout,
	.ndo_set_rx_mode = xpcxd_set_multicast_list,
#if IS_ENABLED(CONFIG_BPF_SYSCALL)
	.ndo_xdp_xmit = xpcxd_xdp_xmit,
#endif
	/* .ndo_get_stats = xpcxd_get_stats, */
	.ndo_do_ioctl = xpcxd_do_ioctl,
	.ndo_change_mtu = xpcxd_change_mtu,
	.ndo_set_mac_address = xpcxd_set_mac_address,
#ifdef __XPCXD_STATS64__
	.ndo_get_stats64 = xpcxd_get_stats64,
#endif /* __XPCXD_STATS64__ */
};

/*
 * Helper for alloc_netdev()
 */
static void xpci_setup(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	u8 mac_addr[ETH_ALEN] = { 0 };
#endif

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Initialize the device structure. */
	netdev->netdev_ops = &xpcxd_ops;

	/* Fill in device structure with ethernet-generic values. */
	netdev->type = ARPHRD_ETHER;
	netdev->priv_flags |=
		IFF_LIVE_ADDR_CHANGE | IFF_NO_QUEUE; /* | ~IFF_UP;*/
	if (xpcxd_check_l4_checksum) {
		netdev->features = NETIF_F_HW_CSUM | NETIF_F_RXCSUM;
	}
	if (xpcxd_rss_enabled) {
		netdev->features = NETIF_F_RXHASH;
	}
	netdev->hw_features |= netdev->features;
	netdev->hw_enc_features |= netdev->features;
	netdev->hard_header_len = ETH_HLEN;
	netdev->tx_queue_len = 1000;

	/* According to RFC-791:
	 * Every internet module must be able to forward a datagram of 68
	 * octets without further fragmentation.  This is because an Internet
	 * header may be up to 60 octets, and the minimum fragment is 8 octets.
	 */
	netdev->min_mtu = ETH_MIN_MTU;
	netdev->mtu = xpcxd_default_mtu;
	netdev->max_mtu = XPCXD_MAX_MTU_SIZE;

	net_priv = netdev_priv(netdev);
	memset(net_priv, 0, sizeof(struct xpcxd_priv));
	net_priv->up_state = false;
	net_priv->oper_status = false;

	xpcxd_set_ethtool_ops(netdev);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, mac_addr);
#else
	memset(netdev->dev_addr, 0, ETH_ALEN);
#endif

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

int xpcxd_set_if_state(struct net_device *netdev, bool status,
		       bool carrier_state)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	netdev = xpcxd_netdev;

	xpcxd_dbg_netdev(NETIF_MSG_LINK, netdev, "IN");

	xpcxd_notice_netdev(NETIF_MSG_IFUP, netdev,
			    "Set Interface interface state: %s",
			    (status ? "UP" : "DOWN"));

	if (status) {
		netif_tx_start_all_queues(netdev); /* can transmit now */

		/* xpcxd_intg_spare_write(g_cnt_if_up); */

		net_priv->up_state = true;

		dev_change_flags(netdev, netdev->flags | IFF_UP, NULL);
	} else {
		dev_change_flags(netdev, netdev->flags & ~IFF_UP, NULL);
	}

	if (carrier_state) {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Carrier ON");
		netif_carrier_on(netdev);

		if (net_priv->num_rings) {
			xpcxd_rx_opt_trace_ring(rx_action_carrier_on, 0,
						&net_priv->rxr[0], 0, 0);
		} else {
			xpcxd_opt_trace(rx_action_carrier_on, 0,
					xpcxd_rx_trace_ring_zero, 0, 0);
		}
	} else {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Carrier OFF");
		netif_carrier_off(netdev);

		if (net_priv->num_rings) {
			xpcxd_rx_opt_trace_ring(rx_action_carrier_off, 0,
						&net_priv->rxr[0], 0, 0);
		} else {
			xpcxd_opt_trace(rx_action_carrier_off, 0,
					xpcxd_rx_trace_ring_zero, 0, 0);
		}
	}

	net_priv->oper_status = status;

	xpcxd_dbg_netdev(NETIF_MSG_LINK, netdev, "OUT");

	return 0;
}

static void xpcxd_service_task(struct work_struct *work)
{
	struct xpcxd_priv *net_priv;
	struct net_device *netdev;
	int ret;
	bool was_up;

	net_priv = container_of(work, struct xpcxd_priv, service_task);
	netdev = net_priv->netdev;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* restart the device */
	rtnl_lock();
	was_up = netif_carrier_ok(netdev);
	if (likely(was_up)) {
		xpcxd_opt_trace(drv_lifecycle, 6,
				xpcxd_drv_lifecycle_detail(netdev) | 16,
				ktime_get_ns());
		set_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS,
			&net_priv->dev_flags);
		xpcxd_close();
		clear_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS,
			  &net_priv->dev_flags);
	}
	ret = xpcxd_dev_reset(netdev);
	xpcxd_opt_trace(drv_lifecycle, 7, ret, ktime_get_ns());
	if (ret)
		goto exit;
	if (likely(was_up)) {
		set_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS,
			&net_priv->dev_flags);
		ret = xpcxd_open(netdev);
		xpcxd_opt_trace(drv_lifecycle, 8, ret, ktime_get_ns());
		clear_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS,
			  &net_priv->dev_flags);
		if (ret) {
			goto exit;
		}
	}
	clear_bit(XPCXD_FLAG_DEV_FAILED, &net_priv->dev_flags);

exit:
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "device restart failed");
		set_bit(XPCXD_FLAG_DEV_DEAD, &net_priv->dev_flags);
	}
	rtnl_unlock();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return;
}

static int xpcxd_dev_init(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	net_priv->netdev = netdev;

	ret = xpcxd_dev_reset(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "init: device reset failed");
		goto error;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Allocate workqueue");
	net_priv->wq = alloc_ordered_workqueue("xpcxd", 0);
	if (unlikely(net_priv->wq == NULL)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "init: alloc_ordered_workqueue() failed");
		ret = -ENOMEM;
		goto error;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "INIT_WORK");
	INIT_WORK(&net_priv->service_task, xpcxd_service_task);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error:
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "ERR: OUT");

	return ret;
}

int xpcxd_register_netdev(char *if_name, bool do_rtnl_lock)
{
	struct net_device *netdev = NULL;
	struct xpcxd_priv *net_priv = NULL;
	struct inet6_dev *idev = NULL;
	static const u8 xsight_oui[3] = { 0x00, 0x11, 0x11 };
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_memavail("------ xpcxd_register_netdev ------ ");

	xpcxd_info(NETIF_MSG_DRV, "Allocating new PCXD netdev [%s]", if_name);
	netdev = alloc_netdev_mqs(sizeof(*net_priv), if_name, NET_NAME_UNKNOWN,
				  ether_setup, XPCXD_MAX_RING_NUM,
				  XPCXD_MAX_RING_NUM);
	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "alloc_netdev() [%s] failed", if_name);
		ret = -EINVAL;
		goto error_exit;
	}

	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "Invalid netdev");
		ret = -EINVAL;
		goto error_exit;
	}

	xpcxd_netdev = netdev;

	xpcxd_info(NETIF_MSG_DRV, "New PCXD netdev [%s][%p]", if_name, netdev);

	xpci_setup(netdev);

	net_priv = netdev_priv(netdev);

	/* Set device MAC address */
	memcpy(net_priv->mac, xsight_oui, 3);
	/* get_random_bytes(net_priv->mac + 3, 3); */
	net_priv->mac[3] = 0x19;
	net_priv->mac[4] = 0x72;
	net_priv->mac[5] = 0; /* phy_port */

	if (g_pxdev)
		net_priv->hw_dev = &g_pxdev->pdev->dev;

	idev = __in6_dev_get(netdev);
	if (idev) {
		idev->cnf.disable_ipv6 = 1;
	}

	if (do_rtnl_lock)
		rtnl_lock();

	ret = register_netdevice(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Net Device register failed: %d", ret);
		goto error_unlock;
	}

	ret = xpcxd_dev_init(netdev);
	if (ret)
		goto error_unregister;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST, NULL);
#else
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, net_priv->mac);
#else
	memcpy(netdev->dev_addr, net_priv->mac, ETH_ALEN);
#endif
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "MAC address SET: [%pM]",
			    netdev->dev_addr);

	/* Initial interface state is always DOWN */
	xpcxd_set_if_state(netdev, true, false);

	netdev_update_features(netdev);

	dev_disable_lro(netdev);

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Device state: [%s]",
			    (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	if (do_rtnl_lock)
		rtnl_unlock();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error_unregister:
	/* Clean up workqueue before unregistering netdev */
	if (netdev) {
		struct xpcxd_priv *net_priv = netdev_priv(netdev);
		if (net_priv && net_priv->wq) {
			flush_workqueue(net_priv->wq);
			destroy_workqueue(net_priv->wq);
			net_priv->wq = NULL;
		}
	}
	unregister_netdev(netdev);

error_unlock:
	if (do_rtnl_lock)
		rtnl_unlock();

	if (netdev) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "free_netdev()");
		free_netdev(netdev);
	}

error_exit:

	xpcxd_err(NETIF_MSG_DRV, "[%s]: ERR OUT", if_name);

	return ret;
}

int xpcxd_hw_init(u32 _num_of_rings, u16 _tx_ring_size, u16 _rx_ring_size)
{
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	net_priv->num_rings = _num_of_rings;
	net_priv->num_tx_desc = _tx_ring_size;
	net_priv->num_rx_desc = _rx_ring_size;

	xpcxd_num_of_rings = _num_of_rings;

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev,
			  "Number of configured Rx queues: [%d]",
			  net_priv->num_rings);

	xpcxd_memavail("xpcxd_config: BEFORE");

	ret = xpcxd_config(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Net Device config failed with error: %d",
				 ret);
		/* Avoid all possible rings operations if failed */
		net_priv->num_rings = 0;
		xpcxd_num_of_rings = 0;
		goto error_exit;
	}

	xpcxd_memavail("xpcxd_config: AFTER");

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error_exit:

	xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "ERR OUT");

	return ret;
}

int xpcxd_hw_activate(bool activate)
{
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	/* Disable Tx before any HW deactivation */
	if (!activate)
		hw_ready = false;

	xpcxd_tx_activate(false);
	xpcxd_rx_activate(false);

	xpcxd_tx_activate(xpcxd_tx_enabled);

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "TX enabled");

	xpcxd_rx_activate(xpcxd_rx_enabled);

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_rx_db_init(netdev, &net_priv->rxr[ring_id], ring_id);
	}

	/* Enable Tx only when HW is activated and ready */
	if (activate)
		hw_ready = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

void xpcxd_unregister_netdev(struct net_device *netdev, bool do_rtnl_lock)
{
	struct xpcxd_priv *net_priv = NULL;
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%p]", netdev);

	net_priv = netdev_priv(netdev);

	/*
	 * Stop TX watchdog triggering while we are deleting NAPI and tearing
	 * the netdev down.
	 */
	netif_tx_disable(netdev);
	netif_carrier_off(netdev);

	/* NAPI Delete */
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "netif_napi_del(RX) Ring[%d]", ring_id);
		netif_napi_del(&net_priv->rxr[ring_id].napi);

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "netif_napi_del(TX) Ring[%d]", ring_id);
		netif_napi_del(&net_priv->txr[ring_id].napi);
	}

	if (do_rtnl_lock)
		rtnl_lock();

	if (do_rtnl_lock)
		rtnl_unlock();
	if (net_priv->wq) {
		flush_workqueue(net_priv->wq);
		destroy_workqueue(net_priv->wq);
		net_priv->wq = NULL;
	}

	unregister_netdev(netdev); /* It will call our stop function */
	free_netdev(netdev);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)) && defined(__XPCXD_DIE_NOTIFIER__)
/**
 * xpcxd_die_notifier - Notifier callback for handling die events.
 * @self: Pointer to the notifier block structure.
 * @event: The event code indicating the type of die event.
 * @ptr: Pointer to additional event-specific data.
 *
 * This function is registered as a notifier for system die events (such as
 * kernel panics or oopses). It is called when such an event occurs, allowing
 * the driver to perform necessary cleanup or logging before the system halts
 * or reboots.
 *
 * Return: NOTIFY_DONE, NOTIFY_OK, or other notifier return codes depending on
 * the handling of the event.
 */
static int xpcxd_die_notifier(struct notifier_block *self, unsigned long event,
			      void *ptr)
{
	if (event == DIE_INT3 || event == DIE_DEBUG)
		return NOTIFY_DONE; /* Ignore debug events */

	tracing_off();

	if (xpcxd_netdev) {
		xpcxd_rx_stat_dump_short(xpcxd_netdev);
		xpcxd_tx_stat_dump_short(xpcxd_netdev);
	}

	pr_emerg(">>> Calling ftrace_dump()\n");

	ftrace_dump(DUMP_ALL);

	return NOTIFY_DONE;
}

/**
 * xpcxd_panic_notifier - Panic event notifier callback for XPCXD driver
 * @nb:   Pointer to the notifier block structure
 * @event: Panic event identifier
 * @ptr:  Pointer to additional event-specific data
 *
 * This function is registered as a panic notifier and is called when a kernel
 * panic occurs. It allows the driver to perform necessary cleanup or logging
 * before the system halts or reboots. The function should return NOTIFY_DONE,
 * NOTIFY_OK, or another appropriate notifier return value based on the action taken.
 *
 * Return: Return value NOTIFY_DONE indicating the result of the notification handling.
 */
static int xpcxd_panic_notifier(struct notifier_block *nb, unsigned long event,
				void *data)
{
	xpci_debug_level = XPCI_DBG_LEVEL__DBG;

	pr_emerg(">>> PANIC event: [%lu] <<<\n", event);

	tracing_off();

	xpci_notice("%s version: %s", XPCI_DRIVER_NAME, XPCI_DRIVER_VERSION);

#ifdef __XPCXD_DEBUG__
	if (xpcxd_netdev)
		xpcxd_dump_pages(xpcxd_netdev, true);
#endif /* __XPCXD_DEBUG__ */

	if (xpcxd_netdev) {
		int rx_desc_dump_ret = xpcxd_rx_desc_status_dump(xpcxd_netdev);
		int tx_desc_dump_ret;

		if (rx_desc_dump_ret)
			pr_emerg(">>> Rx descriptor status dump failed: %d\n",
				 rx_desc_dump_ret);

		tx_desc_dump_ret = xpcxd_tx_desc_status_dump(xpcxd_netdev);
		if (tx_desc_dump_ret)
			pr_emerg(">>> Tx descriptor status dump failed: %d\n",
				 tx_desc_dump_ret);
	}

	pr_emerg(">>> Calling ftrace_dump()\n");

	ftrace_dump(DUMP_ALL);

	return NOTIFY_DONE;
}

static struct notifier_block xpcxd_die_nb = {
	.notifier_call = xpcxd_die_notifier,
};

static struct notifier_block xpcxd_nt_nb = {
	.notifier_call = xpcxd_panic_notifier,
	.priority = INT_MAX, /* run early */
};
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0) && __XPCXD_DIE_NOTIFIER__*/

void resize_ftrace_buffer_from_module(void)
{
	static char *envp[] = { "HOME=/", "TERM=linux",
				"PATH=/sbin:/bin:/usr/sbin:/usr/bin", NULL };

	static char *argv[] = { "/bin/sh", "-c",
				"echo 128 > /sys/kernel/tracing/buffer_size_kb",
				NULL };

	call_usermodehelper(argv[0], argv, envp, UMH_WAIT_PROC);
}

int xpcxd_init(void *_pxdev)
{
	int ret = 0;
	u64 version = 0;
	u64 block_id = 0;
	u64 block_release = 0;
	struct xdev *pxdev = (struct xdev *)_pxdev;

	xpcxd_dbg(NETIF_MSG_DRV, "xpcxd_init() IN: debug level: %d",
		  xpci_debug_level);

	if (WARN_ON_ONCE(READ_ONCE(xpcxd_singleton_active) ||
			 READ_ONCE(xpcxd_netdev) || READ_ONCE(g_pxdev))) {
		xpcxd_err(NETIF_MSG_DRV,
			  "xpcxd supports a single instance; second init rejected");
		return -EOPNOTSUPP;
	}

	WRITE_ONCE(xpcxd_close_done, false);
	WRITE_ONCE(xpcxd_close_started, false);
	WRITE_ONCE(xpcxd_ifdown_in_progress, false);
	xpcxd_stop_done = false;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)) && defined(__XPCXD_DIE_NOTIFIER__)
	register_die_notifier(&xpcxd_die_nb);
	atomic_notifier_chain_register(&panic_notifier_list, &xpcxd_nt_nb);

	resize_ftrace_buffer_from_module();
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0) && __XPCXD_DIE_NOTIFIER__ */

	ret = xpcxd_get_version(&version, &block_id, &block_release);
	xpcxd_notice(
		NETIF_MSG_DRV,
		"PCXD Device version: [0x%llx] block id: [0x%llx] block_release: [0x%llx]",
		version, block_id, block_release);

	ret = xpcxd_netdev_sysctl_init();
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "Sys ctl init failed: %d", ret);
		goto error_notifiers;
	}

	ret = xpcxd_rtnl_link_register();
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "Rtnl link register failed: %d", ret);
		goto error_sysctl;
	}

	g_pxdev = pxdev;

	ret = xpcxd_register_netdev("xpcxd0", true);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_register_netdev() failed: %d",
			  ret);
		goto error_rtnl;
	}

	WRITE_ONCE(xpcxd_singleton_active, true);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;

error_rtnl:
	g_pxdev = NULL;
	xpcxd_rtnl_link_unregister();

error_sysctl:
	unregister_net_sysctl_table(xpcxd_netdev_sysctl_header);

error_notifiers:
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	unregister_die_notifier(&xpcxd_die_nb);
	atomic_notifier_chain_unregister(&panic_notifier_list, &xpcxd_nt_nb);
#endif

	return ret;
}

int xpcxd_close(void)
{
	int lc_detail = 0;

	WRITE_ONCE(xpcxd_close_started, true);

	if (xpci_debug_level < XPCI_DBG_LEVEL__INFO)
		xpci_debug_level = XPCI_DBG_LEVEL__INFO;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	if (xpcxd_netdev)
		lc_detail = xpcxd_drv_lifecycle_detail(xpcxd_netdev);
	if (xpcxd_stop_done)
		lc_detail |= 8;
	xpcxd_opt_trace(drv_lifecycle, 4, lc_detail, ktime_get_ns());

	/* STOP ALL Rx/Tx activity in this case */
	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;

	if (xpcxd_netdev) {
		struct xpcxd_priv *np = netdev_priv(xpcxd_netdev);

		if (np->num_rings) {
			xpcxd_rx_opt_trace_ring(rx_action_close, 0, &np->rxr[0],
						0, 0);
		} else {
			xpcxd_opt_trace(rx_action_close, 0,
					xpcxd_rx_trace_ring_zero, 0, 0);
		}
	} else {
		xpcxd_opt_trace(rx_action_close, 0, xpcxd_rx_trace_ring_zero, 0,
				0);
	}

	if (READ_ONCE(xpcxd_close_done)) {
		xpcxd_dbg(NETIF_MSG_DRV, "Already done");
		return 0;
	}

	WARN_ON_ONCE(READ_ONCE(xpcxd_ifdown_in_progress) && xpcxd_stop_done);

	/* For the case driver just removed without setting interface down, etc. */
	if (!xpcxd_stop_done && xpcxd_netdev) {
		int ret = 0;

		xpcxd_dbg(NETIF_MSG_DRV, "Stopping interface: [%s]",
			  xpcxd_netdev->name);
		ret = xpcxd_stop(xpcxd_netdev);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xpcxd_stop() failed: %d",
				  ret);
		} else {
			WARN_ON_ONCE(!xpcxd_stop_done);
		}
	}

#ifdef __XPCXD_TEARDOWN_DEBUG__
	xpcxd_err(NETIF_MSG_DRV, "BEFORE SLEEP");

	msleep(10000); /* 10 s */

	xpcxd_err(NETIF_MSG_DRV, "AFTER SLEEP");
#endif

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)) && defined(__XPCXD_DIE_NOTIFIER__)
	unregister_die_notifier(&xpcxd_die_nb);
	atomic_notifier_chain_unregister(&panic_notifier_list, &xpcxd_nt_nb);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0) && __XPCXD_DIE_NOTIFIER__ */

	WRITE_ONCE(xpcxd_close_done, true);
	WRITE_ONCE(xpcxd_singleton_active, false);

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD RTNL unregister");
	xpcxd_rtnl_link_unregister();

	if (xpcxd_netdev) {
		xpcxd_dbg(NETIF_MSG_DRV, "PCXD Netdev unregister: [%s]",
			  xpcxd_netdev->name);
		xpcxd_unregister_netdev(xpcxd_netdev, true);
	}

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD sysctl unregister");
	unregister_net_sysctl_table(xpcxd_netdev_sysctl_header);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}
