// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver TX handling
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/icmp.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>
#include <linux/icmpv6.h>
#include <linux/prefetch.h>
#include <linux/string.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/sch_generic.h>

#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xpci_trace.h"
#include "xnetdev_common.h"
#include "xpcxd.h"
#include "xpcxd_os.h"
#if IS_ENABLED(CONFIG_BPF_SYSCALL)
#include <net/xdp.h>
#endif

extern bool hw_ready;
extern int xpcxd_loopback;
extern int xpcxd_ring_threshold;
extern int xpcxd_rx_ring_threshold_stop;
extern int xpcxd_tx_packets_stop;
extern int xpcxd_tx_drop_on_alignment_err;
extern int xpcxd_tx_stats_uc_mc_bc;

/* Internal fixed defaults (no module params) */
static int xpcxd_tx_sbm_rfl_mode = XPCXD_TX_SBM_RFL_MODE_DEFAULT;
static int xpcxd_tx_cmp_rfl_mode = XPCXD_TX_CMP_RFL_MODE_DEFAULT;

extern ktime_t tx_coalescing_ktime;
extern uint xpcxd_cfg_tbl[xpcxd_last_cfg_item];

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx);
extern void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
		     enum xpci_tx_rx tx_rx, u32 stop_val, char *msg);

static bool xpcxd_tx_is_ipv6_mld(struct sk_buff *skb)
{
	const struct ethhdr *eth;
	const struct vlan_ethhdr *veh;
	const struct ipv6hdr *ip6h;
	const struct icmp6hdr *icmp6h;
	__be16 l3_proto;
	u16 l3_off = ETH_HLEN;

	if (!pskb_may_pull(skb, ETH_HLEN))
		return false;

	eth = (const struct ethhdr *)skb->data;
	l3_proto = eth->h_proto;
	if (l3_proto == htons(ETH_P_8021Q) || l3_proto == htons(ETH_P_8021AD)) {
		l3_off = VLAN_ETH_HLEN;
		if (!pskb_may_pull(skb, l3_off))
			return false;
		veh = (const struct vlan_ethhdr *)skb->data;
		l3_proto = veh->h_vlan_encapsulated_proto;
	}

	if (l3_proto != htons(ETH_P_IPV6))
		return false;

	if (!pskb_may_pull(skb, l3_off + sizeof(*ip6h)))
		return false;
	ip6h = (const struct ipv6hdr *)(skb->data + l3_off);
	if (ip6h->nexthdr != IPPROTO_ICMPV6)
		return false;

	if (!pskb_may_pull(skb, l3_off + sizeof(*ip6h) + sizeof(*icmp6h)))
		return false;
	icmp6h = (const struct icmp6hdr *)(skb->data + l3_off + sizeof(*ip6h));

	switch (icmp6h->icmp6_type) {
	case ICMPV6_MGM_QUERY:
	case ICMPV6_MGM_REPORT:
	case ICMPV6_MGM_REDUCTION:
	case ICMPV6_MLD2_REPORT:
		return true;
	default:
		return false;
	}
}

static u16 xpcxd_get_tx_sbm_cns_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_cns = NULL;
	u16 sbm_prd_ptr = 0;
	u32 ret = 0;

	if (xpcxd_tx_sbm_rfl_mode) {
		xpcxd_dma_rmb();

		rfl_cns = net_priv->txr[ring_id].sub.rfl_cns;

		sbm_prd_ptr = rfl_cns->ring_index_tail & net_priv->txr[ring_id].sub.mask;
	} else {
		u8 row[XREG_MEMCFG_RNG_STTS_ROW_BYTES];
		u64 row_lo = 0;

		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(row) /* Size */,
			row);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return 0;
		}

		memcpy(&row_lo, row, sizeof(row_lo));
		sbm_prd_ptr = xreg_memcfg_rng_stts_srd_cns_ptr(row_lo);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD SUB TX: TX_RNG_STTS_TBL_SRD_CNS_PTR_GET: 0x%x | %u --> mask: %u",
			sbm_prd_ptr, sbm_prd_ptr, sbm_prd_ptr & net_priv->txr[ring_id].sub.mask);
		sbm_prd_ptr = sbm_prd_ptr & net_priv->txr[ring_id].sub.mask;
	}

	return sbm_prd_ptr;
}

u16 xpcxd_get_tx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd = NULL;
	u16 cmpl_prd_ptr = 0;
	int ret;

	if (xpcxd_tx_cmp_rfl_mode) {
		xpcxd_dma_rmb();

		rfl_prd = net_priv->txr[ring_id].cmp.rfl_prd;

		cmpl_prd_ptr = rfl_prd->ring_index_head & net_priv->txr[ring_id].cmp.mask;
	} else {
		struct xpcxd_ring *txr = &net_priv->txr[ring_id];
		u8 row[XREG_MEMCFG_RNG_STTS_ROW_BYTES];
		u64 row_lo = 0;

		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(row) /* Size */,
			row);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV,
				  "TX_RNG_STTS xdrv_mem_ind_read() failed: %d (using cached cmpl_prd_ptr)",
				  ret);
			return txr->cmp.cmpl_prd_ptr;
		}

		memcpy(&row_lo, row, sizeof(row_lo));
		cmpl_prd_ptr = xreg_memcfg_rng_stts_crd_prd_ptr(row_lo);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD CMPL TX: TX_RNG_STTS_TBL_CRD_PRD_PTR: 0x%x | %u",
			cmpl_prd_ptr, cmpl_prd_ptr);
	}

	return cmpl_prd_ptr;
}

static void xpcxd_tx_db_write(struct net_device *netdev, u16 ring_id,
			      u16 prod_idx)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = &p->table[XREG_ID_PCXD_TX_DB];
	u32 db_addr;
	u64 v = 0;

	xpcxd_opt_trace(tx_db_write, ring_id, 0, 0, 0, prod_idx);

	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_RIND_ID, ring_id);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_MODE, 0);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_VALUE, prod_idx);

	db_addr = xreg_addr(p, XREG_ID_PCXD_TX_DB, 0, 0);
	xpci_write64_fast(db_addr, v);

	/*
	 * Posting read: flush the doorbell past the PCI bridge so it cannot be
	 * reordered behind the next memory op (parity with RX path). Correctness
	 * relies on dma_wmb() before this function publishing the descriptors,
	 * not on any PCIe transaction ordering attribute.
	 */
	(void)xpci_read64_fast(db_addr);
}

/*
 * Flush a deferred Tx doorbell for @txr. Caller MUST hold txr->tx_lock.
 * No-op when nothing is pending. Used by:
 *   - end of xpcxd_xmit() (normal path + tx_drop cleanup)
 *   - xpcxd_ring_tx_coales_isr() as a safety flush paired with the
 *     deferred-DB policy (netdev_xmit_more() batching).
 *
 * Issues a single xpcxd_dma_wmb() before the DB write: that publishes
 * every descriptor that was enqueued since the previous flush.
 */
static inline void xpcxd_tx_db_flush_locked(struct net_device *netdev,
					    struct xpcxd_ring *txr)
{
	u16 pending = txr->sub_desc_pending;

	if (pending == 0)
		return;

	txr->sub_desc_pending = 0;
	txr->db_count = 0;
	xpcxd_dma_wmb();
	xpcxd_tx_db_write(netdev, txr->ring_id, pending);
}

static int xpcxd_is_multicast_ipv4(__be32 ip_addr) {
    unsigned long addr = ntohl(ip_addr);
    return (addr >= 0xE0000000 && addr <= 0xEFFFFFFF);
}

enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer)
{
	struct xpcxd_ring *ring;

	ring = container_of(timer, struct xpcxd_ring, tx_coales_isr);

	hrtimer_forward_now(timer, tx_coalescing_ktime);

	/*
	 * Safety flush paired with the deferred-DB policy in xpcxd_xmit().
	 * We must serialize with xpcxd_xmit() (producer) via tx_lock, both
	 * to read sub_desc_pending atomically and to avoid a double DB.
	 *
	 * Runs in softirq (HRTIMER_MODE_REL); ndo_start_xmit runs with BH
	 * disabled, so a plain spin_lock() matches xpcxd_xmit()'s locking.
	 */
	spin_lock(&ring->tx_lock);
	xpcxd_tx_db_flush_locked(NULL, ring);
	spin_unlock(&ring->tx_lock);

	return HRTIMER_RESTART;
}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
static u64 prev_tx_underflow_cnt = 0;
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

#ifdef __XPCXD_ICMP_TRACE__
void xpcxd_check_icmp_echo(struct sk_buff *skb, struct net_device *netdev)
{
    struct iphdr *iph;
    struct icmphdr *icmph;

    if (!skb)
        return;

    if (!skb_mac_header_was_set(skb))
        return;

    if (!pskb_may_pull(skb, sizeof(struct iphdr)))
        return;

    iph = ip_hdr(skb);

    if (iph->protocol != IPPROTO_ICMP)
        return;

    if (!pskb_may_pull(skb, ip_hdrlen(skb) + sizeof(struct icmphdr)))
        return;

    icmph = (struct icmphdr *)(skb_transport_header(skb));

    if (icmph->type == ICMP_ECHO) {
		xpcxd_opt_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
        xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
				"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
				skb,
				skb->len,
                ntohs(icmph->un.echo.id),
                ntohs(icmph->un.echo.sequence));
    }

	switch (icmph->type) {
        case ICMP_ECHO:
			xpcxd_opt_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        case ICMP_ECHOREPLY:
			xpcxd_opt_trace(tx_pkt_icmp_reply, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Reply: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        default:
            break;
    }
}
#endif /* __XPCXD_ICMP_TRACE__ */

/* net device transmit always called with BH disabled user __netif_tx_lock */
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr = NULL;
	struct xpcxd_sw_desc *sw_desc = NULL;
	struct xpcxd_desc tx_md = { 0 };
	struct xpcxd_desc tx_bd = { 0 };
	u16 ring_space = 0;
	u16 prod_idx = 0;
	u16 num_desc = 0;
	u32 pad = 0;
	u32 ring_id;
	u16 total_desc_batch = 0; /* descriptors enqueued in this batch, doorbell once at end */
	u8 *skb_tail = NULL;
	dma_addr_t dma_addr = { 0 };
	netdev_tx_t tx_ret = NETDEV_TX_OK;
	bool check_l3_checksum = false;
	bool check_l4_checksum = false;
	__be16 protocol = 0;
	const struct ethhdr *eth = NULL;
	const struct iphdr *iph = NULL;
	const struct ipv6hdr *ip6h = NULL;
	u16 eth_len = 0;
	u16 l3_offset = 0;
	u16 shim_hdr_size = 0;
	bool trimmed = false;
	__be16 l4_protocol = 0;

	u32 batch_pkts = 0;
	u64 batch_bytes = 0;
	u32 batch_uc = 0;
	u32 batch_mc = 0;
	u32 batch_bc = 0;
	u32 batch_vlan = 0;
	u32 batch_align_err = 0;
	u32 batch_realign = 0;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	u32 batch_sz64_128 = 0;
	u32 batch_sz128_256 = 0;
	u32 batch_sz256_plus = 0;
#endif
	bool use_pool = false;
	u32 last_skb_len = 0;

	if (!hw_ready) {
		xpcxd_info_netdev(NETIF_MSG_TX_ERR, netdev,
				 "---> PCXD TX: HW is not ready");
		dev_kfree_skb_any(skb);
		return tx_ret;
	}

	if (unlikely(!net_priv->num_rings)) {
		xpcxd_info_netdev(NETIF_MSG_TX_ERR, netdev,
				  "---> PCXD TX: no rings configured");
		dev_kfree_skb_any(skb);
		return tx_ret;
	}

	ring_id = skb_get_queue_mapping(skb) % net_priv->num_rings;
	txr = &net_priv->txr[ring_id];

	if (xpcxd_cfg_tbl[xpcxd_tx_drop_all]) {
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		return tx_ret;
	}

	if (unlikely(!READ_ONCE(txr->sub.sw))) {
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		return NETDEV_TX_OK;
	}

	spin_lock(&txr->tx_lock);

	txr->db_count++;

	/*
	 * Lazy SUB cns refresh. xpcxd_get_tx_sbm_cns_ptr() does the
	 * MMIO/RFL read (memcfg mode) or coherent-DMA load + dma_rmb()
	 * (RFL mode); on ARM with non-cached coherent mappings that is
	 * an uncached load (~150-300 ns) that we used to pay on every
	 * xmit call.
	 *
	 * The cached value in txr->sub.sub_cns_ptr only grows staler in
	 * one direction: HW is consuming, so real free space is always
	 * >= what we compute from the cache. That means we only need to
	 * refresh when our cached view of free space is getting low;
	 * while the ring has plenty of headroom we can reuse the stale
	 * cache and skip the MMIO/uncached read entirely.
	 *
	 * Threshold: 1/4 of the ring. Well above XPCXD_TX_STOP_THOLD so
	 * xmit_more batching can keep flowing without blocking, and low
	 * enough that we refresh in time to see space free up before we
	 * would actually drop.
	 */
	if (xpcxd_get_tx_sub_ring_space(txr) < (u32)(txr->sub.size >> 2))
		txr->sub.sub_cns_ptr =
			xpcxd_get_tx_sbm_cns_ptr(netdev, ring_id);

	prod_idx = txr->sub.prod;

	xpcxd_opt_trace(tx_xmit, ring_id, skb, skb->len, prod_idx, txr->sub.sub_cns_ptr);

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX", netdev, skb, TX_OFFSET, xpci_tx);

	protocol = vlan_get_protocol(skb);
	/*
	 * Optional guard (enabled by default via ethtool private flag):
	 * drop LLDP frames that are not carried with the expected PCXD shim
	 * EtherTypes, before publishing any Tx descriptors.
	 */
	if (unlikely((net_priv->priv_flags & XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM) &&
		     protocol == htons(XSW_ETHTYPE_LLDP) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_INJECT))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev,
				 "Drop non-shim Tx LLDP: ring=%u skb=%p proto=0x%x",
				 ring_id, skb, ntohs(protocol));
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		spin_unlock(&txr->tx_lock);
		return NETDEV_TX_OK;
	}
	/*
	 * Optional guard (enabled by default via ethtool private flag):
	 * drop IPv6 MLD control traffic unless it is wrapped by the expected
	 * PCXD shim EtherTypes, before publishing any Tx descriptors.
	 */
	if (unlikely((net_priv->priv_flags & XPCXD_FLAG_DROP_TX_MLD_NON_SHIM) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_INJECT) &&
		     xpcxd_tx_is_ipv6_mld(skb))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev,
				 "Drop non-shim Tx IPv6 MLD: ring=%u skb=%p proto=0x%x",
				 ring_id, skb, ntohs(protocol));
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		spin_unlock(&txr->tx_lock);
		return NETDEV_TX_OK;
	}

	if (!netif_carrier_ok(netdev)) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD TX: skb: [%p] Carrier off --> drop",
				ring_id, skb);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	/* pad to min length if necessary */
	if (unlikely(skb->len < ETH_ZLEN)) {
		pad = ETH_ZLEN - skb->len;
		skb_tail = __skb_put(skb, pad);
		memset(skb_tail, 0, pad);
	}

	/*
	 * Pool fast path decision. Must be after pad-to-ETH_ZLEN so
	 * skb->len reflects the on-wire length (the slot only needs to
	 * hold what we memcpy). Packets whose padded length exceeds the
	 * ring's slot (jumbo, or any outsize packet on a small-slot
	 * config) fall back to the legacy dma_map_single() path for
	 * that packet; rings without a pool (vaddr == NULL) always use
	 * legacy.
	 */
	use_pool = likely(txr->tx_pool.vaddr) &&
		   (skb->len <= txr->tx_pool.slot_size);

	/*
	 * Legacy-only realignment: the pool slot is 256-B aligned by
	 * construction (slot_size is ALIGN'd to XPCXD_TX_POOL_SLOT_ALIGN
	 * and the pool base comes from dma_alloc_coherent()), so the
	 * pool path never needs the alloc+memcpy+free realignment dance.
	 */
	if (!use_pool && ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_256 - 1))) {
		struct sk_buff *new_skb;

		/* Alloc new skb */
		new_skb = netdev_alloc_skb(netdev, skb->len + XPCXD_ALIGNMENT_256);
		if (!new_skb) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD TX: Alloc skb: [%p] error skb->len: [%d]",
				ring_id,
				skb,
				skb->len);
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}

		/* Make sure new skb is properly aligned */
		xpcxd_skb_align(new_skb, XPCXD_ALIGNMENT_256);

		/* Copy data to new skb ... */
		skb_copy_from_linear_data(skb, new_skb->data, skb->len);
		skb_put(new_skb, skb->len);

		/* ... and free an old one */
		dev_kfree_skb_any(skb);

		skb = new_skb;

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		/*
		 * Count this realignment. One allocate + linear-copy +
		 * free per occurrence; visible in ethtool as
		 * tx_skb_realigned_256b.
		 */
		batch_realign++;
	}

	ring_space = xpcxd_get_tx_sub_ring_space(txr);

	if (ring_space < ((txr->sub.size / 100) * xpcxd_ring_threshold)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: skb: [%p] Ring space: %d txr->sub.size: %d Ring drain treshold reached:[%d]",
			ring_id,
			skb,
			ring_space,
			txr->sub.size,
			((txr->sub.size / 100) * xpcxd_ring_threshold));
		if (xpcxd_rx_ring_threshold_stop)
			xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Drain treshold");
		tx_ret = NETDEV_TX_OK; // NETDEV_TX_BUSY;
		txr->stats.dropped++;
		txr->stats.tx_sub_threshold++; 		/* Per ring stats */

		goto tx_drop;
	}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
		{
			u64 underflow_cnt = xpcxd_tx_get_underflow_cnt();

			if (prev_tx_underflow_cnt != underflow_cnt) {
				txr->stats.tx_underflow_events++;
				prev_tx_underflow_cnt = underflow_cnt;

				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						"TX UNDERFLOW: [%lld] ", underflow_cnt);				
			}
		}
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

	/* Per-packet state re-init for the current skb. */
	protocol = vlan_get_protocol(skb);
	eth = eth_hdr(skb);
	eth_len = skb_vlan_tag_present(skb) ? VLAN_HLEN : ETH_HLEN;
	l3_offset = 0;
	shim_hdr_size = 0;
	trimmed = false;
	l4_protocol = 0;
	check_l3_checksum = false;
	check_l4_checksum = false;
	num_desc = 0;
	prod_idx = txr->sub.prod;

	/*
	 * Prefetch current and next descriptor/sw_desc lines. Use prefetchw()
	 * for the lines we are about to write (sub.desc[prod_idx],
	 * sub.sw[prod_idx]) so the cache line is brought in M-state and we
	 * skip the read-for-ownership upgrade on the imminent stores.
	 */
	prefetchw(&txr->sub.desc[prod_idx & txr->sub.mask]);
	prefetchw(&txr->sub.sw[prod_idx & txr->sub.mask]);
	prefetchw(&txr->sub.desc[(prod_idx + 2) & txr->sub.mask]);
	prefetchw(&txr->sub.sw[(prod_idx + 2) & txr->sub.mask]);

	sw_desc = &txr->sub.sw[prod_idx & txr->sub.mask];

	if (unlikely(!sw_desc)) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: sw_desc is NULL", ring_id);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	sw_desc->is_xdp = false;
	sw_desc->tx_src = XPCXD_TX_SRC_NONE;
	sw_desc->skb = NULL;

#ifdef __XPCXD_CHECK_TX_ALIGNMENT__
	if ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_64 - 1)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: NOT aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_64, skb->data);
		xprint_hex_dump(netdev, "--- TX DATA NOT ALIGNED ---",
					DUMP_PREFIX_OFFSET, 16, 1, skb->data,
					skb->len, true);
		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpci_print_pkt("TX DATA NOT ALIGNE ", netdev, skb, TX_OFFSET, xpci_tx);
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: SKB Data aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_64, skb->data);
	}

	if ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_256 - 1)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: NOT aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_256, skb->data);
		xprint_hex_dump(netdev, "--- TX DATA NOT ALIGNED ---",
					DUMP_PREFIX_OFFSET, 16, 1, skb->data,
					skb->len, true);
		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpci_print_pkt("TX NOT ALIGNED ", netdev, skb, TX_OFFSET, xpci_tx);
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: SKB Data aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_256, skb->data);
	}
#endif /* __XPCXD_CHECK_TX_ALIGNMENT__ */

	if (use_pool) {
		/*
		 * Pool fast path: skb->data -> pre-mapped slot via memcpy.
		 * Skips dma_map_single() (and its SWIOTLB bounce cost when
		 * applicable) and skips the 256-B/64-B alignment checks below
		 * (slot base is dma_alloc_coherent(); each slot is naturally
		 * slot_size-aligned, and slot_size is ALIGN'd to
		 * XPCXD_TX_POOL_SLOT_ALIGN = 256).
		 *
		 * Pool slot indexing uses the MD's prod_idx (same slot where
		 * sw_desc lives), so consecutive packets don't stomp each
		 * other regardless of XPCXD_NUM_TXD_PER_PKT.
		 */
		u16 pool_idx = prod_idx & txr->sub.mask;
		void *slot_vaddr = (u8 *)txr->tx_pool.vaddr +
				   (size_t)pool_idx * txr->tx_pool.slot_size;

		memcpy(slot_vaddr, skb->data, skb->len);
		dma_addr = txr->tx_pool.daddr +
			   (size_t)pool_idx * txr->tx_pool.slot_size;
		sw_desc->tx_src = XPCXD_TX_SRC_POOL;
	} else {
		dma_addr = xpcxd_dma_map_single(net_priv->hw_dev, skb->data,
						skb->len, DMA_TO_DEVICE);
		if (unlikely(dma_mapping_error(net_priv->hw_dev, dma_addr))) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD TX: DMA Mapping error: [0x%llx]",
				ring_id, dma_addr);
			xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: DMA Mapping error");
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
		sw_desc->tx_src = XPCXD_TX_SRC_MAPPED;
		sw_desc->skb = skb;
	}

	/*
	 * Pool slots are 256-B aligned by construction — skip the legacy
	 * alignment diagnostics for the pool path (the dma_addr we built
	 * is tx_pool.daddr + pool_idx*slot_size, and slot_size is a
	 * multiple of XPCXD_TX_POOL_SLOT_ALIGN=256).
	 */
	if (!use_pool && (dma_addr & (XPCXD_ALIGNMENT_256 - 1))) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: Not %d aligned data skb->data: [%p] len: [%d] DMA address: [0x%llx]",
			ring_id, XPCXD_ALIGNMENT_256, skb->data, skb->len, dma_addr);
		batch_align_err++;
		// xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Not properly aligned DMA address");
		if (xpcxd_tx_drop_on_alignment_err) {
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}

	if (!use_pool && (dma_addr & (XPCXD_ALIGNMENT_64 - 1))) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: Not %d aligned data skb->data: [%p] len: [%d] DMA address: [0x%llx]",
			ring_id, XPCXD_ALIGNMENT_64, skb->data, skb->len, dma_addr);
		batch_align_err++;
		if (xpcxd_tx_drop_on_alignment_err) {
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX: skb: [%p] sw_desc[%p][%d] prod_idx: [%d] protocol: [0x%x]", 
			ring_id, skb, sw_desc, (prod_idx & txr->sub.mask), prod_idx, protocol);

	dma_unmap_addr_set(sw_desc, sw_dma_addr, dma_addr);
	dma_unmap_len_set(sw_desc, dma_len, skb->len);

	if (likely(protocol == htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS))) {
		shim_hdr_size = XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_HDR_SIZE;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN
			"---> [%d] PCXD TX: SHIM before data move: skb: [%p] skb>data[%p] protocol: [0x%x] tx_shim_hdr_size: [%d]" CLR_RST,
			ring_id, skb, skb->data, protocol,
			shim_hdr_size);

		skb_pull(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		trimmed = true;
	} else { 
		if (likely(protocol == htons(XSW_SHIM_HEADER_ETHTYPE_INJECT))) {
			shim_hdr_size = XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_INJECT_HDR_SIZE;

			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN
				"---> [%d] PCXD TX: INJECT SHIM before data move: skb: [%p] skb>data[%p] protocol: [0x%x] tx_shim_hdr_size: [%d]" CLR_RST,
				ring_id, skb, skb->data, protocol,
				shim_hdr_size);

			skb_pull(skb, shim_hdr_size);

			skb_reset_mac_header(skb);
			skb_reset_network_header(skb);
			skb_reset_transport_header(skb);

			eth = eth_hdr(skb);

			trimmed = true;
		} else {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN "---> [%d] PCXD TX: NO SHIM: skb: [%p] skb>data[%p] protocol: [0x%x]" CLR_RST,
				ring_id, skb, skb->data, protocol);

			eth = eth_hdr(skb);
		}
	}

	if (unlikely(eth->h_proto == htons(ETH_P_8021Q))) {
		const struct vlan_ethhdr *veh = vlan_eth_hdr(skb);

		eth_len = VLAN_ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] VLAN: protocol: [0x%x] ---> protocol: [0x%x]" CLR_RST,
			ring_id, skb, protocol, veh->h_vlan_encapsulated_proto);

		protocol = veh->h_vlan_encapsulated_proto;
		l3_offset = shim_hdr_size + VLAN_ETH_HLEN;

		batch_vlan++;
	} else {
		eth_len = ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] ETH: protocol: [0x%x] ---> eth->h_proto: [0x%x]" CLR_RST,
			ring_id, skb, protocol, eth->h_proto);

		protocol = eth->h_proto;

		l3_offset = shim_hdr_size + ETH_HLEN;
	}

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		CLR_YELLOW "---> [%d] PCXD TX: skb: [%p] skb>data[%p] protocol: [0x%x] eth->h_proto: [0x%x]" CLR_RST,
		ring_id, skb, skb->data, htons(protocol), htons(eth->h_proto))

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && 
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-AFTER-TRIM", netdev, skb, 0, xpci_tx);

	/*
	 * Per-packet UC/MC/BC classification
	 */
	if (likely(READ_ONCE(xpcxd_tx_stats_uc_mc_bc))) {
		if (unlikely(protocol == htons(ETH_P_ARP))) {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN "---> [%d] PCXD TX: ARP" CLR_RST, ring_id);
			if (is_broadcast_ether_addr(eth->h_dest))
				batch_bc++;
			else
				batch_uc++;
		}

		if (likely(protocol == htons(ETH_P_IP))) {
			check_l3_checksum = true;
			iph = (struct iphdr *)((u8 *)skb->data + eth_len);

			l4_protocol = iph->protocol;

			if (iph->daddr == htonl(INADDR_BROADCAST))
				batch_bc++;
			if (xpcxd_is_multicast_ipv4(iph->daddr))
				batch_mc++;
			else
				batch_uc++;
		}

		if (likely(protocol == htons(ETH_P_IPV6))) {
			check_l3_checksum = true;
			ip6h = (struct ipv6hdr *)((u8 *)skb->data + eth_len);

			l4_protocol = ip6h->nexthdr;

			if (ipv6_addr_is_multicast(&ip6h->daddr))
				batch_mc++;
			else
				batch_uc++;
		}

		if (likely(l4_protocol == IPPROTO_TCP)) {
			xpcxd_loopback?(check_l4_checksum = false):(check_l4_checksum = true);
		}

		if (likely(l4_protocol == IPPROTO_UDP)) {
			xpcxd_loopback?(check_l4_checksum = false):(check_l4_checksum = true);
		}
	} else {
		/*
		 * Gate off: still need check_l3_checksum to derive l3_offset
		 * for HW L3 csum. Cheap path: detect IPv4/IPv6 by ethertype
		 * only, no per-packet IP header read or UC/MC/BC parse.
		 */
		if (likely(protocol == htons(ETH_P_IP) ||
		           protocol == htons(ETH_P_IPV6)))
			check_l3_checksum = true;
	}

	xpcxd_opt_trace(tx_pkt, ring_id, skb, skb->len, htons(protocol), htons(eth->h_proto));

#ifdef __XPCXD_ICMP_TRACE__
	xpcxd_check_icmp_echo(skb, netdev);
#endif

	/* If packet been trimmed to correctly set layer offsets and protocols then bring it back */
	if (trimmed) {
		eth = eth_hdr(skb);
		skb_push(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);
		if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
			xpci_print_pkt("TX-TRIM-BACK", netdev, skb, TX_OFFSET, xpci_tx);
	}

	/* TX Meta Data handling */

	/* W0 */
	tx_md.md.ctrl_no_cpl = 0; /* 0 - Generate completion per packet */
	/* Hybrid mode */
	/* In TX reflection mode - no need to set interrupt per descriptor */
	tx_md.md.int_en = !xpcxd_tx_cmp_rfl_mode; /* 1 - Generate on packet completion */

	tx_md.md.type = 0; /* 0 - Desciptor type - MD */
	tx_md.md.calc_l3_chks = xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l3_checksum; /* 0 - Don't calculate */
	tx_md.md.calc_l4_chks = xpcxd_cfg_tbl[xpcxd_check_l4_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l4_checksum; /* 0 - Don't calculate */
	tx_md.md.pseudu_hdr_chks_en =
		0; /* 0 - HW calculates pseudo header checksum */
	tx_md.md.l3_offset_en =
		xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
		check_l3_checksum; /* 1 - L3 offset set by W2[L3_OFFSET] | Config taken from register */
	tx_md.md.num_tx_bd = 1; /* Number of buffer descriptors used to assemble the packet */

	/* W1 */
	tx_md.md.pseudu_hdr_chks = 0; /* 0 - HW calculated, 1 - SW provided Pseudo Header checksum */
	tx_md.md.rsrv_10 = 0;
	tx_md.md.rsrv_11 = 0;

	/* W2 */
	tx_md.md.l3_offset = check_l3_checksum?l3_offset:0; /* L3 offset */
	tx_md.md.rsrv_20 = 0;
	tx_md.md.rsrv_21 = 0;

	/* W3 */
	tx_md.md.opaque_0 = prod_idx;

	/* TX Buffer Data handling */

	/* W0 */
	tx_bd.tx_bd.type = 1; /* 1 - Desciptor type - BD */
	/* W1 */
	tx_bd.tx_bd.len = skb->len;
	/* W2 */
	tx_bd.tx_bd.src_buf_addr_lsb = ((u64)dma_addr & 0x00000000FFFFFFFF);
	/* W3 */
	tx_bd.tx_bd.src_buf_addr_msb = ((u64)dma_addr & 0xFFFFFFFF00000000) >> 32;

	/* write metadata descriptor 0 */
	txr->sub.desc[prod_idx].w64[0] = tx_md.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_md.w64[1];

	prod_idx++;
	num_desc++;

	txr->sub.desc[prod_idx].w64[0] = tx_bd.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_bd.w64[1];

	prod_idx++;
	num_desc++;

	if (prod_idx >= net_priv->num_tx_desc)
		prod_idx = 0;

	if (prod_idx >= net_priv->num_tx_desc)
		prod_idx = 0;

	txr->sub.prod = prod_idx;

	/* Accumulate locally; committed once at end of xpcxd_xmit(). */
	batch_pkts++;
	batch_bytes += skb->len;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	if (skb->len < 128)
		batch_sz64_128++;
	else if (skb->len < 256)
		batch_sz128_256++;
	else
		batch_sz256_plus++;
#endif

	total_desc_batch += num_desc;

	/* Cached for the TX-END print + tx_db_defer trace after we drop
	 * our skb reference on the pool fast path (skb dangles otherwise).
	 */
	last_skb_len = skb->len;

	/*
	 * Pool fast path: payload is already in the pre-mapped slot and
	 * the descriptor has been published. CMPL reclaims the slot with
	 * only stats accounting (XPCXD_TX_SRC_POOL), so we can return
	 * the skb to the allocator right here and not pay the skb cache
	 * line cost on the completion CPU.
	 *
	 * sw_desc->skb is intentionally left NULL on the pool path (CMPL
	 * does not own an skb for XPCXD_TX_SRC_POOL). NULL out the local
	 * skb so TX-END print / tx_db_defer trace use last_skb_len instead
	 * of dereferencing a freed skb.
	 */
	if (use_pool) {
		dev_consume_skb_any(skb);
		skb = NULL;
	}

	/*
	 * Policy: do not ring the doorbell while more packets are waiting in
	 * the Tx queue. Defer the DB and carry the descriptor count across
	 * xpcxd_xmit() calls when the stack signals more is coming
	 * (netdev_xmit_more()). We MUST flush anyway if:
	 *  - the stack is done batching (xmit_more false), or
	 *  - ring free space is near XPCXD_TX_STOP_THOLD - don't strand HW
	 *    waiting for a DB that might never come.
	 */
	txr->sub_desc_pending += total_desc_batch;

	if (!netdev_xmit_more() ||
	    xpcxd_get_tx_sub_ring_space(txr) < XPCXD_TX_STOP_THOLD) {
		xpcxd_tx_db_flush_locked(netdev, txr);
	} else {
		/*
		 * Deferred DB: stack promised more via xmit_more. Descriptors are
		 * already published (sub.prod advanced); a later xpcxd_xmit() call
		 * (or the
		 * coalescing ISR) will flush the accumulated DB.
		 *
		 * Note: skb may be NULL here (pool fast path consumed it above).
		 * Tracepoint accepts NULL; we pass the cached last_skb_len so the
		 * event still carries a useful length field.
		 */
		xpcxd_opt_trace(tx_db_defer, ring_id, skb, last_skb_len,
				txr->sub_desc_pending, total_desc_batch);
	}

	/*
	 * Commit batched stats once per xpcxd_xmit() call. Under tx_lock so
	 * the writes are serialized with xpcxd_xmit() readers; the CMPL CPU
	 * touches a different stats sub-line (see xpcxd_stats layout note).
	 */
	if (batch_pkts) {
		txr->stats.packets            += batch_pkts;
		txr->stats.bytes              += batch_bytes;
		if (batch_uc)
			txr->stats.tx_unicast         += batch_uc;
		if (batch_mc)
			txr->stats.tx_multicast       += batch_mc;
		if (batch_bc)
			txr->stats.tx_broadcast       += batch_bc;
		if (batch_vlan)
			txr->stats.tx_vlan_packets    += batch_vlan;
		if (batch_align_err)
			txr->stats.tx_alignment_error += batch_align_err;
		if (batch_realign)
			txr->stats.tx_skb_realigned_256b   += batch_realign;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
		if (batch_sz64_128)
			txr->stats.tx_pkt_size_64_128  += batch_sz64_128;
		if (batch_sz128_256)
			txr->stats.tx_pkt_size_128_256 += batch_sz128_256;
		if (batch_sz256_plus)
			txr->stats.tx_pkt_size_256_plus += batch_sz256_plus;
#endif
		batch_pkts = 0;
		batch_bytes = 0;
		batch_uc = batch_mc = batch_bc = 0;
		batch_vlan = 0;
		batch_align_err = 0;
		batch_realign = 0;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
		batch_sz64_128 = batch_sz128_256 = batch_sz256_plus = 0;
#endif
	}

	/*
	 * skb may be NULL here if the last iteration took the pool fast
	 * path. The TX-END dump is diagnostic only; skip it when we no
	 * longer own the skb.
	 */
	if (skb && unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
			    (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-END", netdev, skb, TX_OFFSET, xpci_tx);

	if (xpcxd_tx_packets_stop) {
		/*
		 * Debug-only fault injection trigger. skb may be NULL if the
		 * last iteration used the pool fast path; pass NULL through
		 * the printk / set_error helpers, they tolerate it.
		 */
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: skb: [%p] Tx stop triggered: [%llu]",
			ring_id, skb, (unsigned long long)txr->stats.packets);
		xpcxd_set_error(netdev, skb, xpci_tx, 0x1 /*g_cnt_tx_stop*/,
				"TX ERROR: Tx stop");
		tx_ret = NET_XMIT_DROP; // NETDEV_TX_BUSY;
		goto tx_drop;
	}

	spin_unlock(&net_priv->txr[ring_id].tx_lock);

	return tx_ret;

tx_drop:

	/*
	 * Commit any stats accumulated for packets successfully enqueued
	 * earlier in this call before the drop, flush the pending DB (so
	 * mid-batch drops don't strand published descriptors), then unlock.
	 */
	if (spin_is_locked(&net_priv->txr[ring_id].tx_lock)) {
		if (batch_pkts) {
			txr->stats.packets            += batch_pkts;
			txr->stats.bytes              += batch_bytes;
			if (batch_uc)
				txr->stats.tx_unicast         += batch_uc;
			if (batch_mc)
				txr->stats.tx_multicast       += batch_mc;
			if (batch_bc)
				txr->stats.tx_broadcast       += batch_bc;
			if (batch_vlan)
				txr->stats.tx_vlan_packets    += batch_vlan;
			if (batch_align_err)
				txr->stats.tx_alignment_error += batch_align_err;
			if (batch_realign)
				txr->stats.tx_skb_realigned_256b   += batch_realign;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
			if (batch_sz64_128)
				txr->stats.tx_pkt_size_64_128  += batch_sz64_128;
			if (batch_sz128_256)
				txr->stats.tx_pkt_size_128_256 += batch_sz128_256;
			if (batch_sz256_plus)
				txr->stats.tx_pkt_size_256_plus += batch_sz256_plus;
#endif
		}
		xpcxd_tx_db_flush_locked(netdev, &net_priv->txr[ring_id]);
		spin_unlock(&net_priv->txr[ring_id].tx_lock);
	}

	xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev, "---> [%d] PCXD TX: skb: [%p] ERROR", ring_id, skb);
	dev_kfree_skb_any(skb);
	txr->stats.errors++;

	return tx_ret;
}
EXPORT_SYMBOL(xpcxd_xmit);

#if IS_ENABLED(CONFIG_BPF_SYSCALL)
/**
 * xpcxd_xdp_xmit_frame - Enqueue one XDP frame on a Tx ring (caller must not hold tx_lock).
 *
 * Descriptors are published to the ring but the doorbell is NOT written here;
 * instead the per-frame contribution is accumulated into txr->sub_desc_pending
 * and the caller (xpcxd_xdp_xmit) flushes a single DB per ring touched on
 * XDP_XMIT_FLUSH.
 *
 * Returns 0 on success, -ENOSPC if ring full, -EIO on DMA error.
 */
int xpcxd_xdp_xmit_frame(struct net_device *netdev, u32 ring_id, struct xdp_frame *frame)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr;
	struct xpcxd_sw_desc *sw_desc;
	struct xpcxd_desc tx_md = { 0 };
	struct xpcxd_desc tx_bd = { 0 };
	u16 prod_idx;
	u16 num_desc = 1;
	u16 ring_space;
	dma_addr_t dma_addr;

	if (ring_id >= net_priv->num_rings)
		return -EINVAL;

	txr = &net_priv->txr[ring_id];
	spin_lock(&txr->tx_lock);

	ring_space = xpcxd_get_tx_sub_ring_space(txr);
	if (ring_space < 1) {
		spin_unlock(&txr->tx_lock);
		return -ENOSPC;
	}

	prod_idx = txr->sub.prod;
	sw_desc = &txr->sub.sw[prod_idx & txr->sub.mask];

	dma_addr = xpcxd_dma_map_single(net_priv->hw_dev, frame->data, frame->len, DMA_TO_DEVICE);
	if (dma_mapping_error(net_priv->hw_dev, dma_addr)) {
		spin_unlock(&txr->tx_lock);
		return -EIO;
	}

	/* Minimal TX MD: no checksum, one BD */
	tx_md.md.ctrl_no_cpl = 0;
	tx_md.md.int_en = !xpcxd_tx_cmp_rfl_mode;
	tx_md.md.type = 0;
	tx_md.md.calc_l3_chks = 0;
	tx_md.md.calc_l4_chks = 0;
	tx_md.md.pseudu_hdr_chks_en = 0;
	tx_md.md.l3_offset_en = 0;
	tx_md.md.num_tx_bd = 1;
	tx_md.md.opaque_0 = prod_idx;

	tx_bd.tx_bd.type = 1;
	tx_bd.tx_bd.len = frame->len;
	tx_bd.tx_bd.src_buf_addr_lsb = (u32)((u64)dma_addr & 0xFFFFFFFF);
	tx_bd.tx_bd.src_buf_addr_msb = (u32)((u64)dma_addr >> 32);

	txr->sub.desc[prod_idx].w64[0] = tx_md.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_md.w64[1];
	prod_idx++;
	num_desc++;

	txr->sub.desc[prod_idx & txr->sub.mask].w64[0] = tx_bd.w64[0];
	txr->sub.desc[prod_idx & txr->sub.mask].w64[1] = tx_bd.w64[1];
	prod_idx++;
	if (prod_idx >= net_priv->num_tx_desc)
		prod_idx = 0;

	txr->sub.prod = prod_idx;

	sw_desc->is_xdp = true;
	sw_desc->xdpf = frame;
	sw_desc->skb = NULL;
	/*
	 * XDP redirect frames always use the legacy dma_map_single() path
	 * (no pool integration for XDP yet — the frame pages come from a
	 * different page_pool); CMPL uses tx_src to pick the correct
	 * reclaim (dma_unmap_single + xdp_return_frame).
	 */
	sw_desc->tx_src = XPCXD_TX_SRC_XDP;
	dma_unmap_addr_set(sw_desc, sw_dma_addr, dma_addr);
	dma_unmap_len_set(sw_desc, dma_len, frame->len);

	txr->stats.tx_xdp_packets++;
	txr->stats.tx_xdp_bytes += frame->len;
	xpcxd_pkt_stats_inc(txr, frame->len);

	txr->sub_desc_pending += num_desc;

	spin_unlock(&txr->tx_lock);
	return 0;
}
EXPORT_SYMBOL(xpcxd_xdp_xmit_frame);

/**
 * ndo_xdp_xmit - Transmit frames received via XDP redirect (per-Tx-ring).
 * Tries to transmit as many frames as possible: for each frame, try rings in
 * round-robin order until one has space, so multiple packets can transit when
 * rings are available. The doorbell for each ring that accepted at least one
 * frame is written once, on XDP_XMIT_FLUSH, so we emit a single MMIO per
 * ring per flush regardless of how many frames went through it.
 */
int xpcxd_xdp_xmit(struct net_device *netdev, int n, struct xdp_frame **frames, u32 flags)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int i;
	int r;
	int nxmit = 0;
	u32 ring_id;

	if (!net_priv->num_rings)
		return -ENXIO;

	for (i = 0; i < n; i++) {
		/* Try each ring (round-robin) until one accepts the frame */
		for (r = 0; r < net_priv->num_rings; r++) {
			ring_id = (u32)(i + r) % net_priv->num_rings;
			if (xpcxd_xdp_xmit_frame(netdev, ring_id, frames[i]) == 0) {
				nxmit++;
				break;
			}
		}
	}

	/*
	 * ndo_xdp_xmit contract: when XDP_XMIT_FLUSH is set, descriptors must
	 * be visible to HW before we return. Walk all rings and flush any
	 * pending DB we accumulated above. xpcxd_tx_db_flush_locked() is a
	 * no-op for rings we didn't touch (sub_desc_pending == 0).
	 */
	if (flags & XDP_XMIT_FLUSH) {
		u32 rid;

		for (rid = 0; rid < net_priv->num_rings; rid++) {
			struct xpcxd_ring *txr = &net_priv->txr[rid];

			spin_lock(&txr->tx_lock);
			xpcxd_tx_db_flush_locked(netdev, txr);
			spin_unlock(&txr->tx_lock);
		}
	}

	return nxmit;
}
EXPORT_SYMBOL(xpcxd_xdp_xmit);
#endif /* IS_ENABLED(CONFIG_BPF_SYSCALL) */
