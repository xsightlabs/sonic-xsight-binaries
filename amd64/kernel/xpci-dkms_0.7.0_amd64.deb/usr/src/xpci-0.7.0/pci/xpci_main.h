// SPDX-License-Identifier: GPL-2.0

/*
 * X Device PCIe driver definitions
 *
 * Copyright (c) 2019-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_MAIN_H_
#define XPCI_MAIN_H_

#include <linux/cdev.h>
#include <linux/irq.h>
#include "xpci_dbg.h"

/**
 *  XPCI MSIX definitions
 *
 */

/* Number of GIC supported in Arava - 16 */
/* Number of GIC supported in Alon  - 64 */
#define XPCI_MSIX_VECTORS 64

#define XPCI_INTR_ID0 0

/**
 *  XPCI Ioctl definitions
 *
 */

#define XPCI_IOCTL_MAGIC 0x3A

#define XPCI_WRITE_REG 0x01
#define XPCI_READ_REG 0x02
#define XPCI_CFG_REG 0x03
#define XPCI_DMA_ALLOC 0x04
#define XPCI_DMA_FREE 0x05
#define XPCI_HW_IRQ_SUPPORT 0x06
#define XPCI_ENABLE_MSIX 0x08
#define XPCI_DISABLE_MSIX 0x09
#define XPCI_IRQ_MAP_SIZE NR_IRQS

/**
 *  IRQ table entry
 *
 */
struct xdev_irq_tbl {
	bool allocated;
	char name[32];
	u32 irq;
};

/**
 *  Structure to link a pci_dev to a cdev
 *
 */
struct xdev {
	int minor;
	struct pci_dev *pdev;

	bool dev_probe; /* Probe callback called */
	bool dev_open; /* Device opened */
	bool dev_int_register; /* Interrupt handler registered */

	struct mutex fd_open_cnt_lock;
	atomic_t fd_open_cnt;

	u16 id; /* idr id */

	struct cdev cdev;
	u32 major;

	/* MSI-X */
	u8 num_vec;
	struct xdev_irq_tbl irq_tbl[XPCI_MSIX_VECTORS];
	/* Maps between system vector number and internal number */
	char irq_map[XPCI_IRQ_MAP_SIZE];
	/* DMA */
	u8 *dma_block_v;
	u8 *dma_block_p;
	int dma_block_size;
};

/**
 *  Structure file private_data
 *
 */
struct xpci_fprv {
	struct xdev *pxdev;
	struct file *filp;
	struct pid *taskpid;
};

/**
 *  ASIC Configuration Read/Write
 *
 */
struct xcfg {
	u32 data;
	u64 res;
};

/**
 *  ASIC Configuration Read/Write
 *
 */
struct xcmd {
	u32 value;
};

long xpci_ioctl(struct file *file, unsigned int cmd, unsigned long arg);

bool xpci_is_probed(void);

int xpci_device_setup_cdev(struct xdev *pxdev, struct class *xpci_class,
			   int minor, const struct file_operations *fops);

int xpci_get_pci_base_addr0(void);
int xpci_get_pci_base_addr2(void);
int xpci_get_hw_irq_mode(void);

#endif /* XPCI_MAIN_H_ */
