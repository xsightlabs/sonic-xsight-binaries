// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI driver IRQ definitions
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_INT_H_
#define XPCI_INT_H_

#include "linux/interrupt.h"
#include "xpci_main.h"

/* ************* X Device definitions */

#define XPCI_X_PORT_STATUS_CHANGE_INT 0 /* X Port status change interrupt */
#define XPCI_X_ECC_INT                1 /* X ECC Interrupt (not in use yet) */
#define XPCI_X_PCIe_CAPABILITIES      8 /* X PCIe capabilities interrupt (not in use yet) */
#define XPCI_X_MAX_INTERRUPTS         16 /* Max SDK (legacy) interrupts: 0..15 */

/* ************* X2 Device definitions */

#define XPCI_X2_RX_CMP_INT_MIN         16
#define XPCI_X2_RX_CMP_INT_MAX         23

#define XPCI_X2_TX_CMP_INT_MIN         24
#define XPCI_X2_TX_CMP_INT_MAX         31

#define XPCI_X2_RX_ERR_INT             32
#define XPCI_X2_TX_ERR_INT             33

#define XPCI_X2_PCXD_INT_FIRST         XPCI_X_MAX_INTERRUPTS
#define XPCI_X2_PCXD_INT_MAX           XPCI_X2_TX_ERR_INT

/* xpci interrupts context structure */
typedef struct {
	struct work_struct work;
	void *data;
	int vec;
} xpci_irq_ctx_t;

unsigned char xpci_get_irq(struct pci_dev *pdev);
int xpci_register_interrupt(struct xdev *pxdev, int vec_num, char *irq_name, irq_handler_t irq_h);
int xpci_unregister_interrupt(struct xdev *pxdev, int vec_num);
int xpci_register_x_interrupts(struct xdev *pxdev, u16 num_ints);
int xpci_unregister_interrupts(struct xdev *pxdev);
int xpci_enable_interrupt(struct xdev *pxdev, int irq_num);
int xpci_disable_interrupt(struct xdev *pxdev, int irq_num);
void xpci_enable_msix_interrupt(struct xdev *pxdev, int irq_num);
void xpci_disable_msix_interrupt(struct xdev *pxdev, int irq_num);
irqreturn_t xpci_handle_interrupt(int irq, void *xpci_irq);

#endif /* XPCI_INT_H_ */
