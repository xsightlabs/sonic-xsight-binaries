// SPDX-License-Identifier: GPL-2.0

/*
 * X Device PCIe (XPCI) driver main
 *
 * Copyright (c) 2019-present Xsight Labs Inc.
 *
 */

#include <linux/err.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/aer.h>

#include "xpci_version.h"
#include "xpci_common.h"
#include "xpci_irq.h"
#include "netdev/xnetdev.h"
#include "pcxd/xpcxd.h"
#include "xpci_main.h"

#define XPCI_DRIVER_NAME "XPCI"

#ifndef KERNEL_VERSION
#define KERNEL_VERSION(a, b, c) ((a)*65536 + (b)*256 + (c))
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 8, 0)
#error Incompatible Linux kernel version. Need to be >= 4.8
#endif

#define MAX_DEVICE 8
#define DEVICE_NAME "xpci"
#define BAR_MEM 0

int xpci_debug_level = XPCI_DBG_LEVEL__ERR;
module_param_named(debug_level, xpci_debug_level, uint, 0644);
MODULE_PARM_DESC(
	debug_level,
	"mask: 1 = errors, 2 = notice, 3 = info, 4 = debug, 5 = debug + registers read/write, 0 = none. Default = 2");

static int xpci_pci_mode = 1;
module_param_named(pci_mode, xpci_pci_mode, uint, 0644);
MODULE_PARM_DESC(
	pci_mode,
	"mask: 0 = No PCI Driver Init/Enumeration, 1 = PCI Driver Enabled. Default = 1");

static int xnetdev_mode = 0;
static bool xnetdev_init_done = false;
module_param_named(netdev_mode, xnetdev_mode, uint, 0644);
MODULE_PARM_DESC(
	netdev_mode,
	"mask: 0 = No NetDev Driver Init/Rx/Tx, 1 = NetDev Driver Enabled. Default = 0");

static int xpci_hw_irq_mode = 1;
module_param_named(hw_irq_mode, xpci_hw_irq_mode, uint, 0644);
MODULE_PARM_DESC(
	hw_irq_mode,
	"mask: 0 = HW IRQ support Disabled, 1 = HW IRQ support Enabled. Default = 1");

static int xpcxd_mode = 1;
static bool xpcxd_init_done = false;
module_param_named(pcxd_mode, xpcxd_mode, uint, 0644);
MODULE_PARM_DESC(
	pcxd_mode,
	"mask: 0 = Packet Over PCI (PCXD) support Disabled, 1 = Packet Over PCI (PCXD) support Enabled. Default = 1");

static int xpcxd_sw_only_mode = 0;
module_param_named(pcxd_sw_only_mode, xpcxd_sw_only_mode, uint, 0644);
MODULE_PARM_DESC(
	pcxd_sw_only_mode,
	"mask: 0 = PCXD SW Only mode Disabled, 1 = SW Only mode Enabled. Default = 0");

static int xpci_reg_access_default = 1;
module_param_named(reg_access_default, xpci_reg_access_default, uint, 0644);
MODULE_PARM_DESC(
	xpci_reg_access_default,
	"mask: 1 = Register access (read/write) enabled, 0 = Register Access disabled. Default = 1");

static int pci_base_addr_0 = 0;	/* Memory */
static int pci_base_addr_2 = 0;	/* I/O */

/* Registered PCI vendor ID                       */
/* https://pcisig.com/membership/member-companies */
#define PCI_VENDOR_ID_XSIGHTLABS 0x1E6C
#define PCI_DEVICE_ID_X2_ALON 0x0002

static struct pci_device_id xpci_id_table[] = {
	{
		PCI_DEVICE(PCI_VENDOR_ID_XSIGHTLABS, PCI_DEVICE_ID_X2_ALON),
	},
	{
		0,
	}
};
MODULE_DEVICE_TABLE(pci, xpci_id_table);

static size_t mem_len = 0;

#define MAJOR_NUM 100
#define BUF_LEN 80

static DEFINE_IDR(xpci_idr);
static DEFINE_MUTEX(xpci_idr_lock);

static dev_t devno = 0;
static int major = 0;

static struct class *xclass = NULL;

static bool class_created = false;
static bool device_created = false;

static int xpci_open(struct inode *inode, struct file *file);
static int xpci_release(struct inode *inode, struct file *file);
static int xpci_dma_mmap(struct file *filp, struct vm_area_struct *vma);

extern int xpcxd_pci_relaxed_ordering;

/**
 * PCI node info
 */
static const struct file_operations xpci_ops = {
	.owner = THIS_MODULE,
	.open = xpci_open,
	.release = xpci_release,
	.unlocked_ioctl = xpci_ioctl,
	.mmap = xpci_dma_mmap
};

static const struct vm_operations_struct xpci_vmem_ops = {

};

int xpci_get_pci_base_addr0(void)
{
	return pci_base_addr_0;
}

int xpci_get_pci_base_addr2(void)
{
	return pci_base_addr_2;
}

int xpci_get_hw_irq_mode(void)
{
	return xpci_hw_irq_mode;
}

/**
 * Device create callback
 */
static char *xpci_devnode(struct device *dev, umode_t *mode)
{
 	if (mode)
 		*mode = 0666;
 	return kasprintf(GFP_KERNEL, "%s", dev_name(dev));
}

/**
 * Device create (/dev/xpci)
 */
static int xpci_device_init(void)
{
	struct device *dev = NULL;

	/* get major number and save it in major */
	devno = MKDEV(MAJOR_NUM, 0);

	xclass = class_create(THIS_MODULE, DEVICE_NAME);
	if (IS_ERR(xclass)) {
		xpci_err("Failed to create class %s", DEVICE_NAME);
		return -1;
	}
	xpci_info("class_create(%s): DONE", DEVICE_NAME);

	xclass->devnode = xpci_devnode;
	device_created = true;

	dev = device_create(xclass, NULL, devno, NULL, "%s", DEVICE_NAME);
	if (IS_ERR(dev)) {
		xpci_err("Failed to create device %s", DEVICE_NAME);
		class_destroy(xclass);
		return -2;
	}
	class_created = true;

	xpci_info("device_create(): DONE");

	return 0;
}

/**
 * Device close (/dev/xpci)
 */
static int xpci_device_close(void)
{
	if (device_created) {
		xpci_dbg("device_destroy()");
		device_destroy(xclass, MKDEV(MAJOR_NUM, 0));
		device_created = false;
	}

	if (class_created) {
		xpci_dbg("class_destroy()");
		class_destroy(xclass);
		class_created = false;
	}

	return 0;
}

/**
 * This function is called when the device node is opened
 *
 */
static int xpci_open(struct inode *inode, struct file *file)
{
	struct xdev *pxdev = NULL;
	struct xpci_fprv *xpci_prv = NULL;
	int rc;

	mutex_lock(&xpci_idr_lock);
	pxdev = idr_find(&xpci_idr, iminor(inode));
	mutex_unlock(&xpci_idr_lock);

	if (!pxdev) {
		xpci_err("XPCI device not found. pxdev == NULL");
		return -EFAULT;
	}

	xpci_dbg_dev(&pxdev->pdev->dev, "OPEN: IN (%p) pxdev: %p", file, pxdev);

	if (!pxdev->dev_probe) {
		xpci_err("No probe for this device");
		return -ENODEV;
	}

	atomic_inc(&pxdev->fd_open_cnt);

	xpci_prv = kzalloc(sizeof(*xpci_prv), GFP_KERNEL);
	if (!xpci_prv) {
		xpci_err("Failed to allocate pxci_fprv");
		rc = -ENOMEM;
		goto close_device;
	}

	file->private_data = (void *)xpci_prv;
	xpci_prv->pxdev = pxdev;

	/* These manipulate the module usage count, to protect against removal */
	/* a module also can't be removed if another module uses one of its exported */
	/* symbols */
	try_module_get(THIS_MODULE);

	pxdev->dev_open = 1;

	xpci_dbg_dev(&pxdev->pdev->dev, "OPEN: OUT (%p)", file)

		return 0;

close_device:
	atomic_dec(&pxdev->fd_open_cnt);

	xpci_err_dev(&pxdev->pdev->dev, "OPEN: OUT (%p)", file)

	return rc;
}

/**
 * Device node close
 */
static int xpci_release(struct inode *inode, struct file *file)
{
	struct xpci_fprv *xprv = file->private_data;
	struct xdev *pxdev = xprv->pxdev;

	if (!pxdev) {
		xpci_err("failed. pxdev == NULL. Couldn't find xpci device");
		return -EFAULT;
	}

	xpci_dbg_dev(&pxdev->pdev->dev, "RELEASE: IN (%p)", file);

	kfree(xprv);

	module_put(THIS_MODULE);

	atomic_dec(&pxdev->fd_open_cnt);
	pxdev->dev_open = 0;

	xpci_dbg("RELEASE: OUT (%p)", file);

	return 0;
}

static int xpci_dma_mmap(struct file *file, struct vm_area_struct *vma)
{
	struct xpci_fprv *xprv = file->private_data;
	struct xdev *pxdev = xprv->pxdev;
	struct device *dev = NULL;
	size_t size = vma->vm_end - vma->vm_start;
	int ret = 0;

	xpci_dbg("IN");

	if (!pxdev) {
		xpci_err("XPCI device not found. pxdev == NULL");
		return -EFAULT;
	}

	if (!pxdev->dev_probe) {
		xpci_err("No probe for this device");
		return -ENODEV;
	}

	vma->vm_ops = &xpci_vmem_ops;
	vma->vm_flags |= VM_IO | VM_PFNMAP | VM_DONTEXPAND | VM_DONTDUMP;

	dev = &pxdev->pdev->dev;

	vma->vm_pgoff = virt_to_phys((void *)pxdev->dma_block_v) >> PAGE_SHIFT;
	xpci_dbg_dev(dev, "DMA block: %p size: %d PG Off: 0x%lx",
		     pxdev->dma_block_v, (uint)size, vma->vm_pgoff);
	vma->vm_private_data = file->private_data;

	/* Remark Kernel memory to User Space */
	/* Remap-pfn-range will mark the range VM_IO */
	/* vma - user vma to map
           vma->vm_start - target user address to start at
           vma->vm_pgoff - physical address of kernel memory
           size - size of map area
           vma->vm_page_prot - page protection flags for this mapping
        */
	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
	if (remap_pfn_range(vma, vma->vm_start, vma->vm_pgoff, size,
			    vma->vm_page_prot)) {
		return -EAGAIN;
	}

	xpci_dbg_dev(dev, "VMA Open. Virt_addr: 0x%lx, phy_addr: 0x%lx",
			vma->vm_start, vma->vm_pgoff << PAGE_SHIFT);

	xpci_dbg_dev(dev, "OUT");

	return ret;
}

static int xpci_probe(struct pci_dev *pdev, const struct pci_device_id *id)
{
	struct device *dev = &pdev->dev;
	struct xdev *pxdev = NULL;
	u64 pci_io_addr = 0;
	u64 reg_mem_base = 0;
	u16 num_pci_ints = 0;
	int rc = 0;

	xpci_dbg_dev(dev, "IN");

	switch (id->device) {
		case PCI_DEVICE_ID_X2_ALON:
			xpci_dbg_dev(dev, "Device is: PCI_DEVICE_ID_X2_ALON");
			num_pci_ints = XPCI_X_MAX_INTERRUPTS;
			break;
		default:
			xpci_err_dev(dev, "Unknown or unsupported device id: [%d]", id->device);
			return -ENXIO;
	}

	pxdev = devm_kzalloc(dev, sizeof(struct xdev), GFP_KERNEL);
	if (!pxdev)
		return -ENOMEM;

	pci_set_drvdata(pdev, pxdev);

	/* add this pci device in xpci_cdev */
	pxdev->pdev = pdev;

	xpci_info_dev(dev, "Probe(1): found");

	rc = xpci_device_init();
	if (rc < 0) {
		xpci_err("Can't init device");
		devm_kfree(dev, pxdev);
		rc = -ENXIO;
		goto out;
	}

	/* compute major/minor number */
	devno = MKDEV(major, pxdev->minor);

	xpci_info_dev(dev, "Probe: devno %d major(%d) minor(%d) pxdev: %p",
			devno, major, pxdev->minor, pxdev);

	mutex_lock(&xpci_idr_lock);
	rc = idr_alloc(&xpci_idr, pxdev, 0, MAX_DEVICE, GFP_KERNEL);
	mutex_unlock(&xpci_idr_lock);
	if (rc < 0) {
		xpci_err_dev(dev, "can't alloc new IDR device");
		rc = -ENODEV;
		goto out;
	}

	pxdev->id = rc;

	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0,
					&pci_base_addr_0);
	xpci_info_dev(dev, "PCI_BASE_ADDRESS_0: 0x%x", pci_base_addr_0);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_2,
					&pci_base_addr_2);

	rc = pci_enable_pcie_error_reporting(pdev);
	if (rc) {
		xpci_notice_dev(dev, "PCIe AER capability disabled");
	}
	//else { /* Cleanup nonfatal error status before getting to init */
	//	pci_aer_clear_nonfatal_status(pdev);
	//}

	/* ------ Enable PCI Device ------ */
	if (pci_enable_device(pdev)) {
		xpci_err_dev(dev, "can't enable PCI device");
		rc = -ENODEV;
		goto out;
	}

	pci_set_master(pdev);

	if (xpcxd_pci_relaxed_ordering)
		pcie_capability_set_word(pdev, PCI_EXP_DEVCTL, PCI_EXP_DEVCTL_RELAX_EN);
	//pcie_capability_clear_and_set_word(pdev, PCI_EXP_DEVCTL, PCI_EXP_DEVCTL_RELAX_EN, xpcxd_pci_relaxed_ordering);

	/* ------ Request MMIO/IOP Resources ------ */
	xpci_info_dev(dev, "Probe(6): pci_request_region() BAR_MEM :%d",
			BAR_MEM);
	if (pci_request_region(pdev, BAR_MEM, "xpci-mem")) {
		xpci_err_dev(dev, "Can't request BAR_MEM: 0x%x", BAR_MEM);
		goto out_disable;
	}

	/* Check that BAR_MEM is *really* MEM region */
	if ((pci_resource_flags(pdev, BAR_MEM) & IORESOURCE_MEM) !=
	    IORESOURCE_MEM) {
		xpci_err_dev(dev, "pci_resource_flags() != IORESOURCE_MEM");
		goto out_release;
	} else {
		xpci_dbg_dev(&(pdev->dev),
			     "pci_resource_flags() IORESOURCE_MEM: OK");
	}

	/* check that BAR_MEM is non-cacheble */
	if ((pci_resource_flags(pdev, BAR_MEM) & IORESOURCE_CACHEABLE) ==
	    IORESOURCE_CACHEABLE) {
		xpci_err_dev(
			dev,
			"pci_resource_flags() check return IORESOURCE_CACHEABLE. "
			"Must be non-cacheable...");
		goto out_release;
	}

	/* Get PCI IO Address per BAR */
	pci_io_addr = pci_resource_start(pdev, BAR_MEM);

	/* Get BAR size */
	mem_len = pci_resource_len(pdev, BAR_MEM);

	/* ------ IOMAP ------ */
	/* The correct way to work described here: https://lwn.net/Articles/178084/ */
	reg_mem_base = (unsigned long)pci_iomap(pdev, BAR_MEM, mem_len);
	if (!reg_mem_base) /* If failed - fallback to BAR 0 */
		reg_mem_base = (unsigned long)pci_iomap(pdev, BAR_MEM, mem_len);
	if (!reg_mem_base) {
		rc = -ENOMEM;
		goto out_release;
	}

	xpci_info_dev(
		dev,
		"PCI IO base: [0x%llx] ---> Reg Mem Base: [0x%llx] Len: %d",
		pci_io_addr, reg_mem_base, (int)mem_len);

	xpci_set_reg_mem_base(reg_mem_base);

	/* TODO: Check the exact device revision */
	/* xpci_get_revision(pdev); */

	/* Check intterupt line number: "The interrupt number is stored in
	 * configuration register 60 (PCI_INTERRUPT_LINE)" */
	xpci_get_irq(pdev);

	if (xpci_hw_irq_mode) {
		/* ------ Register IRQ handlers ------ */
		rc = xpci_register_x_interrupts(pxdev, num_pci_ints);
		if (rc)
			goto out_release;

		pxdev->dev_int_register = 1;
	}
	pxdev->dev_probe = 1;

	if (!xpci_reg_access_default)
		xpci_err_dev(dev, "Registers access is DISABLED");

	xpci_register_access(xpci_reg_access_default);

	/* ------------------------------ PCXD initialization place ------------------------ */

	if (xpcxd_mode) {
		rc = xpcxd_init(pxdev);
		if (rc) {
			xpci_err("xpcxd init %d", rc);
			goto out_release;
		}
		xpcxd_init_done = true;
	}
	/* ------------------------------------------------------------------------------------ */

	/* ------------------------------ Net Dev initialization place ------------------------ */
	/* xnetdev_init() should be called here when NetDev only mode is deprecated             */
	/* Till that NetDev only mode is used in XBM / No PCI simulation                        */
	/* ------------------------------------------------------------------------------------ */

	xpci_dbg_dev(dev, "Probe(FIN): probe() DONE");

	return 0;

// out_unregister:
//    xpci_unregister_interrupts(pxdev);
out_release:
	xpci_err_dev(
		dev,
		"0: XPCI probe() failed. rc: %d", rc);

	if (pxdev)
		devm_kfree(dev, pxdev);

	mutex_lock(&xpci_idr_lock);
	idr_remove(&xpci_idr, pxdev->id);
	mutex_unlock(&xpci_idr_lock);

	xpci_dbg_dev(dev, "pci_release_region() ...");
	pci_release_regions(pdev);
out_disable:
	xpci_err_dev(
		dev,
		"1: XPCI probe() failed. rc: %d", rc);

	pci_disable_pcie_error_reporting(pdev);

	xpci_dbg_dev(dev, "pci_disable_device() ...");
	pci_disable_device(pdev);

	xpci_dbg("xpci_device_close");
	xpci_device_close();

out:
	return rc;
}

static void xpci_remove(struct pci_dev *pdev)
{
	struct xdev *pxdev = pci_get_drvdata(pdev);

	xpci_dbg_dev(&pdev->dev, "IN");

	if (!pxdev)
		return;

	if (!pxdev->dev_probe) {
		xpci_dbg_dev(&pdev->dev,
			     "xpci_remove(): OUT - deviced not probed yet");
		return;
	}

	pci_clear_master(pdev);
	pci_disable_pcie_error_reporting(pdev);


	/* DMA */
	if (pxdev->dma_block_v) {
		xpci_info_dev(&pdev->dev,
				"Free pages for: [%d] bytes driver memory",
				pxdev->dma_block_size);

		free_pages_exact(pxdev->dma_block_v, pxdev->dma_block_size);
	}

	/* IRQs */
	if (pxdev->dev_int_register)
		xpci_unregister_interrupts(pxdev);
	else
		pxdev->dev_int_register = 0;

	mutex_lock(&xpci_idr_lock);
	idr_remove(&xpci_idr, pxdev->id);
	mutex_unlock(&xpci_idr_lock);

	devm_kfree(&pdev->dev, pxdev);

	/* release the IO region */
	pci_release_region(pdev, BAR_MEM);
}

static void xpci_shutdown(struct pci_dev *pdev)
{
	struct xdev *pxdev = pci_get_drvdata(pdev);

	xpci_dbg_dev(&pdev->dev, "IN");

	if (!pxdev->dev_probe) {
		xpci_dbg("xpci_shutdown: OUT - deviced not probed yet");
		return;
	}

	pxdev->dev_probe = 0;
}

extern void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
			    enum xpci_tx_rx tx_rx, u32 stop_val, char *msg);

extern bool reg_access_enable;

/**
 * xpci_io_error_detected - called when PCI error is detected
 * @pdev: Pointer to PCI device
 * @state: The current pci connection state
 *
 * This function is called after a PCI bus error affecting
 * this device has been detected.
 */
static pci_ers_result_t xpci_io_error_detected(struct pci_dev *pdev,
						pci_channel_state_t state)
{
	xpci_err_dev(&pdev->dev, "IN: PCI ERROR DETECTED");

	xpcxd_set_error(NULL, NULL, xpci_rx, 0x1/*g_cnt_tx_stop*/, "PCI IO ERROR");

	reg_access_enable = false;

	/* Request a slot reset. */
	return PCI_ERS_RESULT_NEED_RESET;
}

static pci_ers_result_t xpci_io_slot_reset(struct pci_dev *pdev)
{
	xpci_err_dev(&pdev->dev, "IN: PCI SLOT RESET DETECTED");

	xpcxd_set_error(NULL, NULL, xpci_rx, 0x1/*g_cnt_tx_stop*/, "PCI SLOT RESET ERROR");

	reg_access_enable = false;

	/* Request a slot reset. */
	return PCI_ERS_RESULT_NEED_RESET;
}

static void xpci_io_resume(struct pci_dev *pdev)
{
	xpci_err_dev(&pdev->dev, "IN PCI SLOT RESUME DETECTED");

	// reg_access_enable = false;
}

static const struct pci_error_handlers xpci_err_handler = {
	.error_detected = xpci_io_error_detected,
	.slot_reset = xpci_io_slot_reset,
	.resume = xpci_io_resume,
};

static struct pci_driver xpci_driver = {
	.name = "xpci_main",
	.id_table = xpci_id_table,
	.probe = xpci_probe,
	.remove = xpci_remove,
	.shutdown = xpci_shutdown,
	.err_handler = &xpci_err_handler,
};

static int __init xpci_init(void)
{
	int orig_debug_level = xpci_debug_level;
	int ret;

	if (xpci_debug_level < XPCI_DBG_LEVEL__NOTICE)
		xpci_debug_level = XPCI_DBG_LEVEL__NOTICE;

	xpci_notice("%s Init. Debug Level set to: 0x%x",
		 XPCI_DRIVER_NAME, xpci_debug_level);

	xpci_notice("%s version: %s",
		XPCI_DRIVER_NAME, XPCI_DRIVER_VERSION);

	// ret = xnetdev_rtnl_link_register();
	// if (ret) {
	// 	xpci_err("Rtnl link register failed: %d", ret);
	// 	return ret;
	// }

	/* TODO: The following should be placed in xpci_probe()
			PCXD can work only if X2 PCI device is enumerated and probed.
			The code below is for testing only
	*/
	if (xpcxd_mode && xpcxd_sw_only_mode) {
		xpci_info("%s Init. PCXD mode - enabled", XPCI_DRIVER_NAME);
		ret = xpcxd_init(NULL);
		if (ret) {
			xpci_err("xpcxd_init() PCXD init failed with %d", ret);
			return ret;
		}
		xpcxd_init_done = true;
	}

	if (xnetdev_mode) {
		ret = xnetdev_init();
		if (ret) {
			xpci_err("net_dev() init failed with %d", ret);
			return ret;
		}

		xnetdev_init_done = true;
		/* Attach if working mode is Net Dev only */
		xpci_info("NetDev only mode detected - attaching to underline interface");
		if (!xpci_pci_mode && !xpcxd_mode) {
			ret = xnetdev_attach();
			if (ret) {
				xpci_err("net dev attach error: %d", ret);
				return ret;
			}
		}
	}

	if (xpci_pci_mode) {
		/*
		* Register the character device (at least try)
		*/
		(void)&xpci_ops;
		ret = register_chrdev(MAJOR_NUM, DEVICE_NAME, &xpci_ops);
		if (ret < 0) {
			xpci_err("%s failed with %d",
				 "Sorry, registering the character device ",
				 ret);
			return ret;
		}

		/* register pci driver */
		ret = pci_register_driver(&xpci_driver);
		if (ret < 0) {
			xpci_err("xpci-driver: can't register pci driver");
			goto unregister_chrdev_region;
		}
	} else {
		xpci_info("%s Init. PCI mode - disabled",
		 XPCI_DRIVER_NAME);

		xpci_hw_irq_mode = 0;
		xpci_info("%s Init. HW IRQ is auto-disabled by PCI mode",
		 XPCI_DRIVER_NAME);
	}

	if (xpci_hw_irq_mode) {
		xpci_info("%s Init. HW IRQ mode - enabled",
		 XPCI_DRIVER_NAME);
	} else {
		xpci_info("%s Init. HW IRQ mode - disabled",
		 XPCI_DRIVER_NAME);
	}

	xpci_info("XPCI Init: done");


	xpci_debug_level = orig_debug_level;

	return 0;

unregister_chrdev_region:
	xpci_dbg("unregister_chrdev_region");
	unregister_chrdev_region(devno, 1);
	unregister_chrdev(MAJOR_NUM, DEVICE_NAME);

//rtnl_link_register_err:
//	xpci_err("Init error: rtnl_link_unregister()");
//	xnetdev_rtnl_link_unregister();

	return ret;
}

static void __exit xpci_exit(void)
{
	int ret;

	xpci_notice("XPCI Exit: begin");

	if (xnetdev_init_done) {
		ret = xnetdev_close();
		if (ret) {
			xpci_err("net_dev() close failed with %d", ret);
			/* return ret; */
		}
	}

	if (xpcxd_init_done) {
		xpci_dbg("xpcxd_close");
		xpcxd_close();
	}

	if (xpci_pci_mode) {
		/* unregister pci driver */
		xpci_dbg("pci_unregister_driver()");
		pci_unregister_driver(&xpci_driver);

		xpci_dbg("xpci_device_close");
		xpci_device_close();

		/* free major/minor number */
		xpci_dbg("unregister_chrdev()");
		unregister_chrdev(MAJOR_NUM, DEVICE_NAME);

		xpci_dbg("idr_destroy()");
		idr_destroy(&xpci_idr);
	}

	xpci_info("XPCI Exit: done");
}

module_init(xpci_init);
module_exit(xpci_exit);

MODULE_AUTHOR("kt <kirillt@xsightlabs.com>");
MODULE_DESCRIPTION("Xsight Labs PCI and Networking Device driver");
MODULE_LICENSE("GPL");
MODULE_VERSION(XPCI_DRIVER_VERSION);
