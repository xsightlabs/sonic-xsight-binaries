// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI driver common routines
 *
 * Copyright (c) 2017-present Xsight Labs Inc.
 *
 */

#include <linux/err.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/netdevice.h>

#include "xpci_dbg.h"
#include "xpci_common.h"

bool reg_access_enable = false;

static u64 common_reg_mem_base = 0;
static DEFINE_MUTEX(xpci_rw_lock);

void xprint_hex_dump(const void *dev, const char *prefix_str, int prefix_type, int rowsize,
		     int groupsize, const void *buf, size_t len, bool ascii)
{
	const u8 *ptr = buf;
	int i, linelen, remaining = len;
	struct net_device *netdev = (struct net_device*) dev;
	unsigned char linebuf[32 * 3 + 2 + 32 + 1];

	if (rowsize != 16 && rowsize != 32)
		rowsize = 16;

	for (i = 0; i < len; i += rowsize) {
		linelen = min(remaining, rowsize);
		remaining -= rowsize;

		hex_dump_to_buffer(ptr + i, linelen, rowsize, groupsize,
				   linebuf, sizeof(linebuf), ascii);

		switch (prefix_type) {
		case DUMP_PREFIX_ADDRESS:
			if (netdev) {
				xpci_dbg_netdev(netdev, "%s%p: %s", prefix_str, ptr + i, linebuf);
			} else {
				xpci_dbg("%s%p: %s", prefix_str, ptr + i, linebuf);
			}
			break;
		case DUMP_PREFIX_OFFSET:
			if (netdev) {
				xpci_dbg_netdev(netdev, "%s%.8x: %s", prefix_str, i, linebuf);
			} else {
				xpci_dbg("%s%.8x: %s", prefix_str, i, linebuf);
			}
			break;
		default:
			if (netdev) {
				xpci_dbg_netdev(netdev, "%s%s", prefix_str, linebuf);
			} else {
				xpci_dbg("%s%s", prefix_str, linebuf);
			}
			break;
		}
	}
}

void xprint_hex_dump_bytes(const char *prefix_str, int prefix_type,
			   const void *buf, size_t len)
{
	xprint_hex_dump(NULL, prefix_str, prefix_type, 16, 1, buf, len, true);
}

u32 xpci_register_access(bool flag)
{
	reg_access_enable = flag;

	xpci_notice("XPCI Register access: [%s]", flag?"Enabled":"Disabled");

	return 0;
}

void xpci_set_reg_mem_base(u64 reg_mem_base)
{
	common_reg_mem_base = reg_mem_base;
}

u64 xpci_get_reg_mem_base(void)
{
	return common_reg_mem_base;
}

/**
 * Low level 64 bit read
 */
u64 xpci_read64(char *reg_name, u32 addr, bool log)
{
	u64 value = 0;
	void __iomem *raddr =
		(__iomem void *) (common_reg_mem_base + addr); /* IO base + offset */
	char addr_str[96];

#ifdef __XPRINT_BEFORE_READ__
	if (log) {
		snprintf(addr_str, sizeof(addr_str), "REG READ: addr: [0x%llx] ",
			(long long unsigned int)raddr);
		xpci_dbg("%s", addr_str);
	}
#endif

	if (!reg_access_enable)
		return 0;

	value = readq(raddr);

	if ((xpci_debug_level > XPCI_DBG_LEVEL__DBG) && log) {
		snprintf(
			addr_str, sizeof(addr_str),
			"RR [%36s]: addr: [0x%x] --> raddr: [0x%llx] hex_value: [0x%-16llx] - reg value: ",
			reg_name?reg_name:"", addr, (__force long long unsigned int)raddr, value);
		xprint_hex_dump_bytes(addr_str, DUMP_PREFIX_NONE,
				      (const void *)&value, 8);
	}

	return value;
}

/**
 * Low level 64 bit read - no debug version
 */
u64 xpci_read64_fast(u32 addr)
{
	u64 value = 0;
	void __iomem *raddr =
		(__iomem void *) (common_reg_mem_base + addr); /* IO base + offset */

	if (!reg_access_enable)
		return 0;

	value = readq(raddr);

	return value;
}

/**
 * Low level 64 bit write
 */
void xpci_write64(char *reg_name, u32 addr, u64 value)
{
	void __iomem *raddr =
		(__iomem void *)(common_reg_mem_base + addr); /* IO base + offset */
	char addr_str[96];

	if (xpci_debug_level > XPCI_DBG_LEVEL__DBG) {
		snprintf(
			addr_str, sizeof(addr_str),
			"RW [%36s]: addr: [0x%x] --> raddr: [0x%llx] hex_value: [0x%-16llx] - reg value: ",
			reg_name?reg_name:"", addr, (__force long long unsigned int)raddr, value);
		xprint_hex_dump_bytes(addr_str, DUMP_PREFIX_NONE,
				      (const void *)&value, 8);
	}

	if (!reg_access_enable)
		return;

	writeq(value, raddr);
}

/**
 * Low level 64 bit write
 */
void xpci_write64_fast(u32 addr, u64 value)
{
	void __iomem *raddr =
		(__iomem void *)(common_reg_mem_base + addr); /* IO base + offset */

	if (!reg_access_enable)
		return;

	writeq(value, raddr);
}
