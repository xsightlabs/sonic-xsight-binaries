// SPDX-License-Identifier: GPL-2.0

/*
 * Version definitions for XPCI, XPCXD and XNetDev
 *
 * Copyright (c) 2017-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_VERSION_H_
#define XPCI_VERSION_H_

#define XPCI_DRIVER_VERSION "Version 0.9.6_rel_pub_050525"

#define XPCXD_NETDEV_DRV_VERSION XPCI_DRIVER_VERSION
#define XNETDEV_DRV_VERSION XPCI_DRIVER_VERSION

#endif /* XPCI_VERSION_H_ */
