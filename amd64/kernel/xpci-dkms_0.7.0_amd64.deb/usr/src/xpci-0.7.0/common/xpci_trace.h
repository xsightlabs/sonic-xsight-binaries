// SPDX-License-Identifier: GPL-2.0

/*
 * Kernel traces definition
 *
 * Copyright (c) 2025-present Xsight Labs Inc.
 *
 */

#if !IS_ENABLED(CONFIG_TRACEPOINTS) || defined(__CHECKER__)
#ifndef XPCI_TRACE_H_
#define XPCI_TRACE_H_
/* If the Linux kernel tracepoints are not available then the xpcxd_trace*
 * macros become nops.
 */
#define xpcxd_trace(trace_name, args...)
#define xpcxd_trace_enabled(trace_name) (0)

#define xpci_trace(trace_name, args...)
#define xpci_trace_enabled(trace_name) (0)

#endif /* ifndef XPCI_TRACE_H_ */
#else /* CONFIG_TRACEPOINTS */

/* The trace subsystem name for xpcxd will be "xpcxd".
 *
 * This file is named xpci_trace.h.
 *n
 * Since this include file's name is different from the trace
 * subsystem name, we'll have to define TRACE_INCLUDE_FILE at the end
 * of this file.
 */
#undef TRACE_SYSTEM
#define TRACE_SYSTEM xpci

#include <linux/tracepoint.h>

#define _XPCXD_TRACE_NAME(trace_name) (trace_##xpcxd##_##trace_name)
#define XPCXD_TRACE_NAME(trace_name) _XPCXD_TRACE_NAME(trace_name)

#define xpcxd_trace(trace_name, args...) XPCXD_TRACE_NAME(trace_name)(args)
#define xpcxd_trace_enabled(trace_name) XPCXD_TRACE_NAME(trace_name##_enabled)()

DECLARE_EVENT_CLASS(xpcxd_tx_event_class,
    TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(void*, skb)
        __field(uint, skb_len)
        __field(int, value1)
        __field(int, value2)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->skb = skb;
        __entry->skb_len = skb_len;
        __entry->value1 = value1;
        __entry->value2 = value2;
    ),
    TP_printk("ring_id=%d skb=%p skb_len=%d v1=0x%x v2=0x%x", 
        __entry->ring_id,
        __entry->skb, 
        __entry->skb_len,
        __entry->value1,
        __entry->value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt_icmp_req,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_pkt_icmp_reply,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_db_write,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DEFINE_EVENT(xpcxd_tx_event_class, xpcxd_tx_netdev_pkt,
	TP_PROTO(int ring_id, void *skb, uint skb_len, int value1, int value2),
    TP_ARGS(ring_id, skb, skb_len, value1, value2)
);

DECLARE_EVENT_CLASS(xpcxd_rx_event_class,
    TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(int, value1)
        __field(int, value2)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->value1 = value1;
        __entry->value2 = value2;
    ),
    TP_printk("ring_id=%d n=%d v=0x%x", __entry->ring_id, __entry->value1, __entry->value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_start,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_next,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_sw_desc_index,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_stop,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_mtu_too_big,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_done,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_poll_space_check,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_fill_start,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_fill_finish,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_db_write,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_napi_complete,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_napi_next,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_enable_irq,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_disable_irq,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

/* Timing check */

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_carrier_on,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_carrier_off,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_start,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_end,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_alloc_skip,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_next,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_rx_db_ring,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_alloc_err,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_alloc_sim_err,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_dma_err,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_signature_err,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_fill_tail_stop,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_close,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_stop,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_rx_disable,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_tx_disable,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_napi_disable,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_dev_alloc_page,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_start,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_page,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_recycle_page,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DEFINE_EVENT(xpcxd_rx_event_class, xpcxd_rx_action_pool_free_done,
	TP_PROTO(int ring_id, int value1, int value2),
    TP_ARGS(ring_id, value1, value2)
);

DECLARE_EVENT_CLASS(xpcxd_rx_skb_event_class,
    TP_PROTO(int ring_id, int value1, void *skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(int, value1)
        __field(void*, skb)
        __field(int, value3)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->value1 = value1;
        __entry->skb = skb;
        __entry->value3 = value3;
    ),
    TP_printk("ring_id=%d n=%d skb=%p pfn=0x%x", __entry->ring_id, __entry->value1, __entry->skb, __entry->value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_align,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_consume,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_build_err,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_page_err,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DEFINE_EVENT(xpcxd_rx_skb_event_class, xpcxd_rx_skb_pass_to_stack,
	TP_PROTO(int ring_id, int value1, void* skb, int value3),
    TP_ARGS(ring_id, value1, skb, value3)
);

DECLARE_EVENT_CLASS(xpcxd_rx_fill_event_class,
    TP_PROTO(int ring_id, int prod_idx, void *sw_desc, u8 eof, u32 len, u32 lsb, u32 msb),
    TP_ARGS(ring_id, prod_idx, sw_desc, eof, len, lsb, msb),
    TP_STRUCT__entry(
		__field(int, ring_id)
        __field(int, prod_idx)
        __field(void*, sw_desc)
        __field(u8, eof)
        __field(u32, len)
        __field(u32, lsb)
        __field(u32, msb)
    ),
    TP_fast_assign(
		__entry->ring_id = ring_id;
        __entry->prod_idx = prod_idx;
        __entry->sw_desc = sw_desc;
        __entry->eof = eof;
        __entry->len = len;
        __entry->lsb = lsb;
        __entry->msb = msb;
    ),
    TP_printk("ring_id=%d prod_idx=%d sw_desc=%p eof=%u len=%d lsb=0x%x msb=0x%x", 
       	__entry->ring_id,
        __entry->prod_idx,
        __entry->sw_desc,
        __entry->eof,
        __entry->len,
        __entry->lsb,
        __entry->msb)
);

DEFINE_EVENT(xpcxd_rx_fill_event_class, xpcxd_rx_fill_bd,
	TP_PROTO(int ring_id, int prod_idx, void *sw_desc, u8 eof, u32 len, u32 lsb, u32 msb),
    TP_ARGS(ring_id, prod_idx, sw_desc, eof, len, lsb, msb)
);

DECLARE_EVENT_CLASS(
	xpcxd_rx_poll_frag_event_class,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size),
	TP_STRUCT__entry(
    	__field(int, ring_id)
        __field(int, prod_idx)
        __field(void*, skb)
        __field(int, skb_len)
		__field(u32, num_desc)
		__field(u32, sub_desc_idx)
        __field(void*, sw_desc)
        __field(void*, page)
        __field(u32, len_left)
        __field(u32, frag_size)
    ),
	TP_fast_assign(
       	__entry->ring_id = ring_id;
        __entry->prod_idx = prod_idx;
        __entry->skb = skb;
        __entry->skb_len = skb_len;
		__entry->num_desc = num_desc;
		__entry->sub_desc_idx = sub_desc_idx;
        __entry->sw_desc = sw_desc;
        __entry->page = page;
        __entry->len_left = len_left;
        __entry->frag_size = frag_size;
    ),
	TP_printk("ring_id=%d prod_idx=%d skb=%p skb_len=%d num_desc=%d sub_desc_idx=%d sw_desc=%p page=%p len_left=%d frag_size=%d",
       	__entry->ring_id,
        __entry->prod_idx,
        __entry->skb, 
        __entry->skb_len,
        __entry->num_desc,
        __entry->sub_desc_idx,
        __entry->sw_desc,
        __entry->page, 
        __entry->len_left,
        __entry->frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_index_wrap,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_index_next,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_add_frag,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_new_skb,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size)
);

DEFINE_EVENT(xpcxd_rx_poll_frag_event_class, xpcxd_rx_poll_consume_skb,
	TP_PROTO(int ring_id, int prod_idx, void *skb, int skb_len, u32 num_desc,
		u32 sub_desc_idx, void *sw_desc, void *page, u32 len_left, u32 frag_size),
	TP_ARGS(ring_id, prod_idx, skb, skb_len, num_desc, sub_desc_idx, sw_desc, page, len_left, frag_size)
);

#define _XPCI_TRACE_NAME(trace_name) (trace_##xpci##_##trace_name)
#define XPCI_TRACE_NAME(trace_name) _XPCI_TRACE_NAME(trace_name)

#define xpci_trace(trace_name, args...) XPCI_TRACE_NAME(trace_name)(args)
#define xpci_trace_enabled(trace_name) XPCI_TRACE_NAME(trace_name##_enabled)()

DECLARE_EVENT_CLASS(xpci_irq_event_class,
    TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr),
    TP_STRUCT__entry(
		__field(int, irq)
        __field(void*, desc_addr)
        __field(void*, msix_table_addr)
    ),
    TP_fast_assign(
		__entry->irq = irq;
        __entry->desc_addr = desc_addr;
        __entry->msix_table_addr = msix_table_addr;
    ),
    TP_printk("irq=%d desc_addr=%p msix_table_addr=%p", __entry->irq, __entry->desc_addr, __entry->msix_table_addr)
);

DEFINE_EVENT(xpci_irq_event_class, xpci_irq_mask,
	TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr)
);

DEFINE_EVENT(xpci_irq_event_class, xpci_irq_unmask,
	TP_PROTO(int irq, void *desc_addr, void *msix_table_addr),
    TP_ARGS(irq, desc_addr, msix_table_addr)
);


DECLARE_EVENT_CLASS(xpci_netdev_rx_learning_event_class,
    TP_PROTO(u32 event, u32 port_id, u16 vlan_id, unsigned char *addr),
    TP_ARGS(event, port_id, vlan_id, addr),
    TP_STRUCT__entry(
		__field(u32, event)
        __field(u32, port_id)
        __field(u16, vlan_id)
        __array(unsigned char, addr, ETH_ALEN)
    ),
    TP_fast_assign(
		__entry->event = event;
        __entry->port_id = port_id;
        __entry->vlan_id = vlan_id;
        memcpy(__entry->addr, addr, ETH_ALEN);
    ),
    TP_printk("FDB Event=%d Port=%d Vid %u Addr=[%02x:%02x:%02x:%02x:%02x:%02x]",
                __entry->event, __entry->port_id, __entry->vlan_id, __entry->addr[0],
                __entry->addr[1], __entry->addr[2], __entry->addr[3],
                __entry->addr[4], __entry->addr[5])
);

DEFINE_EVENT(xpci_netdev_rx_learning_event_class, xpci_netdev_rx_fdb_learning,
	TP_PROTO(u32 event, u32 port_id, u16 vlan_id, unsigned char *addr),
    TP_ARGS(event, port_id, vlan_id, addr)
);


#endif /* XPCI_TRACE_H_ */

/* This trace include file is not located in the .../include/trace
 * with the kernel tracepoint definitions, because we're a loadable
 * module.
 */
#undef TRACE_INCLUDE_PATH
#define TRACE_INCLUDE_PATH .
#undef TRACE_INCLUDE_FILE
#define TRACE_INCLUDE_FILE xpci_trace

#include <trace/define_trace.h>

