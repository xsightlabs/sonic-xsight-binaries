// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver TX handling
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/icmp.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>

#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xpci_trace.h"
#include "xnetdev_common.h"
#include "xreg.h"
#include "xpcxd.h"
#include "xpcxd_os.h"

extern int xpcxd_tx_sbm_rfl_mode;
extern bool hw_ready;
extern int xpcxd_loopback;
extern int xpcxd_ring_threshold;
extern int xpcxd_rx_ring_threshold_stop;
extern int xpcxd_tx_cmp_rfl_mode;
extern int xpcxd_insert_empty_bd;
extern int xpcxd_tx_packets_stop;
extern int xpcxd_tx_drop_on_alignment_err;

extern ktime_t tx_coalescing_ktime;

static u32 ring_id_cycle = 0;

extern uint xpcxd_cfg_tbl[xpcxd_last_cfg_item];

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx);
extern void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
		     enum xpci_tx_rx tx_rx, u32 stop_val, char *msg);

static u16 xpcxd_get_tx_sbm_cns_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_cns = NULL;
	xreg_pcxd_memcfg_tx_rng_stts_tbl_t rng_stts = { 0 };
	u16 sbm_prd_ptr = 0;
	u32 ret = 0;

	if (xpcxd_tx_sbm_rfl_mode) {
		// TODO: Check if it's absolutely needed
		// Relevant for IA-64
		xpcxd_dma_rmb();

		rfl_cns = net_priv->txr[ring_id].sub.rfl_cns;

		sbm_prd_ptr = rfl_cns->ring_index_tail & net_priv->txr[ring_id].sub.mask;
		// xpcxd_info_netdev(
		// 	NETIF_MSG_DRV,
		// 	netdev,
		// 	"---> PCXD SBM TX: value: [0x%llx] ring_index_head: [0x%x] ring_index_tail: [0x%x] sbm_prd_ptr: [%d]",
		// 	rfl_cns->value, rfl_cns->ring_index_head,
		// 	rfl_cns->ring_index_tail, sbm_prd_ptr);

	} else {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_rng_stts_tbl_t) /* Size */,
			(void *)&rng_stts);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return 0;
		}

		sbm_prd_ptr = XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_SRD_CNS_PTR_GET(
			rng_stts);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD SUB TX: TX_RNG_STTS_TBL_SRD_CNS_PTR_GET: 0x%x | %u --> mask: %u",
			sbm_prd_ptr, sbm_prd_ptr, sbm_prd_ptr & net_priv->txr[ring_id].sub.mask);
		sbm_prd_ptr = sbm_prd_ptr & net_priv->txr[ring_id].sub.mask;
	}

	return sbm_prd_ptr;
}

u16 xpcxd_get_tx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd = NULL;
	xreg_pcxd_memcfg_tx_rng_stts_tbl_t rng_stts = { 0 };
	u16 cmpl_prd_ptr = 0;
	int ret;

	if (xpcxd_tx_cmp_rfl_mode) {
		// TODO: Check if it's absolutely needed
		// Relevant for IA-64
		xpcxd_dma_rmb();

		rfl_prd = net_priv->txr[ring_id].cmp.rfl_prd;
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV,
			netdev,
			"---> PCXD CMPL TX: value: [0x%llx] ring_index_head: [0x%x] ring_index_tail: [0x%x]",
			rfl_prd->value, rfl_prd->ring_index_head,
			rfl_prd->ring_index_tail);

		cmpl_prd_ptr = rfl_prd->ring_index_head & net_priv->txr[ring_id].cmp.mask;
	} else {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_rng_stts_tbl_t) /* Size */,
			(void *)&rng_stts);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return 0;
		}

		cmpl_prd_ptr = XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_CRD_PRD_PTR_GET(
			rng_stts);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD CMPL TX: TX_RNG_STTS_TBL_CRD_PRD_PTR: 0x%x | %u",
			cmpl_prd_ptr, cmpl_prd_ptr);
	}

	return cmpl_prd_ptr;
}

static void xpcxd_tx_db_write(struct net_device *netdev, u16 ring_id,
			      u16 prod_idx)
{
	xreg_pcxd_tx_db_t tx_dbv = { 0 };

	xpcxd_trace(tx_db_write, ring_id, 0, 0, 0, prod_idx);

#ifdef __XPCXD_TX_DEBUG__
	if (netdev) {
		struct xpcxd_priv *net_priv = netdev_priv(netdev);
		struct xpcxd_ring *txr = &net_priv->txr[ring_id];
		u32 tx_sub_space = 0;
		u32 tx_cmpl_space = 0;

		tx_sub_space = xpcxd_get_tx_sub_ring_space(txr);
		tx_cmpl_space = xpcxd_get_cmpl_ring_space(txr);

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				"TX_DB: Ring: %d Mode: %d prod_idx: %d Tx SUB space: %d CMPL space: %d SUB: p:%d c:%d CMPL: p:%d c:%d",
				ring_id, 0, prod_idx, tx_sub_space, tx_cmpl_space,
				txr->sub.prod, txr->sub.cons,
				txr->cmp.cmpl_prd_ptr, txr->cmp.cons);
	}
#endif

	XREG_PCXD_TX_DB_RIND_ID_SET(tx_dbv, ring_id);
	XREG_PCXD_TX_DB_MODE_SET(tx_dbv, 0); // 0 - Incremental | 1 - Absolute
	XREG_PCXD_TX_DB_VALUE_SET(tx_dbv, prod_idx);

#ifdef __XPCXD_TX_DEBUG__
	xpci_write64("XREG_PCXD_TX_DB", XREG_PCXD_TX_DB_ADDR,
		     XREG_PCXD_TX_DB_GET(tx_dbv));
#else
	xpci_write64_fast(XREG_PCXD_TX_DB_ADDR,
		     XREG_PCXD_TX_DB_GET(tx_dbv));
#endif

	// TODO: Check if it's absolutely needed
	// Relevant for IA-64
	// wmb();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static int xpcxd_is_multicast_ipv4(__be32 ip_addr) {
    unsigned long addr = ntohl(ip_addr);
    return (addr >= 0xE0000000 && addr <= 0xEFFFFFFF);
}

enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer)
{
	struct xpcxd_ring *ring;

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	ring = container_of(timer, struct xpcxd_ring, tx_coales_isr);

	hrtimer_forward_now(timer, tx_coalescing_ktime);

	if (ring->db_count > 0) {
		xpcxd_tx_db_write(NULL, ring->ring_id, ring->db_count * 2 /* Num of descripts per one Tx */);
		ring->db_count = 0;
	}

    return HRTIMER_RESTART;
}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
static u64 prev_tx_underflow_cnt = 0;
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

#ifdef __XPCXD_ICMP_TRACE__
void xpcxd_check_icmp_echo(struct sk_buff *skb, struct net_device *netdev)
{
    struct iphdr *iph;
    struct icmphdr *icmph;

    // Make sure skb has IP header
    if (!skb)
        return;

    if (!skb_mac_header_was_set(skb))
        return;

    // Ensure skb has full IP header
    if (!pskb_may_pull(skb, sizeof(struct iphdr)))
        return;

    iph = ip_hdr(skb);

    // Check if it's IPv4 and ICMP
    if (iph->protocol != IPPROTO_ICMP)
        return;

    // Make sure there's enough room for ICMP header
    if (!pskb_may_pull(skb, ip_hdrlen(skb) + sizeof(struct icmphdr)))
        return;

    icmph = (struct icmphdr *)(skb_transport_header(skb));

    // Check if it's Echo Request (ping)
    if (icmph->type == ICMP_ECHO) {
		xpcxd_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
        xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
				"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
				skb,
				skb->len,
                ntohs(icmph->un.echo.id),
                ntohs(icmph->un.echo.sequence));
    }

	switch (icmph->type) {
        case ICMP_ECHO:
			xpcxd_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        case ICMP_ECHOREPLY:
			xpcxd_trace(tx_pkt_icmp_reply, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Reply: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        default:
            // Not an echo-related message
            break;
    }
}
#endif /* __XPCXD_ICMP_TRACE__ */

/* net device transmit always called with BH disabled user __netif_tx_lock */
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr = NULL;
	struct xpcxd_sw_desc *sw_desc = NULL;
	struct xpcxd_desc tx_md = { 0 };
	struct xpcxd_desc tx_bd = { 0 };
	struct xpcxd_desc tx_empty_bd = { 0 };
	u16 ring_space = 0;
	u16 prod_idx = 0;
	u16 num_desc = 0;
	u32 pad = 0;
	u32 ring_id = 0;
	u8 *skb_tail = NULL;
	dma_addr_t dma_addr = { 0 };
	netdev_tx_t tx_ret = NETDEV_TX_OK;
	u16 tx_sub_cons = 0;
	bool check_l3_checksum = false;
	bool check_l4_checksum = false;
	__be16 protocol = vlan_get_protocol(skb);
	const struct ethhdr *eth = eth_hdr(skb);
	const struct iphdr *iph = NULL;
	const struct ipv6hdr *ip6h = NULL;
	u16 eth_len = skb_vlan_tag_present(skb)?VLAN_HLEN:ETH_HLEN;
	u16 l3_offset = 0;
	u16 shim_hdr_size = 0;
	bool trimmed = false;
	__be16 l4_protocol = 0;


	if (!hw_ready) {
		xpcxd_info_netdev(NETIF_MSG_TX_ERR, netdev,
				 "---> PCXD TX: HW is not ready");
		dev_kfree_skb_any(skb);
		netdev->stats.tx_dropped++;
		return tx_ret;
	}

	if (xpcxd_cfg_tbl[xpcxd_tx_drop_all]) {
		dev_kfree_skb_any(skb);
		netdev->stats.tx_dropped++;
		return tx_ret;
	}

	spin_lock(&net_priv->txr[ring_id].tx_lock);

	txr = &net_priv->txr[ring_id];

	txr->db_count++;

	if (net_priv->num_rings > 1) {
		ring_id = ring_id_cycle;

		if (txr->db_count % xpcxd_cfg_tbl[xpcxd_tx_db_skip] == 0)
			ring_id_cycle++;

		if (ring_id_cycle >= net_priv->num_rings)
			ring_id_cycle = 0;
	}

	txr->sub.sub_cns_ptr = xpcxd_get_tx_sbm_cns_ptr(netdev, ring_id);

	prod_idx = txr->sub.prod;

	xpcxd_info_netdev(NETIF_MSG_TX_QUEUED, netdev,
			"                                                ");
	xpcxd_info_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> PCXD TX[%d] us:[%d] delta:[%d] : START skb: [%p] skb->data: [%p] protocol: [0x%x] prod_idx: [%d] cns: [cur: %d prev: %d] VLAN:[%s]",
		ring_id, 0 /*jiffies_to_usecs(jiffies)*/,
		0 /*jiffies_to_usecs(jiffies - txr->stats.xmit_prev_jiffy)*/,
		skb, skb->data, protocol,
		prod_idx,
		txr->sub.sub_cns_ptr,
		txr->sub.sub_cns_ptr_prev,
		skb_vlan_tag_present(skb)?"YES":"NO");

	txr->stats.xmit_prev_jiffy = jiffies;

	txr->sub.sub_cns_ptr_prev = txr->sub.sub_cns_ptr;

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX", netdev, skb, TX_OFFSET, xpci_tx);

	if (!netif_carrier_ok(netdev)) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD TX: skb: [%p] Carrier off --> drop",
				ring_id, skb);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	/* pad to min length if necessary */
	/* TODO: replace with skb_put_padto() */
	if (unlikely(skb->len < ETH_ZLEN)) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX: skb: [%p] Padding to minimum length: %d",
			ring_id, skb, ETH_ZLEN - skb->len);
		pad = ETH_ZLEN - skb->len;
		skb_tail = __skb_put(skb, pad);
		memset(skb_tail, 0, pad);
	}

	if ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_256 - 1)) {
		struct sk_buff *new_skb;

		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
			netdev,
			CLR_YELLOW "---> [%d] PCXD TX: RE-ALIGN skb: [%p] skb->data: [0x%px]" CLR_RST,
			ring_id, skb, skb->data);

		/* Alloc new skb */
		new_skb = netdev_alloc_skb(netdev, skb->len + XPCXD_ALIGNMENT_256);
		if (!new_skb) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD TX: Alloc skb: [%p] error skb->len: [%d]",
				ring_id,
				skb,
				skb->len);
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}

		/* Make sure new skb is properly aligned */
		xpcxd_skb_align(new_skb, XPCXD_ALIGNMENT_256);

		/* Copy data to new skb ... */
		skb_copy_from_linear_data(skb, new_skb->data, skb->len);
		skb_put(new_skb, skb->len);

		/* ... and free an old one */
		dev_kfree_skb_any(skb);

		skb = new_skb;

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
			netdev,
			"---> [%d] PCXD TX: RE-ALIGNED skb: [%p] skb->data: [0x%px] protocol: [0x%x]",
			ring_id, skb, skb->data, protocol);
	}

	tx_sub_cons = txr->sub.cons;

	ring_space = xpcxd_get_tx_sub_ring_space(txr);
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
		netdev,
		"---> [%d] PCXD TX: skb: [%p] txr->sub.size: %d prod_idx: %d tx_sub_cons: %d txr->sub.mask: 0x%x",
		ring_id, skb, txr->sub.size, prod_idx, tx_sub_cons, txr->sub.mask);
	// xpcxd_info_netdev(netdev,
	// 		"---> [%d] PCXD TX: skb: [%p] Available ring space: %d", skb,
	// 		ring_id, ring_space);

	if (ring_space < ((txr->sub.size / 100) * xpcxd_ring_threshold)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: skb: [%p] Ring space: %d txr->sub.size: %d Ring drain treshold reached:[%d]",
			ring_id,
			skb,
			ring_space,
			txr->sub.size,
			((txr->sub.size / 100) * xpcxd_ring_threshold));
		if (xpcxd_rx_ring_threshold_stop)
			xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Drain treshold");
		tx_ret = NETDEV_TX_OK; // NETDEV_TX_BUSY;
		xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: skb: [%p] Available ring space: %d Cmpl Ptr: %d",
			ring_id, skb, ring_space, xpcxd_get_tx_cmpl_prod_ptr(netdev, ring_id));

		txr->stats.dropped++;
		txr->stats.tx_sub_threshold++; 		/* Per ring stats */

		goto tx_drop;
	}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
		{
			u64 underflow_cnt = xpcxd_tx_get_underflow_cnt();

			if (prev_tx_underflow_cnt != underflow_cnt) {
				txr->stats.tx_underflow_events++;
				prev_tx_underflow_cnt = underflow_cnt;

				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						"TX UNDERFLOW: [%lld] ", underflow_cnt);				
			}
		}
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

	sw_desc = &txr->sub.sw[prod_idx & txr->sub.mask];

	if (unlikely(!sw_desc)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: sw_desc is NULL", ring_id);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	sw_desc->skb = skb;

#ifdef __XPCXD_CHECK_TX_ALIGNMENT__
	if ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_64 - 1)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: NOT aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_64, skb->data);
		xprint_hex_dump(netdev, "--- TX DATA NOT ALIGNED ---",
					DUMP_PREFIX_OFFSET, 16, 1, skb->data,
					skb->len, true);
		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpci_print_pkt("TX DATA NOT ALIGNE ", netdev, skb, TX_OFFSET, xpci_tx);
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: SKB Data aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_64, skb->data);
	}

	if ((uintptr_t)skb->data & (XPCXD_ALIGNMENT_256 - 1)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: NOT aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_256, skb->data);
		xprint_hex_dump(netdev, "--- TX DATA NOT ALIGNED ---",
					DUMP_PREFIX_OFFSET, 16, 1, skb->data,
					skb->len, true);
		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpci_print_pkt("TX NOT ALIGNED ", netdev, skb, TX_OFFSET, xpci_tx);
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: SKB Data aligned to %d: skb->data: [%px]", XPCXD_ALIGNMENT_256, skb->data);
	}
#endif /* __XPCXD_CHECK_TX_ALIGNMENT__ */

	dma_addr = xpcxd_dma_map_single(net_priv->hw_dev, skb->data, skb->len,
				  DMA_TO_DEVICE);
	if (unlikely(dma_mapping_error(net_priv->hw_dev, dma_addr))) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: DMA Mapping error: [0x%llx]",
			ring_id, dma_addr);
		xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: DMA Mapping error");
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
		netdev,
		"---> [%d] PCXD TX: dma_addr:[0x%llx] dma_map_single(hw_dev: [%p] skb->data: [%p] len=%d, --> DMA_TO_DEVICE -->)",
		ring_id, dma_addr, net_priv->hw_dev, skb->data, skb->len);

// #ifdef __XPCXD_CHECK_TX_ALIGNMENT__
	if (dma_addr & (XPCXD_ALIGNMENT_256 - 1)) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: Not %d aligned data skb->data: [%p] len: [%d] DMA address: [0x%llx]",
			ring_id, XPCXD_ALIGNMENT_256, skb->data, skb->len, dma_addr);
		txr->stats.tx_alignment_error++;
		// xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Not properly aligned DMA address");
		if (xpcxd_tx_drop_on_alignment_err) {
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}

	if (dma_addr & (XPCXD_ALIGNMENT_64 - 1)) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: Not %d aligned data skb->data: [%p] len: [%d] DMA address: [0x%llx]",
			ring_id, XPCXD_ALIGNMENT_64, skb->data, skb->len, dma_addr);
		txr->stats.tx_alignment_error++;
		// xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Not properly aligned DMA address");
		if (xpcxd_tx_drop_on_alignment_err) {
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}
// #endif /* __XPCXD_CHECK_TX_ALIGNMENT__ */

	// xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
	// 	netdev,
	// 	"dma_addr:[0x%llx] dma_map_single(hw_dev: [%p] skb->data: [%p] len=%d, --> DMA_TO_DEVICE -->)",
	// 	dma_addr, net_priv->hw_dev, skb->data, skb->len);

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX: skb: [%p] sw_desc[%p][%d] prod_idx: [%d] protocol: [0x%x]", 
			ring_id, skb, sw_desc, (prod_idx & txr->sub.mask), prod_idx, protocol);

	dma_unmap_addr_set(sw_desc, sw_dma_addr, dma_addr);
	dma_unmap_len_set(sw_desc, dma_len, skb->len);

	if (likely(protocol == htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS))) {
		shim_hdr_size = XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_HDR_SIZE;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN
			"---> [%d] PCXD TX: SHIM before data move: skb: [%p] skb>data[%p] protocol: [0x%x] tx_shim_hdr_size: [%d]" CLR_RST,
			ring_id, skb, skb->data, protocol,
			shim_hdr_size);

		//if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		//	xpci_print_pkt("TX-BEFORE-TRIM", netdev, skb, TX_OFFSET, xpci_tx);

		skb_pull(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		trimmed = true;
	} else { 
		if (likely(protocol == htons(XSW_SHIM_HEADER_ETHTYPE_INJECT))) {
			shim_hdr_size = XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_INJECT_HDR_SIZE;

			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN
				"---> [%d] PCXD TX: INJECT SHIM before data move: skb: [%p] skb>data[%p] protocol: [0x%x] tx_shim_hdr_size: [%d]" CLR_RST,
				ring_id, skb, skb->data, protocol,
				shim_hdr_size);

			//if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
			//	xpci_print_pkt("TX-BEFORE-TRIM", netdev, skb, TX_OFFSET, xpci_tx);

			skb_pull(skb, shim_hdr_size);

			skb_reset_mac_header(skb);
			skb_reset_network_header(skb);
			skb_reset_transport_header(skb);

			eth = eth_hdr(skb);

			trimmed = true;
		} else {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN "---> [%d] PCXD TX: NO SHIM: skb: [%p] skb>data[%p] protocol: [0x%x]" CLR_RST,
				ring_id, skb, skb->data, protocol);

			eth = eth_hdr(skb);
		}
	}

	if (unlikely(eth->h_proto == htons(ETH_P_8021Q))) {
		const struct vlan_ethhdr *veh = vlan_eth_hdr(skb);

		eth_len = VLAN_ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] VLAN: protocol: [0x%x] ---> protocol: [0x%x]" CLR_RST,
			ring_id, skb, protocol, veh->h_vlan_encapsulated_proto);

		protocol = veh->h_vlan_encapsulated_proto;
		l3_offset = shim_hdr_size + VLAN_ETH_HLEN;

		net_priv->stats.tx_vlan_packets++;
	} else {
		eth_len = ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] ETH: protocol: [0x%x] ---> eth->h_proto: [0x%x]" CLR_RST,
			ring_id, skb, protocol, eth->h_proto);

		protocol = eth->h_proto;

		l3_offset = shim_hdr_size + ETH_HLEN;
	}

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		CLR_YELLOW "---> [%d] PCXD TX: skb: [%p] skb>data[%p] protocol: [0x%x] eth->h_proto: [0x%x]" CLR_RST,
		ring_id, skb, skb->data, htons(protocol), htons(eth->h_proto))

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && 
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-AFTER-TRIM", netdev, skb, 0, xpci_tx);

	if (unlikely(protocol == htons(ETH_P_ARP))) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: ARP" CLR_RST, ring_id);
		if (is_broadcast_ether_addr(eth->h_dest)) {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN "---> [%d] PCXD TX: ARP BROADCAST" CLR_RST, ring_id);
			txr->stats.tx_broadcast++;
		} else {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				CLR_GREEN "---> [%d] PCXD TX: ARP UNICAST" CLR_RST, ring_id);
			txr->stats.tx_unicast++;
		}
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX NON ARP: protocol: [0x%x] <--> htons(ETH_P_ARP:0x%x)", ring_id, protocol, htons(ETH_P_ARP));
	}

	if (likely(protocol == htons(ETH_P_IP))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] --> IPv4 [0x%x]" CLR_RST, ring_id, skb, protocol);
		check_l3_checksum = true;
		iph = (struct iphdr *)((u8 *)skb->data + eth_len);

		l4_protocol = iph->protocol;

		/* Calculate per packet statistics */
        if (iph->daddr == htonl(INADDR_BROADCAST)) {
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
					"---> [%d] PCXD TX: tx_broadcast", ring_id);
			txr->stats.tx_broadcast++;
		} if (xpcxd_is_multicast_ipv4(iph->daddr)) {
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
					"---> [%d] PCXD TX: tx_multicast", ring_id);
            txr->stats.tx_multicast++;
        } else {
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
					"---> [%d] PCXD TX: tx_unicast", ring_id);
            txr->stats.tx_unicast++;
        }
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: skb: [%p] --> NON IPv4 [0x%x]", ring_id, skb, protocol);
	}

	if (likely(protocol == htons(ETH_P_IPV6))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] --> IPv6 [0x%x]" CLR_RST, ring_id, skb, protocol);
		check_l3_checksum = true;
		ip6h = (struct ipv6hdr *)((u8 *)skb->data + eth_len);

		l4_protocol = ip6h->nexthdr;

		/* Calculate per packet statistics */
        if (ipv6_addr_is_multicast(&ip6h->daddr)) {
            txr->stats.tx_multicast++;
        } else {
            txr->stats.tx_unicast++;
        }
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: skb: [%p] --> NON IPv6 [0x%x]", ring_id, skb, protocol);
	}

	if (likely(l4_protocol == IPPROTO_TCP)) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] --> TCP [0x%x]" CLR_RST, ring_id, skb, l4_protocol);

		xpcxd_loopback?(check_l4_checksum = false):(check_l4_checksum = true);
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD TX: skb: [%p] --> NON TCP [0x%x]",
				ring_id, skb, l4_protocol);
	}

	if (likely(l4_protocol == IPPROTO_UDP)) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] --> UDP [0x%x] <-> [0x%x]" CLR_RST,
			ring_id, skb, l4_protocol, IPPROTO_UDP);

		xpcxd_loopback?(check_l4_checksum = false):(check_l4_checksum = true);
	} else {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD TX: skb: [%p] --> NON UDP [0x%x]",
				ring_id, skb, l4_protocol);
	}

	xpcxd_trace(tx_pkt, ring_id, skb, skb->len, htons(protocol), htons(eth->h_proto));

#ifdef __XPCXD_ICMP_TRACE__
	xpcxd_check_icmp_echo(skb, netdev);
#endif

	/* If packet been trimmed to correctly set layer offsets and protocols then bring it back */
	if (trimmed) {
		eth = eth_hdr(skb);
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> PCXD TX Before Trim it back [%d]: skb: [%p] skb>data[%p] eth_proto: [0x%x] skb->protocol: [0x%x] l4_protocol: [0x%x]",
			ring_id, skb, skb->data, eth->h_proto, skb->protocol, l4_protocol);

		skb_push(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> PCXD TX After Trim it back [%d]: skb: [%p] skb>data[%p] eth_proto: [0x%x] skb->protocol: [0x%x] l4_protocol: [0x%x]",
			ring_id, skb, skb->data, eth->h_proto, skb->protocol, l4_protocol);

		if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
			xpci_print_pkt("TX-TRIM-BACK", netdev, skb, TX_OFFSET, xpci_tx);
	}

	/* TX Meta Data handling */

	/* W0 */
	tx_md.md.ctrl_no_cpl = 0; /* 0 - Generate completion per packet */
	/* Hybrid mode */
	/* In TX reflection mode - no need to set interrupt per descriptor */
	tx_md.md.int_en =
		!xpcxd_tx_cmp_rfl_mode; /* 1 - Generate on packet completion */

	tx_md.md.type = 0; /* 0 - Desciptor type - MD */
	tx_md.md.calc_l3_chks = xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l3_checksum; /* 0 - Don't calculate */
	tx_md.md.calc_l4_chks = xpcxd_cfg_tbl[xpcxd_check_l4_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l4_checksum; /* 0 - Don't calculate */
	tx_md.md.pseudu_hdr_chks_en =
		0; /* 0 - HW calculates pseudo header checksum */
	tx_md.md.l3_offset_en =
		xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
		check_l3_checksum; /* 1 - L3 offset set by W2[L3_OFFSET] | Config taken from register */
	tx_md.md.num_tx_bd =
		xpcxd_insert_empty_bd?2:1; /* Number of buffer descriptors used to assemble the packet */

	// tx_md.md.rsrv_03 = 0xF0;

	/* W1 */
	tx_md.md.pseudu_hdr_chks = 0; /* 0 - HW calculated, 1 - SW provided Pseudo Header checksum */
	tx_md.md.rsrv_10 = 0;
	tx_md.md.rsrv_11 = 0;

	/* W2 */
	tx_md.md.l3_offset = check_l3_checksum?l3_offset:0; /* L3 offset */
	tx_md.md.rsrv_20 = 0;
	tx_md.md.rsrv_21 = 0;

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: skb: [%p] --> L3 Offset: %d|%d md.calc_l3_chks: %d md.calc_l4_chks: %d",
		ring_id, skb, tx_md.md.l3_offset_en, tx_md.md.l3_offset, tx_md.md.calc_l3_chks, tx_md.md.calc_l4_chks);

	/* W3 */
	tx_md.md.opaque_0 = prod_idx;

	xprint_hex_dump(netdev, "--- TX Md ---", DUMP_PREFIX_OFFSET, 16, 1,
			&tx_md.md, sizeof(struct xpcxd_tx_md), true);

	/* TX Buffer Data handling */

	/* W0 */
	tx_bd.tx_bd.type = 1; /* 1 - Desciptor type - BD */
	/* W1 */
	tx_bd.tx_bd.len = skb->len;
	/* W2 */
	tx_bd.tx_bd.src_buf_addr_lsb = ((u64)dma_addr & 0x00000000FFFFFFFF);
	/* W3 */
	tx_bd.tx_bd.src_buf_addr_msb = ((u64)dma_addr & 0xFFFFFFFF00000000) >> 32;

	xprint_hex_dump(netdev, "--- TX Bd ---", DUMP_PREFIX_OFFSET, 16, 1,
			&tx_bd.tx_bd, sizeof(struct xpcxd_tx_bd), true);

	/* write metadata descriptor 0 */
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
		netdev,
		"---> [%d] PCXD TX: skb dma_addr: [0x%llx] tx_bd.src_buf_addr_LSB: [0x%x] tx_bd.src_buf_addr_MSB: [0x%x] LEN: %d",
		ring_id, dma_addr, tx_bd.tx_bd.src_buf_addr_lsb,
		tx_bd.tx_bd.src_buf_addr_msb, tx_bd.tx_bd.len);
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED,
		netdev,
		"---> [%d] PCXD TX: txr->sub.dma_addr[%d]: base: [0x%llx] point: [0x%llx] size: [%ld] skb: [%p] Write TX MD prod_idx: %d",
		ring_id, prod_idx,
		txr->sub.dma_addr,
		(u64)(txr->sub.dma_addr +
		      (sizeof(struct xpcxd_desc) * prod_idx)),
		sizeof(struct xpcxd_desc),
		skb, prod_idx);
	txr->sub.desc[prod_idx].w64[0] = tx_md.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_md.w64[1];

	// TODO: Check if it's absolutely needed
	// Relevant for IA-64
	// xpcxd_dma_wmb();

	xprint_hex_dump(netdev, "--- TX Md SUB.DESC (DMA) ---",
			DUMP_PREFIX_OFFSET, 16, 1,
			(void *)(txr->sub.desc + prod_idx), sizeof(u64) * 2,
			true);

	prod_idx++;
	num_desc++;

	/* write buffer descriptor */
	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED,
		netdev,
		"---> [%d] PCXD TX: txr->sub.dma_addr[%d]: [0x%llx] skb: [%p] Write TX BD. prod_idx: %d",
		ring_id, prod_idx,
		(u64)(txr->sub.dma_addr +
		      (sizeof(struct xpcxd_desc) * prod_idx)),
		skb, prod_idx);
	txr->sub.desc[prod_idx].w64[0] = tx_bd.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_bd.w64[1];

	xprint_hex_dump(netdev, "--- TX Bd SUB.DESC (DMA) ---",
			DUMP_PREFIX_OFFSET, 16, 1,
			(void *)(txr->sub.desc + prod_idx), sizeof(u64) * 2,
			true);

	prod_idx++;
	num_desc++;

	if (prod_idx >= net_priv->num_tx_desc) {
		prod_idx = 0;
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
				 "---> [%d] PCXD TX: skb: [%p] PROD WRAP AROUND",
				 ring_id, skb);
	}

	if (xpcxd_insert_empty_bd) {
		tx_empty_bd.tx_bd.type = 1; /* 1 - Desciptor type - BD */
		/* W1 */
		tx_empty_bd.tx_bd.len = 0;
		/* W2 */
		tx_empty_bd.tx_bd.src_buf_addr_lsb = 0x123;
		/* W3 */
		tx_empty_bd.tx_bd.src_buf_addr_msb = 0x456;

		xprint_hex_dump(netdev, "--- TX EMPTY Bd ---",
				DUMP_PREFIX_OFFSET, 16, 1, &tx_empty_bd.tx_bd,
				sizeof(struct xpcxd_tx_bd), true);

		/* write empty buffer descriptor */
		txr->sub.desc[prod_idx].w64[0] = tx_empty_bd.w64[0];
		txr->sub.desc[prod_idx].w64[1] = tx_empty_bd.w64[1];

		xprint_hex_dump(netdev, "--- TX EMPTY Bd SUB.DESC (DMA) ---",
				DUMP_PREFIX_OFFSET, 16, 1,
				(void *)(txr->sub.desc + prod_idx), sizeof(u64) * 2,
				true);

		prod_idx++;
		num_desc++;
	}

	// TODO: Check if it's absolutely needed
	// Relevant for IA-64
	xpcxd_dma_wmb();

	if (prod_idx >= net_priv->num_tx_desc) {
		prod_idx = 0;
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX: skb: [%p] PROD WRAP AROUND",
			ring_id, skb);
	}

	txr->sub.prod = prod_idx;
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			 "---> [%d] PCXD TX: skb: [%p] TX FINISH. prod_idx: %d",
			ring_id, skb, prod_idx);

	xpcxd_pkt_stats_inc(txr, skb->len);

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			 "---> [%d] PCXD TX: skb: [%p] DB Write", ring_id, skb);

	netdev->stats.tx_packets++;
	netdev->stats.tx_bytes += skb->len;

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: netdev->stats.tx_packets: %lu netdev->stats.tx_bytes: %lu stats.packets: %lld stats.bytes: %lld tx_db_skip: %d",
		ring_id, netdev->stats.tx_packets, netdev->stats.tx_bytes,
		txr->stats.packets, txr->stats.bytes,
		xpcxd_cfg_tbl[xpcxd_tx_db_skip]);

	if ((txr->db_count % xpcxd_cfg_tbl[xpcxd_tx_db_skip]) == 0) {
		xpcxd_tx_db_write(netdev, ring_id, txr->db_count * num_desc);
		txr->db_count = 0;
	}

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
		     (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-END", netdev, skb, TX_OFFSET, xpci_tx);

	xpcxd_info_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: skb: [%p] | [%s] skb->len: %d txr->db_count: %d",
		ring_id, skb, skb->dev->name, skb->len, txr->db_count);

	if (xpcxd_tx_packets_stop) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: skb: [%p] Tx stop triggered: [%ld]",
			ring_id, skb, netdev->stats.tx_packets);
		xpcxd_set_error(netdev, skb, xpci_tx, 0x1 /*g_cnt_tx_stop*/,
				"TX ERROR: Tx stop");
		tx_ret = NET_XMIT_DROP; // NETDEV_TX_BUSY;
		goto tx_drop;
	}

	spin_unlock(&net_priv->txr[ring_id].tx_lock);

	return tx_ret;

tx_drop:

	if (spin_is_locked(&net_priv->txr[ring_id].tx_lock))
		spin_unlock(&net_priv->txr[ring_id].tx_lock);

	xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev, "---> [%d] PCXD TX: skb: [%p] ERROR", ring_id, skb);
	dev_kfree_skb_any(skb);
	// xpcxd_pkt_stats_inc(txr, skb->len);
	netdev->stats.tx_dropped++;
	netdev->stats.tx_errors++;

	xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev, "---> [%d] PCXD TX: skb: [%p] OUT", ring_id, skb);

	return tx_ret;
}
EXPORT_SYMBOL(xpcxd_xmit);