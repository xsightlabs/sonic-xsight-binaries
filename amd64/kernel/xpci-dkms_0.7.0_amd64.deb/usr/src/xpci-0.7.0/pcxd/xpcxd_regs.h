// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver HW definitions
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#ifndef __XPCXD_REGS_H__
#define __XPCXD_REGS_H__

#include "xreg.h"

/**< Tx Meta Data descriptor */
struct __attribute__((__packed__)) xpcxd_tx_md {
	/* w0 */
	u32 ctrl_no_cpl : 1,        /**< [0:0] No completion, 0 - Generate completion after each packet, 1 - not generated for this packet */
		rsrv_00 : 1,             /**< [1:1] Reserved */
		int_en : 1,             /**< [2:2] Interrupt enable, 0 - Don't generate, 1 - Generate on packet completion */
		rsrv_01 : 4,            /**< [6:3] Reserved */
		type : 1,               /**< [7:7] Descriptor type, 0 - MD, 1 - BD */
		calc_l3_chks : 1,       /**< [8:8] 0 - Don't calculate, 1 - Calculate L3 checksum */
		calc_l4_chks : 1,       /**< [9:9] 0 - Don't calculate, 1 - Calculate L4 checksum */
		pseudu_hdr_chks_en : 1, /**< [10:10] 0 - HW calculates pseudo header checksum, 1 - SW provides pseudo header checksum on W1[15:0] */
		l3_offset_en : 1,       /**< [11:11] 0 - L3 offset set by MMIO, L3 offset set by W2[L3_OFFSET] */
		rsrv_02 : 4,            /**< [15:12] Reserved */
		num_tx_bd : 8,          /**< [23:16] Number of buffer descriptors used t assemble the packet */
		rsrv_03: 8;             /**< [24:31] Reserved */

	/* w1 */
	u32 pseudu_hdr_chks: 16,    /**< [15:0] Pseudo Header checksum */
		rsrv_10: 8,             /**< [31:16] Reserved */
		rsrv_11: 8;             /**< ... */

	/* w2 */
	u32 l3_offset : 8,          /**< [7:0] L3 offset */
		rsrv_20 : 8,            /**< [31:8] Reserved */
		rsrv_21 : 8,            /**< ... */
	    rsrv_22 : 8;            /**< ... */

	/* w3 */
	u32 opaque_0:32;           /**< [31:0] Echoed data to completion, for sw purposes */
};

/**< Tx Buffer Data descriptor */
struct __attribute__((__packed__)) xpcxd_tx_bd {
	/* w0 */
	u32 rsrv_w0_1 : 7,             /**< [6:0]: Reserved */
		type : 1,                  /**< [7]: Descriptor type, 0 - MD, 1 - BD */
		rsrv_w0_2 : 24;            /**< [31:7] Reserved */

	/* w1 */
	u32 len : 20,                  /**< [19:0] Data length in bytes: 0x0 - 0B Empty descriptor, can be used for memory alignment purposes */
	                               /**<                              0x1 - 0B 1B */
	                               /**<                              0xFFFF - (1M-1)B */
	    rsrv_w1 : 12;              /**< W1: Reserved */

	/* w2 */
	u32 src_buf_addr_lsb;          /**< [31:0] Buffer Source Address 32 LSB */

	/* w3 */
	u32 src_buf_addr_msb;          /**< [63:32] Buffer Source Address 32 MSB */
};

struct __attribute__((__packed__)) xpcxd_tx_cmpl {
	/* w0 */
	u32 cmp_ctrl_valid : 1,        /**< [0:0] 0 - Toggle mode / 1 - Valid mode */
		cmp_ctrl_error : 1,        /**< [1:1] Error indication */
		cmp_ctrl_int_en: 1,        /**< [2:2] Interrupt generated when Tx cmpl issued */
		cmp_ctrl_drop: 1,          /**< [3:3] Drop indication */
		cmp_ctrl_reserved: 4,      /**< [4:7] Reserved */
	    num_desc: 8,               /**< [8:15] Number of descriptors in packet */
	    desc_index: 16;            /**< [16:31] 1st desc index in submit ring */

	/* w1 */
	u32  timestamp;                /**< [0:31] TX timestamp, 32 LSB of device RTC */

	/* w2 */
	u32  opaque_0;                 /**< [0:31] Echoed data from MD.W3 */

	/* w3 */
	u32  reserved;                 /**< [0:31] Echoed data from MD.W3 */
};

struct __attribute__((__packed__)) xpcxd_rx_bd {
	/* w0 */
	u32 ctrl_no_cpl : 1,           /**< [0:0] No Completion: no completion is generated for this frame */
		reserved : 1,              /**< [1:1] Reserved */
		int_en : 1,                /**< [2:2] Interrupt enable, 0 - Don't generate, 1 - Generate on packet completion */
		eof : 1,                   /**< [3:3] End of frame */
		rsrv : 28;                 /**< [31:4] Reserved */

	/* w1 */
	u32 len : 20,                  /**< [19:0] Data length in bytes: 0x0 - 0B Empty descriptor, can be used for memory alignment purposes */
	                               /**<                              0x1 - 0B 1B */
	                               /**<                              0xFFFF - (1M-1)B */
	    rsrv_w1 : 12;              /**< W1: Reserved */

	/* w2 */
	u32 dst_buf_addr_lsb;          /**< [31:0] Buffer Destination Address 32 LSB */

	/* w3 */
	u32 dst_buf_addr_msb;          /**< [63:32] Buffer Destination Address 32 MSB */
};

struct __attribute__((__packed__)) xpcxd_rx_cmpl {
	/* --- w0 --- */
	u32  cmp_ctrl_valid : 1,       /**< [0:0] 0 - Toggle mode / 1 - Valid mode */
		cmp_ctrl_rsv_5 : 5,      /**< [1:5] Reserved 2..4 */
		cmp_ctrl_l3_chks_err : 1, /**< [6:6] L3 Checksum Error */
		cmp_ctrl_l4_chks_err : 1, /**< [7:7] L4 Checksum Error */
		num_desc: 8,              /**< [15:8] Number of descriptors in packet */
		desc_index: 16;           /**< [31:16] 1st desc index in submit ring */

	/* --- w1 --- */
	u32 len : 16,                 /**< [15:0] Frame length in bytes */
		reserved_w1 : 16;         /**< [31:16] Reserved */

	/* --- w2 --- */
	u32 rss_hash;              	  /**< [31:0] RSS Hash Result */

	/* --- w3 --- */
	u32 shim : 24,                /**< [23:0] DMA Shim Header | PCXD Shim Header*/
		reserved_w3 : 8;          /**< [31:24] Reserved */
};

struct xpcxd_desc {
	union {
		u64 w64[2];
		u32 w32[4];
		struct xpcxd_tx_md  md;     /**< Tx meta data */
		struct xpcxd_tx_bd  tx_bd;  /**< Tx buffer descriptor data */
		struct xpcxd_tx_cmpl txc;   /**< Tx completion */
		struct xpcxd_rx_bd   rx_bd;
		struct xpcxd_rx_cmpl rxc;   /**< Rx completion */
	};
};

/*
 * Atomic FIFO control structure
 * Used in producer pointers reflection
 */
struct xpcxd_atomic_fifo_ctrl {
	union {
		u64 value;
		struct {
		/* --- w0 --- */ /* Tail */
		u32 ring_index_tail : 24,
			variable_zeros_tail : 8;

		/* --- w1 --- */ /* Head */
		u32 ring_index_head : 24,
			variable_zeros_head : 8;
		};
	};
};

/*
 * Doorbell format for both transmit and receive.
 */
struct xpcxd_db {
	union {
		u64 value;
		struct {
			u16 ring_id;
			u16 prod_idx;
			u32 reserved;
		};
	};
};

u32 xpcxd_get_version(uint64_t *version, uint64_t *block_id,
		      uint64_t *block_release);

typedef u32 xdrv_sram_id_t;
typedef /*u64*/ u32 xdrv_reg_address_t;

int xdrv_mem_ind_write(char *reg_name, xdrv_sram_id_t msel, u32 row, u32 size,
		       const u8 *data);

int xdrv_mem_ind_read(char *reg_name, xdrv_sram_id_t msel, u32 row, u32 size,
		      u8 *data);

void xpci_htobe_data(unsigned char *data, u32 size);
void xpci_betoh_data(unsigned char *data, u32 size);

#endif /* __XPCXD_REGS_H__ */
