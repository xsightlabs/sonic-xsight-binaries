// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI ethtool callbacks
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/jiffies.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>

#include "xpci_version.h"
#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xnetdev_common.h"
#include "xreg.h"
#include "xpcxd.h"

extern int xpcxd_rx_enabled;
extern int xpcxd_tx_enabled;
extern int xpcxd_rss_enabled;
extern u8 rss_secret_key[XPCXD_RSS_SECRET_KEY_SIZE];

extern int xpcxd_tx_packets_stop;
extern int xpcxd_rx_packets_stop;
extern int xpcxd_stop_on_next_isr;
extern int xpcxd_rx_ignore_l3_checksum_err;
extern int xpcxd_rx_ignore_l4_checksum_err;
extern int xpcxd_rx_stop_on_l3_checksum_err;
extern int xpcxd_rx_stop_on_l4_checksum_err;
extern int xpcxd_rx_ring_threshold_stop;
extern int xpcxd_enable_tx_err_interrupt;
extern int xpcxd_enable_rx_err_interrupt;
extern int xpcxd_insert_empty_bd;
extern int xpcxd_tx_drop_on_alignment_err;

extern uint xpcxd_cfg_tbl[xpcxd_last_cfg_item];

enum {NETDEV_STATS, XPCXD_STATS, XPCXD_STATS64};

struct xpcxd_queue_stats {
	u64 packets;
	u64 bytes;
};

struct xpcxd_eth_stats {
	char stat_string[ETH_GSTRING_LEN];
	int type;
	int sizeof_stat;
	int stat_offset;
};

#define XPCXD_STAT(m)		XPCXD_STATS, \
				sizeof(((struct xpcxd_stats *)0)->m), \
				offsetof(struct xpcxd_stats, m)
#define XPCXD_NETDEV_STAT(m)	NETDEV_STATS, \
				sizeof(((struct rtnl_link_stats64 *)0)->m), \
				offsetof(struct rtnl_link_stats64, m)

static const struct xpcxd_eth_stats xpcxd_gstrings_stats[] = {
	{"rx_packets", XPCXD_NETDEV_STAT(rx_packets)},				/* total packets received		*/
	{"tx_packets", XPCXD_NETDEV_STAT(tx_packets)},				/* total packets transmitted	*/
	{"rx_bytes", XPCXD_NETDEV_STAT(rx_bytes)},					/* total bytes received 		*/
	{"tx_bytes", XPCXD_NETDEV_STAT(tx_bytes)},					/* total bytes transmitted		*/
	{"rx_errors", XPCXD_NETDEV_STAT(rx_errors)},				/* bad packets received			*/
	{"tx_errors", XPCXD_NETDEV_STAT(tx_errors)},				/* packet transmit problems		*/
	{"rx_dropped", XPCXD_NETDEV_STAT(rx_dropped)},				/* no space in linux buffers	*/
	{"tx_dropped", XPCXD_NETDEV_STAT(tx_dropped)},				/* no space available in linux	*/

	{"rx_multicast", XPCXD_NETDEV_STAT(multicast)},				/* multicast packets received	*/
	{"rx_broadcast", XPCXD_STAT(rx_broadcast)},
	{"rx_unicast", XPCXD_STAT(rx_unicast)},
	{"tx_multicast", XPCXD_STAT(tx_multicast)},
	{"tx_broadcast", XPCXD_STAT(tx_broadcast)},
	{"tx_unicast", XPCXD_STAT(tx_unicast)},
	{"rx_vlan_packets", XPCXD_STAT(rx_vlan_packets)},
	{"rx_drop_events", XPCXD_STAT(rx_drop_events)},
	{"tx_vlan_packets", XPCXD_STAT(tx_vlan_packets)},
	{"rx_over_errors", XPCXD_NETDEV_STAT(rx_over_errors)}, 		/* receiver ring buff overflow	*/
	{"rx_crc_errors", XPCXD_NETDEV_STAT(rx_crc_errors)},		/* recved pkt with crc error	*/
	{"rx_fifo_errors", XPCXD_NETDEV_STAT(rx_fifo_errors)}, 		/* Same as rx_over_errors */

	{"rx_underflow_events", XPCXD_STAT(rx_underflow_events)}, 	/* Rx underflow events count */

	{"rx_page_alloc_err", XPCXD_STAT(rx_page_alloc_err)}, 		/* Rx page allocation errors count */
	{"rx_dma_get_err", XPCXD_STAT(rx_dma_get_err)}, 			/* Rx DMA get errors count */
	
	{"rx_wrong_page_state", XPCXD_STAT(rx_wrong_page_state)}, 	/* Rx wrong page state detected */

	{"rx_sub_threshold", XPCXD_STAT(rx_sub_threshold)}, 		/* Number of times Rx submission ring threshold reached */
	{"rx_cmpl_threshold", XPCXD_STAT(rx_cmpl_threshold)}, 		/* Number of times Rx submission ring threshold reacheds */

	{"rx_cns_catched_prd", XPCXD_STAT(rx_cns_catched_prd)}, 	/* Rx consumer pointer catched producer */

	{"tx_underflow_events", XPCXD_STAT(tx_underflow_events)}, 	/* Tx underflow events count */

	{"tx_sub_threshold", XPCXD_STAT(tx_sub_threshold)}, 		/* Number of times Tx submission ring threshold reached */
	{"tx_cmpl_threshold", XPCXD_STAT(tx_cmpl_threshold)}, 		/* Number of times Tx submission ring threshold reaches */

	{"tx_alignment_error", XPCXD_STAT(tx_alignment_error)}, 	/* Number of 64/256 alignment error in Tx data allocation */
	{"tx_shim_error", XPCXD_STAT(tx_shim_error)}, 	/* Number of Tx Shim header errors */
};

#define XPCXD_GLOBAL_STATS_LEN ARRAY_SIZE(xpcxd_gstrings_stats)
#define XPCXD_STATS_LEN (XPCXD_GLOBAL_STATS_LEN)

static const char xpcxd_priv_flags_strings[][ETH_GSTRING_LEN] = {
	"dump-tx-stat",
	"dump-rx-stat",
	"stop-on-next-tx",
	"stop-on-next-rx",
	"stop-on-next-isr",
	"drop-all-tx",
	"drop-all-rx",
	"stop-on-tx-valid",
	"stop-on-rx-valid",
	"ignore-rx-l3-checksum-err",
	"ignore-rx-l4-checksum-err",
	"stop-rx-l3-checksum-err",
	"stop-rx-l4-checksum-err",
	"stop-on-rx-ring-space-threshold",
	"enable-tx-err-interrupt",
	"enable-rx-err-interrupt",
	"insert-empty-bd",
	"stop-rx-on-empty-interrupt",
	"stop-on-rx-data-integrity-check",
	"drop-on-tx-alignment-err"
};

#define XPCXD_PRIV_FLAGS_STR_LEN ARRAY_SIZE(xpcxd_priv_flags_strings)

static u16 xpcxd_err_int_coales_val = 1;	/* TODO: Check the real value */
static u16 xpcxd_err_int_timeout_val = 1;	/* TODO: Check the real value */

static void xpcxd_get_drvinfo(struct net_device *netdev,
			      struct ethtool_drvinfo *info)
{
	strlcpy(info->driver, XPCXD_NETDEV_DRV_NAME, sizeof(info->driver));
	strlcpy(info->version, XPCXD_NETDEV_DRV_VERSION,
		sizeof(info->version));
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)
static void xpcxd_get_ringparam(struct net_device *netdev,
				struct ethtool_ringparam *ring,
				struct kernel_ethtool_ringparam *kernel_ring,
				struct netlink_ext_ack *ext_ack)
#else
static void xpcxd_get_ringparam(struct net_device *netdev,
				struct ethtool_ringparam *ring)
#endif
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	ring->rx_max_pending = net_priv->rxr[0].cmp.size;
	ring->tx_max_pending = net_priv->txr[0].sub.size;
	ring->rx_mini_max_pending = 0;
	ring->rx_jumbo_max_pending = 0;
	ring->rx_pending = xpcxd_get_cmpl_ring_space(&net_priv->rxr[0]);
	ring->tx_pending = xpcxd_get_tx_sub_ring_space(&net_priv->txr[0]);
	ring->rx_mini_pending = 0;
	ring->rx_jumbo_pending = 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)
static int xpcxd_set_ringparam(struct net_device *netdev,
			       struct ethtool_ringparam *ring,
			       struct kernel_ethtool_ringparam *kernel_ring,
			       struct netlink_ext_ack *ext_ack)
#else
static int xpcxd_set_ringparam(struct net_device *netdev,
			       struct ethtool_ringparam *ring)
#endif
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: Change ring parameter is not implemented yet");

	return 0;
}

static void xpcxd_get_pauseparam(struct net_device *netdev,
				 struct ethtool_pauseparam *pause)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	pause->autoneg = 0;

	pause->rx_pause = xpcxd_rx_enabled;
	pause->tx_pause = xpcxd_tx_enabled;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [Rx: enabled:%d| pause:%d Tx: enabled:%d| pause:%d]",
		xpcxd_rx_enabled, pause->rx_pause, xpcxd_tx_enabled, pause->tx_pause);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static int xpcxd_set_pauseparam(struct net_device *netdev,
				struct ethtool_pauseparam *pause)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [Rx: enabled:%d| pause:%d Tx: enabled:%d| pause:%d]",
		xpcxd_rx_enabled, pause->rx_pause, xpcxd_tx_enabled, pause->tx_pause);

	if (!pause->rx_pause && xpcxd_rx_enabled) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Disabling RX");

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_dev_rx_disable(netdev, ring_id);
			if (ret) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Ring Tx disable failed: %d", ret);
				return -EAGAIN;
			}
		}

		xpcxd_rx_activate(false);

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device RX disabled");

		/* Rx On/Off per ring is not supported in ethtool interface */
		/* So, we update rx_enable per ring, but set it also globally */

		xpcxd_rx_enabled = false;
	}

	if (!pause->tx_pause && xpcxd_tx_enabled) {
		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_dev_tx_disable(netdev, ring_id);
			if (ret) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Ring Tx disable failed: %d", ret);
				return -EAGAIN;
			}
		}

		xpcxd_tx_activate(false);

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device TX disabled");
		xpcxd_tx_enabled = false;
	}

	if (pause->rx_pause && !xpcxd_rx_enabled) {
		ret = xpcxd_dev_rx_enable(netdev, true);
		if (ret) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Ring device Rx enable failed: %d", ret);
			return -EAGAIN;
		}

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device RX enabled");
		xpcxd_rx_enabled = true;
	}

	if (pause->tx_pause && !xpcxd_tx_enabled) {
		ret = xpcxd_dev_tx_enable(netdev, true);
		if (ret) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Ring device Tx enable failed: %d", ret);
			return -EAGAIN;
		}

		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Device TX enabled");
		xpcxd_tx_enabled = true;
	}

	return 0;
}

/*
	msglvl N
	msglvl type on|off ...
			Sets the driver message type flags by name or number.
			type names the type of message to enable or disable; N
			specifies the new flags numerically. The defined type
			names and numbers are:

			drv         0x0001  General driver status
			probe       0x0002  Hardware probing
			link        0x0004  Link state
			timer       0x0008  Periodic status check
			ifdown      0x0010  Interface being brought down
			ifup        0x0020  Interface being brought up
			rx_err      0x0040  Receive error
			tx_err      0x0080  Transmit error
			tx_queued   0x0100  Transmit queueing
			intr        0x0200  Interrupt handling
			tx_done     0x0400  Transmit completion
			rx_status   0x0800  Receive completion
			pktdata     0x1000  Packet contents
			hw          0x2000  Hardware status
			wol         0x4000  Wake-on-LAN status

			The precise meanings of these type flags differ
			between drivers.
*/

static u32 xpcxd_get_msglevel(struct net_device *netdev)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return xpcxd_msglvl_level;
}

static void xpcxd_set_msglevel(struct net_device *netdev, u32 data)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_msglvl_level = data;

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "New msglevel setting is data: 0x%x xpcxd_msglvl_level: 0x%x", data, xpcxd_msglvl_level);

	if (xpcxd_msglvl_level & NETIF_MSG_LINK)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_LINK is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TIMER)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_TIMER is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_INTR)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_INTR is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_RX_STATUS)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_RX_STATUS is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_PKTDATA)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_PKTDATA is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TX_DONE)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_TX_DONE is ON");

	if (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Message level NETIF_MSG_TX_QUEUED is ON");
}

static u32 xpcxd_rss_indir_size(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return sizeof(xreg_pcxd_rx_rss_indrct_tbl_t);
}

static u32 xpcxd_get_rxfh_key_size(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return XPCXD_RSS_SECRET_KEY_SIZE;
}

static int xpcxd_get_rxfh(struct net_device *netdev, u32 *indir, u8 *key,
			  u8 *hfunc)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (key)
		memcpy(key, rss_secret_key, xpcxd_get_rxfh_key_size(netdev));

	return 0;
}

static int xpcxd_set_rxfh(struct net_device *netdev, const u32 *indir,
			  const u8 *key, const u8 hfunc)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Fill out the rss hash key */
	if (key) {
		memcpy(rss_secret_key, key, xpcxd_get_rxfh_key_size(netdev));
		xpcxd_rss_hash_key_write();
	}

	return 0;
}

#ifdef __XPCXD_STATS64__
/* Calculate and fill ethtool strings array with statistics */
static void xpcxd_get_ethtool_stats(struct net_device *netdev,
				    struct ethtool_stats *estats, u64 *data)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int i = 0;
	struct rtnl_link_stats64 net_stats;
	struct rtnl_link_stats64 *pnet_stats = &net_stats;
	struct xpcxd_stats *pstats = &net_priv->stats; 
	char *p = NULL;
	uint32_t ring_id = 0;

	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_get_stats64(netdev, pnet_stats);

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {

		net_priv->stats.rx_unicast += net_priv->txr[ring_id].stats.rx_unicast;
		net_priv->stats.rx_broadcast += net_priv->txr[ring_id].stats.rx_broadcast;

		net_priv->stats.rx_underflow_events += net_priv->rxr[ring_id].stats.rx_underflow_events,
		net_priv->stats.rx_sub_threshold +=	net_priv->rxr[ring_id].stats.rx_sub_threshold,
		net_priv->stats.rx_cmpl_threshold += net_priv->rxr[ring_id].stats.rx_cmpl_threshold,
		net_priv->stats.rx_cns_catched_prd += net_priv->rxr[ring_id].stats.rx_cns_catched_prd;

		net_priv->stats.rx_page_alloc_err += net_priv->rxr[ring_id].stats.rx_page_alloc_err;
		net_priv->stats.rx_dma_get_err += net_priv->rxr[ring_id].stats.rx_dma_get_err;
		net_priv->stats.rx_wrong_page_state += net_priv->rxr[ring_id].stats.rx_wrong_page_state;
		
		net_priv->stats.tx_unicast += net_priv->txr[ring_id].stats.tx_unicast;
		net_priv->stats.tx_multicast += net_priv->txr[ring_id].stats.tx_multicast;
		net_priv->stats.tx_broadcast += net_priv->txr[ring_id].stats.tx_broadcast;

		net_priv->stats.tx_underflow_events += net_priv->txr[ring_id].stats.tx_underflow_events,
		net_priv->stats.tx_sub_threshold += net_priv->txr[ring_id].stats.tx_sub_threshold,
		net_priv->stats.tx_cmpl_threshold += net_priv->txr[ring_id].stats.tx_cmpl_threshold,
		net_priv->stats.tx_alignment_error += net_priv->txr[ring_id].stats.tx_alignment_error,
		net_priv->stats.tx_shim_error += net_priv->txr[ring_id].stats.tx_shim_error;
	}

	for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
		switch (xpcxd_gstrings_stats[i].type) {
		case NETDEV_STATS:
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
					 "NETDEV_STATS: %s | %d",
					 xpcxd_gstrings_stats[i].stat_string,
					 xpcxd_gstrings_stats[i].stat_offset);
			p = (char *)pnet_stats +
			    xpcxd_gstrings_stats[i].stat_offset;
			break;
		case XPCXD_STATS:
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
					 "XPCXD_STATS: %s | %d",
					 xpcxd_gstrings_stats[i].stat_string,
					 xpcxd_gstrings_stats[i].stat_offset);
			p = (char *)pstats +
			    xpcxd_gstrings_stats[i].stat_offset;
			break;
		default:
			data[i] = 0;
			continue;
		}

		data[i] = (xpcxd_gstrings_stats[i].sizeof_stat ==
			sizeof(u64)) ? *(u64 *)p : *(u32 *)p;

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Data[%d]:[%lld]", i, data[i]);
	}
}
#endif /* __XPCXD_STATS64__ */

static void xpcxd_get_channels(struct net_device *netdev,
			       struct ethtool_channels *ch)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	/* report maximum channels */
	ch->max_combined = net_priv->num_rings;

	ch->max_rx = net_priv->num_rings;
	ch->max_tx = net_priv->num_rings;

	ch->rx_count = xpcxd_rss_enabled?XPCXD_NUM_OF_RSS_QUEUES:1;
	ch->tx_count = xpcxd_rss_enabled?XPCXD_NUM_OF_RSS_QUEUES:1;

	/* record RSS queues */
	ch->combined_count = xpcxd_rss_enabled?XPCXD_NUM_OF_RSS_QUEUES:1;
}

static int xpcxd_set_channels(struct net_device *netdev,
			      struct ethtool_channels *ch)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	return 0;
}

/* Get ethtool statistics array and return it to user space  */
static void xpcxd_get_strings(struct net_device *netdev, u32 stringset,
			      u8 *data)
{
	char *p = (char *)data;
	int i;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: %d", stringset);

	switch (stringset) {
	case ETH_SS_STATS:
		for (i = 0; i < XPCXD_GLOBAL_STATS_LEN; i++) {
			memcpy(p, xpcxd_gstrings_stats[i].stat_string,
			       ETH_GSTRING_LEN);
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "STRING[%d]: [%s]", i, xpcxd_gstrings_stats[i].stat_string);
			p += ETH_GSTRING_LEN;
		}

		/* BUG_ON(p - data != XPCXD_STATS_LEN * ETH_GSTRING_LEN); */
		break;
	case ETH_SS_PRIV_FLAGS:
		memcpy(data, xpcxd_priv_flags_strings,
		       XPCXD_PRIV_FLAGS_STR_LEN * ETH_GSTRING_LEN);
		break;
	}
}

static int xpcxd_get_sset_count(struct net_device *netdev, int sset)
{
	switch (sset) {
	case ETH_SS_STATS:
		return XPCXD_STATS_LEN;
	case ETH_SS_PRIV_FLAGS:
		return XPCXD_PRIV_FLAGS_STR_LEN;
	default:
		return -EOPNOTSUPP;
	}
}

int xpcxd_tx_stat_clear(struct net_device *netdev, uint32_t ring_id)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_tx_stts_brg_ring_pkt_t tx_stts_brg_ring_pkt = {0};
	xreg_pcxd_memcfg_tx_stts_chl_cmp_desc_t tx_stts_chl_cmp = {0};
	xreg_pcxd_memcfg_tx_stts_chl_desc_rd_t tx_stts_chl_desc_rd = {0};
	xreg_pcxd_memcfg_tx_stts_chl_ring_mac_pkt_t tx_stts_chl_ring_mac_pkt = {0};
	xreg_pcxd_memcfg_tx_stts_chl_ring_sel_pkt_t tx_stts_chl_ring_sel_pkt = {0};
	xreg_pcxd_memcfg_tx_stts_cmp_unit_desc_t tx_stts_cmp_unit_desc = {0};
	xreg_pcxd_memcfg_tx_stts_cmp_unit_int_t tx_stts_cmp_unit_int = {0};
	xreg_pcxd_memcfg_tx_stts_fch_db_t tx_stts_fch_db = {0};
	xreg_pcxd_memcfg_tx_stts_fch_desc_t tx_stts_fch_desc = {0};
	xreg_pcxd_memcfg_tx_stts_fch_pkt_t tx_stts_fch_pkt = {0};
	xreg_pcxd_memcfg_tx_stts_cmp_unit_cr_rfl_t tx_stts_cmp_unit_cr_rfl = {0};
	xreg_pcxd_memcfg_tx_stts_cmp_unit_sr_rfl_t tx_stts_cmp_unit_sr_rfl = {0};
	int ret = 0;

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT",
		XREG_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_brg_ring_pkt_t) /* Size */,
		(void *)&tx_stts_brg_ring_pkt);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC",
		XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_chl_cmp_desc_t) /* Size */,
		(void *)&tx_stts_chl_cmp);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX ch comp descriptors per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC",
		XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_chl_cmp_desc_t) /* Size */,
		(void *)&tx_stts_chl_desc_rd);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX ch descriptor per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD",
		XREG_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_chl_desc_rd_t) /* Size */,
		(void *)&tx_stts_chl_desc_rd);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX ch MAC packets per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT",
		XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_chl_ring_mac_pkt_t) /* Size */,
		(void *)&tx_stts_chl_ring_mac_pkt);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX ch per ring select pkt */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT",
		XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_chl_ring_sel_pkt_t) /* Size */,
		(void *)&tx_stts_chl_ring_sel_pkt);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX comp unit desc write per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC",
		XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_desc_t) /* Size */,
		(void *)&tx_stts_cmp_unit_desc);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX comp unit interrupts per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT",
		XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_int_t) /* Size */,
		(void *)&tx_stts_cmp_unit_int);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX pre fetch doorbell per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_FCH_DB",
		XREG_PCXD_MEMCFG_TX_STTS_FCH_DB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_fch_db_t) /* Size */,
		(void *)&tx_stts_fch_db);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TXpre fetch descriptors per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_FCH_DESC",
		XREG_PCXD_MEMCFG_TX_STTS_FCH_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_fch_desc_t) /* Size */,
		(void *)&tx_stts_fch_desc);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX pre fetch packets per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_FCH_PKT",
		XREG_PCXD_MEMCFG_TX_STTS_FCH_PKT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_fch_pkt_t) /* Size */,
		(void *)&tx_stts_fch_pkt);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX comp unit cr cns rfl per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL",
		XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_cr_rfl_t) /* Size */,
		(void *)&tx_stts_cmp_unit_cr_rfl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter TX comp unit sr cns rfl per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL",
		XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_sr_rfl_t) /* Size */,
		(void *)&tx_stts_cmp_unit_sr_rfl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	return 0;
}

int xpcxd_tx_stat_dump_short(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	uint32_t ring_id = 0;

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "---------- Ring [%d] TX Statistics ----------", ring_id);

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			" Tx Pkts: %llu Bytes: %llu UF: %llu Sub_Trsh: %llu Cmpl_Trsh: %llu Tx_Align_err: %llu Tx_Shim_err: %llu",
			net_priv->txr[ring_id].stats.packets,
			net_priv->txr[ring_id].stats.bytes,
			net_priv->txr[ring_id].stats.tx_underflow_events,
			net_priv->txr[ring_id].stats.tx_sub_threshold,
			net_priv->txr[ring_id].stats.tx_cmpl_threshold,
			net_priv->txr[ring_id].stats.tx_alignment_error,
			net_priv->txr[ring_id].stats.tx_shim_error);
	}

	return 0;
}

int xpcxd_tx_stat_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_rx_stts_err_glb0_t xpcxd_tx_err_glb0 = {0};
	xreg_pcxd_rx_stts_err_glb1_t xpcxd_tx_err_glb1 = {0};
	xreg_pcxd_rx_stts_err_prs0_t xpcxd_tx_err_prs0 = {0};
	xreg_pcxd_rx_stts_err_prs1_t xpcxd_tx_err_prs1 = {0};
	uint32_t ring_id = 0;
	int ret = 0;

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CHL_DATA_RD_RQ: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_DATA_RD_RQ",
			    XREG_PCXD_TX_STTS_CHL_DATA_RD_RQ_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CHL_DATA_RD_RS: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_DATA_RD_RS",
			    XREG_PCXD_TX_STTS_CHL_DATA_RD_RS_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CHL_PKT_CS_OUT: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_PKT_CS_OUT",
			    XREG_PCXD_TX_STTS_CHL_PKT_CS_OUT_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CHL_PKT_L3_CS_EN: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_PKT_L3_CS_EN",
			    XREG_PCXD_TX_STTS_CHL_PKT_L3_CS_EN_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN",
			    XREG_PCXD_TX_STTS_CHL_PKT_L3_L4_CS_EN_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CHL_PKT_WO_CS_EN: [%lld]",
		xpci_read64("PCXD_TX_STTS_CHL_PKT_WO_CS_EN",
			    XREG_PCXD_TX_STTS_CHL_PKT_WO_CS_EN_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_CMP_UNIT_D_WR_RQ: [%lld]",
		xpci_read64("PCXD_TX_STTS_CMP_UNIT_D_WR_RQ",
			    XREG_PCXD_TX_STTS_CMP_UNIT_D_WR_RQ_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ: [%lld]",
		xpci_read64("PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ",
			    XREG_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RQ_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS: [%lld]",
		xpci_read64("PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS",
			    XREG_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS_ADDR, true));

	xpcxd_tx_err_glb0.v = xpci_read64(
		"PCXD_TX_STTS_ERR_GLB0", XREG_PCXD_TX_STTS_ERR_GLB0_ADDR, true);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_GLB0_DB_ADDR_VIOLATION: %d",
			    XREG_PCXD_TX_STTS_ERR_GLB0_DB_ADDR_VIOLATION_GET(
				    xpcxd_tx_err_glb0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION: %d",
		XREG_PCXD_TX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION_GET(
			xpcxd_tx_err_glb0));

	xpcxd_tx_err_glb1.v = xpci_read64(
		"PCXD_TX_STTS_ERR_GLB1", XREG_PCXD_TX_STTS_ERR_GLB1_ADDR, true);
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_ERR_GLB1_TLP_POISON: %d",
		XREG_PCXD_TX_STTS_ERR_GLB1_TLP_POISON_GET(xpcxd_tx_err_glb1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
		XREG_PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW_GET(
			xpcxd_tx_err_glb1));

	xpcxd_tx_err_prs0.v = xpci_read64("PCXD_TX_STTS_ERR_PRS0",
					 XREG_PCXD_TX_STTS_ERR_PRS0_ADDR, true);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN_GET(
				    xpcxd_tx_err_prs0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev,
		"PCXD_TX_STTS_ERR_PRS0_PRS_NON_IP_PKT: %d",
		XREG_PCXD_TX_STTS_ERR_PRS0_PRS_NON_IP_PKT_GET(xpcxd_tx_err_prs0));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL_GET(
				    xpcxd_tx_err_prs0));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS_PRS0_IPV6_HDR_VIOL: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL_GET(
				    xpcxd_tx_err_prs0));

	xpcxd_tx_err_prs1.v = xpci_read64("PCXD_TX_STTS_ERR_PRS1",
					 XREG_PCXD_TX_STTS_ERR_PRS1_ADDR, true);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL_GET(
				    xpcxd_tx_err_prs1));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B_GET(
				    xpcxd_tx_err_prs1));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS1_PRS_IPLEN_VIOL: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS1_PRS_IPLEN_VIOL_GET(
				    xpcxd_tx_err_prs1));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			    "PCXD_TX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL: %d",
			    XREG_PCXD_TX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL_GET(
				    xpcxd_tx_err_prs1));

	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_FCH_DESC_RD_RQ: [%lld]",
		xpci_read64("PCXD_TX_STTS_FCH_DESC_RD_RQ",
			    XREG_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS_ADDR, true));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_TX_STTS_FCH_DESC_RD_RS: [%lld]",
		xpci_read64("PCXD_TX_STTS_FCH_DESC_RD_RS",
			    XREG_PCXD_TX_STTS_CMP_UNIT_MSIX_RD_RS_ADDR, true));

	xpcxd_tx_stat_dump_short(netdev);

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xreg_pcxd_memcfg_tx_stts_brg_ring_pkt_t tx_stts_brg_ring_pkt = {0};
		xreg_pcxd_memcfg_tx_stts_chl_cmp_desc_t tx_stts_chl_cmp = {0};
		xreg_pcxd_memcfg_tx_stts_chl_desc_rd_t tx_stts_chl_desc_rd = {0};
		xreg_pcxd_memcfg_tx_stts_chl_ring_mac_pkt_t tx_stts_chl_ring_mac_pkt = {0};
		xreg_pcxd_memcfg_tx_stts_chl_ring_sel_pkt_t tx_stts_chl_ring_sel_pkt = {0};
		xreg_pcxd_memcfg_tx_stts_cmp_unit_desc_t tx_stts_cmp_unit_desc = {0};
		xreg_pcxd_memcfg_tx_stts_cmp_unit_int_t tx_stts_cmp_unit_int = {0};
		xreg_pcxd_memcfg_tx_stts_fch_db_t tx_stts_fch_db = {0};
		xreg_pcxd_memcfg_tx_stts_fch_desc_t tx_stts_fch_desc = {0};
		xreg_pcxd_memcfg_tx_stts_fch_pkt_t tx_stts_fch_pkt = {0};
		xreg_pcxd_memcfg_tx_stts_cmp_unit_cr_rfl_t tx_stts_cmp_unit_cr_rfl = {0};
		xreg_pcxd_memcfg_tx_stts_cmp_unit_sr_rfl_t tx_stts_cmp_unit_sr_rfl = {0};

		/* statistic counter TX BRG packets per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT",
			XREG_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_brg_ring_pkt_t) /* Size */,
			(void *)&tx_stts_brg_ring_pkt);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_BRG_RING_PKT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT_GET(tx_stts_brg_ring_pkt));

		/* statistic counter TX ch comp descriptors per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC",
			XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_chl_cmp_desc_t) /* Size */,
			(void *)&tx_stts_chl_cmp);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC_VALUE_GET(tx_stts_chl_cmp));

		/* statistic counter TX ch descriptor read per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD",
			XREG_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_chl_desc_rd_t) /* Size */,
			(void *)&tx_stts_chl_desc_rd);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CHL_DESC_RD[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD_VALUE_GET(tx_stts_chl_desc_rd));

		/* statistic counter TX ch MAC packets per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT",
			XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_chl_ring_mac_pkt_t) /* Size */,
			(void *)&tx_stts_chl_ring_mac_pkt);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT_VALUE_GET(tx_stts_chl_ring_mac_pkt));

		/* statistic counter TX ch per ring select pkt */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT",
			XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_chl_ring_sel_pkt_t) /* Size */,
			(void *)&tx_stts_chl_ring_sel_pkt);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT_GET(tx_stts_chl_ring_sel_pkt));

		/* statistic counter TX comp unit desc write per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC",
			XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_desc_t) /* Size */,
			(void *)&tx_stts_cmp_unit_desc);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC_VALUE_GET(tx_stts_cmp_unit_desc));

		/* statistic counter TX comp unit interrupts per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT",
			XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_int_t) /* Size */,
			(void *)&tx_stts_cmp_unit_int);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT_VALUE_GET(tx_stts_cmp_unit_int));

		/* statistic counter TX pre fetch doorbell per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_FCH_DB",
			XREG_PCXD_MEMCFG_TX_STTS_FCH_DB_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_fch_db_t) /* Size */,
			(void *)&tx_stts_fch_db);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_FCH_DB[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_FCH_DB_VALUE_GET(tx_stts_fch_db));

		/* statistic counter TXpre fetch descriptors per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_FCH_DESC",
			XREG_PCXD_MEMCFG_TX_STTS_FCH_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_fch_desc_t) /* Size */,
			(void *)&tx_stts_fch_desc);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_FCH_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_FCH_DESC_VALUE_GET(tx_stts_fch_desc));

		/* statistic counter TX pre fetch packets per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_FCH_PKT",
			XREG_PCXD_MEMCFG_TX_STTS_FCH_PKT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_fch_pkt_t) /* Size */,
			(void *)&tx_stts_fch_pkt);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_FCH_PKT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_FCH_PKT_VALUE_GET(tx_stts_fch_pkt));

		/* statistic counter TX comp unit cr prd rfl per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL",
			XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_cr_rfl_t) /* Size */,
			(void *)&tx_stts_cmp_unit_cr_rfl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL_VALUE_GET(tx_stts_cmp_unit_sr_rfl));

		/* statistic counter TX comp unit sr cns rfl per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL",
			XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_cr_rfl_t) /* Size */,
			(void *)&tx_stts_cmp_unit_cr_rfl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL_VALUE_GET(tx_stts_cmp_unit_sr_rfl));

		/* statistic counter TX comp unit sr cns rfl per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL",
			XREG_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_stts_cmp_unit_sr_rfl_t) /* Size */,
			(void *)&tx_stts_cmp_unit_sr_rfl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}
	}

	return 0;
}

int xpcxd_rx_stat_clear(struct net_device *netdev, uint32_t ring_id)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_rx_stts_chl_cmp_desc_t rx_stts_chl_cmp = {0};
	xreg_pcxd_memcfg_rx_stts_chl_desc_rd_t rx_stts_chl_desc_rd = {0};
	xreg_pcxd_memcfg_rx_stts_cmp_unit_desc_t rx_stts_cmp_unit_desc = {0};
	xreg_pcxd_memcfg_rx_stts_cmp_unit_int_t rx_stts_cmp_unit_int = {0};
	xreg_pcxd_memcfg_rx_stts_fch_db_t rx_stts_fch = {0};
	xreg_pcxd_memcfg_rx_stts_fch_pkt_t rx_stts_fch_pkt = {0};
	xreg_pcxd_memcfg_rx_stts_fch_desc_t rx_stts_fch_desc = {0};
	xreg_pcxd_memcfg_rx_stts_cmp_unit_cr_rfl_t rx_stts_cmp_unit_cr_rfl = {0};
	xreg_pcxd_memcfg_rx_stts_cmp_unit_sr_rfl_t rx_stts_cmp_unit_sr_rfl = {0};
	int ret = 0;

	/* statistic counter RX ch comp descriptors per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC",
		XREG_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_chl_cmp_desc_t) /* Size */,
		(void *)&rx_stts_chl_cmp);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX ch descriptor read per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD",
		XREG_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_chl_desc_rd_t) /* Size */,
		(void *)&rx_stts_chl_desc_rd);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX comp unit desc write per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC",
		XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_desc_t) /* Size */,
		(void *)&rx_stts_cmp_unit_desc);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX comp unit interrupts per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT",
		XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_int_t) /* Size */,
		(void *)&rx_stts_cmp_unit_int);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX pre fetch doorbell per ring */

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_FCH_DB",
		XREG_PCXD_MEMCFG_RX_STTS_FCH_DB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_fch_db_t) /* Size */,
		(void *)&rx_stts_fch);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RXpre fetch descriptors per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_FCH_DESC",
		XREG_PCXD_MEMCFG_RX_STTS_FCH_DESC_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_fch_desc_t) /* Size */,
		(void *)&rx_stts_fch_desc);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX pre fetch packets per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_FCH_PKT",
		XREG_PCXD_MEMCFG_RX_STTS_FCH_PKT_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_fch_pkt_t) /* Size */,
		(void *)&rx_stts_fch_pkt);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX comp unit cr prd rfl per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL",
		XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_cr_rfl_t) /* Size */,
		(void *)&rx_stts_cmp_unit_cr_rfl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	/* statistic counter RX comp unit sr cns rfl per ring */
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL",
		XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_sr_rfl_t) /* Size */,
		(void *)&rx_stts_cmp_unit_sr_rfl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	return 0;
}

int xpcxd_rx_stat_dump_short(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	uint32_t ring_id = 0;

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "---------- Ring [%d] RX Statistics ----------", ring_id);

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, " Pkts: %llu Bytes: %llu UF: %llu Sub_Trsh: %llu Cmpl_Trsh: %llu Cns_Catched_Prd: %llu",
			net_priv->rxr[ring_id].stats.packets,
			net_priv->rxr[ring_id].stats.bytes,
			net_priv->rxr[ring_id].stats.rx_underflow_events,
			net_priv->rxr[ring_id].stats.rx_sub_threshold,
			net_priv->rxr[ring_id].stats.rx_cmpl_threshold,
			net_priv->rxr[ring_id].stats.rx_cns_catched_prd);
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, " Page_err: %llu DMA_err: %llu Wrong page state: %llu",
			net_priv->rxr[ring_id].stats.rx_page_alloc_err,
			net_priv->rxr[ring_id].stats.rx_dma_get_err,
			net_priv->rxr[ring_id].stats.rx_wrong_page_state);
	}

	return 0;
}

int xpcxd_rx_stat_dump(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_rx_stts_err_glb0_t xpcxd_rx_err_glb0 = {0};
	xreg_pcxd_rx_stts_err_glb1_t xpcxd_rx_err_glb1 = {0};
	xreg_pcxd_rx_stts_err_prs0_t xpcxd_rx_err_prs0 = {0};
	xreg_pcxd_rx_stts_err_prs1_t xpcxd_rx_err_prs1 = {0};
	uint32_t ring_id = 0;
	int ret = 0;

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_CHL_GLB_MAC_PKT: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_GLB_MAC_PKT",
			    XREG_PCXD_RX_STTS_CHL_GLB_MAC_PKT_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_CHL_PKT_CS_OUT: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_PKT_CS_OUT",
			    XREG_PCXD_RX_STTS_CHL_PKT_CS_OUT_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_PKT_L3_CS_EN: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_PKT_L3_CS_EN",
			    XREG_PCXD_RX_STTS_CHL_PKT_L3_CS_EN_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN",
			    XREG_PCXD_RX_STTS_CHL_PKT_L3_L4_CS_EN_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_PKT_WO_CS_EN: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_PKT_WO_CS_EN",
			    XREG_PCXD_RX_STTS_CHL_PKT_WO_CS_EN_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CHL_WR_RQ: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CHL_WR_RQ",
			    XREG_PCXD_RX_STTS_CHL_WR_RQ_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_CMP_UNIT_D_WR_RQ: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CMP_UNIT_D_WR_RQ",
			    XREG_PCXD_RX_STTS_CMP_UNIT_D_WR_RQ_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ",
			    XREG_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RQ_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS: [%lld]",
			 xpci_read64("PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS",
			    XREG_PCXD_RX_STTS_CMP_UNIT_MSIX_RD_RS_ADDR, true));

	xpcxd_rx_err_glb0.v = xpci_read64(
		"PCXD_RX_STTS_ERR_GLB0", XREG_PCXD_RX_STTS_ERR_GLB0_ADDR, true);
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_ERR_GLB0_DB_ADDR_VIOLATION: %d",
			 XREG_PCXD_RX_STTS_ERR_GLB0_DB_ADDR_VIOLATION_GET(
				 xpcxd_rx_err_glb0));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION: %d",
			 XREG_PCXD_RX_STTS_ERR_GLB0_DB_DATA_SIZE_VIOLATION_GET(
				 xpcxd_rx_err_glb0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_GLB0_BD_LEN0: %d",
		XREG_PCXD_RX_STTS_ERR_GLB0_BD_LEN0_GET(xpcxd_rx_err_glb0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_GLB0_RSS_RING_ID_ERR: %d",
		XREG_PCXD_RX_STTS_ERR_GLB0_RSS_RING_ID_ERR_GET(xpcxd_rx_err_glb0));

	xpcxd_rx_err_glb1.v = xpci_read64(
		"PCXD_RX_STTS_ERR_GLB1", XREG_PCXD_RX_STTS_ERR_GLB1_ADDR, true);
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_GLB1_TLP_POISON: %d",
		XREG_PCXD_RX_STTS_ERR_GLB1_TLP_POISON_GET(xpcxd_rx_err_glb1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
		XREG_PCXD_RX_STTS_ERR_GLB1_RING_UNDERFLOW_GET(xpcxd_rx_err_glb1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_GLB1_CS_VALIDATION_ERR: %d",
		XREG_PCXD_RX_STTS_ERR_GLB1_CS_VALIDATION_ERR_GET(xpcxd_rx_err_glb1));

	xpcxd_rx_err_prs0.v = xpci_read64(
		"PCXD_RX_STTS_ERR_PRS0", XREG_PCXD_RX_STTS_ERR_PRS0_ADDR, true);
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN: %d",
		XREG_PCXD_RX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN_GET(xpcxd_rx_err_prs0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS0_PRS_NON_IP_PKT: %d",
		XREG_PCXD_RX_STTS_ERR_PRS0_PRS_NON_IP_PKT_GET(xpcxd_rx_err_prs0));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
			 "PCXD_RX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL: %d",
			 XREG_PCXD_RX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL_GET(
				 xpcxd_rx_err_prs0));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL: %d",
		XREG_PCXD_RX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL_GET(xpcxd_rx_err_prs0));

	xpcxd_rx_err_prs1.v = xpci_read64(
		"PCXD_RX_STTS_ERR_PRS1", XREG_PCXD_RX_STTS_ERR_PRS1_ADDR, true);
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL: %d",
		XREG_PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_EXT_LEN_VIOL_GET(xpcxd_rx_err_prs1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B_GET: %d",
		XREG_PCXD_RX_STTS_ERR_PRS1_PRS_IPV6_HDR_LEN_GT_256B_GET(xpcxd_rx_err_prs1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS1_PRS_IPLEN_VIOL_GET: %d",
		XREG_PCXD_RX_STTS_ERR_PRS1_PRS_IPLEN_VIOL_GET(xpcxd_rx_err_prs1));
	xpcxd_notice_netdev(
		NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL_GET: %d",
		XREG_PCXD_RX_STTS_ERR_PRS1_PRS_IPV4_IHL_VIOL_GET(xpcxd_rx_err_prs1));

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_FCH_DESC_RD_RQ: [%lld]",
			 xpci_read64("PCXD_RX_STTS_FCH_DESC_RD_RQ",
			    XREG_PCXD_RX_STTS_FCH_DESC_RD_RQ_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_FCH_DESC_RD_RS: [%lld]",
			 xpci_read64("PCXD_RX_STTS_FCH_DESC_RD_RS",
			    XREG_PCXD_RX_STTS_FCH_DESC_RD_RS_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_RSS_GRP_ID: [%lld]",
			 xpci_read64("PCXD_RX_STTS_RSS_GRP_ID",
			    XREG_PCXD_RX_STTS_RSS_GRP_ID_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_RSS_INDR_TBL: [%lld]",
			 xpci_read64("PCXD_RX_STTS_RSS_INDR_TBL",
			    XREG_PCXD_RX_STTS_RSS_INDR_TBL_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_RSS_QID_TBL: [%lld]",
			 xpci_read64("PCXD_RX_STTS_RSS_QID_TBL",
			    XREG_PCXD_RX_STTS_RSS_QID_TBL_ADDR, true));
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_RX_STTS_RSS_RING_ID: [%lld]",
			 xpci_read64("PCXD_RX_STTS_RSS_RING_ID",
			    XREG_PCXD_RX_STTS_RSS_RING_ID_ADDR, true));

	xpcxd_rx_stat_dump_short(netdev);

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xreg_pcxd_memcfg_rx_stts_chl_cmp_desc_t rx_stts_chl_cmp = {0};
		xreg_pcxd_memcfg_rx_stts_chl_desc_rd_t rx_stts_chl_desc_rd = {0};
		xreg_pcxd_memcfg_rx_stts_cmp_unit_desc_t rx_stts_cmp_unit_desc = {0};
		xreg_pcxd_memcfg_rx_stts_cmp_unit_int_t rx_stts_cmp_unit_int = {0};
		xreg_pcxd_memcfg_rx_stts_fch_db_t rx_stts_fch = {0};
		xreg_pcxd_memcfg_rx_stts_fch_pkt_t rx_stts_fch_pkt = {0};
		xreg_pcxd_memcfg_rx_stts_fch_desc_t rx_stts_fch_desc = {0};
		xreg_pcxd_memcfg_rx_stts_cmp_unit_cr_rfl_t rx_stts_cmp_unit_cr_rfl = {0};
		xreg_pcxd_memcfg_rx_stts_cmp_unit_sr_rfl_t rx_stts_cmp_unit_sr_rfl = {0};

		/* statistic counter RX ch comp descriptors per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC",
			XREG_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_chl_cmp_desc_t) /* Size */,
			(void *)&rx_stts_chl_cmp);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC_VALUE_GET(rx_stts_chl_cmp));

		/* statistic counter RX ch descriptor read per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD",
			XREG_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_chl_desc_rd_t) /* Size */,
			(void *)&rx_stts_chl_desc_rd);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CHL_DESC_RD[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD_VALUE_GET(rx_stts_chl_desc_rd));

		/* statistic counter RX comp unit desc write per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC",
			XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_desc_t) /* Size */,
			(void *)&rx_stts_cmp_unit_desc);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC_VALUE_GET(rx_stts_cmp_unit_desc));

		/* statistic counter RX comp unit interrupts per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT",
			XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_int_t) /* Size */,
			(void *)&rx_stts_cmp_unit_int);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT_VALUE_GET(rx_stts_cmp_unit_int));

		/* statistic counter RX pre fetch doorbell per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_FCH_DB",
			XREG_PCXD_MEMCFG_RX_STTS_FCH_DB_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_fch_db_t) /* Size */,
			(void *)&rx_stts_fch);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_FCH_DB[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_FCH_DB_VALUE_GET(rx_stts_fch));

		/* statistic counter RXpre fetch descriptors per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_FCH_DESC",
			XREG_PCXD_MEMCFG_RX_STTS_FCH_DESC_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_fch_desc_t) /* Size */,
			(void *)&rx_stts_fch_desc);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_FCH_DESC[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_FCH_DESC_VALUE_GET(rx_stts_fch_desc));

		/* statistic counter RX pre fetch packets per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_FCH_PKT",
			XREG_PCXD_MEMCFG_RX_STTS_FCH_PKT_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_fch_pkt_t) /* Size */,
			(void *)&rx_stts_fch_pkt);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_FCH_PKT[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_FCH_PKT_VALUE_GET(rx_stts_fch_pkt));

		/* statistic counter RX comp unit cr prd rfl per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL",
			XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_cr_rfl_t) /* Size */,
			(void *)&rx_stts_cmp_unit_cr_rfl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL_VALUE_GET(rx_stts_cmp_unit_cr_rfl));

		/* statistic counter RX comp unit sr cns rfl per ring */
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL",
			XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_stts_cmp_unit_sr_rfl_t) /* Size */,
			(void *)&rx_stts_cmp_unit_sr_rfl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL[%d]: [%lld]",
			ring_id, XREG_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL_VALUE_GET(rx_stts_cmp_unit_sr_rfl));
	}

	return 0;
}

int xpcxd_rx_get_underflow_cnt(void)
{
	xreg_pcxd_rx_stts_err_glb1_t xpcxd_rx_err_glb1 = {0};

	xpcxd_rx_err_glb1.v = xpci_read64_fast(XREG_PCXD_RX_STTS_ERR_GLB1_ADDR);
	return XREG_PCXD_RX_STTS_ERR_GLB1_TLP_POISON_GET(xpcxd_rx_err_glb1);
}

int xpcxd_tx_get_underflow_cnt(void)
{
	xreg_pcxd_tx_stts_err_glb1_t xpcxd_tx_err_glb1 = {0};

	xpcxd_tx_err_glb1.v = xpci_read64_fast(XREG_PCXD_TX_STTS_ERR_GLB1_ADDR);

	xpcxd_notice(
		NETIF_MSG_DRV,"PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW: %d",
		XREG_PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW_GET(
			xpcxd_tx_err_glb1));

	return XREG_PCXD_TX_STTS_ERR_GLB1_RING_UNDERFLOW_GET(xpcxd_tx_err_glb1);
}

static int xpcxd_tx_err_int(struct net_device *netdev, bool enable)
{
	xreg_pcxd_rx_err_int_t pcxd_tx_err_int = {0};

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%s]", enable?"SET":"CLEAR");

	XREG_PCXD_TX_ERR_INT_DB_ADDR_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_DB_SIZE_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PKT_L4_ONLY_CS_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_PKT_NON_IP_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPV4_PROT_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPV6_NHDR_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPV6_ELEN_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPV6_HDR_TLP_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPLEN_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_PRS_IPV4_IHL_VIOL_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_TLP_POISON_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_RING_UNDERFLOW_INT_EN_SET(pcxd_tx_err_int, enable);
	XREG_PCXD_TX_ERR_INT_INT_COALESCING_SET(pcxd_tx_err_int, xpcxd_err_int_coales_val);
	XREG_PCXD_TX_ERR_INT_INT_TIMEOUT_SET(pcxd_tx_err_int, xpcxd_err_int_timeout_val);

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_TX_ERR_INT: [%s]", enable?"SET":"CLEAR");

	xpci_write64("XREG_PCXD_MSIX_CTRL", XREG_PCXD_TX_ERR_INT_ADDR,
		     XREG_PCXD_MSIX_CTRL_GET(pcxd_tx_err_int));

	return 0;
}

static int xpcxd_rx_err_int(struct net_device *netdev, bool enable)
{
	xreg_pcxd_rx_err_int_t pcxd_rx_err_int = {0};

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%s]", enable?"SET":"CLEAR");

	XREG_PCXD_RX_ERR_INT_DB_ADDR_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_DB_SIZE_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PKT_L4_ONLY_CS_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_PKT_NON_IP_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPV4_PROT_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPV6_NHDR_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPV6_ELEN_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPV6_HDR_TLP_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPLEN_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_PRS_IPV4_IHL_VIOL_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_CS_VALIDATION_ERR_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_TLP_POISON_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_RING_UNDERFLOW_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_BD_LEN0_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_RSS_RING_ID_ERR_INT_EN_SET(pcxd_rx_err_int, enable);
	XREG_PCXD_RX_ERR_INT_INT_COALESCING_SET(pcxd_rx_err_int, xpcxd_err_int_coales_val);
	XREG_PCXD_RX_ERR_INT_INT_TIMEOUT_SET(pcxd_rx_err_int, xpcxd_err_int_timeout_val);

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_RX_ERR_INT: [%s]", enable?"SET":"CLEAR");

	xpci_write64("XREG_PCXD_MSIX_CTRL", XREG_PCXD_RX_ERR_INT_ADDR,
		     XREG_PCXD_MSIX_CTRL_GET(pcxd_rx_err_int));

	return 0;
}

static u32 xpcxd_get_priv_flags(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 priv_flags = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: net_priv->priv_flags: 0x%x", net_priv->priv_flags);

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_TX_STAT)
		priv_flags |= XPCXD_FLAG_DUMP_TX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_DUMP_RX_STAT)
		priv_flags |= XPCXD_FLAG_DUMP_RX_STAT;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_TX)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_TX;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_RX)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_RX;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_NEXT_ISR)
		priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_ISR;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ALL_TX)
		priv_flags |= XPCXD_FLAG_DROP_ALL_TX;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ALL_RX)
		priv_flags |= XPCXD_FLAG_DROP_ALL_RX;

	if (net_priv->priv_flags & XPCXD_FLAG_IGNORE_RX_L3_CHKSUM)
		priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_IGNORE_RX_L4_CHKSUM)
		priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_RX_L3_CHKSUM)
		priv_flags |= XPCXD_FLAG_STOP_RX_L3_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_RX_L4_CHKSUM)
		priv_flags |= XPCXD_FLAG_STOP_RX_L4_CHKSUM;

	if (net_priv->priv_flags & XPCXD_FLAG_STOP_ON_RX_THRESHOLD)
		priv_flags |= XPCXD_FLAG_STOP_ON_RX_THRESHOLD;

	if (net_priv->priv_flags & XPCXD_FLAG_ENABLE_TX_ERR_INT)
		priv_flags |= XPCXD_FLAG_ENABLE_TX_ERR_INT;

	if (net_priv->priv_flags & XPCXD_FLAG_ENABLE_RX_ERR_INT)
		priv_flags |= XPCXD_FLAG_ENABLE_RX_ERR_INT;

	if (net_priv->priv_flags & XPCXD_FLAG_INSERT_EMPTY_BD)
		priv_flags |= XPCXD_FLAG_INSERT_EMPTY_BD;

	if (net_priv->priv_flags & XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR)
		priv_flags |= XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT: npriv_flags: 0x%x", priv_flags);

	return priv_flags;
}

static int xpcxd_set_priv_flags(struct net_device *netdev, u32 priv_flags)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: 0x%x", priv_flags);

	if (priv_flags & XPCXD_FLAG_DUMP_TX_STAT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Tx statistics requested");

		xpcxd_tx_stat_dump(netdev);
	}

	if (priv_flags & XPCXD_FLAG_DUMP_RX_STAT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Dump Rx statistics requested");

		xpcxd_rx_stat_dump(netdev);
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_TX;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_TX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next Tx packet");

		xpcxd_tx_packets_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_TX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_RX;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_RX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next Rx packet");

		xpcxd_rx_packets_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_RX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_NEXT_ISR;
	if (priv_flags & XPCXD_FLAG_STOP_ON_NEXT_ISR) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on next timer interrupt");

		xpcxd_stop_on_next_isr = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_NEXT_ISR;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ALL_TX;
	if (priv_flags & XPCXD_FLAG_DROP_ALL_TX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Drop all Tx packets");

		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ALL_TX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ALL_RX;
	if (priv_flags & XPCXD_FLAG_DROP_ALL_RX) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Drop all Rx packets");

		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ALL_RX;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;
	if (priv_flags & XPCXD_FLAG_IGNORE_RX_L3_CHKSUM) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"Enable ignore error print and count on L3 checksum error");

		xpcxd_rx_ignore_l3_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);
	if (priv_flags & XPCXD_FLAG_IGNORE_RX_L4_CHKSUM) {
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"Enable ignore error print and count on L4 checksum error");

		xpcxd_rx_ignore_l4_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_RX_L3_CHKSUM;
	if (priv_flags & XPCXD_FLAG_STOP_RX_L3_CHKSUM) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on L3 checksum error");

		xpcxd_rx_stop_on_l3_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_RX_L3_CHKSUM;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_RX_L4_CHKSUM;
	if (priv_flags & XPCXD_FLAG_STOP_RX_L4_CHKSUM) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable stop on L4 checksum error");

		xpcxd_rx_stop_on_l4_checksum_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_RX_L4_CHKSUM;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_STOP_ON_RX_THRESHOLD;
	if (priv_flags & XPCXD_FLAG_STOP_ON_RX_THRESHOLD) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Stop on Rx ring threshold");

		xpcxd_rx_ring_threshold_stop = 1;

		net_priv->priv_flags |= XPCXD_FLAG_STOP_ON_RX_THRESHOLD;
	}


	net_priv->priv_flags &= ~XPCXD_FLAG_ENABLE_TX_ERR_INT;
	xpcxd_tx_err_int(netdev, false);
	if (priv_flags & XPCXD_FLAG_ENABLE_TX_ERR_INT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable Tx error interrupts");

		xpcxd_enable_tx_err_interrupt = 1;
		xpcxd_tx_err_int(netdev, true);

		net_priv->priv_flags |= XPCXD_FLAG_ENABLE_TX_ERR_INT;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_ENABLE_RX_ERR_INT;
	xpcxd_rx_err_int(netdev, false);
	if (priv_flags & XPCXD_FLAG_ENABLE_RX_ERR_INT) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable Rx error interrupts");

		xpcxd_enable_rx_err_interrupt = 1;
		xpcxd_rx_err_int(netdev, true);

		net_priv->priv_flags |= XPCXD_FLAG_ENABLE_RX_ERR_INT;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_INSERT_EMPTY_BD;
	if (priv_flags & XPCXD_FLAG_INSERT_EMPTY_BD) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Enable insertion of empty Buffer Descriptor");

		xpcxd_insert_empty_bd = 1;

		net_priv->priv_flags |= XPCXD_FLAG_INSERT_EMPTY_BD;
	}

	net_priv->priv_flags &= ~XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;
	if (priv_flags & XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				 "Tx drop badly aligned packets");

		xpcxd_tx_drop_on_alignment_err = 1;

		net_priv->priv_flags |= XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "FLAGS: priv_flags: 0x%x net_priv->priv_flags: 0x%x",
			 priv_flags, net_priv->priv_flags);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

const struct ethtool_ops xpcxd_ethtool_ops = {
	.get_drvinfo = xpcxd_get_drvinfo,
#ifdef __XPCXD_STATS64__
	.get_ethtool_stats = xpcxd_get_ethtool_stats,
#endif
	.get_link = ethtool_op_get_link,
	.get_channels = xpcxd_get_channels,
	.set_channels = xpcxd_set_channels,
	.get_ringparam = xpcxd_get_ringparam,
	.set_ringparam = xpcxd_set_ringparam,
	.get_pauseparam	= xpcxd_get_pauseparam,
	.set_pauseparam	= xpcxd_set_pauseparam,
	.get_msglevel = xpcxd_get_msglevel,
	.set_msglevel = xpcxd_set_msglevel,
	.get_rxfh_indir_size = xpcxd_rss_indir_size,
	.get_rxfh_key_size = xpcxd_get_rxfh_key_size,
	.get_rxfh = xpcxd_get_rxfh,
	.set_rxfh = xpcxd_set_rxfh,
	.get_strings = xpcxd_get_strings,
	.get_sset_count = xpcxd_get_sset_count,
	.get_priv_flags = xpcxd_get_priv_flags,
	.set_priv_flags = xpcxd_set_priv_flags,
};

void xpcxd_set_ethtool_ops(struct net_device *netdev)
{
struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	netdev->ethtool_ops = &xpcxd_ethtool_ops;

	/* Configuration presets */
	xpcxd_rx_ignore_l3_checksum_err ? (net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L3_CHKSUM) : 0;
	xpcxd_rx_ignore_l4_checksum_err ? (net_priv->priv_flags |= XPCXD_FLAG_IGNORE_RX_L4_CHKSUM) : 0;
	xpcxd_rx_stop_on_l3_checksum_err ? (net_priv->priv_flags |= XPCXD_FLAG_STOP_RX_L3_CHKSUM) : 0;
	xpcxd_rx_stop_on_l4_checksum_err ? (net_priv->priv_flags |= XPCXD_FLAG_STOP_RX_L3_CHKSUM) : 0;
}
