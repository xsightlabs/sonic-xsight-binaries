// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver RT Netlink callbacks
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/rtnetlink.h>
#include <net/rtnetlink.h>
#include <linux/netlink.h>
#include <linux/list.h>

#include "xpci_dbg.h"
#include "xpcxd.h"

struct xpcxd_nl_msg {
	bool dump_msg;
	__u32 cmd;
	bool if_msg;
	char *if_name;
	__u32 if_state;
	__u8 if_op;
	bool if_port_msg;
	__u8 if_port_op;
	__u8 if_mode;
	__u8 num_rings;
	__u16 tx_ring_size;
	__u16 rx_ring_size;
};

static int xpcxd_nl_msg_parse(struct nlattr *data[], struct xpcxd_nl_msg *nl_msg)
{
	bool pcxd_cfg = false;

	xpci_dbg("--- Parsing started ---");

	if (!data) {
		xpci_err("Missing data[]");
		return -EINVAL;
	}

	if (data[IFLA_XPCXD_IF_CFG]) {
		xpci_dbg("--- IFLA_XPCXD_IF_CFG:%d ---", nla_get_u32(data[IFLA_XPCXD_IF_CFG]));
		if (nla_get_u8(data[IFLA_XPCXD_IF_CFG]))
			pcxd_cfg = true;
	}

	if (pcxd_cfg) {
		xpci_dbg("Parsing IFLA_XPCXD_IF_CFG");
		nl_msg->if_msg = true;
		if (data[IFLA_XPCXD_IF_OP]) {
			nl_msg->if_op =
				nla_get_u8(data[IFLA_XPCXD_IF_OP]);
		} else {
			xpci_err("Interface operation name is not provided");
			return -EINVAL;
		}

		xpci_info("IFLA_XPCXD_IF_OP: [%d]", nl_msg->if_op);

		if (data[IFLA_XPCXD_IF_NAME]) {
			nl_msg->if_name = (char *)nla_data(
				data[IFLA_XPCXD_IF_NAME]);
		} else {
			xpci_err("Interface name is not provided");
			return -EINVAL;
		}

		xpci_info("IFLA_XPCXD_IF_NAME: interface name: [%s]",
			  nl_msg->if_name);

		if (data[IFLA_XPCXD_IF_STATE]) {
			nl_msg->if_state = nla_get_u32(
				data[IFLA_XPCXD_IF_STATE]);
		} else {
			xpci_err("Interface state is not provided");
			return -EINVAL;
		}

		xpci_info(
			"IFLA_XPCXD_IF_STATE: %s ",
			((nl_msg->if_state) ?
				       ((nl_msg->if_state == XPCXD_IF_UP) ?
						"UP" :
						"DOWN") :
						"UNCHANGED"));

		if (nl_msg->if_op == XPCXD_IF_OP_ADD) {
			xpci_info("XPCXD_IF_OP_ADD");

			if (data[IFLA_XPCXD_IF_MODE]) {
				nl_msg->if_mode =
					nla_get_u8(data[IFLA_XPCXD_IF_MODE]);
			} else {
				xpci_err("Interface mode is not provided");
				return -EINVAL;
			}

			if (data[IFLA_XPCXD_CFG_NUM_OF_RINGS]) {
				nl_msg->num_rings =
					nla_get_u8(data[IFLA_XPCXD_CFG_NUM_OF_RINGS]);
			} else {
				xpci_err("Number of rings is not provided");
				return -EINVAL;
			}

			xpci_info(
				"IFLA_XPCXD_CFG_NUM_OF_RINGS: %d ",
				nl_msg->num_rings);

			if (data[IFLA_XPCXD_CFG_TX_RING_SIZE]) {
				nl_msg->tx_ring_size =
					nla_get_u16(data[IFLA_XPCXD_CFG_TX_RING_SIZE]);
			} else {
				xpci_err("Tx ring size is not provided");
				return -EINVAL;
			}

			xpci_info(
				"IFLA_XPCXD_CFG_TX_RING_SIZE: %d ",
				nl_msg->tx_ring_size);

			if (data[IFLA_XPCXD_CFG_RX_RING_SIZE]) {
				nl_msg->rx_ring_size =
					nla_get_u16(data[IFLA_XPCXD_CFG_RX_RING_SIZE]);
			} else {
				xpci_err("Rx ring size is not provided");
				return -EINVAL;
			}

			xpci_info(
				"IFLA_XPCXD_CFG_RX_RING_SIZE: %d ",
				nl_msg->rx_ring_size);
		}

		if (nl_msg->if_op == XPCXD_IF_OP_UPDATE) {
			xpci_info("XPCXD_IF_OP_UPDATE");
			xpci_info(
				"XPCXD_IF_OP_UPDATE");
		}
	}

	xpci_dbg("--- Parsing finished ---");

	return 0;
}

static void xpcxd_setup(struct net_device *netdev)
{
	xpci_dbg("RTNL SETUP");
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xpcxd_validate(struct nlattr *tb[], struct nlattr *data[],
				struct netlink_ext_ack *extack)
#else
static int xpcxd_validate(struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct xpcxd_nl_msg nl_msg = { 0 };

	int ret = 0;

	xpci_info("RTNL VALIDATE");

	// dump_stack();

	if (tb[IFLA_ADDRESS]) {
		xpci_info("RTNL: IFLA_ADDRESS");

		if (nla_len(tb[IFLA_ADDRESS]) != ETH_ALEN)
			return -EINVAL;
		if (!is_valid_ether_addr(nla_data(tb[IFLA_ADDRESS])))
			return -EADDRNOTAVAIL;
	}

	ret = xpcxd_nl_msg_parse(data, &nl_msg);
	if (ret)
		return ret;

	xpci_info("RTNL VALIDATE: OK");

	return 0;
}

static size_t xpcxd_get_size(const struct net_device *netdev)
{
	xpci_dbg_netdev(netdev, "RTNL GET SIZE");

	return (0 + nla_total_size(sizeof(__u32)) /* IFLA_XPCXD_IF_CFG */
		+ nla_total_size(sizeof(__u8)) /* IFLA_XPCXD_IF_OP */
		+ nla_total_size(XPCXD_IF_NAME_SIZE) /* IFLA_XPCXD_IF_NAME */
		+ nla_total_size(sizeof(__u32)) /* IFLA_XPCXD_IF_STATE */
		+ nla_total_size(sizeof(__u8)) /* IFLA_XPCXD_IF_MODE */
		+ nla_total_size(sizeof(__u8)) /* IFLA_XPCXD_CFG_NUM_OF_RINGS */
		+ nla_total_size(sizeof(__u16)) /* IFLA_XPCXD_CFG_TX_RING_SIZE */
		+ nla_total_size(sizeof(__u16)) /* IFLA_XPCXD_CFG_RX_RING_SIZE */
	);
}

static int xpcxd_fill_info(struct sk_buff *skb,
				 const struct net_device *netdev)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	// int err = 0;

	// xpci_dbg_netdev(netdev, "IN:  RTNL FILL INFO");

	// xpci_dbg_netdev(netdev, "OUT: RTNL FILL INFO");

	return 0;

// nla_put_failure:

	// xpci_dbg_netdev(netdev, "ERROR: RTNL FILL INFO: %d", -EMSGSIZE);
	// return -EMSGSIZE;
}

static bool xpcxd_if_add = false;
static bool xpcxd_add_done = false;
static bool xpcxd_update_done = false;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xpcxd_newlink(struct net *src_net, struct net_device *netdev,
			       struct nlattr *tb[], struct nlattr *data[],
			       struct netlink_ext_ack *extack)
#else
static int xpcxd_newlink(struct net *src_net, struct net_device *netdev,
			       struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct xpcxd_nl_msg nl_msg = { 0 };
	char if_attach_name[] = "xpcxd0";
	struct net_device *ethdev = NULL;
	int ret = 0;

	xpci_dbg("RTNL NEWLINK: IN");

	//rtnl_lock();
	// ret = register_netdevice(netdev);
	// if (ret) {
	// 	xpci_err("Net Device register failed: %d", ret);
	// 	return -ENXIO;
	// }
	//rtnl_unlock();

	xpci_dbg_netdev(ethdev, "RTNL NEWLINK");

	ret = xpcxd_nl_msg_parse(data, &nl_msg);
	if (ret) {
		dev_put(ethdev);
		return ret;
	}

	xpci_dbg("RTNL NEWLINK: Attaching to xpcxd0");

	/* Attach to CPU port Ethernet device */
	ethdev = dev_get_by_name(&init_net, if_attach_name);
	if (!ethdev) {
		xpci_err("Can not attach to interface: [%s]",
				if_attach_name);
		dev_put(ethdev);
		return -ENXIO;
	}

	switch (nl_msg.if_op) {
	case XPCXD_IF_OP_ADD: {
		xpci_dbg_netdev(ethdev, "XPCXD_IF_OP_ADD");

		if (xpcxd_add_done) {
			xpci_err("XPCXD_IF_OP_ADD: Already done");
			dev_put(ethdev);
			return -EEXIST;
		}

		xpcxd_add_done = true;

		/* Check interface section is present  */
		xpci_dbg_netdev(ethdev, "Initializing PCXD HW Net device: [%s]",
				if_attach_name);
		ret = xpcxd_hw_init(nl_msg.num_rings, nl_msg.tx_ring_size,
				    nl_msg.rx_ring_size);
		if (ret) {
			xpci_err_netdev(ethdev,
					"PCXD HW Net Device %s init failed",
					nl_msg.if_name);
			dev_put(ethdev);
			return -ENODEV;
		}

		xpcxd_if_add = true;

		dev_put(ethdev);
	} 
	break;
	case XPCXD_IF_OP_UPDATE: {
		bool if_state = false;

		xpci_dbg_netdev(ethdev, "XPCXD_IF_OP_UPDATE");

		if (!xpcxd_if_add) {
			xpci_err("RTNL NEWLINK: Configuration for non-cerated interface");
			dev_put(ethdev);
			return -ENODEV;
		}

		if (nl_msg.if_state == XPCXD_IF_UP) {
			xpci_dbg_netdev(ethdev, "XPCXD_IF_UP");

			if (xpcxd_update_done) {
				xpci_err("XPCXD_IF_UP: Already UP");
				dev_put(ethdev);
				return -EEXIST;
			}

			ret = xpcxd_hw_activate(true);
			if (ret) {
				xpci_err_netdev(
					ethdev,
					"PCXD HW Net Device %s activation failed",
					nl_msg.if_name);
				dev_put(ethdev);
				return -ENODEV;
			}

			if_state = true;
			xpcxd_update_done = true;
		}
		else {
			xpci_dbg_netdev(ethdev, "XPCXD_IF_DOWN");

			if (!xpcxd_update_done) {
				xpci_err("XPCXD_IF_DOWN: Already DOWN");
				dev_put(ethdev);
				return -ENODEV;
			}

			if_state = false;
			xpcxd_update_done = false;
		}

		xpcxd_set_if_state(ethdev, if_state, if_state);
		dev_put(ethdev);
	} 
	break;
	case XPCXD_IF_OP_DEL: {
		xpci_dbg_netdev(ethdev, "XPCXD_IF_OP_DEL");

		if (!xpcxd_if_add) {
			xpci_err("RTNL NEWLINK: Configuration for non-cerated interface");
			dev_put(ethdev);
			return -ENODEV;
		}

		ret = xpcxd_hw_activate(false);
		if (ret) {
			xpci_err_netdev(
				ethdev,
				"PCXD HW Net Device %s activation failed",
				nl_msg.if_name);
			dev_put(ethdev);
			return -ENODEV;
		}

		xpcxd_set_if_state(ethdev, false, false);
		dev_put(ethdev);

		xpcxd_add_done = false;
		xpcxd_if_add = false;
	} 
	break;
	default:
		xpci_err("Unknown interface operation: [%d]", nl_msg.if_op);
	}

	xpci_dbg_netdev(ethdev, "RTNL NEWLINK: DONE");

	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xpcxd_changelink(struct net_device *netdev,
				  struct nlattr *tb[], struct nlattr *data[],
				  struct netlink_ext_ack *extack)
#else
static int xpcxd_changelink(struct net_device *netdev,
				  struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct xpcxd_nl_msg nl_msg = { 0 };
	char if_attach_name[] = "xpcxd0";
	struct net_device *ethdev = NULL;
	int ret = 0;

	/* Attach to CPU port Ethernet device */
	ethdev = dev_get_by_name(&init_net, if_attach_name);
	if (!ethdev) {
		xpci_err("Can not attach to interface: [%s]", if_attach_name);
		dev_put(ethdev);
		return -ENXIO;
	}

	xpci_dbg_netdev(ethdev, "RTNL CHANGE LINK");

	ret = xpcxd_nl_msg_parse(data, &nl_msg);
	if (ret) {
		dev_put(ethdev);
		return ret;
	}

	if (nl_msg.if_msg) {
		// xpcxd_hw_activate((nl_msg.if_state == XPCXD_IF_UP));
		xpcxd_set_if_state(ethdev, (nl_msg.if_state == XPCXD_IF_UP), true);
	}

	dev_put(ethdev);

	xpci_dbg_netdev(ethdev, "RTNL CHANGE LINK: DONE");

	return 0;
}

static void xpcxd_dellink(struct net_device *netdev,
				struct list_head *head)
{
	xpci_dbg_netdev(netdev, "RTNL DELLINK");

	unregister_netdev(netdev); /* It will call our stop function */

	xpci_dbg_netdev(netdev, "RTNL DELLINK: DONE");
}

static const struct nla_policy xpcxd_policy[IFLA_XPCXD_MAX + 1] = {
	[IFLA_XPCXD_IF_CFG] = { .type = NLA_U32 },
	[IFLA_XPCXD_IF_OP] = { .type = NLA_U8 },
	[IFLA_XPCXD_IF_NAME] = { .type = NLA_STRING,
	                         .len =  XPCXD_IF_NAME_SIZE - 1},
	[IFLA_XPCXD_IF_STATE] = { .type = NLA_U32 },
	[IFLA_XPCXD_IF_MODE] = { .type = NLA_U8 },
	[IFLA_XPCXD_CFG_NUM_OF_RINGS] = { .type = NLA_U8 },
	[IFLA_XPCXD_CFG_TX_RING_SIZE] = { .type = NLA_U16 },
	[IFLA_XPCXD_CFG_RX_RING_SIZE] = { .type = NLA_U16 },
};

static struct rtnl_link_ops xpcxd_link_ops __read_mostly = {
	.kind = "xpci_xpcxd",
	.priv_size = sizeof(struct xpcxd_priv),
	.maxtype = IFLA_XPCXD_MAX,
	.policy = xpcxd_policy,
	.setup = xpcxd_setup,
	.validate = xpcxd_validate,
	.newlink = xpcxd_newlink,
	.changelink = xpcxd_changelink,
	.dellink = xpcxd_dellink,
	.get_size = xpcxd_get_size,
	.fill_info = xpcxd_fill_info
};

int xpcxd_rtnl_link_register(void)
{
	xpci_dbg("PCXD RTNL REGISTER");

	return rtnl_link_register(&xpcxd_link_ops);
}

void xpcxd_rtnl_link_unregister(void)
{
	xpci_dbg("PCXD RTNL UNREGISTER");

	rtnl_link_unregister(&xpcxd_link_ops);
}
