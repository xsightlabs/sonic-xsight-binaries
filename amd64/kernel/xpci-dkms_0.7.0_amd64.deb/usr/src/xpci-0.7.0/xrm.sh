sudo rmmod xpci
