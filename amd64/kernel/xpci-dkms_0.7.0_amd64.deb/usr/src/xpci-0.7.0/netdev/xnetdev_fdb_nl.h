// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device FDB Netlink definitions
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_FDB_NL_
#define XPCI_FDB_NL_

#include <linux/if_ether.h>

#define XPCI_FDB_NL_FAMILY_NAME		"xnetdevNlFamily"
#define XPCI_FDB_NL_GROUP_NAME		"xnetdevNlGroup"

/* xpci netdev fdb event multicast group */
#define XPCI_FDB_NL_GROUP_OFFSET	0

/* XPCI FDB Event netlink commands */
enum {
	XPCI_FDB_NL_CMD_UNSPEC,
	XPCI_FDB_NL_CMD_NOTIFY,
	__XPCI_FDB_NL_CMD_MAX,
};
#define XPCI_FDB_NL_CMD_MAX (__XPCI_FDB_NL_CMD_MAX - 1)

/* XPCI NetDev FDB netlink attributes */
enum {
	XPCI_FDB_NL_ATTR_UNSPEC,
	XPCI_FDB_NL_ATTR_PORT_ID,
	XPCI_FDB_NL_ATTR_MAC,
	XPCI_FDB_NL_ATTR_VLAN_ID,
	XPCI_FDB_NL_ATTR_EVENT_ID,
	__XPCI_FDB_NL_ATTR_MAX,
};
#define XPCI_FDB_NL_ATTR_MAX (__XPCI_FDB_NL_ATTR_MAX - 1)

enum xnetdev_fdb_event {
	XSW_LEARNING_EVENT_UNKNOWN = 0,
	XSW_LEARNING_EVENT_SA_MISS = 1,
	XSW_LEARNING_EVENT_SA_MOVE = 2,
};

struct xnetdev_fdb_key {
	unsigned char addr[ETH_ALEN];
	u16 vlan_id;
};

struct xpci_fdb_event_entry {
	u32 port_id;
	enum xnetdev_fdb_event fdb_event;
	struct xnetdev_fdb_key fdb_key;
};

#endif /* XPCI_FDB_NL_ */
