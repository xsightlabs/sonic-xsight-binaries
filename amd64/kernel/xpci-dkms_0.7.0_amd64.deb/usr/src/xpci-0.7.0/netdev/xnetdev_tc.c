// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device Traffic Control support
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/pkt_cls.h>
#include <net/tc_act/tc_mirred.h>
#include <net/tc_act/tc_sample.h>

#include "xnetdev.h"
#include "xpci_main.h"

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)

#define XNETDEV_SAMPLE_RATE_MAX 8000000

enum xnetdev_mall_action_type {
	XNETDEV_MALL_ACTION_TYPE_SAMPLE,
};

struct xnetdev_mall_entry {
	struct list_head list;
	unsigned long cookie;
	unsigned int priority;
	enum xnetdev_mall_action_type type;
	bool ingress;
	struct xnetdev_port_sample sample;
	struct xnetdev_priv *net_priv;
	struct rcu_head rcu;
};

static void xnetdev_mall_prio_update(struct xnetdev_flow_block *block)
{
	struct xnetdev_mall_entry *mall_entry;

	xpci_dbg_netdev(block->net_priv->netdev, "IN");

	if (list_empty(&block->mall.list))
		return;
	block->mall.min_prio = UINT_MAX;
	block->mall.max_prio = 0;
	list_for_each_entry(mall_entry, &block->mall.list, list) {
		if (mall_entry->priority < block->mall.min_prio)
			block->mall.min_prio = mall_entry->priority;
		if (mall_entry->priority > block->mall.max_prio)
			block->mall.max_prio = mall_entry->priority;
	}

	xpci_dbg_netdev(block->net_priv->netdev, "OUT");
}

int xnetdev_mall_replace(struct xnetdev_priv *net_priv,
			  struct xnetdev_flow_block *block,
			  struct tc_cls_matchall_offload *f)
{
	struct xnetdev_mall_entry *mall_entry;
	__be16 protocol = f->common.protocol;
	struct flow_action_entry *act;
	unsigned int flower_min_prio;
	// unsigned int flower_max_prio;
	bool flower_prio_valid;
	int err;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	if (!flow_offload_has_one_action(&f->rule->action)) {
		xpci_err_netdev(net_priv->netdev, "Only singular actions are supported");
		return -EOPNOTSUPP;
	}

	if (f->common.chain_index) {
		xpci_err_netdev(net_priv->netdev, "Only chain 0 is supported");
		return -EOPNOTSUPP;
	}

	if (block->ingress_binding_count && block->egress_binding_count) {
		xpci_err_netdev(net_priv->netdev, "Only not mixed bound blocks are supported");
		return -EOPNOTSUPP;
	}

	mall_entry = kzalloc(sizeof(*mall_entry), GFP_KERNEL);
	if (!mall_entry)
		return -ENOMEM;
	mall_entry->cookie = f->cookie;
	mall_entry->priority = f->common.prio;
	mall_entry->ingress = block->ingress_binding_count;

	act = &f->rule->action.entries[0];

	if (act->id == FLOW_ACTION_SAMPLE &&
		   protocol == htons(ETH_P_ALL)) {
		if (!mall_entry->ingress) {
			xpci_err_netdev(net_priv->netdev, "Sample is not supported on egress");
			err = -EOPNOTSUPP;
			goto errout;
		}
		if (flower_prio_valid &&
		    mall_entry->priority >= flower_min_prio) {
			xpci_err_netdev(net_priv->netdev, "Failed to add behind existing flower rules");
			err = -EOPNOTSUPP;
			goto errout;
		}
		if (act->sample.rate > XNETDEV_SAMPLE_RATE_MAX) {
			xpci_err_netdev(net_priv->netdev, "Sample rate not supported");
			err = -EOPNOTSUPP;
			goto errout;
		}
		mall_entry->type = XNETDEV_MALL_ACTION_TYPE_SAMPLE;
		mall_entry->sample.psample_group = act->sample.psample_group;
		mall_entry->sample.truncate = act->sample.truncate;
		mall_entry->sample.trunc_size = act->sample.trunc_size;
		mall_entry->sample.rate = act->sample.rate;

		net_priv->sample = &mall_entry->sample;

		xpci_dbg_netdev(net_priv->netdev, "Action SAMPLE(%p): truncate: [%s] trunc_size: [%d] rate: [%d]",
			net_priv->sample, mall_entry->sample.truncate?"YES":"NO", mall_entry->sample.trunc_size, mall_entry->sample.rate);
	} else {
		err = -EOPNOTSUPP;
		goto errout;
	}

	block->rule_count++;
	if (mall_entry->ingress)
		block->egress_blocker_rule_count++;
	else
		block->ingress_blocker_rule_count++;

	list_add_tail(&mall_entry->list, &block->mall.list);
	xnetdev_mall_prio_update(block);

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return 0;

errout:
	xpci_dbg_netdev(net_priv->netdev, "ERR_OUT");

	kfree(mall_entry);
	return err;
}

static struct xnetdev_mall_entry *
xnetdev_mall_entry_find(struct xnetdev_flow_block *block,
			    unsigned long cookie)
{
	struct xnetdev_mall_entry *mall_entry;

	xpci_dbg_netdev(block->net_priv->netdev, "IN");

	list_for_each_entry (mall_entry, &block->mall.list, list)
		if (mall_entry->cookie == cookie) {
			xpci_dbg_netdev(block->net_priv->netdev, "OUT: %p",
					mall_entry);
			return mall_entry;
		}

	xpci_dbg_netdev(block->net_priv->netdev, "OUT_NULL");

	return NULL;
}

void xnetdev_mall_destroy(struct xnetdev_flow_block *block,
			      struct tc_cls_matchall_offload *f)
{
	struct xnetdev_mall_entry *mall_entry;

	xpci_dbg_netdev(block->net_priv->netdev, "IN");

	mall_entry = xnetdev_mall_entry_find(block, f->cookie);
	if (!mall_entry) {
		xpci_dbg("Entry not found");
		return;
	}

	list_del(&mall_entry->list);
	if (mall_entry->ingress)
		block->egress_blocker_rule_count--;
	else
		block->ingress_blocker_rule_count--;

	block->rule_count--;

	kfree_rcu(mall_entry, rcu); /* sample RX packets may be in-flight */
	xnetdev_mall_prio_update(block);

	xpci_dbg_netdev(block->net_priv->netdev, "OUT");
}

static int
xnetdev_flow_block_mall_cb(struct xnetdev_flow_block *flow_block,
			       struct tc_cls_matchall_offload *f)
{
	struct xnetdev_priv *net_priv = flow_block->net_priv;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	switch (f->command) {
	case TC_CLSMATCHALL_REPLACE:
		return xnetdev_mall_replace(net_priv, flow_block, f);
	case TC_CLSMATCHALL_DESTROY:
		xnetdev_mall_destroy(flow_block, f);
		break;
	default:
		xpci_err_netdev(net_priv->netdev, "Noy supported");
		return -EOPNOTSUPP;
	}

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return 0;
}

static int xnetdev_flow_block_cb(enum tc_setup_type type, void *type_data,
				     void *cb_priv)
{
	struct xnetdev_flow_block *flow_block = cb_priv;

	xpci_dbg_netdev(flow_block->net_priv->netdev, "IN");

	if (flow_block->disable_count)
		return -EOPNOTSUPP;

	switch (type) {
	case TC_SETUP_CLSMATCHALL:
		return xnetdev_flow_block_mall_cb(flow_block, type_data);
	default:
		xpci_err_netdev(flow_block->net_priv->netdev, "Noy supported");
		return -EOPNOTSUPP;
	}

	xpci_dbg_netdev(flow_block->net_priv->netdev, "OUT");
}

struct xnetdev_flow_block *
xnetdev_flow_block_create(struct xnetdev_priv *net_priv,
			      struct net *net)
{
	struct xnetdev_flow_block *block;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	block = kzalloc(sizeof(*block), GFP_KERNEL);
	if (!block)
		return NULL;
	INIT_LIST_HEAD(&block->binding_list);
	INIT_LIST_HEAD(&block->mall.list);
	block->net_priv = net_priv;
	block->net = net;

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return block;
}

void xnetdev_flow_block_destroy(struct xnetdev_flow_block *block)
{
	xpci_dbg_netdev(block->net_priv->netdev, "IN");

	WARN_ON(!list_empty(&block->binding_list));
	kfree(block);

	xpci_dbg_netdev(block->net_priv->netdev, "OUT");
}

static struct xnetdev_flow_block_binding *
xnetdev_flow_block_lookup(struct xnetdev_flow_block *block,
			      struct xnetdev_priv *net_priv, bool ingress)
{
	struct xnetdev_flow_block_binding *binding;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	list_for_each_entry (binding, &block->binding_list, list)
		if (binding->net_priv == net_priv &&
		    binding->ingress == ingress)
			return binding;

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return NULL;
}

static void xnetdev_tc_block_release(void *cb_priv)
{
	struct xnetdev_flow_block *flow_block = cb_priv;

	xpci_dbg_netdev(flow_block->net_priv->netdev, "IN");

	xnetdev_flow_block_destroy(flow_block);

	xpci_dbg_netdev(flow_block->net_priv->netdev, "OUT");
}

static LIST_HEAD(xnetdev_block_cb_list);

static int xnetdev_flow_block_bind(struct xnetdev_priv *net_priv,
				       struct xnetdev_flow_block *block,
				       bool ingress,
				       struct netlink_ext_ack *extack)
{
	struct xnetdev_flow_block_binding *binding;
	int err;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	if (WARN_ON(xnetdev_flow_block_lookup(block, net_priv, ingress)))
		return -EEXIST;

	if (!ingress) {
		xpci_err_netdev(net_priv->netdev,
				"Bound to egress is not supported");
		return -EOPNOTSUPP;
	}

	if (ingress && block->ingress_blocker_rule_count) {
		xpci_err_netdev(
			net_priv->netdev,
			"Block cannot be bound to ingress because it contains unsupported rules");
		return -EOPNOTSUPP;
	}

	binding = kzalloc(sizeof(*binding), GFP_KERNEL);
	if (!binding) {
		err = -ENOMEM;
		goto err_binding_alloc;
	}
	binding->net_priv = net_priv;
	binding->ingress = ingress;

	if (ingress)
		block->ingress_binding_count++;

	list_add(&binding->list, &block->binding_list);

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return 0;

err_binding_alloc:

	xpci_dbg_netdev(net_priv->netdev, "OUT-ERR");

	return err;
}

static int xnetdev_flow_block_unbind(struct xnetdev_priv *net_priv,
					 struct xnetdev_flow_block *block,
					 bool ingress)
{
	struct xnetdev_flow_block_binding *binding;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	binding = xnetdev_flow_block_lookup(block, net_priv, ingress);
	if (!binding)
		return -ENOENT;

	list_del(&binding->list);

	if (ingress)
		block->ingress_binding_count--;

	kfree(binding);

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return 0;
}

static int xnetdev_setup_tc_block_bind(struct xnetdev_priv *net_priv,
					   struct flow_block_offload *f,
					   bool ingress)
{
	struct xnetdev_flow_block *flow_block;
	struct flow_block_cb *block_cb;
	bool register_block = false;
	int err;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	block_cb = flow_block_cb_lookup(f->block, xnetdev_flow_block_cb,
					net_priv);
	if (!block_cb) {
		flow_block = xnetdev_flow_block_create(net_priv, f->net);
		if (!flow_block)
			return -ENOMEM;
		block_cb = flow_block_cb_alloc(xnetdev_flow_block_cb,
					       net_priv, flow_block,
					       xnetdev_tc_block_release);
		if (IS_ERR(block_cb)) {
			xnetdev_flow_block_destroy(flow_block);
			return PTR_ERR(block_cb);
		}
		register_block = true;
	} else {
		flow_block = flow_block_cb_priv(block_cb);
	}
	flow_block_cb_incref(block_cb);
	err = xnetdev_flow_block_bind(net_priv, flow_block, ingress,
					  f->extack);
	if (err)
		goto err_block_bind;

	if (ingress)
		net_priv->ing_flow_block = flow_block;
	else
		net_priv->eg_flow_block = flow_block;

	if (register_block) {
		flow_block_cb_add(block_cb, f);
		list_add_tail(&block_cb->driver_list,
			      &xnetdev_block_cb_list);
	}

	xpci_dbg_netdev(net_priv->netdev, "OUT");

	return 0;

err_block_bind:
	if (!flow_block_cb_decref(block_cb))
		flow_block_cb_free(block_cb);

	xpci_dbg_netdev(net_priv->netdev, "OUT-ERR");

	return err;
}

static void xnetdev_setup_tc_block_unbind(struct xnetdev_priv *net_priv,
					      struct flow_block_offload *f,
					      bool ingress)
{
	struct xnetdev_flow_block *flow_block;
	struct flow_block_cb *block_cb;
	int err;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	block_cb = flow_block_cb_lookup(f->block, xnetdev_flow_block_cb,
					net_priv);
	if (!block_cb)
		return;

	if (ingress)
		net_priv->ing_flow_block = NULL;
	else
		net_priv->eg_flow_block = NULL;

	flow_block = flow_block_cb_priv(block_cb);
	err = xnetdev_flow_block_unbind(net_priv, flow_block, ingress);
	if (!err && !flow_block_cb_decref(block_cb)) {
		flow_block_cb_remove(block_cb, f);
		list_del(&block_cb->driver_list);
	}

	xpci_dbg_netdev(net_priv->netdev, "OUT");
}

int xnetdev_setup_tc_block_clsact(struct xnetdev_priv *net_priv,
				      struct flow_block_offload *f,
				      bool ingress)
{
	f->driver_block_list = &xnetdev_block_cb_list;

	xpci_dbg_netdev(net_priv->netdev, "IN");

	switch (f->command) {
	case FLOW_BLOCK_BIND:
		return xnetdev_setup_tc_block_bind(net_priv, f, ingress);
	case FLOW_BLOCK_UNBIND:
		xnetdev_setup_tc_block_unbind(net_priv, f, ingress);
		xpci_dbg_netdev(net_priv->netdev, "UNBIND_OUT");
		return 0;
	default:
		xpci_err_netdev(net_priv->netdev, "Not supported command: %d",
				f->command);
		return -EOPNOTSUPP;
	}

	xpci_dbg_netdev(net_priv->netdev, "OUT");
}

static int xnetdev_setup_tc_block(struct xnetdev_priv *net_priv,
				      struct flow_block_offload *f)
{
	xpci_dbg_netdev(net_priv->netdev, "IN");

	switch (f->binder_type) {
	case FLOW_BLOCK_BINDER_TYPE_CLSACT_INGRESS:
		return xnetdev_setup_tc_block_clsact(net_priv, f, true);
	default:
		xpci_err_netdev(net_priv->netdev,
				"Not supported binder type: %d",
				f->binder_type);
		return -EOPNOTSUPP;
	}
}

int xnetdev_setup_tc(struct net_device *netdev, enum tc_setup_type type,
			 void *type_data)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);

	xpci_dbg_netdev(net_priv->netdev, "IN");

	switch (type) {
	case TC_SETUP_BLOCK:
		return xnetdev_setup_tc_block(net_priv, type_data);
	default:
		xpci_err_netdev(net_priv->netdev, "Not supported tc type: %d",
				type);
		return -EOPNOTSUPP;
	}

	xpci_dbg_netdev(net_priv->netdev, "OUT");
}
#endif