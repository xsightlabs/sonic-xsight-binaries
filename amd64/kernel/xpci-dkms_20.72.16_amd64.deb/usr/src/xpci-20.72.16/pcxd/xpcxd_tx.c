// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver TX handling
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/icmp.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>
#include <linux/icmpv6.h>
#include <linux/prefetch.h>
#include <linux/string.h>
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/sch_generic.h>

#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xpci_trace.h"
#include "xnetdev_common.h"
#include "xpcxd.h"
#include "xpcxd_os.h"
#if IS_ENABLED(CONFIG_BPF_SYSCALL)
#include <net/xdp.h>
#endif

extern bool hw_ready;
extern int xpcxd_loopback;
extern int xpcxd_ring_threshold;
extern int xpcxd_rx_ring_threshold_stop;
extern int xpcxd_tx_packets_stop;
extern int xpcxd_tx_drop_on_alignment_err;
extern int xpcxd_tx_stats_uc_mc_bc;

/* Internal fixed defaults (no module params) */
static int xpcxd_tx_sbm_rfl_mode = XPCXD_TX_SBM_RFL_MODE_DEFAULT;
static int xpcxd_tx_cmp_rfl_mode = XPCXD_TX_CMP_RFL_MODE_DEFAULT;

extern ktime_t tx_coalescing_ktime;
extern int xpcxd_tx_coales_isr_mode;
extern int xpcxd_tx_db_batch;
extern uint xpcxd_cfg_tbl[xpcxd_last_cfg_item];

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx);
extern void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
		     enum xpci_tx_rx tx_rx, u32 stop_val, char *msg);

/*
 * Size of the tunnel+shim header carried by CPU Tx frames, derived from
 * the outer EtherType; 0 when the frame is not shim-framed.
 *
 * HW strips these bytes before the frame reaches the wire, so this is
 * both the amount to pull for L3/L4 parsing and the difference between
 * skb->len and the resulting on-wire length.
 */
static inline u16 xpcxd_tx_shim_hdr_size(__be16 protocol)
{
	if (likely(protocol == htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS)))
		return XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_HDR_SIZE;

	if (protocol == htons(XSW_SHIM_HEADER_ETHTYPE_INJECT))
		return XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_INJECT_HDR_SIZE;

	return 0;
}

/*
 * Dump the bytes that follow the packet in the buffer HW is given.
 * xpci_print_pkt() stops at skb->len, so the region an overread would put on
 * the wire is exactly what it never shows.
 */
#define XPCXD_TX_TAIL_DUMP_LEN	16

static void xpcxd_tx_print_tail(const char *trace_point,
				struct net_device *netdev, const void *buf,
				u32 used, u32 capacity)
{
	u32 len;

	if (!buf || capacity <= used) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
				 "%s: no tail: len=%u capacity=%u", trace_point,
				 used, capacity);
		return;
	}

	len = min_t(u32, XPCXD_TX_TAIL_DUMP_LEN, capacity - used);
	xprint_hex_dump(netdev, trace_point, DUMP_PREFIX_OFFSET, 16, 1,
			(const u8 *)buf + used, len, true);
}

/*
 * Pad a CPU Tx frame so the inner Ethernet frame still meets ETH_ZLEN
 * (60) once HW has stripped the tunnel+shim header.
 *
 * skb->len at this point includes the shim, which HW removes before the
 * frame reaches the wire, so padding the outer skb to ETH_ZLEN would
 * count the shim towards the minimum: a 42B ARP arrives as 58B, gains
 * 2B of pad, and leaves the strip as a 44B frame. What was observed on
 * the wire in that case is a 60B frame whose trailing bytes are not
 * zeros (e.g. 0x04 at offset 0x2F). The egress MAC is confirmed to
 * zero-pad per 802.3, so it never saw a 44B frame: the extension back
 * to 60 happens ahead of it and re-reads the buffer rather than
 * inserting zeros.
 *
 * Padding to shim size + ETH_ZLEN hands over a frame that is already at
 * the minimum after the strip, with a tail that skb_put_padto() has
 * zero-filled.
 *
 * Hostif frames are padded by xnetdev_xmit() before the shim push and
 * arrive here at exactly that length, so they are not padded twice.
 * This is still required for senders that never traverse xnetdev,
 * notably the control plane writing shim-framed packets straight to the
 * CPU port socket.
 *
 * Must run before the buffer is committed, i.e. before the Tx pool slot
 * is chosen and before the DMA map, since both use skb->len.
 *
 * Returns 0 on success, -ENOMEM on failure. On failure skb_put_padto()
 * has already freed the skb and the caller must not touch it again.
 */
static int xpcxd_tx_pad_inner_zlen(struct net_device *netdev,
				   struct sk_buff *skb, u32 ring_id,
				   __be16 protocol)
{
	u16 shim_hdr_size = xpcxd_tx_shim_hdr_size(protocol);
	u32 min_len = shim_hdr_size + ETH_ZLEN;
	unsigned int orig_len = skb->len;
	bool dump_pkt = (xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
			(xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED);

	if (likely(skb->len >= min_len))
		return 0;

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD TX: skb: [%p] Pad inner to ETH_ZLEN: len=%u shim=%u pad=%u -> %u",
		ring_id, skb, orig_len, shim_hdr_size,
		min_len - orig_len, min_len);

	if (unlikely(dump_pkt))
		xpci_print_pkt("short-TX-before", netdev, skb, TX_OFFSET,
			       xpci_tx);

	if (unlikely(skb_put_padto(skb, min_len))) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
				 "---> [%d] PCXD TX: skb_put_padto(%u) failed",
				 ring_id, min_len);
		return -ENOMEM;
	}

	if (unlikely(dump_pkt))
		xpci_print_pkt("short-TX-after", netdev, skb, TX_OFFSET,
			       xpci_tx);

	return 0;
}

static bool xpcxd_tx_is_ipv6_mld(struct sk_buff *skb)
{
	const struct ethhdr *eth;
	const struct vlan_ethhdr *veh;
	const struct ipv6hdr *ip6h;
	const struct icmp6hdr *icmp6h;
	__be16 l3_proto;
	u16 l3_off = ETH_HLEN;

	if (!pskb_may_pull(skb, ETH_HLEN))
		return false;

	eth = (const struct ethhdr *)skb->data;
	l3_proto = eth->h_proto;
	if (l3_proto == htons(ETH_P_8021Q) || l3_proto == htons(ETH_P_8021AD)) {
		l3_off = VLAN_ETH_HLEN;
		if (!pskb_may_pull(skb, l3_off))
			return false;
		veh = (const struct vlan_ethhdr *)skb->data;
		l3_proto = veh->h_vlan_encapsulated_proto;
	}

	if (l3_proto != htons(ETH_P_IPV6))
		return false;

	if (!pskb_may_pull(skb, l3_off + sizeof(*ip6h)))
		return false;
	ip6h = (const struct ipv6hdr *)(skb->data + l3_off);
	if (ip6h->nexthdr != IPPROTO_ICMPV6)
		return false;

	if (!pskb_may_pull(skb, l3_off + sizeof(*ip6h) + sizeof(*icmp6h)))
		return false;
	icmp6h = (const struct icmp6hdr *)(skb->data + l3_off + sizeof(*ip6h));

	switch (icmp6h->icmp6_type) {
	case ICMPV6_MGM_QUERY:
	case ICMPV6_MGM_REPORT:
	case ICMPV6_MGM_REDUCTION:
	case ICMPV6_MLD2_REPORT:
		return true;
	default:
		return false;
	}
}

static u16 xpcxd_get_tx_sbm_cns_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_cns = NULL;
	u16 sbm_prd_ptr = 0;
	u32 ret = 0;

	if (xpcxd_tx_sbm_rfl_mode) {
		xpcxd_dma_rmb();

		rfl_cns = net_priv->txr[ring_id].sub.rfl_cns;

		sbm_prd_ptr = rfl_cns->ring_index_tail & net_priv->txr[ring_id].sub.mask;
	} else {
		u8 row[XREG_MEMCFG_RNG_STTS_ROW_BYTES];
		u64 row_lo = 0;

		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(row) /* Size */,
			row);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return 0;
		}

		memcpy(&row_lo, row, sizeof(row_lo));
		sbm_prd_ptr = xreg_memcfg_rng_stts_srd_cns_ptr(row_lo);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD SUB TX: TX_RNG_STTS_TBL_SRD_CNS_PTR_GET: 0x%x | %u --> mask: %u",
			sbm_prd_ptr, sbm_prd_ptr, sbm_prd_ptr & net_priv->txr[ring_id].sub.mask);
		sbm_prd_ptr = sbm_prd_ptr & net_priv->txr[ring_id].sub.mask;
	}

	return sbm_prd_ptr;
}

u16 xpcxd_get_tx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd = NULL;
	u16 cmpl_prd_ptr = 0;
	int ret;

	if (xpcxd_tx_cmp_rfl_mode) {
		xpcxd_dma_rmb();

		rfl_prd = net_priv->txr[ring_id].cmp.rfl_prd;

		cmpl_prd_ptr = rfl_prd->ring_index_head & net_priv->txr[ring_id].cmp.mask;
	} else {
		struct xpcxd_ring *txr = &net_priv->txr[ring_id];
		u8 row[XREG_MEMCFG_RNG_STTS_ROW_BYTES];
		u64 row_lo = 0;

		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_TX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(row) /* Size */,
			row);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV,
				  "TX_RNG_STTS xdrv_mem_ind_read() failed: %d (using cached cmpl_prd_ptr)",
				  ret);
			return txr->cmp.cmpl_prd_ptr;
		}

		memcpy(&row_lo, row, sizeof(row_lo));
		cmpl_prd_ptr = xreg_memcfg_rng_stts_crd_prd_ptr(row_lo);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV, netdev,
			"---> PCXD CMPL TX: TX_RNG_STTS_TBL_CRD_PRD_PTR: 0x%x | %u",
			cmpl_prd_ptr, cmpl_prd_ptr);
	}

	return cmpl_prd_ptr;
}

static void xpcxd_tx_db_write(struct net_device *netdev, u16 ring_id,
			      u16 prod_idx)
{
	const struct xreg_profile *p = xreg_get_profile();
	const struct xreg_desc *d = &p->table[XREG_ID_PCXD_TX_DB];
	u32 db_addr;
	u64 v = 0;

	xpcxd_opt_trace(tx_db_write, ring_id, 0, 0, 0, prod_idx);

	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_RIND_ID, ring_id);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_MODE, 0);
	xreg_field_put_idx(&v, d, XREG_FIELD_PCXD_TX_DB_VALUE, prod_idx);

	db_addr = xreg_addr(p, XREG_ID_PCXD_TX_DB, 0, 0);
	xpci_write64_fast(db_addr, v);
}

/*
 * Flush a deferred Tx doorbell for @txr. Caller MUST hold txr->tx_lock.
 * No-op when nothing is pending. Used by:
 *   - end of xpcxd_xmit() (normal path + tx_drop cleanup)
 *   - xpcxd_ring_tx_coales_isr() as a safety flush paired with the
 *     deferred-DB policy (netdev_xmit_more() batching).
 *
 * Issues a single xpcxd_dma_wmb() before the DB write: that publishes
 * every descriptor that was enqueued since the previous flush.
 */
static inline void xpcxd_tx_db_flush_locked(struct net_device *netdev,
					    struct xpcxd_ring *txr)
{
	u16 pending = txr->sub_desc_pending;

	if (pending == 0)
		return;

	txr->sub_desc_pending = 0;
	txr->db_count = 0;
	xpcxd_dma_wmb();
	xpcxd_tx_db_write(netdev, txr->ring_id, pending);
}

enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer)
{
	struct xpcxd_ring *ring;

	ring = container_of(timer, struct xpcxd_ring, tx_coales_isr);

	hrtimer_forward_now(timer, tx_coalescing_ktime);

	/*
	 * Safety flush paired with the deferred-DB policy in xpcxd_xmit().
	 */
	spin_lock(&ring->tx_lock);
	xpcxd_tx_db_flush_locked(NULL, ring);
	spin_unlock(&ring->tx_lock);

	return HRTIMER_RESTART;
}

/*
 * Flush any deferred Tx doorbell on @txr from process context. Used by the
 * live disarm of Tx doorbell coalescing (pcxd_tx_coales_isr_mode 1 -> 0) to
 * drain a tail that a concurrent xmit may have deferred just before the mode
 * flipped. The datapath takes tx_lock from softirq/BH (xpcxd_xmit is called
 * with BH disabled; the tail-flush timer is a SOFT hrtimer), so disable BH
 * here to avoid a self-deadlock against that context on the same CPU.
 */
void xpcxd_tx_db_flush_ring_bh(struct net_device *netdev,
			      struct xpcxd_ring *txr)
{
	spin_lock_bh(&txr->tx_lock);
	xpcxd_tx_db_flush_locked(netdev, txr);
	spin_unlock_bh(&txr->tx_lock);
}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
static u64 prev_tx_underflow_cnt = 0;
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

#ifdef __XPCXD_ICMP_TRACE__
void xpcxd_check_icmp_echo(struct sk_buff *skb, struct net_device *netdev)
{
    struct iphdr *iph;
    struct icmphdr *icmph;

    if (!skb)
        return;

    if (!skb_mac_header_was_set(skb))
        return;

    if (!pskb_may_pull(skb, sizeof(struct iphdr)))
        return;

    iph = ip_hdr(skb);

    if (iph->protocol != IPPROTO_ICMP)
        return;

    if (!pskb_may_pull(skb, ip_hdrlen(skb) + sizeof(struct icmphdr)))
        return;

    icmph = (struct icmphdr *)(skb_transport_header(skb));

    if (icmph->type == ICMP_ECHO) {
		xpcxd_opt_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
        xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
				"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
				skb,
				skb->len,
                ntohs(icmph->un.echo.id),
                ntohs(icmph->un.echo.sequence));
    }

	switch (icmph->type) {
        case ICMP_ECHO:
			xpcxd_opt_trace(tx_pkt_icmp_req, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Request: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        case ICMP_ECHOREPLY:
			xpcxd_opt_trace(tx_pkt_icmp_reply, 0, skb, skb->len, ntohs(icmph->un.echo.id), ntohs(icmph->un.echo.sequence));
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, CLR_LIGHT_BLUE
					"ICMP Echo Reply: skb: [%p] len: [%d] ID=[%u], SEQ=[%u]" CLR_RST,
					skb,
					skb->len,
					ntohs(icmph->un.echo.id),
					ntohs(icmph->un.echo.sequence));
            break;
        default:
            break;
    }
}
#endif /* __XPCXD_ICMP_TRACE__ */

/* net device transmit always called with BH disabled user __netif_tx_lock */
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr = NULL;
	struct xpcxd_sw_desc *sw_desc = NULL;
	struct xpcxd_desc tx_md = { 0 };
	struct xpcxd_desc tx_bd = { 0 };
	struct xpcxd_desc tx_bd2 = { 0 }; /* 2nd BD: aligned data (multi-BD path) */
	/*
	 * Multi-BD 64/256 alignment compensation state. When skb->data is
	 * not xpcxd_tx_align-aligned and the frame is large enough, we emit
	 * two BDs under one MD instead of allocating+copying a realigned skb:
	 *   BD0 - empty (len=0) compensation descriptor anchored at the
	 *         tx_align-aligned base (skb->data rounded down by mbd_off).
	 *         The device consumes it to skip the leading mbd_off
	 *         sub-alignment bytes.
	 *   BD1 - the real data, also anchored at that aligned base with
	 *         len = mbd_off + skb->len, so the source address the device
	 *         receives is perfectly tx_align-aligned and the emitted
	 *         frame begins exactly at skb->data.
	 * mbd_off is the sub-alignment offset (skb->data & (tx_align-1)); it
	 * is the number of leading headroom bytes the empty BD compensates.
	 */
	bool use_multi_bd = false;
	u32 mbd_off = 0;
	u16 ring_space = 0;
	u16 prod_idx = 0;
	u16 num_desc = 0;
	u32 ring_id;
	u16 total_desc_batch = 0; /* descriptors enqueued in this batch, doorbell once at end */
	dma_addr_t dma_addr = { 0 };
	netdev_tx_t tx_ret = NETDEV_TX_OK;
	bool check_l3_checksum = false;
	bool check_l4_checksum = false;
	__be16 protocol = 0;
	const struct ethhdr *eth = NULL;
	const struct iphdr *iph = NULL;
	const struct ipv6hdr *ip6h = NULL;
	u16 eth_len = 0;
	u16 l3_offset = 0;
	u16 shim_hdr_size = 0;
	bool trimmed = false;
	__be16 l4_protocol = 0;

	u32 batch_pkts = 0;
	u64 batch_bytes = 0;
	u32 batch_uc = 0;
	u32 batch_mc = 0;
	u32 batch_bc = 0;
	u32 batch_vlan = 0;
	u32 batch_align_err = 0;
	u32 batch_realign = 0;
	u32 batch_realign_mbd = 0;
	u32 batch_realign_mbd_fallback = 0;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	u32 batch_sz64_128 = 0;
	u32 batch_sz128_256 = 0;
	u32 batch_sz256_plus = 0;
#endif
	bool use_pool = false;
	u32 last_skb_len = 0;
	/* Buffer handed to HW - pool slot or skb->data - for the tail dump. */
	const void *tx_buf = NULL;
	u32 tx_buf_size = 0;
	const u32 tx_align = xpcxd_tx_align;
	bool dma_mapped = false;
	bool pkt_published = false;
	u32 map_len = 0;

	if (!hw_ready) {
		xpcxd_info_netdev(NETIF_MSG_TX_ERR, netdev,
				 "---> PCXD TX: HW is not ready");
		dev_kfree_skb_any(skb);
		return tx_ret;
	}

	if (unlikely(!net_priv->num_rings)) {
		xpcxd_info_netdev(NETIF_MSG_TX_ERR, netdev,
				  "---> PCXD TX: no rings configured");
		dev_kfree_skb_any(skb);
		return tx_ret;
	}

	ring_id = skb_get_queue_mapping(skb) % net_priv->num_rings;
	txr = &net_priv->txr[ring_id];

	if (xpcxd_cfg_tbl[xpcxd_tx_drop_all]) {
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		return tx_ret;
	}

	if (unlikely(!READ_ONCE(txr->sub.sw))) {
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		return NETDEV_TX_OK;
	}

	spin_lock(&txr->tx_lock);

	txr->db_count++;

	/*
	 * Lazy SUB cns refresh. xpcxd_get_tx_sbm_cns_ptr() does the
	 * MMIO/RFL read (memcfg mode) or coherent-DMA load + dma_rmb()
	 * (RFL mode); on ARM with non-cached coherent mappings that is
	 * an uncached load (~150-300 ns) that we used to pay on every
	 * xmit call.
	 *
	 * The cached value in txr->sub.sub_cns_ptr only grows staler in
	 * one direction: HW is consuming, so real free space is always
	 * >= what we compute from the cache. That means we only need to
	 * refresh when our cached view of free space is getting low;
	 * while the ring has plenty of headroom we can reuse the stale
	 * cache and skip the MMIO/uncached read entirely.
	 *
	 * Threshold: 1/4 of the ring. Well above XPCXD_TX_STOP_THOLD so
	 * xmit_more batching can keep flowing without blocking, and low
	 * enough that we refresh in time to see space free up before we
	 * would actually drop.
	 */
	if (xpcxd_get_tx_sub_ring_space(txr) < (u32)(txr->sub.size >> 2))
		txr->sub.sub_cns_ptr =
			xpcxd_get_tx_sbm_cns_ptr(netdev, ring_id);

	prod_idx = txr->sub.prod;

	xpcxd_opt_trace(tx_xmit, ring_id, skb, skb->len, prod_idx, txr->sub.sub_cns_ptr);

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX", netdev, skb, TX_OFFSET, xpci_tx);

	protocol = vlan_get_protocol(skb);
	/*
	 * Optional guard (enabled by default via ethtool private flag):
	 * drop LLDP frames that are not carried with the expected PCXD shim
	 * EtherTypes, before publishing any Tx descriptors.
	 */
	if (unlikely((net_priv->priv_flags & XPCXD_FLAG_DROP_TX_LLDP_NON_SHIM) &&
		     protocol == htons(XSW_ETHTYPE_LLDP) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_INJECT))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev,
				 "Drop non-shim Tx LLDP: ring=%u skb=%p proto=0x%x",
				 ring_id, skb, ntohs(protocol));
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		spin_unlock(&txr->tx_lock);
		return NETDEV_TX_OK;
	}
	/*
	 * Optional guard (enabled by default via ethtool private flag):
	 * drop IPv6 MLD control traffic unless it is wrapped by the expected
	 * PCXD shim EtherTypes, before publishing any Tx descriptors.
	 */
	if (unlikely((net_priv->priv_flags & XPCXD_FLAG_DROP_TX_MLD_NON_SHIM) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_EGRESS) &&
		     protocol != htons(XSW_SHIM_HEADER_ETHTYPE_INJECT) &&
		     xpcxd_tx_is_ipv6_mld(skb))) {
		xpcxd_dbg_netdev(NETIF_MSG_TX_ERR, netdev,
				 "Drop non-shim Tx IPv6 MLD: ring=%u skb=%p proto=0x%x",
				 ring_id, skb, ntohs(protocol));
		dev_kfree_skb_any(skb);
		txr->stats.dropped++;
		spin_unlock(&txr->tx_lock);
		return NETDEV_TX_OK;
	}

	if (!netif_carrier_ok(netdev)) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD TX: skb: [%p] Carrier off --> drop",
				ring_id, skb);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	/* Frees the skb on failure, hence the NULL before tx_drop. */
	if (unlikely(xpcxd_tx_pad_inner_zlen(netdev, skb, ring_id, protocol))) {
		skb = NULL;
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	/*
	 * Pool fast path decision. Must be after inner ETH_ZLEN pad so
	 * skb->len reflects the on-wire length (the slot only needs to
	 * hold what we memcpy). Packets whose padded length exceeds the
	 * ring's slot (jumbo, or any outsize packet on a small-slot
	 * config) fall back to the legacy dma_map_single() path for
	 * that packet; rings without a pool (vaddr == NULL) always use
	 * legacy.
	 */
	use_pool = likely(txr->tx_pool.blk_vaddr) &&
		   (skb->len <= txr->tx_pool.slot_size);

	/*
	 * Legacy-only realignment: the pool slot is tx_align-aligned by
	 * construction, so the pool path never needs the alloc+memcpy+free
	 * realignment dance.
	 */
	if (!use_pool && ((uintptr_t)skb->data & (tx_align - 1))) {
		struct sk_buff *new_skb;
		u32 off = (u32)((uintptr_t)skb->data & (tx_align - 1));
		unsigned long base_va = (unsigned long)skb->data - off;
		unsigned long read_last = (unsigned long)skb->data + skb->len - 1;

		/*
		 * Multi-BD empty-BD 64/256 alignment compensation (preferred,
		 * zero-copy). Instead of allocating an aligned skb and copying
		 * the whole payload, keep the skb as-is and present the device
		 * with two descriptors under one MD:
		 *  - BD0: an empty (len=0) descriptor at the tx_align-aligned
		 *    base (skb->data rounded down by off). The device consumes
		 *    it to compensate the leading off sub-alignment bytes.
		 *  - BD1: the real data, also anchored at that aligned base with
		 *    len = off + skb->len, so the source address the device
		 *    receives is perfectly tx_align-aligned and the emitted
		 *    frame begins exactly at skb->data.
		 * Conditions:
		 *  - real payload >= XPCXD_TX_MULTI_BD_MIN_BULK bytes;
		 *  - the off compensation bytes lie within the skb's own
		 *    headroom (base >= skb->head) so the DMA map we extend down
		 *    to base stays in-bounds;
		 *  - the [base, skb->data+skb->len) read stays within one page
		 *    so it cannot run into the trailing skb_shared_info
		 *    ("page boundary - shared skb info" guard);
		 *  - the ring has room for the extra (3rd) descriptor.
		 * dma_map_single() preserves the intra-page offset, so the
		 * alignment and page-residency computed here from the virtual
		 * address hold for the device address used below. Frames that do
		 * not qualify fall through to the copy realignment path.
		 */
		if (skb->len >= XPCXD_TX_MULTI_BD_MIN_BULK &&
		    off <= skb_headroom(skb) &&
		    (base_va >> PAGE_SHIFT) == (read_last >> PAGE_SHIFT) &&
		    xpcxd_get_tx_sub_ring_space(txr) >=
			    (u32)(XPCXD_NUM_TXD_PER_PKT + 1)) {
			use_multi_bd = true;
			mbd_off = off;
			goto tx_align_done;
		}

		/* Not eligible for multi-BD: fall back to copy realignment. */
		batch_realign_mbd_fallback++;

		/* Alloc new skb */
		new_skb = netdev_alloc_skb(netdev, skb->len + tx_align);
		if (!new_skb) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD TX: Alloc skb: [%p] error skb->len: [%d]",
				ring_id,
				skb,
				skb->len);
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}

		/* Make sure new skb is properly aligned */
		xpcxd_skb_align(new_skb, tx_align);

		/* Copy data to new skb ... */
		skb_copy_from_linear_data(skb, new_skb->data, skb->len);
		skb_put(new_skb, skb->len);

		/* ... and free an old one */
		dev_kfree_skb_any(skb);

		skb = new_skb;

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		/*
		 * Count this realignment. One allocate + linear-copy +
		 * free per occurrence; visible in ethtool as
		 * tx_skb_realigned_256b (legacy statistic name).
		 */
		batch_realign++;
	}

tx_align_done:

	ring_space = xpcxd_get_tx_sub_ring_space(txr);

	if (ring_space < ((txr->sub.size / 100) * xpcxd_ring_threshold)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: skb: [%p] Ring space: %d txr->sub.size: %d Ring drain treshold reached:[%d]",
			ring_id,
			skb,
			ring_space,
			txr->sub.size,
			((txr->sub.size / 100) * xpcxd_ring_threshold));
		if (xpcxd_rx_ring_threshold_stop)
			xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Drain treshold");
		tx_ret = NETDEV_TX_OK; // NETDEV_TX_BUSY;
		txr->stats.dropped++;
		txr->stats.tx_sub_threshold++; 		/* Per ring stats */

		goto tx_drop;
	}

#ifdef __XPCXD_CHECK_TX_UNDERFLOW_COUNT__
		{
			u64 underflow_cnt = xpcxd_tx_get_underflow_cnt();

			if (prev_tx_underflow_cnt != underflow_cnt) {
				txr->stats.tx_underflow_events++;
				prev_tx_underflow_cnt = underflow_cnt;

				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						"TX UNDERFLOW: [%lld] ", underflow_cnt);				
			}
		}
#endif /* __XPCXD_CHECK_TX_UNDERFLOW_COUNT__ */

	/* Per-packet state re-init for the current skb. */
	protocol = vlan_get_protocol(skb);
	eth = eth_hdr(skb);
	eth_len = skb_vlan_tag_present(skb) ? VLAN_HLEN : ETH_HLEN;
	l3_offset = 0;
	shim_hdr_size = 0;
	trimmed = false;
	l4_protocol = 0;
	check_l3_checksum = false;
	check_l4_checksum = false;
	num_desc = 0;
	prod_idx = txr->sub.prod;

	/*
	 * Prefetch current and next descriptor/sw_desc lines. Use prefetchw()
	 * for the lines we are about to write (sub.desc[prod_idx],
	 * sub.sw[prod_idx]) so the cache line is brought in M-state and we
	 * skip the read-for-ownership upgrade on the imminent stores.
	 */
	prefetchw(&txr->sub.desc[prod_idx & txr->sub.mask]);
	prefetchw(&txr->sub.sw[prod_idx & txr->sub.mask]);
	prefetchw(&txr->sub.desc[(prod_idx + 2) & txr->sub.mask]);
	prefetchw(&txr->sub.sw[(prod_idx + 2) & txr->sub.mask]);

	sw_desc = &txr->sub.sw[prod_idx & txr->sub.mask];

	if (unlikely(!sw_desc)) {
		xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: sw_desc is NULL", ring_id);
		txr->stats.dropped++;
		tx_ret = NET_XMIT_DROP;
		goto tx_drop;
	}

	sw_desc->is_xdp = false;
	sw_desc->tx_src = XPCXD_TX_SRC_NONE;
	sw_desc->skb = NULL;

	/*
	 * Linearize headers before DMA map / pool memcpy. pskb_may_pull
	 * after map could reallocate and invalidate the mapping.
	 * Covers shim (inject is the larger) plus VLAN + IPv6 for the
	 * later L3 parse.
	 */
	{
		u32 hdr_need = XSW_TX_TUN_HDR_SIZE +
			       XSW_TX_SHIM_INJECT_HDR_SIZE + VLAN_ETH_HLEN +
			       sizeof(struct ipv6hdr);
		u32 pull_len = skb->len < hdr_need ? skb->len : hdr_need;

		if (pull_len && !pskb_may_pull(skb, pull_len)) {
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}

#ifdef __XPCXD_CHECK_TX_ALIGNMENT__
	if ((uintptr_t)skb->data & (tx_align - 1)) {
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: NOT aligned to %d: skb->data: [%px]",
			tx_align, skb->data);
		xprint_hex_dump(netdev, "--- TX DATA NOT ALIGNED ---",
					DUMP_PREFIX_OFFSET, 16, 1, skb->data,
					skb->len, true);
		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpci_print_pkt("TX DATA NOT ALIGNED ", netdev, skb,
				       TX_OFFSET, xpci_tx);
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> PCXD TX: SKB Data aligned to %d: skb->data: [%px]",
			tx_align, skb->data);
	}
#endif /* __XPCXD_CHECK_TX_ALIGNMENT__ */

	if (use_pool) {
		/*
		 * Pool fast path: skb->data -> pre-mapped slot via memcpy.
		 * Skips dma_map_single() (and its SWIOTLB bounce cost when
		 * applicable) and skips the tx_align alignment check below
		 * (slot base is dma_alloc_coherent(); each slot is naturally
		 * slot_size-aligned).
		 *
		 * Pool slot indexing uses the MD's prod_idx (same slot where
		 * sw_desc lives), so consecutive packets don't stomp each
		 * other regardless of XPCXD_NUM_TXD_PER_PKT.
		 *
		 * The pool is backed by page-sized blocks (block_slots slots
		 * each, a power of two), so map slot -> block with a shift and
		 * the in-block offset with a mask; no slot straddles a block.
		 */
		u16 pool_idx = prod_idx & txr->sub.mask;
		u32 blk = pool_idx >> txr->tx_pool.block_shift;
		size_t off = (size_t)(pool_idx & (txr->tx_pool.block_slots - 1)) *
			     txr->tx_pool.slot_size;
		void *slot_vaddr = (u8 *)txr->tx_pool.blk_vaddr[blk] + off;

		memcpy(slot_vaddr, skb->data, skb->len);
		tx_buf = slot_vaddr;
		tx_buf_size = txr->tx_pool.slot_size;
		dma_addr = txr->tx_pool.blk_daddr[blk] + off;
		sw_desc->tx_src = XPCXD_TX_SRC_POOL;
		/* CMPL POOL path uses dma_len for byte stats only. */
		dma_unmap_len_set(sw_desc, dma_len, skb->len);
	} else {
		/*
		 * Multi-BD empty-BD path: extend the streaming map down to the
		 * tx_align-aligned base (skb->data - mbd_off) and up by mbd_off
		 * bytes, so the leading compensation bytes the device reads via
		 * the empty BD are covered/synced and dma_addr is the aligned
		 * base. The headroom guard at the decision site guarantees the
		 * extended start stays inside the skb head buffer.
		 */
		void *map_va = use_multi_bd ? skb->data - mbd_off : skb->data;

		tx_buf = skb->data;
		tx_buf_size = skb->len + skb_tailroom(skb);
		map_len = use_multi_bd ? skb->len + mbd_off : skb->len;
		dma_addr = xpcxd_dma_map_single(net_priv->hw_dev, map_va,
						map_len, DMA_TO_DEVICE);
		if (unlikely(dma_mapping_error(net_priv->hw_dev, dma_addr))) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD TX: DMA Mapping error: [0x%llx]",
				ring_id, dma_addr);
			xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: DMA Mapping error");
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
		dma_mapped = true;
		sw_desc->tx_src = XPCXD_TX_SRC_MAPPED;
		sw_desc->skb = skb;
		dma_unmap_addr_set(sw_desc, sw_dma_addr, dma_addr);
		dma_unmap_len_set(sw_desc, dma_len, map_len);
	}

	/*
	 * Pool slots are tx_align-aligned by construction — skip the legacy
	 * alignment diagnostics for the pool path (the dma_addr we built is
	 * a page-aligned block base + a slot_size-multiple offset, and
	 * slot_size is a multiple of xpcxd_tx_align).
	 */
	if (!use_pool && !use_multi_bd && (dma_addr & (tx_align - 1))) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_ERR,
			netdev,
			"---> [%d] PCXD TX: Not %d aligned data skb->data: [%p] len: [%d] DMA address: [0x%llx]",
			ring_id, tx_align, skb->data, skb->len, dma_addr);
		batch_align_err++;
		// xpcxd_set_error(netdev, skb, xpci_tx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: Not properly aligned DMA address");
		if (xpcxd_tx_drop_on_alignment_err) {
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
	}

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD TX: skb: [%p] sw_desc[%p][%d] prod_idx: [%d] protocol: [0x%x]", 
			ring_id, skb, sw_desc, (prod_idx & txr->sub.mask), prod_idx, protocol);

	shim_hdr_size = xpcxd_tx_shim_hdr_size(protocol);

	if (likely(shim_hdr_size)) {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN
			"---> [%d] PCXD TX: SHIM before data move: skb: [%p] skb>data[%p] protocol: [0x%x] tx_shim_hdr_size: [%d]" CLR_RST,
			ring_id, skb, skb->data, protocol,
			shim_hdr_size);

		if (unlikely(!pskb_may_pull(skb, shim_hdr_size))) {
			txr->stats.dropped++;
			tx_ret = NET_XMIT_DROP;
			goto tx_drop;
		}
		skb_pull(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);

		trimmed = true;
	} else {
		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: NO SHIM: skb: [%p] skb>data[%p] protocol: [0x%x]" CLR_RST,
			ring_id, skb, skb->data, protocol);

		eth = eth_hdr(skb);
	}

	if (unlikely(eth->h_proto == htons(ETH_P_8021Q))) {
		const struct vlan_ethhdr *veh = vlan_eth_hdr(skb);

		eth_len = VLAN_ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] VLAN: protocol: [0x%x] ---> protocol: [0x%x]" CLR_RST,
			ring_id, skb, protocol, veh->h_vlan_encapsulated_proto);

		protocol = veh->h_vlan_encapsulated_proto;
		l3_offset = shim_hdr_size + VLAN_ETH_HLEN;

		batch_vlan++;
	} else {
		eth_len = ETH_HLEN;

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			CLR_GREEN "---> [%d] PCXD TX: skb: [%p] ETH: protocol: [0x%x] ---> eth->h_proto: [0x%x]" CLR_RST,
			ring_id, skb, protocol, eth->h_proto);

		protocol = eth->h_proto;

		l3_offset = shim_hdr_size + ETH_HLEN;
	}

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		CLR_YELLOW "---> [%d] PCXD TX: skb: [%p] skb>data[%p] protocol: [0x%x] eth->h_proto: [0x%x]" CLR_RST,
		ring_id, skb, skb->data, htons(protocol), htons(eth->h_proto))

	if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && 
	             (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-AFTER-TRIM", netdev, skb, 0, xpci_tx);

	if (likely(READ_ONCE(xpcxd_tx_stats_uc_mc_bc))) {
		if (is_broadcast_ether_addr(eth->h_dest))
			batch_bc++;
		else if (is_multicast_ether_addr(eth->h_dest))
			batch_mc++;
		else
			batch_uc++;
	}

	/*
	 * L3/L4 parse for HW checksum offload. Independent of the UC/MC/BC
	 * stats knob: detect IPv4/IPv6 by ethertype to derive l3_offset, and
	 * read the L4 protocol to decide L4 csum offload.
	 */
	if (likely(protocol == htons(ETH_P_IP))) {
		if (pskb_may_pull(skb, eth_len + sizeof(*iph))) {
			check_l3_checksum = true;
			iph = (struct iphdr *)((u8 *)skb->data + eth_len);
			l4_protocol = iph->protocol;
		}
	} else if (likely(protocol == htons(ETH_P_IPV6))) {
		if (pskb_may_pull(skb, eth_len + sizeof(*ip6h))) {
			check_l3_checksum = true;
			ip6h = (struct ipv6hdr *)((u8 *)skb->data + eth_len);
			l4_protocol = ip6h->nexthdr;
		}
	}

	if (likely(l4_protocol == IPPROTO_TCP || l4_protocol == IPPROTO_UDP))
		check_l4_checksum = xpcxd_loopback ? false : true;

	xpcxd_opt_trace(tx_pkt, ring_id, skb, skb->len, htons(protocol), htons(eth->h_proto));

#ifdef __XPCXD_ICMP_TRACE__
	xpcxd_check_icmp_echo(skb, netdev);
#endif

	/* If packet been trimmed to correctly set layer offsets and protocols then bring it back */
	if (trimmed) {
		eth = eth_hdr(skb);
		skb_push(skb, shim_hdr_size);

		skb_reset_mac_header(skb);
		skb_reset_network_header(skb);
		skb_reset_transport_header(skb);

		eth = eth_hdr(skb);
		if (unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) && (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED))) {
			xpci_print_pkt("TX-TRIM-BACK", netdev, skb, TX_OFFSET, xpci_tx);
			/*
			 * skb->len is back to the length HW was given, so the
			 * dump starts exactly where an overread would begin.
			 */
			/* Trailing space: xprint_hex_dump() puts the offset
			 * straight after the prefix. */
			xpcxd_tx_print_tail("--- TX-TRIM-BACK tail --- ",
					    netdev, tx_buf, skb->len,
					    tx_buf_size);
		}
	}

	/* TX Meta Data handling */

	/* W0 */
	tx_md.md.ctrl_no_cpl = 0; /* 0 - Generate completion per packet */
	/* Hybrid mode */
	/* In TX reflection mode - no need to set interrupt per descriptor */
	tx_md.md.int_en = !xpcxd_tx_cmp_rfl_mode; /* 1 - Generate on packet completion */

	tx_md.md.type = 0; /* 0 - Desciptor type - MD */
	tx_md.md.calc_l3_chks = xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l3_checksum; /* 0 - Don't calculate */
	tx_md.md.calc_l4_chks = xpcxd_cfg_tbl[xpcxd_check_l4_checksum] &
				(xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] != xpcxd_global_bypass) &
				check_l4_checksum; /* 0 - Don't calculate */
	tx_md.md.pseudu_hdr_chks_en =
		0; /* 0 - HW calculates pseudo header checksum */
	tx_md.md.l3_offset_en =
		xpcxd_cfg_tbl[xpcxd_check_l3_checksum] &
		check_l3_checksum; /* 1 - L3 offset set by W2[L3_OFFSET] | Config taken from register */
	/* Number of buffer descriptors used to assemble the packet: the
	 * multi-BD alignment compensation path emits 2 BDs (head + bulk).
	 */
	tx_md.md.num_tx_bd = use_multi_bd ? 2 : 1;

	/* W1 */
	tx_md.md.pseudu_hdr_chks = 0; /* 0 - HW calculated, 1 - SW provided Pseudo Header checksum */
	tx_md.md.rsrv_10 = 0;
	tx_md.md.rsrv_11 = 0;

	/* W2 */
	tx_md.md.l3_offset = check_l3_checksum?l3_offset:0; /* L3 offset */
	tx_md.md.rsrv_20 = 0;
	tx_md.md.rsrv_21 = 0;

	/* W3 */
	tx_md.md.opaque_0 = prod_idx;

	/* TX Buffer Data handling */

	if (use_multi_bd) {
		/*
		 * dma_addr is the tx_align-aligned base (skb->data - mbd_off),
		 * since the mapping above was extended down by mbd_off.
		 *
		 * BD0 - empty compensation descriptor: len=0 at the aligned
		 * base. The device consumes it to skip the leading mbd_off
		 * sub-alignment bytes so the data BD that follows is emitted
		 * starting at the real frame (skb->data).
		 */
		tx_bd.tx_bd.type = 1;
		tx_bd.tx_bd.len = 0;
		tx_bd.tx_bd.src_buf_addr_lsb = ((u64)dma_addr & 0x00000000FFFFFFFF);
		tx_bd.tx_bd.src_buf_addr_msb =
			((u64)dma_addr & 0xFFFFFFFF00000000) >> 32;

		/*
		 * BD1 - real data anchored at the same perfectly tx_align-
		 * aligned base; len covers the mbd_off compensation bytes plus
		 * the full frame (mbd_off + skb->len).
		 */
		tx_bd2.tx_bd.type = 1;
		tx_bd2.tx_bd.len = skb->len + mbd_off;
		tx_bd2.tx_bd.src_buf_addr_lsb =
			((u64)dma_addr & 0x00000000FFFFFFFF);
		tx_bd2.tx_bd.src_buf_addr_msb =
			((u64)dma_addr & 0xFFFFFFFF00000000) >> 32;

		batch_realign_mbd++;
	} else {
		/* W0 */
		tx_bd.tx_bd.type = 1; /* 1 - Desciptor type - BD */
		/* W1 */
		tx_bd.tx_bd.len = skb->len;
		/* W2 */
		tx_bd.tx_bd.src_buf_addr_lsb = ((u64)dma_addr & 0x00000000FFFFFFFF);
		/* W3 */
		tx_bd.tx_bd.src_buf_addr_msb = ((u64)dma_addr & 0xFFFFFFFF00000000) >> 32;
	}

	/*
	 * Publish MD + BD(s). Index each write with sub.mask so a packet
	 * that wraps the ring end is laid out correctly: the multi-BD path
	 * makes the per-packet descriptor count variable (2 or 3), so the
	 * old "even prod, reset to 0 on overflow" shortcut no longer holds.
	 */
	txr->sub.desc[prod_idx & txr->sub.mask].w64[0] = tx_md.w64[0];
	txr->sub.desc[prod_idx & txr->sub.mask].w64[1] = tx_md.w64[1];
	prod_idx++;
	num_desc++;

	txr->sub.desc[prod_idx & txr->sub.mask].w64[0] = tx_bd.w64[0];
	txr->sub.desc[prod_idx & txr->sub.mask].w64[1] = tx_bd.w64[1];
	prod_idx++;
	num_desc++;

	if (use_multi_bd) {
		txr->sub.desc[prod_idx & txr->sub.mask].w64[0] = tx_bd2.w64[0];
		txr->sub.desc[prod_idx & txr->sub.mask].w64[1] = tx_bd2.w64[1];
		prod_idx++;
		num_desc++;
	}

	/* num_tx_desc is a power of two, so masking yields the wrapped prod. */
	prod_idx &= txr->sub.mask;

	txr->sub.prod = prod_idx;
	pkt_published = true;

	/* Accumulate locally; committed once at end of xpcxd_xmit(). */
	batch_pkts++;
	batch_bytes += skb->len;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
	if (skb->len < 128)
		batch_sz64_128++;
	else if (skb->len < 256)
		batch_sz128_256++;
	else
		batch_sz256_plus++;
#endif

	total_desc_batch += num_desc;

	/* Cached for the TX-END print + tx_db_defer trace after we drop
	 * our skb reference on the pool fast path (skb dangles otherwise).
	 */
	last_skb_len = skb->len;

	/*
	 * Pool fast path: payload is already in the pre-mapped slot and
	 * the descriptor has been published. CMPL reclaims the slot with
	 * only stats accounting (XPCXD_TX_SRC_POOL), so we can return
	 * the skb to the allocator right here and not pay the skb cache
	 * line cost on the completion CPU.
	 *
	 * sw_desc->skb is intentionally left NULL on the pool path (CMPL
	 * does not own an skb for XPCXD_TX_SRC_POOL). NULL out the local
	 * skb so TX-END print / tx_db_defer trace use last_skb_len instead
	 * of dereferencing a freed skb.
	 */
	if (use_pool) {
		dev_consume_skb_any(skb);
		skb = NULL;
	}

	/*
	 * Doorbell policy. The descriptors are already published (sub.prod
	 * advanced); only the MMIO doorbell tells HW about them.
	 *
	 * Coalescing mode (pcxd_tx_coales_isr_mode, opt-in): defer the DB
	 * and amortize the (now read-flush-free) MMIO write across a batch.
	 *
	 * Legacy mode (coalescing off): ring the DB unless the stack itself
	 * promised more via netdev_xmit_more().
	 *
	 */
	txr->sub_desc_pending += total_desc_batch;

	if (xpcxd_tx_coales_isr_mode && txr->tx_coales_isr.function) {
		if (txr->sub_desc_pending >= xpcxd_tx_db_batch ||
		    xpcxd_get_tx_sub_ring_space(txr) < XPCXD_TX_STOP_THOLD)
			xpcxd_tx_db_flush_locked(netdev, txr);
		else
			xpcxd_opt_trace(tx_db_defer, ring_id, skb, last_skb_len,
					txr->sub_desc_pending, total_desc_batch);
	} else if (!netdev_xmit_more() ||
		   xpcxd_get_tx_sub_ring_space(txr) < XPCXD_TX_STOP_THOLD) {
		xpcxd_tx_db_flush_locked(netdev, txr);
	} else {
		xpcxd_opt_trace(tx_db_defer, ring_id, skb, last_skb_len,
				txr->sub_desc_pending, total_desc_batch);
	}

	/*
	 * Commit batched stats once per xpcxd_xmit() call. Under tx_lock so
	 * the writes are serialized with xpcxd_xmit() readers; the CMPL CPU
	 * touches a different stats sub-line (see xpcxd_stats layout note).
	 */
	if (batch_pkts) {
		txr->stats.packets            += batch_pkts;
		txr->stats.bytes              += batch_bytes;
		if (batch_uc)
			txr->stats.tx_unicast         += batch_uc;
		if (batch_mc)
			txr->stats.tx_multicast       += batch_mc;
		if (batch_bc)
			txr->stats.tx_broadcast       += batch_bc;
		if (batch_vlan)
			txr->stats.tx_vlan_packets    += batch_vlan;
		if (batch_align_err)
			txr->stats.tx_alignment_error += batch_align_err;
		if (batch_realign)
			txr->stats.tx_skb_realigned_256b   += batch_realign;
		if (batch_realign_mbd)
			txr->stats.tx_realign_multi_bd += batch_realign_mbd;
		if (batch_realign_mbd_fallback)
			txr->stats.tx_realign_multi_bd_fallback +=
				batch_realign_mbd_fallback;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
		if (batch_sz64_128)
			txr->stats.tx_pkt_size_64_128  += batch_sz64_128;
		if (batch_sz128_256)
			txr->stats.tx_pkt_size_128_256 += batch_sz128_256;
		if (batch_sz256_plus)
			txr->stats.tx_pkt_size_256_plus += batch_sz256_plus;
#endif
		batch_pkts = 0;
		batch_bytes = 0;
		batch_uc = batch_mc = batch_bc = 0;
		batch_vlan = 0;
		batch_align_err = 0;
		batch_realign = 0;
		batch_realign_mbd = 0;
		batch_realign_mbd_fallback = 0;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
		batch_sz64_128 = batch_sz128_256 = batch_sz256_plus = 0;
#endif
	}

	/*
	 * skb may be NULL here if the last iteration took the pool fast
	 * path. The TX-END dump is diagnostic only; skip it when we no
	 * longer own the skb.
	 */
	if (skb && unlikely((xpcxd_msglvl_level & NETIF_MSG_PKTDATA) &&
			    (xpcxd_msglvl_level & NETIF_MSG_TX_QUEUED)))
		xpci_print_pkt("TX-END", netdev, skb, TX_OFFSET, xpci_tx);

	if (xpcxd_tx_packets_stop) {
		/*
		 * Debug-only fault injection. The packet is already
		 * published; CMPL owns the skb (or the pool path already
		 * consumed it). Do not goto tx_drop — that would
		 * double-free a MAPPED skb.
		 */
		xpcxd_err_netdev(
			NETIF_MSG_TX_ERR, netdev,
			"---> [%d] PCXD TX: skb: [%p] Tx stop triggered: [%llu]",
			ring_id, skb, (unsigned long long)txr->stats.packets);
		xpcxd_set_error(netdev, skb, xpci_tx, 0x1 /*g_cnt_tx_stop*/,
				"TX ERROR: Tx stop");
	}

	spin_unlock(&net_priv->txr[ring_id].tx_lock);

	return tx_ret;

tx_drop:

	/*
	 * Commit any stats accumulated for packets successfully enqueued
	 * earlier in this call before the drop, flush the pending DB (so
	 * mid-batch drops don't strand published descriptors), then unlock.
	 */
	if (spin_is_locked(&net_priv->txr[ring_id].tx_lock)) {
		if (batch_pkts) {
			txr->stats.packets            += batch_pkts;
			txr->stats.bytes              += batch_bytes;
			if (batch_uc)
				txr->stats.tx_unicast         += batch_uc;
			if (batch_mc)
				txr->stats.tx_multicast       += batch_mc;
			if (batch_bc)
				txr->stats.tx_broadcast       += batch_bc;
			if (batch_vlan)
				txr->stats.tx_vlan_packets    += batch_vlan;
			if (batch_align_err)
				txr->stats.tx_alignment_error += batch_align_err;
			if (batch_realign)
				txr->stats.tx_skb_realigned_256b   += batch_realign;
			if (batch_realign_mbd)
				txr->stats.tx_realign_multi_bd +=
					batch_realign_mbd;
			if (batch_realign_mbd_fallback)
				txr->stats.tx_realign_multi_bd_fallback +=
					batch_realign_mbd_fallback;
#ifdef __XPCXD_TX_PKT_SIZE_HISTOGRAM__
			if (batch_sz64_128)
				txr->stats.tx_pkt_size_64_128  += batch_sz64_128;
			if (batch_sz128_256)
				txr->stats.tx_pkt_size_128_256 += batch_sz128_256;
			if (batch_sz256_plus)
				txr->stats.tx_pkt_size_256_plus += batch_sz256_plus;
#endif
		}
		xpcxd_tx_db_flush_locked(netdev, &net_priv->txr[ring_id]);
		spin_unlock(&net_priv->txr[ring_id].tx_lock);
	}

	xpcxd_err_netdev(NETIF_MSG_TX_ERR, netdev,
			 "---> [%d] PCXD TX: skb: [%p] ERROR", ring_id, skb);

	if (pkt_published) {
		/*
		 * Descriptors are on the ring. CMPL (or the pool consume
		 * above) owns the skb / DMA mapping. Do not free here.
		 */
		txr->stats.errors++;
		return tx_ret;
	}

	if (dma_mapped) {
		xpcxd_dma_unmap_single(net_priv->hw_dev, dma_addr, map_len,
				       DMA_TO_DEVICE);
		dma_mapped = false;
	}
	if (sw_desc) {
		sw_desc->skb = NULL;
		sw_desc->tx_src = XPCXD_TX_SRC_NONE;
		dma_unmap_addr_set(sw_desc, sw_dma_addr, 0);
		dma_unmap_len_set(sw_desc, dma_len, 0);
	}

	/* Pad failure already freed the skb (skb == NULL). */
	if (skb)
		dev_kfree_skb_any(skb);
	txr->stats.errors++;

	return tx_ret;
}
EXPORT_SYMBOL(xpcxd_xmit);

#if IS_ENABLED(CONFIG_BPF_SYSCALL)
/**
 * xpcxd_xdp_xmit_frame - Enqueue one XDP frame on a Tx ring (caller must not hold tx_lock).
 *
 * Descriptors are published to the ring but the doorbell is NOT written here;
 * instead the per-frame contribution is accumulated into txr->sub_desc_pending
 * and the caller (xpcxd_xdp_xmit) flushes a single DB per ring touched on
 * XDP_XMIT_FLUSH.
 *
 * Returns 0 on success, -ENOSPC if ring full, -EIO on DMA error.
 */
int xpcxd_xdp_xmit_frame(struct net_device *netdev, u32 ring_id, struct xdp_frame *frame)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr;
	struct xpcxd_sw_desc *sw_desc;
	struct xpcxd_desc tx_md = { 0 };
	struct xpcxd_desc tx_bd = { 0 };
	u16 prod_idx;
	u16 num_desc = 0;
	u16 ring_space;
	dma_addr_t dma_addr;

	if (ring_id >= net_priv->num_rings)
		return -EINVAL;

	txr = &net_priv->txr[ring_id];
	spin_lock(&txr->tx_lock);

	ring_space = xpcxd_get_tx_sub_ring_space(txr);
	if (ring_space < XPCXD_NUM_TXD_PER_PKT) {
		spin_unlock(&txr->tx_lock);
		return -ENOSPC;
	}

	prod_idx = txr->sub.prod;
	sw_desc = &txr->sub.sw[prod_idx & txr->sub.mask];

	dma_addr = xpcxd_dma_map_single(net_priv->hw_dev, frame->data, frame->len, DMA_TO_DEVICE);
	if (dma_mapping_error(net_priv->hw_dev, dma_addr)) {
		spin_unlock(&txr->tx_lock);
		return -EIO;
	}

	/* Minimal TX MD: no checksum, one BD */
	tx_md.md.ctrl_no_cpl = 0;
	tx_md.md.int_en = !xpcxd_tx_cmp_rfl_mode;
	tx_md.md.type = 0;
	tx_md.md.calc_l3_chks = 0;
	tx_md.md.calc_l4_chks = 0;
	tx_md.md.pseudu_hdr_chks_en = 0;
	tx_md.md.l3_offset_en = 0;
	tx_md.md.num_tx_bd = 1;
	tx_md.md.opaque_0 = prod_idx;

	tx_bd.tx_bd.type = 1;
	tx_bd.tx_bd.len = frame->len;
	tx_bd.tx_bd.src_buf_addr_lsb = (u32)((u64)dma_addr & 0xFFFFFFFF);
	tx_bd.tx_bd.src_buf_addr_msb = (u32)((u64)dma_addr >> 32);

	txr->sub.desc[prod_idx].w64[0] = tx_md.w64[0];
	txr->sub.desc[prod_idx].w64[1] = tx_md.w64[1];
	prod_idx++;
	num_desc++;

	txr->sub.desc[prod_idx & txr->sub.mask].w64[0] = tx_bd.w64[0];
	txr->sub.desc[prod_idx & txr->sub.mask].w64[1] = tx_bd.w64[1];
	prod_idx++;
	if (prod_idx >= net_priv->num_tx_desc)
		prod_idx = 0;

	txr->sub.prod = prod_idx;

	sw_desc->is_xdp = true;
	sw_desc->xdpf = frame;
	sw_desc->skb = NULL;
	/*
	 * XDP redirect frames always use the legacy dma_map_single() path
	 * (no pool integration for XDP yet — the frame pages come from a
	 * different page_pool); CMPL uses tx_src to pick the correct
	 * reclaim (dma_unmap_single + xdp_return_frame).
	 */
	sw_desc->tx_src = XPCXD_TX_SRC_XDP;
	dma_unmap_addr_set(sw_desc, sw_dma_addr, dma_addr);
	dma_unmap_len_set(sw_desc, dma_len, frame->len);

	txr->stats.tx_xdp_packets++;
	txr->stats.tx_xdp_bytes += frame->len;
	xpcxd_pkt_stats_inc(txr, frame->len);

	txr->sub_desc_pending += num_desc;

	spin_unlock(&txr->tx_lock);
	return 0;
}
EXPORT_SYMBOL(xpcxd_xdp_xmit_frame);

/**
 * ndo_xdp_xmit - Transmit frames received via XDP redirect (per-Tx-ring).
 * Tries to transmit as many frames as possible: for each frame, try rings in
 * round-robin order until one has space, so multiple packets can transit when
 * rings are available. The doorbell for each ring that accepted at least one
 * frame is written once, on XDP_XMIT_FLUSH, so we emit a single MMIO per
 * ring per flush regardless of how many frames went through it.
 */
int xpcxd_xdp_xmit(struct net_device *netdev, int n, struct xdp_frame **frames, u32 flags)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int i;
	int r;
	int nxmit = 0;
	u32 ring_id;

	if (!net_priv->num_rings)
		return -ENXIO;

	for (i = 0; i < n; i++) {
		/* Try each ring (round-robin) until one accepts the frame */
		for (r = 0; r < net_priv->num_rings; r++) {
			ring_id = (u32)(i + r) % net_priv->num_rings;
			if (xpcxd_xdp_xmit_frame(netdev, ring_id, frames[i]) == 0) {
				nxmit++;
				break;
			}
		}
	}

	/*
	 * ndo_xdp_xmit contract: when XDP_XMIT_FLUSH is set, descriptors must
	 * be visible to HW before we return. Walk all rings and flush any
	 * pending DB we accumulated above. xpcxd_tx_db_flush_locked() is a
	 * no-op for rings we didn't touch (sub_desc_pending == 0).
	 */
	if (flags & XDP_XMIT_FLUSH) {
		u32 rid;

		for (rid = 0; rid < net_priv->num_rings; rid++) {
			struct xpcxd_ring *txr = &net_priv->txr[rid];

			spin_lock(&txr->tx_lock);
			xpcxd_tx_db_flush_locked(netdev, txr);
			spin_unlock(&txr->tx_lock);
		}
	}

	return nxmit;
}
EXPORT_SYMBOL(xpcxd_xdp_xmit);
#endif /* IS_ENABLED(CONFIG_BPF_SYSCALL) */
