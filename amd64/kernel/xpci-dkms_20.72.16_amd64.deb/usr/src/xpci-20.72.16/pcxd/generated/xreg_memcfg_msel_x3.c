/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Indirect MEMCFG SRAM selector (MSEL) per enum xreg_id.
 * Auto-generated — do not edit.
 * Regenerate: pcxd/scripts/gen_xreg_layout.py
 */
#include <linux/types.h>
#include "generated/xreg_layout_ids_x3.h"
#include "generated/xreg_memcfg_msel_map_x3.h"

u32 xreg_memcfg_msel_x3(enum xreg_id id)
{
	switch (id) {
	case XREG_ID_PCXD_MEMCFG_RX_BUSY_RING_TBL: return 9u;
	case XREG_ID_PCXD_MEMCFG_RX_CH_TM_SHP_TBL: return 7u;
	case XREG_ID_PCXD_MEMCFG_RX_CMP_RNG_TBL: return 3u;
	case XREG_ID_PCXD_MEMCFG_RX_PAUSE_RING_TBL: return 8u;
	case XREG_ID_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL: return 2u;
	case XREG_ID_PCXD_MEMCFG_RX_RING_ACTV_TBL: return 0u;
	case XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL: return 4u;
	case XREG_ID_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL: return 5u;
	case XREG_ID_PCXD_MEMCFG_RX_RNG_STTS_TBL: return 6u;
	case XREG_ID_PCXD_MEMCFG_RX_SBM_RNG_TBL: return 1u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_CMP_DESC: return 27u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_DESC_RD: return 25u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CHL_RING_MAC_PKT: return 26u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_CR_RFL: return 30u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_DESC: return 28u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_INT: return 29u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_CMP_UNIT_SR_RFL: return 31u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DB: return 22u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_DESC: return 23u;
	case XREG_ID_PCXD_MEMCFG_RX_STTS_FCH_PKT: return 24u;
	case XREG_ID_PCXD_MEMCFG_TX_BRG_LPB: return 44u;
	case XREG_ID_PCXD_MEMCFG_TX_BUSY_RING_TBL: return 21u;
	case XREG_ID_PCXD_MEMCFG_TX_CH_TM_SHP_TBL: return 17u;
	case XREG_ID_PCXD_MEMCFG_TX_CMP_RNG_TBL: return 13u;
	case XREG_ID_PCXD_MEMCFG_TX_PAUSE_RING_TBL: return 20u;
	case XREG_ID_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL: return 12u;
	case XREG_ID_PCXD_MEMCFG_TX_RING_ACTV_TBL: return 10u;
	case XREG_ID_PCXD_MEMCFG_TX_RNG_BYTE_SHP_TBL: return 18u;
	case XREG_ID_PCXD_MEMCFG_TX_RNG_FRM_SHP_TBL: return 19u;
	case XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL: return 14u;
	case XREG_ID_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL: return 15u;
	case XREG_ID_PCXD_MEMCFG_TX_RNG_STTS_TBL: return 16u;
	case XREG_ID_PCXD_MEMCFG_TX_SBM_RNG_TBL: return 11u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_BRG_RING_PKT: return 43u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_CMP_DESC: return 38u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_DESC_RD: return 36u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_MAC_PKT: return 37u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CHL_RING_SEL_PKT: return 35u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_CR_RFL: return 41u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_DESC: return 39u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_INT: return 40u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_CMP_UNIT_SR_RFL: return 42u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DB: return 32u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_DESC: return 33u;
	case XREG_ID_PCXD_MEMCFG_TX_STTS_FCH_PKT: return 34u;
	default:
		return (u32)-1;
	}
}
