// SPDX-License-Identifier: GPL-2.0

/*
 * Definitions for XPCI common routines
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCI_COMMON_H_
#define XPCI_COMMON_H_

/**
 *  ASIC Register Read/Write
 *
 */
struct xreg {
	u32 addr;
	u64 value;
};

enum xpci_tx_rx {
	xpci_tx = 0,
	xpci_rx = 1,
};

#define XPCI_LOCK true
#define XPCI_NO_LOCK false

#define XPCI_DMA_ALIGNMENT 64

u32 xpci_register_access(bool flag);
void xpci_set_reg_mem_base(u64 reg_mem_base);
u64 xpci_get_reg_mem_base(void);
u64 xpci_read64(char *reg_name, u32 addr, bool log);
u64 xpci_read64_fast(u32 addr);
u32 xpci_readl_fast(u32 addr);
void xpci_write64(char *reg_name, u32 addr, u64 value);
void xpci_write64_fast(u32 addr, u64 value);
void xpci_writel_fast(u32 addr, u32 value);

void xprint_hex_dump(const void *dev, const char *prefix_str, int prefix_type, int rowsize,
		     int groupsize, const void *buf, size_t len, bool ascii);

void xprint_hex_dump_bytes(const char *prefix_str, int prefix_type,
			   const void *buf, size_t len);

#endif /* XPCI_COMMON_H_ */
