#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
#
# Unload and load xpci with the NetDev driver enabled (netdev_mode=1).
# All other module parameters match the xpci_load.sh defaults.
#
# Usage: xpci_reload_netdev.sh [debug_level] [pkt_trace]

set -euo pipefail

# debug_level=1 - Error
# 2 - Notice
# 3 - Info
# 4 - Debug
# 5 - Debug with registers read/write

DBG_LEVEL=1
NUM_OF_PORTS=4
ATTACH_IF="xpcxd0"
NETDEV_MODE_PATH="/sys/module/xpci/parameters/netdev_mode"

# pkt_trace is only passed to modprobe when explicitly requested, so the
# default stays the driver default (0 = mute).
PKT_TRACE_ARG=()

case "${1:-}" in
-h|--help)
	echo "Usage: $(basename "$0") [debug_level] [pkt_trace]"
	echo ""
	echo "Reloads xpci with netdev_mode=1 (NetDev driver enabled)."
	echo "  debug_level  1..5, default ${DBG_LEVEL}"
	echo "  pkt_trace    0..3, default is the driver default (0)"
	exit 0
	;;
esac

if [ $# -ge 1 ]; then
	DBG_LEVEL=$1
fi

if [ $# -ge 2 ]; then
	PKT_TRACE_ARG=("pkt_trace=$2")
fi

echo "Reloading xpci with netdev_mode=1, debug level: ${DBG_LEVEL}"

sudo rmmod xpci 2>/dev/null || true

sudo modprobe xpci attach_if="${ATTACH_IF}" num_of_ports=${NUM_OF_PORTS} \
	debug_level=${DBG_LEVEL} pci_mode=1 netdev_mode=1 pcxd_mode=1 \
	"${PKT_TRACE_ARG[@]}"

lsmod | grep xpci

if [ ! -r "${NETDEV_MODE_PATH}" ]; then
	echo "ERROR: ${NETDEV_MODE_PATH} not readable, xpci did not load" >&2
	exit 1
fi

read -r netdev_mode < "${NETDEV_MODE_PATH}"
if [ "${netdev_mode}" != "1" ]; then
	echo "ERROR: netdev_mode is ${netdev_mode}, expected 1" >&2
	exit 1
fi

echo "netdev_mode: ${netdev_mode}"
