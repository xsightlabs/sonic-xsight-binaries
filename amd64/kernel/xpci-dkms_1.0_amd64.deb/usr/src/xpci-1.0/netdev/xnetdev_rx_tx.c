// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device Rx and Tx handling
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/if_vlan.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/compiler.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/tc_act/tc_sample.h>

#include "xpci_dbg.h"
#include "common/xpci_common.h"
#include "xnetdev_common.h"
#include "xnetdev.h"
#include "xnetdev_trap_dbg.h"
#include "xnetdev_fdb_nl.h"
#include "xpci_trace.h"

/* #define __RX_TX_STOP_SUPPORT__ */

extern struct genl_family xpci_fdb_nl_family;

/*  Array of pointers to upper layer Rx netdevs */
static struct net_device **xpci_net_devs = NULL;
/* Physical to Logical Port map */
struct xpci_phy_port xpci_phy_to_lo_port_map[XPCI_NET_MAX_DEVICE_PORTS_NUM] = { 0 };
/* Software to physical port map */
struct xpci_lo_port xpci_lo_to_phy_port_map[XPCI_NET_MAX_DEVICE_PORTS_NUM] = { 0 };

#ifdef __RX_TX_STOP_SUPPORT__
static bool rx_tx_stop = false;
#endif

/*static*/ void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx)
{
	struct ethhdr *eth = (struct ethhdr *) (skb->data + offset);
	unsigned char buffer[128];
	unsigned int i;

	xpci_dbg_netdev(netdev,
			"\n************** SKB dump: [%s] ****************",
			trace_point);

	xpci_dbg_netdev(netdev, "IF: [%d] %s packet of %d bytes",
			netdev->ifindex,
			((tx_rx == xpci_tx) ? "---->> TX" : "<<---- RX"),
			skb->len);
	xpci_dbg_netdev(netdev, "SKB skb->pkt_type : %d", skb->pkt_type);
	xpci_dbg_netdev(netdev, "SKB skb->len      : %d", skb->len);
	xpci_dbg_netdev(netdev, "SKB skb->mac_len  : %d", skb->mac_len);
	xpci_dbg_netdev(netdev, "SKB skb->head     : %p", skb->head);
	xpci_dbg_netdev(netdev, "SKB skb->data     : %p", skb->data);
	xpci_dbg_netdev(netdev, "SKB skb->protocol : 0x%x",
			be16_to_cpu(skb->protocol));

	xpci_dbg_netdev(netdev, "Dst MAC addr      : %pM",
			eth_hdr(skb)->h_dest);
	xpci_dbg_netdev(netdev, "Src MAC addr      : %pM",
			eth_hdr(skb)->h_source);
	xpci_dbg_netdev(netdev, "ETH eth->h_proto  : %#06hx",
			ntohs(eth->h_proto));

	xpci_dbg_netdev(netdev, "SKB skb->data_len         : %d",
			skb->data_len);
	xpci_dbg_netdev(netdev, "SKB skb->mac_len          : %d", skb->mac_len);
	xpci_dbg_netdev(netdev, "SKB skb->mac_header       : %d",
			skb->mac_header);
	xpci_dbg_netdev(netdev, "SKB skb->inner_mac_header : %d",
			skb->inner_mac_header);
	xpci_dbg_netdev(netdev, "SKB skb->transport_header : %d",
			skb->transport_header);
	xpci_dbg_netdev(netdev, "SKB skb->network_header   : %d",
			skb->network_header);

	for (i = 0; i < skb->len; i += 32) {
		unsigned int len = min(skb->len - i, 32U);

		hex_dump_to_buffer(&skb->data[i], len, 32, 1, buffer,
				   sizeof(buffer), false);
		xpci_dbg_netdev(netdev, "  %#06x: %s", i, buffer);
	}

	xpci_dbg_netdev(netdev, "\n************** SKB dump ****************");
}

static int xpci_fdb_notify(struct sk_buff *skb, struct xpci_fdb_event_entry *event_entry)
{
	struct net_device *netdev = skb->dev;
	struct sk_buff *msg;
	void *hdr = NULL;
	int rc = 0;

	xpci_dbg_netdev(netdev, "<--- CPU RX: Learning Event[%d]: port: [%d] vlan_id: [%d]",
		event_entry->fdb_event,
		event_entry->port_id,
		event_entry->fdb_key.vlan_id);

	xpci_trace(netdev_rx_fdb_learning, event_entry->fdb_event,
		   event_entry->port_id, event_entry->fdb_key.vlan_id,
		   event_entry->fdb_key.addr);

	msg = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (!msg) {
		xpci_err_netdev(netdev, "genlmsg_new() failed");
		return -ENOMEM;
	}

	if (!(hdr = genlmsg_put(msg, 0, 0, &xpci_fdb_nl_family, 0,
				XPCI_FDB_NL_CMD_NOTIFY)))
		goto nla_put_failure;

	if ((rc = nla_put_u32(msg, XPCI_FDB_NL_ATTR_PORT_ID,
			     event_entry->port_id)))
		goto nla_put_failure;

	if ((rc = nla_put_u16(msg, XPCI_FDB_NL_ATTR_EVENT_ID,
			     event_entry->fdb_event)))
		goto nla_put_failure;

	if ((rc = nla_put(msg, XPCI_FDB_NL_ATTR_MAC, ETH_ALEN,
			 &event_entry->fdb_key.addr)))
		goto nla_put_failure;

	if ((rc = nla_put_u16(msg, XPCI_FDB_NL_ATTR_VLAN_ID,
			     event_entry->fdb_key.vlan_id)))
		goto nla_put_failure;

	genlmsg_end(msg, hdr);

	rc = genlmsg_multicast(&xpci_fdb_nl_family, msg, 0,
			       XPCI_FDB_NL_GROUP_OFFSET, GFP_ATOMIC);
	if (rc)
		xpci_info_netdev(netdev, "genlmsg_multicast() failed, err: %d", rc);

	return rc;

nla_put_failure:
	genlmsg_cancel(msg, hdr);
	xpci_err_netdev(netdev, "genlmsg_put() failed");
	// rc = -ENOMEM;
	return rc;
}

static int xpci_handle_learning_event(struct net_device *netdev,
				      struct sk_buff *skb, __u8 learning_event,
				      uint32_t lo_port_id)
{
	struct xpci_fdb_event_entry event_entry = { 0 };
	uint rc = 0;

	switch (learning_event) {
	case XSW_LEARNING_EVENT_SA_MISS:
		xpci_dbg_netdev(
			netdev,
			"<--- CPU RX: SA MISS Event detected. skb: [%p]",
			skb);
		event_entry.fdb_event = XSW_LEARNING_EVENT_SA_MISS;
		break;
	case XSW_LEARNING_EVENT_SA_MOVE:
		xpci_dbg_netdev(
			netdev,
			"<--- CPU RX: SA MOVE Event detected. skb: [%p]",
			skb);
		event_entry.fdb_event = XSW_LEARNING_EVENT_SA_MOVE;
		break;
	default:
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Unknown learning event [%d] --> DROP",
			learning_event);
		return -1;
	}

	memcpy(event_entry.fdb_key.addr, eth_hdr(skb)->h_source, ETH_ALEN);
	xpci_dbg_netdev(netdev, "<--- CPU RX: Learning MAC address: %pM ", event_entry.fdb_key.addr);

	if (skb_vlan_tag_present(skb)) {
		event_entry.fdb_key.vlan_id = skb_vlan_tag_get(skb);
		xpci_dbg_netdev(
			netdev,
			"<--- CPU RX: 0: VLAN Tag [%d] present in skb: [%p]",
			event_entry.fdb_key.vlan_id,
			skb);
	} else {
		if (!__vlan_get_tag(skb, &event_entry.fdb_key.vlan_id)) {
			xpci_dbg_netdev(
				netdev,
				"<--- CPU RX: 1: VLAN Tag [%d] present in skb: [%p]",
				event_entry.fdb_key.vlan_id,
				skb);
		} else {
			xpci_dbg_netdev(
				netdev,
				"<--- CPU RX: VLAN Tag NOT present in skb: [%p]",
				skb);
		}
	}
	event_entry.port_id = lo_port_id;

	if ((rc = xpci_fdb_notify(skb, &event_entry))) {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Port[%d] FDB Notification failed[rc=%d]",
			lo_port_id,
			rc);
		return -1;
	}

	return 0;
}

static int xpci_handle_sflow_sample(struct xnetdev_priv *upper_net_priv,
				    struct sk_buff *skb, uint32_t phy_port_id)
{
	struct xnetdev_port_sample *sample;
	u32 size = 0;

	xpci_notice_netdev(upper_net_priv->netdev,
			   "<--- CPU RX: sFlow Sample ");

	if (!upper_net_priv->sample) {
		xpci_err_netdev(upper_net_priv->netdev, "Sample is NULL");
		goto normal_drop;
	}

	rcu_read_lock();
	sample = rcu_dereference(upper_net_priv->sample);
	if (!sample) {
		xpci_err_netdev(upper_net_priv->netdev,
				"sample is NULL --> DROP");
		rcu_read_unlock();
		goto normal_drop;
	}

	if (!rtnl_dereference(upper_net_priv->sample->psample_group)) {
		xpci_err_netdev(upper_net_priv->netdev,
				"psample_group not defined --> DROP");
		rcu_read_unlock();
		goto normal_drop;
	}

	size = sample->truncate ? sample->trunc_size : skb->len;

	xpci_dbg_netdev(upper_net_priv->netdev, "sFlow Sample sent to psample: skb: [%p] size: [%d] ifindex: [%d] trunc_size: [%d] rate: [%d]",
		skb, size,
		upper_net_priv->netdev->ifindex,
		sample->trunc_size,
		sample->rate);

/* Sonic 202211 has applied patch for psample metadata struct */
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 13, 0)) && (LINUX_VERSION_CODE != KERNEL_VERSION(5, 10, 140)) \
							&& (LINUX_VERSION_CODE != KERNEL_VERSION(5, 10, 179)) \
							&& (LINUX_VERSION_CODE != KERNEL_VERSION(5, 10, 218))
	psample_sample_packet(
		sample->psample_group, skb,
		size,
		upper_net_priv->netdev->ifindex,
		0, // egress ifindex is irrelevant for ingress sampling
		sample->rate);
#else /* For Kernel 5.13.0 and higher */
	{
		struct psample_metadata md = {
			.trunc_size = size,
			.in_ifindex = upper_net_priv->netdev->ifindex,
			.out_ifindex = 0}; // egress ifindex is irrelevant for ingress sampling

		psample_sample_packet(
			sample->psample_group, skb, sample->rate, &md);
	}
#endif

	rcu_read_unlock();

	return 0;

normal_drop:

	return RX_HANDLER_CONSUMED; /* Packet dropped or sent to psample */
}

rx_handler_result_t xpci_handle_cpu_frame(struct sk_buff **pskb)
{
	struct sk_buff *skb = *pskb;
	struct net_device *netdev = skb->dev;
	struct ethhdr *eth = eth_hdr(skb);
	struct ethhdr *inner_eth = NULL;
	struct xnetdev_priv *upper_net_priv = NULL;
	unsigned char *in_packet = (unsigned char *)eth_hdr(skb);
	struct xsw_packet_header *ph =
		(struct xsw_packet_header *)(in_packet);
	struct xsw_cpu_rx_shim_header *cpu_rx_shim =
		&ph->shim_header.cpu_rx_shim;
	__u8 learning_event = 0;
	__u8 trap_reason = 0;
	__u8 die_id = 0;
	__u8 phy_port_id = 0;
	__u8 lo_port_id = 0;
	int ret = 0;

#ifdef __RX_TX_STOP_SUPPORT__
	if (rx_tx_stop) {
		xpci_err_netdev(netdev,
				"<--- CPU RX: RX STOPPED --> drop the packet");
		netdev->stats.rx_dropped++;
		dev_kfree_skb(skb);
		return RX_HANDLER_CONSUMED; /* Packet dropped */
	}
#endif

	xpci_dbg_netdev(netdev,
			"                                                ");
	xpci_dbg_netdev(netdev, "<--- CPU RX: IN skb: [%p] len: %d data_len: %d", skb, skb->len, skb->data_len);

	if (unlikely(unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2)))
		xpci_print_pkt("ETH-IN", netdev, skb, 0, xpci_rx);

	/* GFP_ATOMIC because this is a packet interrupt handler.            */
	/* Make our own copy of the packet.  Otherwise we will mangle the    */
	/* packet for anyone who came before us (e.g. tcpdump via AF_PACKET).*/
	skb = skb_share_check(skb, GFP_ATOMIC);
	if (unlikely(!skb)) {
		xpci_err_netdev(netdev, "Can't skb_share_check");
		return RX_HANDLER_CONSUMED;
	}

	/* Check if interface is UP */
	if (unlikely(!(netdev->flags & IFF_UP))) {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Device is down --> drop the packet");
		goto error_drop;
	}

#ifdef __RX_TX_STOP_SUPPORT__
	/* Check if trace stop asked by XBM */
	if (eth->h_proto == ntohs(0x8888)) {
		xpci_print_pkt("RX-TX-STOP", netdev, skb, 0, xpci_rx);
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Wrong Eth type received on CPU port: [0x%x]",
			ntohs(eth->h_proto));
		rx_tx_stop = true;
		goto error_drop;
	}
#endif

	/* Check if packet is for us */
	/* Only EGRESS shim header is alowed to be received from the device */
	if (unlikely(eth->h_proto != ntohs(XSW_SHIM_HEADER_ETHTYPE_EGRESS))) {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Wrong Eth type received on CPU port: [0x%x]",
			ntohs(eth->h_proto));
		goto error_drop;
	}

	/* Ignore packet loops (and multicast echo) */
	if (unlikely(ether_addr_equal(eth_hdr(skb)->h_source, netdev->dev_addr))) {
		xpci_err_netdev(netdev, "<--- CPU RX: Loooop --> DROP");
		netdev->stats.rx_errors++;
		goto error_drop;
	}

	learning_event = cpu_rx_shim->learning_event;
	trap_reason = cpu_rx_shim->trap_reason;
	die_id = cpu_rx_shim->die_id;
	phy_port_id = cpu_rx_shim->port_id;

	/* Physical to Logical  */
	if (unlikely(phy_port_id >= XPCI_NET_MAX_DEVICE_PORTS_NUM)) {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Packet [%p] received on invalid physical port[%d] --> DROP",
			skb, phy_port_id);
		goto error_drop;
	}

	if (xpci_phy_to_lo_port_map[phy_port_id].in_use) {
		lo_port_id = xpci_phy_to_lo_port_map[phy_port_id].lo_port;
	} else {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Packet [%p] received on non-initialized physical port[%d] --> DROP",
			skb, phy_port_id);
		goto error_drop;
	}
	/************************/

	xpci_dbg_netdev(
		netdev,
		"<--- CPU RX: Trap Reason:[%s|0x%x] Die ID: [%d] Physical/Logical Port ID[%d/%d] Learning Event[0x%x] Cookie[0x%x]",
		xnetdev_trap_name[trap_reason], trap_reason, die_id,
		phy_port_id, lo_port_id, learning_event, cpu_rx_shim->cookie);

	if (trap_reason > XSW_LAST_DEFINED_TRAP_REASON) {
		xpci_err_netdev(
			netdev,
			"<--- CPU RX: Trap Reason of drop type detected:[%s|0x%x] --> DROP",
			xnetdev_trap_name[trap_reason], trap_reason);

		goto normal_drop;
	}

	if (unlikely(!xpci_net_devs[lo_port_id])) {
		if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2))
			xpci_err_netdev(
				netdev,
				"<--- CPU RX: Port[%d] Upper layer is not initialized --> DROP",
				lo_port_id);
		goto error_drop;
	}

	upper_net_priv = netdev_priv(xpci_net_devs[lo_port_id]);
	if (unlikely(!upper_net_priv->up_state) ||
			unlikely(!upper_net_priv->oper_status)) {
		if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2))
			xpci_err_netdev(
				netdev,
				"<--- CPU RX: Port[%d] is down [Admin:%s | Oper:%s]--> DROP",
				lo_port_id,
				upper_net_priv->up_state ? "UP" : "DOWN",
				upper_net_priv->oper_status ? "UP" : "DOWN");
		goto error_drop;
	}

	if (unlikely(unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_3)))
		xpci_print_pkt("<--- CPU RX: SHIM PULL", netdev, skb, 0, xpci_rx);

	/* Actual Rx per port demultiplexing is here */
	skb->dev = xpci_net_devs[lo_port_id];

	/* Check if interface is UP */
	if (unlikely(!(skb->dev->flags & IFF_UP))) {
		if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2))
			xpci_err_netdev(
				skb->dev,
				"<--- CPU RX: Device is down --> drop the packet");
		skb->dev->stats.rx_dropped++;
		goto error_drop;
	}

	if (unlikely(!pskb_may_pull(skb, XSW_RX_SHIM_HDR_SIZE))) {
		xpci_err_netdev(
			skb->dev,
			"<--- CPU RX: SKB error: skb_pull(XSW_RX_SHIM_HDR_SIZE) can't pull. skb: [%p] skb->len: [%d]",
			skb, skb->len);
		xpci_print_pkt("SKB_ERR", netdev, skb, 0, xpci_rx);
		skb->dev->stats.rx_dropped++;
		goto error_drop;
	}

	/* remove the SHIM header */
	skb_pull(skb, XSW_RX_SHIM_HDR_SIZE);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_3))
		xpci_print_pkt("<--- CPU RX: AFTER SHIM header remove", netdev, skb, 0,
			       xpci_rx);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_3))
		xpci_print_pkt("<--- CPU RX: AFTER SHIM header remove", netdev, skb, 0,
			       xpci_rx);

	inner_eth = (struct ethhdr *)skb->data;

	/* Encode MAC length and inner protocol */
	skb->protocol = inner_eth->h_proto;
	skb_reset_mac_header(skb);
	skb_reset_network_header(skb);
	skb_reset_transport_header(skb);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_3))
		xpci_print_pkt("<--- CPU RX: AFTER MAC RESET", netdev, skb, 0,
			       xpci_rx);

	if (unlikely(skb->pkt_type == PACKET_LOOPBACK)) {
		xpci_err_netdev(netdev, "Loopback packet: Packet skipped");
		return RX_HANDLER_PASS;
	}

	if (unlikely(!is_valid_ether_addr(eth_hdr(skb)->h_source))) {
		xpci_err_netdev(netdev, "Invalid source address [1]: %pM",
				eth_hdr(skb)->h_source);
		goto error_drop;
	}

	if (unlikely(trap_reason == XSW_TRAP_REASON_SAMPLEPACKET)) {
		ret = xpci_handle_sflow_sample(upper_net_priv, skb, phy_port_id);
		xpci_dbg_netdev(netdev, "<--- CPU RX: SAMPLEPACKET Trap port [%d]. skb: [%p] --> NORMAL DROP", phy_port_id, skb);
		goto normal_drop;
	}

	if (unlikely(learning_event)) {
		ret = xpci_handle_learning_event(netdev, skb, learning_event, lo_port_id);
		/* Ignore return code - we are going to check if to drop this packet or not just below */

		if (trap_reason == XSW_TRAP_REASON_UNMATCH_SA) {
			xpci_dbg_netdev(netdev, "<--- CPU RX: Learning Event [%s] with UNMATCH SA. skb: [%p] --> NORMAL DROP",
				learning_event==XSW_LEARNING_EVENT_SA_MISS?"SA MISS":"SA MOVE", skb);
			goto normal_drop;
		}
	}

	/*
		 eth_type_trans() is calling to skb_pull_inline() internally
		 It can crash the Kernel - so, let's try to avoid it
	*/
	if (unlikely(!pskb_may_pull(skb, ETH_HLEN))) {
		xpci_err_netdev(
			skb->dev,
			"<--- CPU RX: SKB error: skb_pull(ETH_LEN) can't pull. skb: [%p]",
			skb);
		xpci_print_pkt("SKB_ERR", netdev, skb, 0, xpci_rx);
		skb->dev->stats.rx_dropped++;
		goto error_drop;
	}

	/* Remove Ethernet header */
	skb->protocol = eth_type_trans(skb, skb->dev);
	/*
		This routine often returns PACKET_OTHERHOST and L3 doesn't work
		(see ip_rcv_core() drop for all PACKET_OTHERHOST skb's)
		If it's not PACKET_BROADCAST or PACKET_MULTICAST
		Then set packet type always to PACKET_HOST
		i.e. always redirect skb to host
	*/
	if (skb->pkt_type == PACKET_OTHERHOST)
		skb->pkt_type = PACKET_HOST;

	skb_reset_network_header(skb);
	skb_reset_transport_header(skb);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_3))
		xpci_print_pkt("<--- CPU RX: Before netif_rx()", netdev, skb, 0, xpci_rx);

	*pskb = skb;

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_1)) {
		xpci_info_netdev(
			netdev,
			"<--- CPU RX: skb: [%p] --> [%s] Port ID: [%d] Trap Reason:[%s|0x%x]",
			skb, skb->dev->name, lo_port_id,
			trap_reason < XSW_LAST_DEFINED_TRAP_REASON ?
				xnetdev_trap_name[trap_reason] :
				"undefined",
			trap_reason);
	}

	netif_rx(skb);

	/* Update statistics for this device */
	netdev->stats.rx_packets++;
	netdev->stats.rx_bytes += skb->len;

	/* Update statistics for upper layer device */
	netdev = skb->dev;
	netdev->stats.rx_packets++;
	netdev->stats.rx_bytes += skb->len;

	return RX_HANDLER_CONSUMED;

error_drop:
	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2)) {
		xpci_err_netdev(netdev, "<--- CPU RX: Packet dropped: [%p] Phy Port ID: [%d] Lo Port Id: [%d]", skb,
				phy_port_id, lo_port_id);
		xpci_print_pkt("DROP", netdev, skb, 0, xpci_rx);
	}

	netdev->stats.rx_dropped++;

normal_drop:
	dev_kfree_skb(skb);

	return RX_HANDLER_CONSUMED; /* Packet dropped */
}

/* net device transmit always called with BH disabled */
netdev_tx_t xnetdev_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);
	struct net_device *ethdev = NULL;
	struct xsw_packet_header *pck_hdr = NULL;
	u32 len, hdr_len;
	__be16 protocol = 0;
	u32 q_id = 0;
	int ret = 0;

#ifdef __RX_TX_STOP_SUPPORT__
	if (rx_tx_stop) {
		xpci_err_netdev(
			netdev,
			"---> CPU TX: TX STOPPED --> drop the packet");
		netdev->stats.tx_errors++;
		dev_kfree_skb(skb);
		ret = -ENXIO;
		goto out;
	}
#endif

	xpci_dbg_netdev(netdev,
			"                                                ");
	xpci_dbg_netdev(netdev, "---> CPU TX: IN skb: [%p]", skb);

	spin_lock(&net_priv->tx_lock);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2))
		xpci_print_pkt("TX", netdev, skb, 0, xpci_tx);

	ethdev = dev_get_by_name(&init_net, xpci_get_attach_dev());
	if (!ethdev) {
		xpci_err("---> CPU TX: Can't get attached device: [%s]",
			 xpci_get_attach_dev());
		netdev->stats.tx_errors++;
		dev_kfree_skb(skb);
		ret = -ENXIO;
		goto out;
	}

	if (unlikely(!(ethdev->flags & IFF_UP) || !(netdev->flags & IFF_UP))) {
		xpci_err_netdev(
			netdev,
			"---> CPU TX: TX: Device is down --> drop the packet");
		netdev->stats.tx_errors++;
		dev_kfree_skb(skb);
		ret = -ENXIO;
		goto out;
	}

	protocol = skb->protocol;
	len = skb->len;

	hdr_len = XSW_TX_TUN_HDR_SIZE + XSW_TX_SHIM_HDR_SIZE;

	if (skb_headroom(skb) < hdr_len) {
		struct sk_buff *skb2;

		skb2 = skb_copy_expand(skb, hdr_len, 0, GFP_ATOMIC);
		dev_kfree_skb_any(skb);
		skb = skb2;
		if (!skb) {
			xpci_err_netdev(
				netdev,
				"---> CPU TX: Not enough headroom for %d bytes --> drop the packet",
				hdr_len);
			ret = -ENOMEM;
			goto out;
		}
	}

	pck_hdr = (struct xsw_packet_header *)skb_push(skb, hdr_len);
	if (!pck_hdr) {
		xpci_err_netdev(
			netdev,
			"---> CPU TX: skb_push() error --> drop the packet");
		dev_kfree_skb(skb);
		ret = -ENOMEM;
		goto out;
	}

	/* Get Egress Queue id */
	q_id = net_priv->q_id;
	/***********************/

	memset(pck_hdr->tunnel_header.dsta, 0, ETH_ALEN);
	memset(pck_hdr->tunnel_header.srca, 0, ETH_ALEN);
	pck_hdr->tunnel_header.type = XSW_SHIM_HEADER_ETHTYPE_EGRESS;
	pck_hdr->shim_header.cpu_tx_shim.egress_qid =
		cpu_to_be16(q_id);

	skb->protocol = XSW_SHIM_HEADER_ETHTYPE_EGRESS;
	skb->dev = ethdev;

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_1))
		xpci_info_netdev(
			netdev,
			"---> CPU TX: skb: [%p] --> [%s] skb->len: %d proto: [0x%x] lo_port_id: [%d] phy_port_id: [%d] q_id: [0x%x]",
			skb, skb->dev->name, skb->len, be16_to_cpu(protocol),
			net_priv->lo_port_id, net_priv->phy_port_id, q_id);

	if (unlikely(!(skb->dev->flags & IFF_UP))) {
		xpci_err_netdev(
			netdev,
			"---> CPU TX: output error: device [%s] is DOWN. skb: [%p]",
			skb->dev->name, skb);
		netdev->stats.tx_errors++;
		dev_kfree_skb(skb);
		ret = -ENOMEM;
		goto out;
	}

	skb_tx_timestamp(skb);

	if (unlikely(xpci_pkt_trace >= XPCI_PKT_TRACE_2))
		xpci_print_pkt("++++++TX++++++", netdev, skb, 0, xpci_tx);

	xpcxd_trace(tx_netdev_pkt, q_id, skb, skb->len, skb->protocol, 0);

	ret = dev_queue_xmit(skb);
	if (unlikely(ret < 0)) {
		// xpci_err_netdev(netdev,
		// 		"dev_queue_xmit() skb: [%p] returned %d", skb,
		// 		ret);
		netdev->stats.tx_errors++;
	} else {
		netdev->stats.tx_packets++;
		netdev->stats.tx_bytes += skb->len;
	}

	dev_put(ethdev);

	spin_unlock(&net_priv->tx_lock);

	xpci_dbg_netdev(netdev, "---> CPU TX: OUT");

	return NET_XMIT_SUCCESS;

out:
	netdev->stats.tx_dropped++;
	xpci_err_netdev(netdev, "---> CPU TX: error skb: [%p]", skb);

	spin_unlock(&net_priv->tx_lock);

	return ret;
}

int xpci_init_rx_tx_ports(uint num_of_ports)
{
	/* Number of ports is always num_of_ports + 1: cpu + data ports */
	xpci_net_devs = kcalloc(num_of_ports + 1, sizeof(struct net_device *),
				GFP_KERNEL);
	if (!xpci_net_devs) {
		xpci_err("Can't allocate memory");
		return -1;
	}

	memset(&xpci_phy_to_lo_port_map, 0,
	       sizeof(sizeof(struct xpci_lo_port) *
		      XPCI_NET_MAX_DEVICE_PORTS_NUM));

	return 0;
}

void xnetdev_set_multicast_list(struct net_device *netdev)
{
	/* Empty callback just for teamd compatibility */
	xpci_dbg_netdev(netdev, "ndo_set_rx_mode not implemented");

	return;
}

void xpci_free_rx_tx_ports(void)
{
	if (xpci_net_devs)
		kfree(xpci_net_devs);
}

int xpci_allocate_if_port(struct net_device *netdev, uint phy_port_id, uint lo_port_id, u16 q_id)
{
	uint dev_num = lo_port_id;
	struct xnetdev_priv *net_priv = NULL;

	net_priv = netdev_priv(netdev);
	if (net_priv == NULL) {
		xpci_err_netdev(netdev,
				"Failed to get net_priv pointer: NULL ");
		return -1;
	}

	if (net_priv->in_use) {
		xpci_err_netdev(
			netdev, "Interface is already");
		return -1;
	}

	xpci_notice_netdev(netdev, "Port allocation: Physical/Local Port: %d<->%d q_id: 0x%x",
		phy_port_id, lo_port_id, q_id);

	net_priv->phy_port_id = phy_port_id;
	net_priv->lo_port_id = lo_port_id;
	net_priv->q_id = q_id;
	net_priv->in_use = true;

	xpci_net_devs[dev_num] = netdev;

	xpci_phy_to_lo_port_map[phy_port_id].dev_num = lo_port_id;
	xpci_phy_to_lo_port_map[phy_port_id].lo_port = lo_port_id;
	xpci_phy_to_lo_port_map[phy_port_id].in_use = true;

	xpci_lo_to_phy_port_map[lo_port_id].phy_port = phy_port_id;
	xpci_lo_to_phy_port_map[lo_port_id].q_id = q_id;
	xpci_lo_to_phy_port_map[lo_port_id].in_use = true;

	return 0;
}

int xpci_release_if_port(struct net_device *netdev)
{
	uint dev_num = 0;
	uint phy_port_id = 0;
	uint lo_port_id = 0;
	struct xnetdev_priv *net_priv = NULL;

	net_priv = netdev_priv(netdev);
	if (net_priv == NULL) {
		xpci_err_netdev(netdev,
				"Failed to get net_priv pointer: NULL ");
		return -1;
	}

	if (!net_priv->in_use) {
		xpci_err_netdev(
			netdev, "Interface not in use");
		return -1;
	}

	phy_port_id = net_priv->phy_port_id;
	lo_port_id = net_priv->lo_port_id;

	xpci_notice_netdev(netdev, "Port release: Physical/Local Port: %d<->%d",
		phy_port_id, lo_port_id);

	net_priv->phy_port_id = 0;
	net_priv->lo_port_id = 0;
	net_priv->q_id = 0;
	net_priv->in_use = false;

	xpci_net_devs[dev_num] = netdev;

	xpci_phy_to_lo_port_map[phy_port_id].dev_num = 0;
	xpci_phy_to_lo_port_map[phy_port_id].lo_port = 0;
	xpci_phy_to_lo_port_map[phy_port_id].in_use = false;

	xpci_lo_to_phy_port_map[lo_port_id].phy_port = 0;
	xpci_lo_to_phy_port_map[lo_port_id].q_id = 0;
	xpci_lo_to_phy_port_map[lo_port_id].in_use = false;

	return 0;
}

struct net_device *xpci_get_net_dev(int dev_num)
{
	return xpci_net_devs[dev_num];
}
