// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device RT Netlink handler
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/rtnetlink.h>
#include <net/rtnetlink.h>
#include <linux/netlink.h>

#include "xnetdev.h"
#include "xpci_dbg.h"

extern struct xpci_phy_port xpci_phy_to_lo_port_map[XPCI_NET_MAX_DEVICE_PORTS_NUM];
extern struct xpci_lo_port xpci_lo_to_phy_port_map[XPCI_NET_MAX_DEVICE_PORTS_NUM];

static uint xpci_registered_netdev_ports = 0;
struct xpci_nl_msg {
	bool dump_msg;
	__u32 cmd;
	bool if_msg;
	char *if_name;
	__u32 if_state;
	__u8 if_op;
	bool if_port_msg;
	__u8 if_port_op;
	__u32 phy_port_id;
	__u32 q_id;
	__u32 lo_port_id;
};

static int xpci_nl_msg_parse(struct nlattr *data[], struct xpci_nl_msg *nl_msg)
{
	bool netdev_cfg = false;
	bool port_cfg = false;
	bool dump_cfg = false;

	xpci_dbg("--- Parsing started ---");

	if (!data) {
		xpci_err("Missing data[]");
		return -EINVAL;
	}

	if (data[IFLA_XNETDEV_IF_CFG]) {
		xpci_dbg("--- IFLA_XNETDEV_IF_CFG:%d ---", nla_get_u32(data[IFLA_XNETDEV_IF_CFG]));
		if (nla_get_u8(data[IFLA_XNETDEV_IF_CFG]))
			netdev_cfg = true; 
	}

	if (data[IFLA_XNETDEV_PORT_CFG]) {
		xpci_dbg("--- IFLA_XNETDEV_PORT_CFG:%d ---", nla_get_u32(data[IFLA_XNETDEV_PORT_CFG]));
		if (nla_get_u8(data[IFLA_XNETDEV_PORT_CFG]))
			port_cfg = true;
	}

	if (data[IFLA_XNETDEV_DUMP_CFG]) {
		xpci_dbg("--- IFLA_XNETDEV_DUMP_CFG:%d ---", nla_get_u32(data[IFLA_XNETDEV_DUMP_CFG]));
		if (nla_get_u8(data[IFLA_XNETDEV_DUMP_CFG]))
			dump_cfg = true; 
	}

	if (netdev_cfg) {
		xpci_dbg("Parsing IFLA_XNETDEV_IF_CFG: %d", nla_get_u32(data[IFLA_XNETDEV_IF_CFG]));
		netdev_cfg = true; 
		nl_msg->if_msg = true;
		if (data[IFLA_XNETDEV_IF_OP]) {
			nl_msg->if_op =
				nla_get_u8(data[IFLA_XNETDEV_IF_OP]);
		} else {
			xpci_err("Interface operation name is not provided");
			return -EINVAL;
		}

		xpci_info("IFLA_XNETDEV_IF_OP: [%d]", nl_msg->if_op);

		if (data[IFLA_XNETDEV_IF_NAME]) {
			nl_msg->if_name = (char *)nla_data(
				data[IFLA_XNETDEV_IF_NAME]);
		} else {
			xpci_err("Interface name is not provided");
			return -EINVAL;
		}

		xpci_info("IFLA_XNETDEV_IF_NAME: interface name: [%s]",
			  nl_msg->if_name);

		if (data[IFLA_XNETDEV_IF_STATE]) {
			nl_msg->if_state = nla_get_u32(
				data[IFLA_XNETDEV_IF_STATE]);
		} else {
			xpci_err("Interface state is not provided");
			return -EINVAL;
		}

		xpci_info(
			"IFLA_XNETDEV_IF_STATE: %s ",
			((nl_msg->if_state) ?
				       ((nl_msg->if_state == XPCI_IF_UP) ?
						"UP" :
						"DOWN") :
				       "UNCHANGED"));
	}

	if (port_cfg) {
		xpci_dbg("Parsing IFLA_XNETDEV_PORT_CFG");
		nl_msg->if_port_msg = true;

		if (data[IFLA_XNETDEV_PHY_PORT]) {
			nl_msg->phy_port_id =
				nla_get_u32(data[IFLA_XNETDEV_PHY_PORT]);
			if (nl_msg->phy_port_id >=
			    XPCI_NET_MAX_DEVICE_PORTS_NUM) {
				xpci_err(
					"Physical Port ID out of range: %d of %d ports",
					nl_msg->phy_port_id,
					XPCI_NET_MAX_DEVICE_PORTS_NUM);
				return -ERANGE;
			}
		} else {
			xpci_err("Physical Port ID not provided");
			return -EINVAL;
		}

		xpci_info("Phy port: %d", nl_msg->phy_port_id);

		if (data[IFLA_XNETDEV_LO_PORT]) {
			nl_msg->lo_port_id =
				nla_get_u32(data[IFLA_XNETDEV_LO_PORT]);
		} else {
			xpci_err("Local Port id not provided");
			return -EINVAL;
		}

		xpci_info("Local port: %d", nl_msg->lo_port_id);

		if (data[IFLA_XNETDEV_QID]) {
			nl_msg->q_id =
				nla_get_u32(data[IFLA_XNETDEV_QID]);
		} else {
			xpci_err("Queue id not provided");
			return -EINVAL;
		}

		xpci_info("Queue port: %d", nl_msg->q_id);
	}
	
	if (dump_cfg) {
		xpci_dbg("Parsing IFLA_XNETDEV_DUMP_CFG");
		nl_msg->dump_msg = true;
		nl_msg->cmd = nla_get_u32(data[IFLA_XNETDEV_DUMP_CMD]);

		xpci_info("IFLA_XNETDEV_DUMP_CMD: %d", nl_msg->cmd);
	}

	xpci_dbg("--- Parsing finished ---");

	return 0;
}

static void xnetdev_setup(struct net_device *netdev)
{
	xpci_dbg("RTNL SETUP");
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xnetdev_validate(struct nlattr *tb[], struct nlattr *data[],
				struct netlink_ext_ack *extack)
#else
static int xnetdev_validate(struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct xpci_nl_msg nl_msg = { 0 };
	
	int ret = 0;

	xpci_info("RTNL VALIDATE");

	if (tb[IFLA_ADDRESS]) {
		xpci_info("RTNL: IFLA_ADDRESS");

		if (nla_len(tb[IFLA_ADDRESS]) != ETH_ALEN)
			return -EINVAL;
		if (!is_valid_ether_addr(nla_data(tb[IFLA_ADDRESS])))
			return -EADDRNOTAVAIL;
	}

	ret = xpci_nl_msg_parse(data, &nl_msg);
	if (ret)
		return ret;

	xpci_info("RTNL VALIDATE: OK");

	return 0;
}

static size_t xnetdev_get_size(const struct net_device *netdev)
{
	xpci_dbg_netdev(netdev, "XPCI RTNL GET SIZE");

	return 
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_IF_CFG */
			nla_total_size(sizeof(__u8))  + /* IFLA_XNETDEV_IF_OP */
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_IF_STATE */

			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_PORT_CFG */
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_PHY_PORT */
			nla_total_size(sizeof(__u16)) + /* IFLA_XNETDEV_LO_PORT */
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_QID */
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_DUMP_CFG */
			nla_total_size(sizeof(__u32)) + /* IFLA_XNETDEV_DUMP_CMD */

			0;
}

static int xnetdev_fill_info(struct sk_buff *skb,
				 const struct net_device *netdev)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);
	// int err = 0; 

	// xpci_dbg_netdev(netdev, "IN:  RTNL FILL INFO");

	if (nla_put_u32(skb, IFLA_XNETDEV_PHY_PORT, net_priv->phy_port_id)) {
		goto nla_put_failure;
	}

	if (nla_put_u32(skb, IFLA_XNETDEV_LO_PORT, net_priv->lo_port_id)) {
		goto nla_put_failure;
	}

	if (nla_put_u32(skb, IFLA_XNETDEV_QID, net_priv->q_id)) {
		goto nla_put_failure;
	}

	// xpci_dbg_netdev(netdev, "OUT: RTNL FILL INFO");

	return 0;

nla_put_failure:

	xpci_dbg_netdev(netdev, "ERROR: RTNL FILL INFO: %d", -EMSGSIZE);
	return -EMSGSIZE;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xnetdev_newlink(struct net *src_net, struct net_device *netdev,
			       struct nlattr *tb[], struct nlattr *data[],
			       struct netlink_ext_ack *extack)
#else
static int xnetdev_newlink(struct net *src_net, struct net_device *netdev,
			       struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct net_device *xpci_cpu_net_dev = NULL;
	struct xpci_nl_msg nl_msg = { 0 };
	int ret = 0;

	xpci_dbg_netdev(netdev, "RTNL NEWLINK: %p", netdev);

	if (xpci_registered_netdev_ports >= xpci_max_ports) {
		xpci_err_netdev(netdev, "Max registered ports reached: %d",
				xpci_registered_netdev_ports);
		return 0;
	}

	ret = xpci_nl_msg_parse(data, &nl_msg);
	if (ret)
		return ret;

	/* Check DUMP section is present  */
	if (nl_msg.dump_msg) {
		xpci_dbg_netdev(netdev, "DUMP request");
		xpci_dump_if_port_table();
		return 0;
	}

	/* Check interface section is present  */
	if (!nl_msg.if_msg || nl_msg.if_op != XPCI_IF_OP_ADD) {
		xpci_err_netdev(netdev,"Can't RTNL NEWLINK - device doesn't exist. Wrong config sections !");
		return -ENODEV;
	}

	xpci_notice_netdev(netdev, "RTNL NEWLINK: Physical/Local Port: %d<->%d q_id: 0x%x", 
		nl_msg.phy_port_id, nl_msg.lo_port_id, nl_msg.q_id);

	xpci_cpu_net_dev = xpci_get_cpu_netdev();

	ret = xnetdev_register(xpci_cpu_net_dev->name, nl_msg.if_name,
				   nl_msg.phy_port_id, netdev, false);
	if (ret) {
		xpci_err_netdev(netdev, "Net Device %s register failed",
				nl_msg.if_name);
		return -ENODEV;
	}

	xpci_notice_netdev(netdev, "MAC address SET: %pM ", netdev->dev_addr);

	ret = xpci_allocate_if_port(netdev, nl_msg.phy_port_id, nl_msg.lo_port_id, nl_msg.q_id);
	if (ret) {
		xpci_err_netdev(netdev,"Net Device %s allocation failed", nl_msg.if_name);
		return -ENODEV;
	}

	/* Set operational state */
	xnetdev_set_if_state(netdev, (nl_msg.if_state == XPCI_IF_UP));

	xpci_registered_netdev_ports++;

	xpci_dbg_netdev(netdev, "RTNL NEWLINK: DONE");

	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 13, 0)
static int xnetdev_changelink(struct net_device *netdev,
				  struct nlattr *tb[], struct nlattr *data[],
				  struct netlink_ext_ack *extack)
#else
static int xnetdev_changelink(struct net_device *netdev,
				  struct nlattr *tb[], struct nlattr *data[])
#endif
{
	struct xpci_nl_msg nl_msg = { 0 };
	int ret = 0;

	xpci_dbg_netdev(netdev, "RTNL CHANGE LINK");

	ret = xpci_nl_msg_parse(data, &nl_msg);
	if (ret)
		return ret;

	if (nl_msg.if_msg)
		xnetdev_set_if_state(netdev, (nl_msg.if_state == XPCI_IF_UP));

	/* Check DUMP section is present  */
	if (nl_msg.dump_msg) {
		xpci_dbg_netdev(netdev,"DUMP request");
		xpci_dump_if_port_table();
		return 0;
	}

	xpci_dbg_netdev(netdev, "RTNL CHANGE LINK: DONE");

	return 0;
}

static void xnetdev_dellink(struct net_device *netdev,
				struct list_head *head)
{
	struct net_device *xpci_cpu_net_dev = NULL;
	int ret = 0;

	xpci_dbg_netdev(netdev, "RTNL DELLINK");

	xpci_cpu_net_dev = xpci_get_cpu_netdev();

	if (!xpci_cpu_net_dev) {
		xpci_err_netdev(netdev, "Net Device release failed. xpci_cpu_net_dev==NULL");
		return;	
	}
	xpci_unregister_netdev(xpci_cpu_net_dev->name, netdev, head, false,
			       false);

	ret = xpci_release_if_port(netdev);
	if (ret) {
		xpci_err_netdev(netdev, "Net Device [%s] release failed",
				xpci_cpu_net_dev->name);
		return;
	}

	xpci_registered_netdev_ports--;

	xpci_dbg_netdev(netdev, "RTNL DELLINK: DONE");
}

static const struct nla_policy xnetdev_policy[IFLA_XNETDEV_MAX + 1] = {
	[IFLA_XNETDEV_DUMP_CFG] = { .type = NLA_U32 },
	[IFLA_XNETDEV_DUMP_CMD] = { .type = NLA_U32 },
	[IFLA_XNETDEV_IF_CFG] = { .type = NLA_U32 },
	[IFLA_XNETDEV_IF_OP] = { .type = NLA_U8 },
	[IFLA_XNETDEV_IF_STATE] = { .type = NLA_U32 },
	[IFLA_XNETDEV_PORT_CFG] = { .type = NLA_U32 },
	[IFLA_XNETDEV_PHY_PORT] = { .type = NLA_U32 },
	[IFLA_XNETDEV_LO_PORT] = { .type = NLA_U32 },
	[IFLA_XNETDEV_QID] = { .type = NLA_U32 },
};

static struct rtnl_link_ops xnetdev_link_ops __read_mostly = {
	.kind = "xpci_netdev",
	.priv_size = sizeof(struct xnetdev_priv),
	.maxtype = IFLA_XNETDEV_MAX,
	.policy = xnetdev_policy,
	.setup = xnetdev_setup,
	.validate = xnetdev_validate,
	.newlink = xnetdev_newlink,
	.changelink = xnetdev_changelink,
	.dellink = xnetdev_dellink,
	.get_size = xnetdev_get_size,
	.fill_info = xnetdev_fill_info
};

int xnetdev_rtnl_link_register(void)
{
	xpci_dbg("NETDEV RTNL REGISTER");

	return rtnl_link_register(&xnetdev_link_ops);
}

void xnetdev_rtnl_link_unregister(void)
{
	xpci_dbg("NETDEV RTNL UNREGISTER");

	rtnl_link_unregister(&xnetdev_link_ops);
}

void xpci_dump_if_port_table(void)
{
	int phy_port_id;
	int lo_port_id;

	xpci_info("  ");
	xpci_info("| ****************** |");
	xpci_info("| Phy to Lo mapping  |");
	xpci_info("| ****************** |");
	xpci_info("| phy-port | lo-port |");

	for (phy_port_id = 0; phy_port_id < xpci_max_ports; phy_port_id++) {
		if (!xpci_phy_to_lo_port_map[phy_port_id].in_use)
			continue;

		xpci_info("|    %4d  |    %4d |", phy_port_id,
			  xpci_phy_to_lo_port_map[phy_port_id].lo_port);
	}

	xpci_info("| ****************** |");

	xpci_info("  ");

	xpci_info("| ***************************** |");
	xpci_info("| Lo to Phy mapping             |");
	xpci_info("| ***************************** |");
	xpci_info("| lo-port | phy-port | q_id     |");

	for (lo_port_id = 0; lo_port_id < xpci_max_ports; lo_port_id++) {
		if (!xpci_lo_to_phy_port_map[lo_port_id].in_use)
			continue;

	xpci_info("|   %4d  |   %4d   |   %4d   |", lo_port_id,
			  xpci_lo_to_phy_port_map[lo_port_id].phy_port,
			  xpci_lo_to_phy_port_map[lo_port_id].q_id);
	}
	xpci_info("| ***************************** |");
}