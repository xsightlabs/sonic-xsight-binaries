// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device common definitions
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#ifndef XNETDEV_H_
#define XNETDEV_H_

#include <linux/netdevice.h>
#include <net/psample.h>

#include "xpci_main.h"

#define XNETDEV_DRV_NAME "xpci_netdev"

#define MAX_CFG_ITEM_LEN 32

#define XPCI_NET_DEV_NAME_SIZE 64

/**
 *
 * Max ASIC physical ports
 *
 */
#define XPCI_NET_MAX_DEVICE_PORTS_NUM 256

/**
 *
 * Max frontpanel ports and netdev devices
 *
 */
#define XPCI_NET_DEV_NUM XPCI_NET_MAX_DEVICE_PORTS_NUM

#define XPCI_JUMBO_FRAME_SIZE 9216
#define XPCI_DEFAULT_MTU_SIZE (XPCI_JUMBO_FRAME_SIZE)

/**
 * Netlink parameters to create port netdev
 * ip link add NAME type xnetdev [ queie id QID ] port PORT
 */
enum xnetdev_spec {
	IFLA_XNETDEV_UNSPEC,
	IFLA_XNETDEV_IF_CFG,
	IFLA_XNETDEV_IF_OP,
	IFLA_XNETDEV_IF_NAME,
	IFLA_XNETDEV_IF_STATE,
	IFLA_XNETDEV_PORT_CFG,
	IFLA_XNETDEV_PORT_OP,
	IFLA_XNETDEV_PHY_PORT,
	IFLA_XNETDEV_LO_PORT,
	IFLA_XNETDEV_QID,
	IFLA_XNETDEV_DUMP_CFG,
	IFLA_XNETDEV_DUMP_CMD,

	__IFLA_XNETDEV_MAX
};
#define IFLA_XNETDEV_MAX (__IFLA_XNETDEV_MAX - 1)

/**
 * Interface ADD/DELETE/UPDATE
 */
enum xpci_if_op { XPCI_IF_OP_ADD, XPCI_IF_OP_UPDATE, XPCI_IF_OP_DEL };

/**
 * Interface operational state
 */
enum xpci_if_state { XPCI_IF_UNCHANGED, XPCI_IF_UP, XPCI_IF_DOWN };

struct xnetdev_port_sample {
	struct psample_group __rcu *psample_group;
	u32 trunc_size;
	u32 rate;
	bool truncate;
};

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
struct xnetdev_flow_block_binding {
	struct list_head list;
	struct xnetdev_priv *net_priv;
	bool ingress;
};

struct xnetdev_flow_block {
	struct list_head binding_list;
	struct {
		struct list_head list;
		unsigned int min_prio;
		unsigned int max_prio;
	} mall;
	unsigned int rule_count;
	unsigned int disable_count;
	unsigned int ingress_blocker_rule_count;
	unsigned int egress_blocker_rule_count;
	unsigned int ingress_binding_count;
	unsigned int egress_binding_count;
	struct net *net;
	struct xnetdev_priv *net_priv;
};
#endif

/**
 * Net Dev private structure
 */
struct xnetdev_priv {
	struct net_device *netdev;
	u32 phy_port_id;
	u32 lo_port_id;
	u32 q_id;
	bool in_use;
	union {
		u8 mac[6];
		__be64 mac_addr;
	};
	bool up_state;
	bool oper_status;
	bool cpu_dev;
	spinlock_t tx_lock;

	struct xnetdev_port_sample __rcu *sample;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
	struct xnetdev_flow_block *ing_flow_block;
	struct xnetdev_flow_block *eg_flow_block;
#endif
};

struct xpci_phy_port {
	u32 lo_port;
	u32 dev_num;
	bool in_use;
};

struct xpci_lo_port {
	u32 phy_port;
	u16 q_id;
	bool in_use;
};

extern char attach_dev_name[];
extern u32 *port_to_local_q_map;
extern int xpci_max_ports;

int xnetdev_init(void);
int xnetdev_close(void);
int xnetdev_open(struct net_device *netdev);
int xnetdev_stop(struct net_device *netdev);
int xnetdev_attach(void);
struct net_device *xpci_get_cpu_netdev(void);
int xnetdev_set_if_state(struct net_device *netdev, bool status);
int xnetdev_register(char *if_attach_name, char *if_name, uint phy_port,
			 struct net_device *netdev, bool do_rtnl_lock);
void xpci_unregister_netdev(char *if_attach_name, struct net_device *netdev,
			    struct list_head *head, bool cpu_device,
			    bool do_rtnl_lock);
int xpci_init_rx_tx_ports(uint num_of_ports);
void xpci_free_rx_tx_ports(void);
struct net_device *xpci_get_net_dev(int dev_num);
void xpci_dump_if_port_table(void);
int set_xpci_net_dev(uint phy_port, uint dev_num, uint q_id,
		     struct net_device *netdev);
int clear_xpci_net_dev(uint phy_port);
struct net_device *get_xpci_net_dev(int dev_num);
rx_handler_result_t xpci_handle_cpu_frame(struct sk_buff **pskb);
netdev_tx_t xnetdev_xmit(struct sk_buff *skb, struct net_device *netdev);
void xnetdev_set_multicast_list(struct net_device *netdev);
int xnetdev_rtnl_link_register(void);
void xnetdev_rtnl_link_unregister(void);
int xpci_allocate_if_port(struct net_device *netdev, uint phy_port_id, uint lo_port_id, u16 q_id);
int xpci_release_if_port(struct net_device *netdev);

static __always_inline char *xpci_get_attach_dev(void)
{
	return attach_dev_name;
}

static __always_inline uint xpci_get_local_q_by_port(uint port_id)
{
	return port_to_local_q_map[port_id];
}

int xnetdev_setup_tc(struct net_device *netdev, enum tc_setup_type type,
			 void *type_data);

#endif /* XNETDEV_H_ */
