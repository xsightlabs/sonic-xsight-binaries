// SPDX-License-Identifier: GPL-2.0

/*
 * Networking device (netdev) driver
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/if_arp.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/pkt_cls.h>
#include <net/tc_act/tc_mirred.h>
#include <net/netevent.h>
#include <net/tc_act/tc_sample.h>

#include "xpci_version.h"
#include "xpci_dbg.h"
#include "xnetdev_common.h"
#include "xnetdev.h"
#include "xnetdev_fdb_nl.h"

/* TODOs:
 Active:
 - 1: Change attach_dev_name before or during real system brigup.
      Need to be interface name of the real CPU port
 - 2: Allocate dynamically for max number of ports
 - 3: PCI - NETDEV link. Init netdev from PCI during real system brigup

 Future:
 - 4: ASIC port operational status watchdog - change port status accordingly
      ? By SerDes events ?
 - 5: Consider NAPI polling to improve performance
      Could be not so neccessary. Most probably underline eth device is already implementing NAPI.
 - 6: Add: .ndo_validate_addr	= eth_validate_addr,
 - 7: xnetdev_do_ioctl() is not needed. left as stub. could be removed
 */

#define XNETDEV_ATTACH_DEV_NAME_LEN 64

static int xpci_tx_checksumming_mode = 1;
module_param_named(tx_checksumming, xpci_tx_checksumming_mode, uint, 0644);
MODULE_PARM_DESC(
	tx_checksumming,
	"mask: 0 = TX Checksumming Disabled, 1 = TX Checksumming Enabled. Default = 1");

char attach_dev_name[XNETDEV_ATTACH_DEV_NAME_LEN] = "eth10g1";

module_param_string(attach_if, attach_dev_name, XNETDEV_ATTACH_DEV_NAME_LEN,
		    0644);
MODULE_PARM_DESC(attach_if,
		 "netdev attach interface: [name]. Default = [eth10g1]");

int xpci_max_ports = XPCI_NET_DEV_NUM;
module_param_named(num_of_ports, xpci_max_ports, uint, 0644);
MODULE_PARM_DESC(num_of_ports, "maximum number of ports: Default = 256");

int xpci_pkt_trace = 0;
module_param_named(pkt_trace, xpci_pkt_trace, uint, 0644);
MODULE_PARM_DESC(pkt_trace, "mask: 0 = mute, 1 = low, 2 = mid, 3 = full, Default = 0");

static struct ctl_table_header *xpci_net_dev_sysctl_header;

static int xpci_sysctl_call_debug_level(struct ctl_table *ctl, int write,
					void __user *buffer, size_t *lenp,
					loff_t *ppos)
{
	int ret;

	ret = proc_dointvec(ctl, write, buffer, lenp, ppos);

	if (write) {
		xpci_err("Set debug level to: %d", *(int *)(ctl->data));
	}

	return ret;
}

static int xpci_sysctl_call_pkt_trace(struct ctl_table *ctl, int write,
				      void __user *buffer, size_t *lenp,
				      loff_t *ppos)
{
	int ret;

	ret = proc_dointvec(ctl, write, buffer, lenp, ppos);

	if (write) {
		xpci_err("Packet trace: [%s]",
			 (*(int *)(ctl->data)) ? "ON" : "OFF");
	}

	return ret;
}

static struct ctl_table xpci_net_dev_ctl_table[] = {
	{
		.procname = "debug_level",
		.data = &xpci_debug_level,
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpci_sysctl_call_debug_level,
	},
	{
		.procname = "pkt_trace",
		.data = &xpci_pkt_trace,
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpci_sysctl_call_pkt_trace,
	},
	{}
};

static struct net_device *xpci_cpu_net_dev = NULL;
static bool cpu_if_attached = false;

static int xpci_net_dev_sysctl_init(void)
{
	// xpci_dbg("IN");

	xpci_net_dev_sysctl_header = register_net_sysctl(
		&init_net, "dev/xpci", xpci_net_dev_ctl_table);
	if (xpci_net_dev_sysctl_header == NULL) {
		xpci_err("Can register net_sysctl");
		return -ENOMEM;
	}

	xpci_info("----XSIGHT NET DEV Dynamic configuration ----");
	xpci_info("CPU device to attach        : [%s]", attach_dev_name);
	xpci_info("Number of configured ports  : [%d]", xpci_max_ports);
	xpci_info("Log level                   : [%d]", xpci_debug_level);
	xpci_info("Packet trace                : [%d]", xpci_pkt_trace);

	xpci_info("---------------------------------------------");

	// xpci_dbg("OUT");

	return 0;
}

static int xnetdevice_init(struct net_device *netdev)
{
	xpci_dbg_netdev(netdev, "INIT DONE");

	return 0;
}

static void xnetdevice_uninit(struct net_device *netdev)
{
	xpci_dbg_netdev(netdev, "UNINIT DONE");
}

struct net_device *xpci_get_cpu_netdev(void)
{
	return xpci_cpu_net_dev;
}

/* This function is called when a network device transitions to the UP state */
int xnetdev_open(struct net_device *netdev)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);

	xpci_dbg_netdev(netdev, "IN");

	xpci_notice_netdev(netdev, "old state: [%s] --> UP",
			   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	xpci_info_netdev(netdev, "TX enabled");
	netif_start_queue(netdev); /* can transmit now */

	net_priv->up_state = true;

	return 0;
}

/* This function is called when a network device transitions to the DOWN state */
int xnetdev_stop(struct net_device *netdev)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);

	xpci_notice_netdev(netdev, "DOWN");

	xpci_notice_netdev(netdev, "old state: [%s] --> DOWN",
			   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	xpci_info_netdev(netdev, "TX disabled");
	netif_stop_queue(netdev); /* can't transmit any more */

	net_priv->up_state = false;

	return 0;
}

static int xnetdev_do_ioctl(struct net_device *netdev, struct ifreq *ifr,
				int cmd)
{
	xpci_dbg_netdev(netdev, "IN");

	switch (cmd) {
	/* Most of the default things are already supported in core/dev_ioctl.c */
	default:
		xpci_dbg_netdev(netdev, "Operation not supported: %d", cmd);
		return -EOPNOTSUPP;
	}

	xpci_dbg_netdev(netdev, "OUT");

	return 0;
}

static int xnetdev_change_mtu(struct net_device *netdev, int new_mtu)
{
	if ((new_mtu < ETH_ZLEN) || (new_mtu > XPCI_JUMBO_FRAME_SIZE)) {
		xpci_err_netdev(netdev, "Wrong MTU value: %d", new_mtu);
		return -EINVAL;
	}

	xpci_notice_netdev(netdev, "New MTU set to: %d", new_mtu);
	netdev->mtu = new_mtu;

	return 0;
}

static int xnetdev_set_mac_address(struct net_device *netdev, void *p)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);
	struct sockaddr *addr = p;
	int ret = 0;

	if (!is_valid_ether_addr(addr->sa_data)) {
		xpci_err_netdev(netdev, "MAC address not given");
		return -EADDRNOTAVAIL;
	}

	xpci_notice_netdev(netdev, "NEW MAC address: %pM ", addr->sa_data);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, addr->sa_data);
#else
	memcpy(netdev->dev_addr, addr->sa_data, netdev->addr_len);
#endif

	net_priv->mac_addr = ether_addr_to_u64(netdev->dev_addr);
	ret = eth_prepare_mac_addr_change(netdev, p);
	if (ret < 0) {
		xpci_err_netdev(netdev, "Can't MAC address: %d", ret);
		return ret;
	}

	eth_mac_addr(netdev, p);

	return 0;
}

static struct net_device_stats *xnetdev_get_stats(struct net_device *netdev)
{
	/* xpci_dbg("netdev, "STATS"); */

	return &netdev->stats;
}

static const struct net_device_ops xnetdev_ops = {
	.ndo_init = xnetdevice_init, /* Load */
	.ndo_uninit = xnetdevice_uninit, /* Uload */
	.ndo_open = xnetdev_open, /* UP */
	.ndo_stop = xnetdev_stop, /* DOWN */
	.ndo_start_xmit = xnetdev_xmit,
	.ndo_set_rx_mode = xnetdev_set_multicast_list,
	.ndo_get_stats = xnetdev_get_stats,
	.ndo_do_ioctl = xnetdev_do_ioctl,
	.ndo_change_mtu = xnetdev_change_mtu,
	.ndo_set_mac_address = xnetdev_set_mac_address,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0)
	.ndo_setup_tc = xnetdev_setup_tc,
#endif
};

static const struct genl_multicast_group xpci_fdb_nl_groups[] = {
	{ .name = XPCI_FDB_NL_GROUP_NAME },
};

/* xpci netdev fdb event netlink family */
struct genl_family xpci_fdb_nl_family = {
	.name = XPCI_FDB_NL_FAMILY_NAME,
	.version = 1,
	.module = THIS_MODULE,
	.maxattr = XPCI_FDB_NL_ATTR_MAX,
	.mcgrps = xpci_fdb_nl_groups,
	.n_mcgrps = sizeof(xpci_fdb_nl_groups) / sizeof(xpci_fdb_nl_groups[0]),
};

static void xpci_get_drvinfo(struct net_device *netdev,
			     struct ethtool_drvinfo *info)
{
	strlcpy(info->driver, XNETDEV_DRV_NAME, sizeof(info->driver));
	strlcpy(info->version, XNETDEV_DRV_VERSION, sizeof(info->version));
}

static void xpci_get_ethtool_stats(struct net_device *netdev,
				   struct ethtool_stats *estats, u64 *data)
{
	int i = 0;

	data[i++] = netdev->stats.rx_packets;
	data[i++] = netdev->stats.tx_packets;
	data[i++] = netdev->stats.rx_bytes;
	data[i++] = netdev->stats.tx_bytes;
	data[i++] = netdev->stats.rx_errors;
	data[i++] = netdev->stats.tx_errors;
	data[i++] = netdev->stats.rx_dropped;
	data[i++] = netdev->stats.tx_dropped;
	data[i++] = netdev->stats.multicast;
	data[i++] = netdev->stats.rx_length_errors;
	data[i++] = netdev->stats.rx_frame_errors;
	data[i++] = netdev->stats.rx_missed_errors;
	data[i++] = netdev->stats.tx_carrier_errors;
}

const struct ethtool_ops xpci_ethtool_ops = {
	.get_drvinfo = xpci_get_drvinfo,
	.get_ethtool_stats = xpci_get_ethtool_stats,
	.get_link = ethtool_op_get_link,
};

/*
 * Helper for alloc_netdev()
 */
static void xpci_setup(struct net_device *netdev)
{
	struct xnetdev_priv *net_priv = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	u8 mac_addr[ETH_ALEN] = {0};
#endif

	xpci_dbg("IN");

	/* Set various defaults */
	ether_setup(netdev);

	/* Initialize the device structure. */
	netdev->netdev_ops = &xnetdev_ops;
	netdev->ethtool_ops = &xpci_ethtool_ops;

	/* Fill in device structure with ethernet-generic values. */
	netdev->type = ARPHRD_ETHER;
	netdev->priv_flags |=
		IFF_LIVE_ADDR_CHANGE | IFF_NO_QUEUE;
	if (xpci_tx_checksumming_mode) {
		netdev->features = NETIF_F_HW_CSUM;
	}
	// TODO: Fix conflict with NETIF_F_HW_CSUM
	// netdev->features |= NETIF_F_HW_TC_BIT;
	netdev->hw_features |= netdev->features;
	netdev->hw_enc_features |= netdev->features;
	netdev->hard_header_len = ETH_HLEN + XSW_RX_SHIM_HDR_SIZE;
	netdev->tx_queue_len = 1000;
	netdev->mtu = XPCI_DEFAULT_MTU_SIZE;
	/* According to RFC-791:
	 * Every internet module must be able to forward a datagram of 68
	 * octets without further fragmentation.  This is because an internet
	 * header may be up to 60 octets, and the minimum fragment is 8 octets.
	 */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 15, 0)
	netdev->min_mtu = ETH_MIN_MTU;
	netdev->max_mtu = XPCI_JUMBO_FRAME_SIZE;
#endif

	net_priv = netdev_priv(netdev);
	memset(net_priv, 0, sizeof(struct xnetdev_priv));
	net_priv->up_state = false;
	net_priv->oper_status = false;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, mac_addr);
#else
	memset(netdev->dev_addr, 0, ETH_ALEN);
#endif

	xpci_dbg("OUT");
}

/*static */ int xnetdev_cpu_port_attach(char *if_attach_name,
					rx_handler_func_t *rx_handler,
					bool do_rtnl_lock,
					struct net_device **cpu_net_dev)
{
	struct net_device *ethdev = NULL;
	int ret = 0;

	xpci_info("Attaching to CPU interface: [%s] Do RTNL lock: [%s]", if_attach_name, do_rtnl_lock?"YES":"NO");

	/* Attach to CPU port Ethernet device */
	ethdev = dev_get_by_name(&init_net, if_attach_name);
	if (!ethdev) {
		xpci_err("Can not attach to interface: [%s]", if_attach_name);
		ret = -ENXIO;
		goto error_exit;
	}

	xpci_cpu_net_dev = ethdev;

	if (do_rtnl_lock)
		rtnl_lock();

	ret = netdev_is_rx_handler_busy(ethdev);
	if (ret) {
		xpci_err_netdev(ethdev, "Net Device [%s] is busy",
				if_attach_name);
		ret = -EBUSY;
		goto error_unlock;
	}

	xpci_dbg_netdev(ethdev, "Registering NetDev Rx handler");
	ret = netdev_rx_handler_register(ethdev, rx_handler,
					 NULL /* data */);
	if (ret) {
		xpci_err("Net Device %s RX handler register failed: %d",
			 if_attach_name, ret);
		goto error_unlock;
	}

	ret = dev_set_promiscuity(ethdev, 1);
	if (ret) {
		xpci_err("Net Device %s dev_set_promiscuity() failed: %d",
			 if_attach_name, ret);
		goto error_prom;
	}
	dev_disable_lro(ethdev);

	xpci_dbg_netdev(ethdev, "Setting carier ON");
	netif_carrier_on(ethdev);
	netif_start_queue(ethdev);

	if (do_rtnl_lock)
		rtnl_unlock();

	xpci_dbg_netdev(ethdev, "OUT");

	dev_put(ethdev);

	*cpu_net_dev = ethdev;

	return 0;

error_prom:
	dev_set_promiscuity(ethdev, -1);

error_unlock:
	if (do_rtnl_lock)
		rtnl_unlock();

error_exit:

	xpci_err("[%s]: OUT", if_attach_name);

	return ret;
}

int xnetdev_set_if_state(struct net_device *netdev, bool status)
{
	struct xnetdev_priv *net_priv = netdev_priv(netdev);

	xpci_notice_netdev(netdev, "Set Interface State: %s", (status?"UP":"DOWN"));

	if (status) {
		xpci_info_netdev(netdev, "Carrier ON");
		netif_carrier_on(netdev);
	} else {
		xpci_info_netdev(netdev, "Carrier OFF");
		netif_carrier_off(netdev);
	}

	net_priv->oper_status = status;

	return 0;
}

int xnetdev_register(char *if_attach_name, char *if_name, uint phy_port,
			 struct net_device *netdev, bool do_rtnl_lock)
{
	char dev_name[XPCI_NET_DEV_NAME_SIZE + 1];
	struct net_device *ethdev = NULL;
	struct xnetdev_priv *net_priv = NULL;
	struct inet6_dev *idev = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 15, 0)
	struct netlink_ext_ack *extack = NULL;
#endif
	static const u8 xsight_oui[3] = { 0x00, 0x11, 0x11 };
	int ret = 0;

	if (!cpu_if_attached) {
		ret = xnetdev_cpu_port_attach(attach_dev_name, xpci_handle_cpu_frame, do_rtnl_lock, &xpci_cpu_net_dev);
		if (ret) {
			xpci_err("CPU Net Device attach failed with error: %d", ret);
			goto error_exit;
		}
		cpu_if_attached = true;
	}

	strncpy(dev_name, if_name, XPCI_NET_DEV_NAME_SIZE);

	xpci_info("Attaching netdev [%s][%p] to interface: [%s]", dev_name,
		  netdev, attach_dev_name);

	if (!netdev) {
		xpci_err("Invalid netdev");
		ret = -EINVAL;
		goto error_exit;
	}

	/* Attach to CPU port Ethernet device */
	ethdev = dev_get_by_name(&init_net, attach_dev_name);
	if (!ethdev) {
		xpci_err("Can't attach to device: [%s]", attach_dev_name);
		ret = -ENXIO;
		goto error_exit;
	}

	if ((ethdev->flags & IFF_LOOPBACK) || netdev_uses_dsa(ethdev) ||
	    ethdev->type != ARPHRD_ETHER || ethdev->addr_len != ETH_ALEN) {
		xpci_err("Can not attach to non-ethernet device: [%s]",
			 attach_dev_name);
		ret = -EINVAL;
		goto error_put;
	}

	if (!is_valid_ether_addr(ethdev->dev_addr)) {
		xpci_err("[%s]: Invalid ethernet device: all Zeroes",
			 attach_dev_name);
		ret = -EINVAL;
		goto error_put;
	}

	if (ethdev->netdev_ops->ndo_start_xmit == xnetdev_xmit) {
		xpci_err("[%s]: Can not attach device to itself",
			 attach_dev_name);
		ret = -ELOOP;
		goto error_put;
	}

	xpci_setup(netdev);

	net_priv = netdev_priv(netdev);
	net_priv->netdev = netdev;
	net_priv->phy_port_id = phy_port;
	net_priv->lo_port_id = 0;
	net_priv->q_id = 0;

	/* Set device MAC address */
	memcpy(net_priv->mac, xsight_oui, 3);
	/* get_random_bytes(net_priv->mac + 3, 3); */
	net_priv->mac[3] = 0x15;
	net_priv->mac[4] = 0x28;
	net_priv->mac[5] = 0; // phy_port;
	net_priv->cpu_dev = false;

	idev = __in6_dev_get(netdev);
	if (idev) {
		idev->cnf.disable_ipv6 = 1;
	}

	netdev->priv_flags |= (ethdev->priv_flags);

#ifdef __XNETDEV_INIT__
	/*
	* TODO: 3. PCI - NETDEV link
	* Set the sysfs device type for the network logical device to allow
	* fine-grained identification of different network device types. For
	* example Ethernet, Wirelss LAN, Bluetooth, WiMAX etc.
	*/
	SET_NETDEV_DEV(netdev, &pdev->dev);
#endif /* __XNETDEV_INIT__ */

	if (do_rtnl_lock)
		rtnl_lock();

	ret = register_netdevice(netdev);
	if (ret) {
		xpci_err_netdev(netdev, "Net Device register failed: %d", ret);
		goto error_unlock;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST, NULL);
#else
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, net_priv->mac);
#else
	memcpy(netdev->dev_addr, net_priv->mac, ETH_ALEN);
#endif
	xpci_notice_netdev(netdev, "MAC address SET: [%pM]", netdev->dev_addr);

	/* Initial interface state is always DOWN */
	xnetdev_set_if_state(netdev, false);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4, 15, 0)
	ret = netdev_upper_dev_link(ethdev, netdev, extack);
#else
	ret = netdev_upper_dev_link(ethdev, netdev);
#endif
	if (ret) {
		xpci_err_netdev(netdev, "netdev_upper_dev_link() failed");
		goto error_unregister;
	}

	ret = netdev_is_rx_handler_busy(netdev);
	if (ret) {
		xpci_err_netdev(netdev, "Net Device RX handler is busy");
		goto error_unregister;
	}

	netdev_update_features(netdev);

	dev_disable_lro(netdev);

	xpci_notice_netdev(netdev, "Device state: [%s]",
			   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	// linkwatch_fire_event(dev); /* _MUST_ call rfc2863_policy() */

	if (do_rtnl_lock)
		rtnl_unlock();

	dev_put(ethdev);

	xpci_dbg_netdev(netdev, "OUT");

	return 0;

error_unregister:
	unregister_netdev(netdev);

error_unlock:
	rtnl_unlock();

error_put:
	if (netdev) {
		xpci_err_netdev(netdev, "free_netdev()");
		free_netdev(netdev);
	}

	dev_put(ethdev);
error_exit:

	xpci_err("[%s]: OUT", dev_name);

	return ret;
}

void xpci_unregister_netdev(char *if_attach_name, struct net_device *netdev,
			    struct list_head *head, bool cpu_device,
			    bool do_rtnl_lock)
{
	struct net_device *ethdev = NULL;

	xpci_notice_netdev(netdev, "IN");

	netif_tx_disable(netdev);
	netif_carrier_off(netdev);

	/* Find attached Ethernet device name */
	ethdev = dev_get_by_name(&init_net, if_attach_name);
	if (!ethdev) {
		xpci_err("Can find device to detach from: [%s]",
			 if_attach_name);
		return;
	}

	if (cpu_device) {
		if (do_rtnl_lock)
			rtnl_lock();

		dev_set_promiscuity(netdev, -1);
		netdev_rx_handler_unregister(ethdev);

		if (do_rtnl_lock)
			rtnl_unlock();
	} else {
		if (do_rtnl_lock)
			rtnl_lock();

		netdev_upper_dev_unlink(ethdev, netdev);
		if (do_rtnl_lock)
			rtnl_unlock();

		if (head)
			unregister_netdevice_queue(
				netdev,
				head); /* It will call our stop function */
		else
			unregister_netdev(
				netdev); /* It will call our stop function */
	}

	dev_put(ethdev);

	xpci_dbg("OUT");
}

int xnetdev_init(void)
{
	int ret = 0;

	// xpci_dbg("xnetdev_init() IN");

	ret = xpci_net_dev_sysctl_init();
	if (ret) {
		xpci_err("Sys ctl init failed: %d", ret);
		return ret;
	}

	ret = xnetdev_rtnl_link_register();
	if (ret) {
		xpci_err("Rtnl link register failed: %d", ret);
		goto rtnl_link_register_err;
	}

	ret = xpci_init_rx_tx_ports(xpci_max_ports);
	if (ret) {
		xpci_err("CPU Net Device init failed with error: %d", ret);
		goto all_register_err;
	}

	xpci_dbg("Registering [%s] netlink family",
		      XPCI_FDB_NL_FAMILY_NAME);
	ret = genl_register_family(&xpci_fdb_nl_family);
	if (ret) {
		xpci_err("genl_register_family() failed, err: %d", ret);
		goto all_register_err;
	}

	// xpci_dbg("OUT");

	return 0;

all_register_err:
	xpci_err("Init error: rtnl_link_unregister()");
	xnetdev_rtnl_link_unregister();

rtnl_link_register_err:
	xpci_err("Init error: unregister_net_sysctl_table()");
	unregister_net_sysctl_table(xpci_net_dev_sysctl_header);

	return ret;
}

int xnetdev_attach(void)
{
	int ret = 0;

	xpci_dbg("xnetdev_attach() IN");

	xpci_dbg("Attaching to CPU device: [%s]", attach_dev_name);
	ret = xnetdev_cpu_port_attach(attach_dev_name, xpci_handle_cpu_frame, true, &xpci_cpu_net_dev);
	if (ret) {
		xpci_err("CPU Net Device init failed with error: %d", ret);
		return -1;
	}
	cpu_if_attached = true;

	xpci_dbg("OUT");

	return 0;
}

int xnetdev_close(void)
{
	xpci_dbg("IN");

	/* Unregister FDB nl family */
	xpci_dbg("Unregister [%s] netlink family", XPCI_FDB_NL_FAMILY_NAME);
	genl_unregister_family(&xpci_fdb_nl_family);

	/* Unregister rtnl link */
	xpci_dbg("RTNL unregister");
	xnetdev_rtnl_link_unregister();

	/* Finally close the "root" CPU device */
	if (xpci_cpu_net_dev) {
		xpci_dbg("CPU Netdev unregister: [%s]", xpci_cpu_net_dev->name);
		xpci_unregister_netdev(attach_dev_name, xpci_cpu_net_dev, NULL, true,
					true);
		xpci_dbg("CPU Netdev unregister DONE");
	} else {
		xpci_dbg("CPU Netdev not been attached - skip xpci_unregister_netdev()");
	}

	xpci_free_rx_tx_ports();

	unregister_net_sysctl_table(xpci_net_dev_sysctl_header);

	xpci_dbg("OUT");

	return 0;
}
