// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI IOCTL support
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>

#include "xpci_common.h"
#include "xpci_irq.h"
#include "xpci_main.h"

/**
 * Device node read
 */
static ssize_t xpci_reg_read(struct xpci_fprv *xprv, char __user *buffer,
			     size_t length, loff_t *offset)
{
	struct xdev *pxdev = xprv->pxdev;
	struct pci_dev *pdev = pxdev->pdev;
	struct xreg reg;
	unsigned long num_of_bytes = 0;

	if (copy_from_user(&reg, (struct xreg __user *)buffer, length)) {
		xpci_err("copy_from_user() failed for %p", buffer);
		return -EFAULT;
	}

	reg.value = xpci_read64(NULL, reg.addr, true);

	if ((num_of_bytes = copy_to_user(buffer, &reg, sizeof(struct xreg)))) {
		xpci_err_dev(&pdev->dev,
			 "copy_to_user() failed for %p num of bytes %ld",
			 buffer, num_of_bytes);
		return -EFAULT;
	}

	return 8;
}

/**
 * Device node write
 */
static ssize_t xpci_reg_write(struct xpci_fprv *xprv, const char *buffer,
			      size_t length, loff_t *off)
{
	struct xreg reg;

	if (copy_from_user(&reg, (struct xreg __user *)buffer, length)) {
		xpci_err("copy_from_user() failed for %p len %d", buffer,
			 (int)length);
		return -EFAULT;
	}

	xpci_write64(NULL, reg.addr, reg.value);

	return 8;
}

static ssize_t xpci_reg_cfg(struct xpci_fprv *xprv, const char *buffer,
			    size_t length, loff_t *off)
{
	struct xdev *pxdev = xprv->pxdev;
	struct pci_dev *pdev = pxdev->pdev;
	struct xreg reg;
	u16 pci_status;

	if (copy_from_user(&reg, (struct xreg __user *)buffer, length)) {
		xpci_err("copy_from_user() failed for %p len %d", buffer,
			 (int)length);
		return -EFAULT;
	}

	xpci_info_dev(&pdev->dev, "Register [0x%x] CFG: [0x%llx]", reg.addr,
		  reg.value);

	pci_read_config_word(pdev, PCI_COMMAND, &pci_status);
	pci_write_config_word(pdev, PCI_COMMAND, pci_status);

	xpci_info_dev(&pdev->dev, "PCI Status read/write: [0x%x]", pci_status);

	return 8;
}

static ssize_t xpci_dma_alloc(struct xpci_fprv *xprv, char *buffer,
			      size_t length, loff_t *off)
{
	struct xdev *pxdev = xprv->pxdev;
	struct pci_dev *pdev = pxdev->pdev;
	struct xcfg cfg;
	u32 size = 0;
	unsigned long num_of_bytes = 0;

	if (copy_from_user(&cfg, (struct xcfg __user *)buffer, length)) {
		xpci_err("copy_from_user() failed for %p len %d", buffer,
			 (int)length);
		return -EFAULT;
	}

	size = cfg.data;

	xpci_info_dev(&pdev->dev, "Allocating [%d] bytes of driver memory", size);

	pxdev->dma_block_v = alloc_pages_exact(size, GFP_KERNEL | __GFP_ZERO);
	if (pxdev->dma_block_v == NULL) {
		xpci_err_dev(&pdev->dev, "alloc_pages_exact() failed");
		return -ENOMEM;
	}
	pxdev->dma_block_size = cfg.data;
	pxdev->dma_block_p = (u8 *)virt_to_phys((void *)pxdev->dma_block_v);
	cfg.res = (u64)pxdev->dma_block_p;

	xpci_info_dev(&pdev->dev, "DMA memory allocated: VIRT(%p) --> PHY(%p)",
		  pxdev->dma_block_v, pxdev->dma_block_p);

	if ((num_of_bytes = copy_to_user(buffer, &cfg, sizeof(struct xcfg)))) {
		xpci_err_dev(&pdev->dev,
			 "copy_to_user() failed for %p num of bytes %ld",
			 buffer, num_of_bytes);
		return -EFAULT;
	}

	return 8;
}

static ssize_t xpci_dma_free(struct xpci_fprv *xprv, const char *buffer,
			     size_t length, loff_t *off)
{
	struct xdev *pxdev = xprv->pxdev;
	struct pci_dev *pdev = pxdev->pdev;
	struct xcfg cfg;

	if (copy_from_user(&cfg, (struct xcfg __user *)buffer, length)) {
		xpci_err("copy_from_user() failed for %p len %d", buffer,
			 (int)length);
		return -EFAULT;
	}

	xpci_info_dev(&pdev->dev, "Free [%d] bytes of DMA memory",
		  pxdev->dma_block_size);

	free_pages_exact(pxdev->dma_block_v, pxdev->dma_block_size);

	return 8;
}

long xpci_ioctl(struct file *filep, unsigned int cmd, unsigned long arg)
{
	struct xpci_fprv *xprv = filep->private_data;
	struct xdev *pxdev = xprv->pxdev;
	ssize_t bytes_read = 0;

	if (!pxdev) {
		xpci_err("OUT - pxdev NULL");
		return -EFAULT;
	}

	if (!pxdev->dev_probe) {
		xpci_err("OUT - deviced not probed yet or probe failed");
		return -ENODEV;
	}

	/* xpci_err("_IOC_NR(cmd): %d", _IOC_NR(cmd)); */

	/*
	* Switch according to the ioctl called
	*/
	switch (_IOC_NR(cmd)) {
	case XPCI_WRITE_REG: {
		xpci_reg_write(xprv, (char *)arg, sizeof(struct xreg), 0);
	} break;
	case XPCI_READ_REG: {
		bytes_read = xpci_reg_read(xprv, (char *)arg,
					   sizeof(struct xreg), 0);

		/* KT: Temporary fix for pre-silicon / emulator */
		dma_wmb();
		dma_rmb();
	} break;
	case XPCI_CFG_REG: {
		xpci_reg_cfg(xprv, (char *)arg, sizeof(struct xreg), 0);
	} break;
	case XPCI_DMA_ALLOC: {
		xpci_dma_alloc(xprv, (char *)arg, sizeof(struct xcfg), 0);
	} break;
	case XPCI_DMA_FREE: {
		xpci_dma_free(xprv, (char *)arg, sizeof(struct xcfg), 0);
	} break;
	case XPCI_HW_IRQ_SUPPORT: {
		unsigned long num_of_bytes = 0;
		struct pci_dev *pdev = pxdev->pdev;
		int hw_irq_mode = xpci_get_hw_irq_mode();

		xpci_notice("HW IRQ query: %d", hw_irq_mode);

		if ((num_of_bytes = copy_to_user((char *)arg, &hw_irq_mode,
						 sizeof(int)))) {
			xpci_err_dev(
				&pdev->dev,
				"copy_to_user() failed for %p num of bytes %ld",
				(char *)arg, num_of_bytes);
			return -EFAULT;
		}
	} break;
	case XPCI_ENABLE_MSIX: {
		struct pci_dev *pdev = pxdev->pdev;
		struct xcmd cmd;

		if (copy_from_user(&cmd, (struct xcmd __user *)arg, sizeof(struct xcmd))) {
			xpci_err("copy_from_user() failed for %p len %d", (struct xcmd __user *)arg,
				(int)sizeof(struct xcmd));
			return -EFAULT;
		}

		xpci_info_dev(&pdev->dev,
			"Enable MSIX[%d]", cmd.value);

		xpci_enable_msix_interrupt(pxdev, cmd.value);
	} break;
	case XPCI_DISABLE_MSIX:{
		struct pci_dev *pdev = pxdev->pdev;
		struct xcmd cmd;

		if (copy_from_user(&cmd, (struct xcmd __user *)arg, sizeof(struct xcmd))) {
			xpci_err("copy_from_user() failed for %p len %d", (struct xcmd __user *)arg,
				(int)sizeof(struct xcmd));
			return -EFAULT;
		}

		xpci_info_dev(&pdev->dev,
			"Disable MSIX[%d]", cmd.value);

		xpci_disable_msix_interrupt(pxdev, cmd.value);
	} break;
	default:
		xpci_notice("Unknown IOCTL: 0x%x", cmd);
		return -EINVAL;
	}

	return 0;
}
