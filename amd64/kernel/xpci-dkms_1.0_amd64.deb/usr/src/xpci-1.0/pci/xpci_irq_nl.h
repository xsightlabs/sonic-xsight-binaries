// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI IRQ Netlink interface
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_IRQ_NL_
#define XPCI_IRQ_NL_

#define XPCI_IRQ_NL_FAMILY_NAME		"xpciIrqNlFamily"
#define XPCI_IRQ_NL_GROUP_NAME		"xpciIrqNlGroup"

/* XPCI IRQ netlink commands */
enum {
	XPCI_IRQ_NL_CMD_UNSPEC,
	XPCI_IRQ_NL_CMD_NOTIFY,
	__XPCI_IRQ_NL_CMD_MAX,
};
#define XPCI_IRQ_NL_CMD_MAX (__XPCI_IRQ_NL_CMD_MAX - 1)

/* XPCI IRQ netlink attributes */
enum {
	XPCI_IRQ_NL_ATTR_UNSPEC,
	XPCI_IRQ_NL_ATTR_VEC_NAME,
	XPCI_IRQ_NL_ATTR_VEC_VAL,
	__XPCI_IRQ_NL_ATTR_MAX,
};
#define XPCI_IRQ_NL_ATTR_MAX (__XPCI_IRQ_NL_ATTR_MAX - 1)

#endif /* XPCI_IRQ_NL_ */
