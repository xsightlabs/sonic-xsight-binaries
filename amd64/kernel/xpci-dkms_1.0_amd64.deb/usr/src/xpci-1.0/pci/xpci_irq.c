// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI X Device IRQs
 *
 * Copyright (c) 2020-present Xsight Labs Inc.
 *
 */

#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/pci.h>
#include <linux/uaccess.h>
#include <linux/irq.h>
#include <linux/msi.h>
#include <linux/version.h>
#include <net/genetlink.h>

#include "xpci_irq_nl.h"
#include "xpci_irq.h"
#include "xpci_main.h"
#include "xpci_trace.h"

#define XPCI_IRQ_WQ_NAME	"xpci_irq_wq"

/* xpci interrupts work queue */
static struct workqueue_struct *xpci_irq_wq;

/* xpci interrupts multicast group */
#define XPCI_IRQ_NL_GROUP_OFFSET	0
static const struct genl_multicast_group xpci_irq_nl_groups[] = {
	{ .name = XPCI_IRQ_NL_GROUP_NAME },
};

/* xpci interrupts netlink family */
static struct genl_family xpci_irq_nl_family = {
	.name = XPCI_IRQ_NL_FAMILY_NAME,
	.version = 1,
	.module = THIS_MODULE,
	.maxattr = XPCI_IRQ_NL_ATTR_MAX,
	.mcgrps = xpci_irq_nl_groups,
	.n_mcgrps = sizeof(xpci_irq_nl_groups) / sizeof(xpci_irq_nl_groups[0]),
};

unsigned char xpci_get_irq(struct pci_dev *pdev)
{
	struct device *dev = &pdev->dev;
	u8 intline = 0;

	pci_read_config_byte(pdev, PCI_INTERRUPT_LINE, &intline);
	xpci_info_dev(dev, "xcpi interrupt line num: 0x%x", intline);

	return intline;
}

static int xpci_irq_notify(xpci_irq_ctx_t *ctx)
{
	struct xdev *pxdev = (struct xdev *)ctx->data;
	struct device *dev = &pxdev->pdev->dev;
	struct sk_buff *skb = NULL;
	void *hdr = NULL;
	int rc = 0;

	skb = genlmsg_new(NLMSG_GOODSIZE, GFP_KERNEL);
	if (!skb) {
		xpci_err_dev(dev, "genlmsg_new() failed");
		return -ENOMEM;
	}
	hdr = genlmsg_put(skb, 0, 0, &xpci_irq_nl_family, 0,
			  XPCI_IRQ_NL_CMD_NOTIFY);
	if (!hdr) {
		xpci_err_dev(dev, "genlmsg_put() failed");
		rc = -ENOMEM;
		goto fail;
	}
	rc = nla_put_string(skb, XPCI_IRQ_NL_ATTR_VEC_NAME,
			    pxdev->irq_tbl[ctx->vec].name);
	if (rc) {
		xpci_err_dev(dev, "nla_put_string() failed, err: %d", rc);
		goto fail;
	}
	rc = nla_put_u32(skb, XPCI_IRQ_NL_ATTR_VEC_VAL, ctx->vec);
	if (rc) {
		xpci_err_dev(dev, "nla_put_u32() failed, err: %d", rc);
		goto fail;
	}
	genlmsg_end(skb, hdr);
	rc = genlmsg_multicast(&xpci_irq_nl_family, skb, 0,
			       XPCI_IRQ_NL_GROUP_OFFSET, GFP_ATOMIC);
#ifdef __XPCI_IRQ_DEBUG__
	if (rc)
		xpci_info_dev(dev, "genlmsg_multicast() failed, err: %d", rc);
#endif
	return rc;
fail:
	genlmsg_cancel(skb, hdr);
	return rc;
}

static void xpci_irq_task(struct work_struct *work)
{
	xpci_irq_ctx_t *ctx = container_of(work, xpci_irq_ctx_t, work);

	int rc = 0;

	rc = xpci_irq_notify(ctx);

#ifdef __XPCI_IRQ_DEBUG__
	{
		struct xdev *pxdev = (struct xdev *)ctx->data;
		struct device *dev = &pxdev->pdev->dev;

		if (rc)
			xpci_err_dev(dev, "Error in task for vector [%s]:%d: %d",
					pxdev->irq_tbl[ctx->vec].name, ctx->vec, rc)
		else
			xpci_info_dev(dev, "Finished task for vector [%s]:%d",
					pxdev->irq_tbl[ctx->vec].name, ctx->vec);
	}
#endif

	kfree(ctx);
}

static irqreturn_t xpci_intr_handler(int irq, void *xpci_irq)
{
	struct xdev *pxdev = (struct xdev *)xpci_irq;
	struct device *dev = &pxdev->pdev->dev;
	int vec = pxdev->irq_map[irq];
	
	xpci_irq_ctx_t *ctx = kzalloc(sizeof(xpci_irq_ctx_t), GFP_NOWAIT);

#ifdef __XPCI_IRQ_DEBUG__
	xpci_dbg_dev(dev, "pxdev->irq_map[%d]=%d", irq, pxdev->irq_map[irq]);
#endif

	if ((vec < XPCI_MSIX_VECTORS) && !pxdev->irq_tbl[vec].allocated) {
		xpci_err_dev(dev, "Interrupt: %d vector: %d is not allocated - skip handling", irq, vec);
		return IRQ_NONE;
	}

	if (ctx) {
		INIT_WORK(&ctx->work, xpci_irq_task);
		ctx->data = xpci_irq;
		ctx->vec = vec;
		if (xpci_irq_wq) {
			queue_work(xpci_irq_wq, &ctx->work);
		} else {
			xpci_err_dev(dev, "Skipping interrupt on uninitilizaed work queue: IRQ: [%d] Vec: [%s][%d]", irq, pxdev->irq_tbl[vec].name, vec);
		}
	} else {
		xpci_err_dev(dev, "kzalloc() failed! Unregistering interrupts");
		xpci_unregister_interrupts(pxdev);
	}
#ifdef __XPCI_IRQ_DEBUG__
	xpci_dbg_dev(dev, "Interrupt: %d vector [%s]:%d handled", irq, pxdev->irq_tbl[vec].name,
		 vec);
#endif

	return IRQ_HANDLED;
}

irqreturn_t xpci_handle_interrupt(int irq, void *xpci_irq) 
{
	return xpci_intr_handler(irq, xpci_irq);
}

static void xpci_free_all_interrupts(struct xdev *pxdev)
{
	struct device *dev = &pxdev->pdev->dev;
	int irq, vec;

	for (vec = 0; vec < pxdev->num_vec; vec++) {
		if (pxdev->irq_tbl[vec].allocated) {
			irq = pci_irq_vector(pxdev->pdev, vec);
			xpci_dbg_dev(dev, "Unregistering interrupt vector [%s]:%d:%d", 
				pxdev->irq_tbl[vec].name, irq, vec);
			free_irq(irq, pxdev);
			pxdev->irq_tbl[vec].allocated = false;
		}
	}
	memset(pxdev->irq_map, 0, sizeof(pxdev->irq_map));
}

int xpci_register_interrupt(struct xdev *pxdev, int vec_num, char *irq_name, irq_handler_t irq_hnd)
{
	int rc, irq;
	struct device *dev = &pxdev->pdev->dev;

	xpci_dbg_dev(dev, "Register interrupt [%d]: IN", vec_num);

	if (pxdev->irq_tbl[vec_num].allocated) {
		xpci_err_dev(dev, "MSI-X vector [%s][%d] is already allocated",
			pxdev->irq_tbl[vec_num].name, vec_num);
		goto fail;
	}

	sprintf(pxdev->irq_tbl[vec_num].name, "%s-%d", irq_name, (vec_num - XPCI_INTR_ID0));

	/* get the vector number */
	irq = pci_irq_vector(pxdev->pdev, vec_num);
	pxdev->irq_tbl[vec_num].irq = irq;
	pxdev->irq_map[irq] = vec_num;

	xpci_info_dev(dev, "Allocating MSI-X vector: [%s]:%p num: %d",
			pxdev->irq_tbl[vec_num].name, irq_hnd, irq);
	rc = request_irq(irq, *irq_hnd, 0, pxdev->irq_tbl[vec_num].name,
				pxdev);
	if (rc) {
		xpci_err_dev(dev, "Allocation of MSI-X vector: [%s] vec: %d is failed",
			pxdev->irq_tbl[vec_num].name, vec_num);
		goto fail;
	}

	pxdev->irq_tbl[vec_num].allocated = true;

	xpci_dbg_dev(dev, "Register interrupt: OUT");

	return 0;

fail:
	xpci_err_dev(dev,"Request irq failed");

	return rc;
}

int xpci_register_x_interrupts(struct xdev *pxdev, u16 num_pci_ints)
{
	int i, rc, irq_num, irq;
	struct device *dev = NULL;

	xpci_dbg("Register interrupts: IN: num_pci_ints: %d", num_pci_ints);

	if (!pxdev)
		return -EFAULT;

	if (pxdev->dev_int_register) {
		xpci_err("Can't register interrupts twice");
		return -EFAULT;
	}

	dev = &pxdev->pdev->dev;

	pxdev->num_vec = min_t(u32, pci_msix_vec_count(pxdev->pdev), XPCI_MSIX_VECTORS);

	xpci_info_dev(dev, "Allocating %d MSI-X vectors", pxdev->num_vec);

	/* Enable MSI-X */
	irq_num = pci_alloc_irq_vectors(pxdev->pdev, pxdev->num_vec,
					pxdev->num_vec, PCI_IRQ_MSIX);
	if (irq_num < 0) {
		xpci_err_dev(dev,
			 "Request for #%d msix vectors failed, returned %d",
			 pxdev->num_vec, irq_num);
		return irq_num;
	}

	/* Register mailbox interrupt handler for XSDK interrupts */
	for (i = XPCI_INTR_ID0; i < num_pci_ints; i++) {
		sprintf(pxdev->irq_tbl[i].name, "MSI-X-%d", (i - XPCI_INTR_ID0));

		/* get the vector number */
		irq = pci_irq_vector(pxdev->pdev, i);
		if (!irq) {
			xpci_err_dev(dev, "Allocation of MSI-X vector: [%s] vec: %d is failed",
				pxdev->irq_tbl[i].name, i);
			goto fail;
		}
		// pxdev->irq_tbl[i].irq = irq;

		/* Store relative "per device" vector number in system interrupts map */
		/* Example: [84] <-- 1 */
		/* Interrupt will resolve vector number by interrupt number 84 --> 1 */
		pxdev->irq_map[irq] = i;

		xpci_info_dev(dev, "Allocating MSI-X vector: [%s]:%p irq: %d --> xpci vec: %d",
			  pxdev->irq_tbl[i].name, xpci_intr_handler, irq, i);
		rc = request_irq(irq, xpci_intr_handler, 0, pxdev->irq_tbl[i].name,
				 pxdev);
		if (rc)
			goto fail;

		pxdev->irq_tbl[i].allocated = true;
	}

	pxdev->dev_int_register = 1;

	/* Register Generic Netlink family for IRQ updates family */

	xpci_info_dev(dev, "Creating %s work queue", XPCI_IRQ_WQ_NAME);
	xpci_irq_wq = alloc_ordered_workqueue(XPCI_IRQ_WQ_NAME, WQ_MEM_RECLAIM);
	if (!xpci_irq_wq)
		goto fail;
	xpci_info_dev(dev, "Registering %s netlink family",
		      XPCI_IRQ_NL_FAMILY_NAME);
	rc = genl_register_family(&xpci_irq_nl_family);
	if (rc) {
		xpci_err_dev(dev, "genl_register_family() failed, err: %d", rc);
		goto fail;
	}

	xpci_dbg_dev(dev, "Register interrupts: OUT");

	return 0;

fail:
	xpci_err_dev(dev,"Request irq failed");
	xpci_free_all_interrupts(pxdev);
	pci_free_irq_vectors(pxdev->pdev);
	pxdev->num_vec = 0;

	return rc;
}

int xpci_unregister_interrupts(struct xdev *pxdev)
{
	int rc = 0;
	struct device *dev = NULL;

	xpci_dbg("Unregister: IN");

	if (!pxdev)
		return -EFAULT;

	if (!pxdev->dev_int_register) {
		xpci_err("Can't unregister interrupts: not registered");
		return -EFAULT;
	}

	dev = &pxdev->pdev->dev;

	xpci_free_all_interrupts(pxdev);
	pci_free_irq_vectors(pxdev->pdev);
	pxdev->num_vec = 0;

	flush_workqueue(xpci_irq_wq );
	destroy_workqueue(xpci_irq_wq);
	genl_unregister_family(&xpci_irq_nl_family);

	pxdev->dev_int_register = 0;

	xpci_dbg_dev(dev, "Unregister: OUT");

	return rc;
}

int xpci_unregister_interrupt(struct xdev *pxdev, int vec_num)
{
	int irq;
	struct device *dev = &pxdev->pdev->dev;

	xpci_dbg_dev(dev, "Unregister interrupt [%d]: IN", vec_num);

	if (pxdev->irq_tbl[vec_num].allocated) {
		irq = pci_irq_vector(pxdev->pdev, vec_num);
		xpci_info_dev(dev, "Unregistering interrupt vector [%s]:%d:%d", 
			pxdev->irq_tbl[vec_num].name, irq, vec_num);
		free_irq(irq, pxdev);
		pxdev->irq_tbl[vec_num].allocated = false;
	}

	xpci_dbg_dev(dev, "Unregister interrupt: OUT");

	return 0;
}

static inline void __iomem *pci_msix_desc_addr(struct msi_desc *desc)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)
	return desc->pci.mask_base + desc->msi_index * PCI_MSIX_ENTRY_SIZE;
#else
	return desc->mask_base + desc->msi_attrib.entry_nr * PCI_MSIX_ENTRY_SIZE;
#endif
}

static void xpci_mask_msix_irq(struct xdev *pxdev, int irq)
{
    void __iomem *msix_table_addr;
    u32 mask;
	struct msi_desc *desc_addr = NULL;

	//xpci_dbg("IN");
	
	desc_addr = irq_get_msi_desc(irq);
	if (!desc_addr) {
		xpci_err("desc_addr NULL for irq: %d", irq);
		return;
	}

    msix_table_addr = pci_msix_desc_addr(desc_addr);

	xpci_dbg("Disable interrupt[%d]: desc_addr: %p msix_table_addr: %p", irq, desc_addr, msix_table_addr);

	xpci_trace(irq_mask, irq, desc_addr, msix_table_addr);

    mask = readl(msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
    mask |= PCI_MSIX_ENTRY_CTRL_MASKBIT;
    writel(mask, msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
	readl(msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
}

static void xpci_unmask_msix_irq(struct xdev *pxdev, int irq)
{
    void __iomem *msix_table_addr;
    u32 mask;
	struct msi_desc *desc_addr = NULL;

	//xpci_dbg("IN");
	
	desc_addr = irq_get_msi_desc(irq);
	if (!desc_addr) {
		xpci_err("desc_addr NULL for irq: %d", irq);
		return;
	}

    msix_table_addr = pci_msix_desc_addr(desc_addr);

	xpci_dbg("Enable interrupt[%d]: desc_addr: %p msix_table_addr: %p", irq, desc_addr, msix_table_addr);

	xpci_trace(irq_unmask, irq, desc_addr, msix_table_addr);

    mask = readl(msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
    mask &= ~PCI_MSIX_ENTRY_CTRL_MASKBIT;
    writel(mask, msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
	readl(msix_table_addr + PCI_MSIX_ENTRY_VECTOR_CTRL);
}

void xpci_enable_msix_interrupt(struct xdev *pxdev, int vec)
{
	if (!pxdev || !pxdev->dev_int_register) {
		xpci_err("Interrupts are not registered");
		return;
	}

	if (!pxdev->irq_tbl[vec].allocated) {
		xpci_err("Interrupt: %d is not allocated", vec);
		return;
	}

	xpci_unmask_msix_irq(pxdev, pxdev->irq_tbl[vec].irq);
}

void xpci_disable_msix_interrupt(struct xdev *pxdev, int vec)
{
	if (!pxdev || !pxdev->dev_int_register) {
		xpci_err("Interrupts are not registered");
		return;
	}

	if (!pxdev->irq_tbl[vec].allocated) {
		xpci_err("Interrupt: %d is not allocated", vec);
		return;
	}

	xpci_mask_msix_irq(pxdev, pxdev->irq_tbl[vec].irq);
}
