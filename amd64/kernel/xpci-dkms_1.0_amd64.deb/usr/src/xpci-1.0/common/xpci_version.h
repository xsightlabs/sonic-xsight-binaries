// SPDX-License-Identifier: GPL-2.0

/*
 * Version definitions for XPCI, XPCXD and XNetDev
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCI_VERSION_H_
#define XPCI_VERSION_H_

#define XPCI_DRIVER_NAME "XPCI"

#define XPCI_DRIVER_VERSION "Version 0.9.66_mltsct_free_2"
#define XPCXD_NETDEV_DRV_VERSION XPCI_DRIVER_VERSION
#define XNETDEV_DRV_VERSION XPCI_DRIVER_VERSION

#endif /* XPCI_VERSION_H_ */
