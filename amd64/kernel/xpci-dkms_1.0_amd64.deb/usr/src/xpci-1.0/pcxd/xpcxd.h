// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver common definitions
 *
 * Copyright (c) Xsight Labs Ltd.
 * All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.
 *
 */

#ifndef XPCXD_H_
#define XPCXD_H_

#include <asm/byteorder.h>
#include <linux/netdevice.h>
#include <linux/hrtimer.h>
#include "xpcxd_regs.h"
#include "xpcxd_dbg.h"
#include "xnetdev_common.h"

#ifndef __LITTLE_ENDIAN
#define __LITTLE_ENDIAN -1
#endif
#define __BYTE_ORDER __LITTLE_ENDIAN

typedef uint64_t xpcxd_ring_handle_t; /**< Type definition for XPCXD ring handle */

#define XPCXD_NETDEV_DRV_NAME "xpcxd_netdev" /**< Name of the XPCXD network device driver */

#define MAX_CFG_ITEM_LEN 32 /**< Maximum length of a configuration item */

#define XPCXD_NET_DEV_NAME_SIZE 64 /**< Size of the XPCXD network device name */
#define XPCXD_IF_NAME_SIZE 64 /**< Size of the XPCXD interface name */

#define XPCXD_DEFAULT_RING_SIZE 256 /**< Default size of the XPCXD ring */
#define XPCXD_MAX_RING_NUM 8 /**< Maximum number of XPCXD rings */

#define XPCXD_NO_LIMIT 0 /**< No limit value */

#define XPCXD_RING_DSC_BUFFERS 256 /**< Number of ring descriptor buffers */

#define XPCXD_HW_SHIM_SIZE 3 /**< Size of the hardware shim header */

#define XPCXD_NUM_OF_RSS_QUEUES 8 /**< Number of RSS queues */
#define XPCXD_RSS_SECRET_KEY_SIZE 40 /**< Size of the RSS secret key */

/**
 * @brief Netlink parameters to create PCXD netdev.
 * ip link add NAME type pcxd
 */
enum xpcxd_spec {
	IFLA_XPCXD_UNSPEC, /**< Unspecified parameter */
	IFLA_XPCXD_IF_CFG, /**< Interface configuration */
	IFLA_XPCXD_IF_OP, /**< Interface operation */
	IFLA_XPCXD_IF_NAME, /**< Interface name */
	IFLA_XPCXD_IF_STATE, /**< Interface state */
	IFLA_XPCXD_IF_MODE, /**< Interface mode */
	IFLA_XPCXD_CFG_NUM_OF_RINGS, /**< Number of rings in the configuration */
	IFLA_XPCXD_CFG_TX_RING_SIZE, /**< Transmit ring size in the configuration */
	IFLA_XPCXD_CFG_RX_RING_SIZE, /**< Receive ring size in the configuration */

	__IFLA_XPCXD_MAX
};
#define IFLA_XPCXD_MAX (__IFLA_XPCXD_MAX - 1) /**< Maximum value of xpcxd_spec */

/**
 * @brief Packet over PCI (PCXD) interface operations: ADD/DELETE/UPDATE
 */
enum xpcxd_if_op {
	XPCXD_IF_OP_UNKNOWN = 0, /**< Unknown interface operation */
	XPCXD_IF_OP_ADD = 1, /**< Add interface */
	XPCXD_IF_OP_UPDATE = 2, /**< Update interface */
	XPCXD_IF_OP_DEL = 3, /**< Delete interface */
	XPCXD_IF_OP_MAX = XPCXD_IF_OP_DEL /**< Maximum value of xpcxd_if_op */
};

/**
 * @brief Interface operational state
 */
enum xpcxd_if_state {
	XPCXD_IF_UNCHANGED, /**< Interface state unchanged */
	XPCXD_IF_UP, /**< Interface up */
	XPCXD_IF_DOWN /**< Interface down */
};

/**
 * @brief Interface mode
 */
enum xpcxd_mode {
	XPCXD_MODE_UNKNOWN, /**< Unknown mode */
	XPCXD_MODE_INIT, /**< Initialization mode */
	XPCXD_MODE_STOP, /**< Stop mode */
	XPCXD_MODE_RESUME, /**< Resume mode */
	XPCXD_MODE_SHUTDOWN /**< Shutdown mode */
};

#define XPCXD_NAPI_POLL_WEIGHT 8 /**< NAPI poll weight */

#define XPCXD_MAX_RING_SIZE 32768 /**< Maximum ring size */
#define XPCXD_NUM_TXD_PER_PKT 2 /**< Number of transmit descriptors per packet */
#define XPCXD_TX_STOP_THOLD XPCXD_NUM_TXD_PER_PKT /**< Transmit stop threshold */

/* make IP header 4 byte aligned */
// #define XPCXD_DATA_START_OFS   2

// #define XPCXD_SKB_SIZE_MIN     1536
// #define XPCXD_SKB_RX_HEADROOM     XPCXD_DATA_START_OFS
#define XPCXD_SKB_DATA_SIZE 1536 /**< Size of the SKB data */

#define RX_OFFSET xpcxd_loopback ? 0 : XSW_RX_SHIM_HDR_SIZE /**< Receive offset */
#define TX_OFFSET xpcxd_loopback ? 0 : XSW_TX_SHIM_HDR_SIZE /**< Transmit offset */

#define XPCXD_ALIGNMENT_64 64 /**< 64-byte alignment */
#define XPCXD_ALIGNMENT_256 256 /**< 256-byte alignment */
#define XPCXD_SKB_RX_HEADROOM SKB_DATA_ALIGN(/*NET_SKB_PAD + */ NET_IP_ALIGN) /**< SKB receive headroom */
#define XPCXD_SKB_SHINFO_SIZE (SKB_DATA_ALIGN(sizeof(struct skb_shared_info))) /**< Size of the SKB shared info */
#define XPCXD_SKB_TAIL_ROOM (XPCXD_SKB_SHINFO_SIZE) /**< SKB tail room */

#define XPCXD_FRAG_OFFSET (XPCXD_SKB_RX_HEADROOM) /**< Fragment offset */
#define XPCXD_FRAG_DATA_SIZE SKB_DATA_ALIGN(PAGE_SIZE - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM) /**< Fragment data size */

#define XPCXD_DEFAULT_MTU_SIZE 10200 /**< Default MTU size */
#define XPCXD_MAX_MTU_SIZE ((PAGE_SIZE * 4) - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM) /**< Maximum MTU size */

#define XPCXD_MAX_RX_BUF_SIZE (XPCXD_MAX_MTU_SIZE + XPCXD_SKB_RX_HEADROOM + XPCXD_SKB_TAIL_ROOM) /**< Maximum receive buffer size */

/**
 * @struct xpcxd_sw_desc
 * @brief Enumeration representing the state of a page in the xpcxd module.
 */
enum xpcxd_page_state {
	XPCXD_PAGE_INIT = 0, /**< Page initialization state */
	XPCXD_PAGE_FREE = 1, /**< Page free state */
	XPCXD_PAGE_ALLOCATED = 2, /**< Page allocated state */
	XPCXD_PAGE_PASSED_TO_STACK = 3 /**< Page passed to stack state */
};

/**
 * @struct xpcxd_sw_desc
 * @brief EStructure representing a software descriptor used in the xpcxd driver.
 */
struct xpcxd_sw_desc {
	struct sk_buff *skb; /**< SKB pointer */
	DEFINE_DMA_UNMAP_ADDR(sw_dma_addr); /**< DMA unmap address */
	DEFINE_DMA_UNMAP_LEN(dma_len); /**< DMA unmap length */
	struct page *page; /**< Page pointer */
	dma_addr_t addr; /**< DMA address */
	enum xpcxd_page_state page_state; /**< Page state */
	u32 prod_idx; /**< Producer index */
	bool dma_err; /** DMA error flag */
	u32 usg_cnt; /** Descriptor usage count */
};

/**
 * @struct xpcxd_submit_ring
 * @brief Represents a submit ring for the XPCXD driver.
 */
struct xpcxd_submit_ring {
	struct xpcxd_desc *desc; /**< Submit and completion descriptors */
	struct xpcxd_sw_desc *sw; /**< Software descriptors */
	struct xpcxd_doorbell *db; /**< Doorbell */
	dma_addr_t dma_addr; /**< DMA address */
	size_t dma_size; /**< DMA size */
	struct xpcxd_atomic_fifo_ctrl *rfl_cns; /**< Receive FIFO control */
	dma_addr_t rfl_cns_dma_addr; /**< DMA address of receive FIFO control */
	size_t rfl_cns_dma_size; /**< DMA size of receive FIFO control */
	u16 size; /**< Ring size */
	u16 mask; /**< Mask */
	u16 prod; /**< Producer index */
	u16 cons; /**< Consumer index */
	u16 sub_cns_ptr; /**< Submission consumer pointer */
	u16 sub_cns_ptr_prev; /**< Previous submission consumer pointer */
};

/**
 * @struct xpcxd_compl_ring
 * @brief Structure representing a completion ring in the xpcxd driver.
 */
struct xpcxd_compl_ring {
	struct xpcxd_desc *desc; /**< Completion descriptors */
	dma_addr_t dma_addr; /**< DMA address */
	size_t dma_size; /**< DMA size */
	struct xpcxd_atomic_fifo_ctrl *rfl_prd; /**< Receive FIFO control */
	dma_addr_t rfl_prd_dma_addr; /**< DMA address of receive FIFO control */
	size_t rfl_prd_dma_size; /**< DMA size of receive FIFO control */
	u16 size; /**< Ring size */
	u16 mask; /**< Mask */
	u16 cons; /**< Consumer index */
	u16 cmpl_prd_ptr; /**< Completion production pointer */
	u16 cmpl_prd_ptr_prev; /**< Previous completion production pointer */
	u16 prev_cns_valid; /**< Previous consumer valid flag */
	u32 round_cnt; /**< Round count */
};

/**
 * @struct xpcxd_stats
 * @brief Structure representing statistics for the XPCXD driver.
 */
struct xpcxd_stats {
	u64 packets; /**< Number of packets */
	u64 bytes; /**< Number of bytes */
	u64 errors; /**< Number of errors */
	u64 dropped; /**< Number of dropped packets */
	u64 fifo_errors; /**< Number of FIFO errors */
	u64 rx_multicast; /**< Number of received multicast packets */
	u64 rx_broadcast; /**< Number of received broadcast packets */
	u64 rx_unicast; /**< Number of received unicast packets */
	u64 tx_multicast; /**< Number of transmitted multicast packets */
	u64 tx_broadcast; /**< Number of transmitted broadcast packets */
	u64 tx_unicast; /**< Number of transmitted unicast packets */
	u64 hw_csum_rx_error; /**< Number of hardware checksum receive errors */
	u64 rx_vlan_packets; /**< Number of received VLAN packets (not supported yet) */
	u64 tx_vlan_packets; /**< Number of transmitted VLAN packets */
	u64 rx_drop_events; /**< Number of receive drop events */
	u64 rx_underflow_events; /**< Number of receive underflow events */

	u64 rx_l3_csm_err; /**< Number of receive L3 checksum errors */
	u64 rx_l4_csm_err; /**< Number of receive L4 checksum errors */

	u64 rx_sub_threshold; /**< Number of receive sub-threshold events */
	u64 rx_cmpl_threshold; /**< Number of receive completion threshold events */
	u64 rx_cns_catched_prd; /**< Number of received consumer catched producer events */
	u64 rx_page_alloc_err; /**< Number of receive page allocation errors */
	u64 rx_dma_get_err_0; /**< Number of receive DMA get errors */
	u64 rx_dma_get_err; /**< Number of receive DMA get errors */
	u64 rx_wrong_page_state; /**< Number of receive wrong page state events */
	u64 rx_swdesc_err; /**< Number of receive software descriptor errors */
	u64 rx_page_err; /**< Receive page pointer errors */
	u64 rx_state_err; /**< Receive page state errors */
	u64 rx_page_state_les_then_free_err; /**< Number of receive page state less than free errors */
	u64 rx_swdesc_addr_err; /**< Number of receive software descriptor address errors */
	u64 rx_free_ref_cnt_0_page; /**< Number of times we attempted to release a page with ref count == 0 */
	u64 tx_underflow_events; /**< Number of transmit underflow events */
	u64 tx_sub_threshold; /**< Number of transmit sub-threshold events */
	u64 tx_cmpl_threshold; /**< Number of transmit completion threshold events */
	u64 tx_alignment_error; /**< Number of transmit alignment errors */
	u64 tx_shim_error; /**< Number of transmit shim errors */
	u32 cmpl_irq_cnt; /**< Completion IRQ count */
	u32 prev_cmpl_irq_cnt; /**< Previous completion IRQ count */
	u32 prev_packets; /**< Previous packet count */
	unsigned long cmpl_prev_jiffy; /**< Previous completion jiffy */
	unsigned long xmit_prev_jiffy; /**< Previous transmit jiffy */
	unsigned long rx_prev_jiffy; /**< Previous receive jiffy */
	bool int_enabled; /**< Interrupt enabled flag */
};

/**
 * @enum xpcxd_ring_type
 * @brief Enumeration for the types of XPCXD rings.
 */
enum xpcxd_ring_type {
	XPCXD_RING_RX = 1, /**< Receive ring */
	XPCXD_RING_TX = 2, /**< Transmit ring */
};

/**
 * @struct xpcxd_ring
 * @brief Structure representing an XPCXD ring.
 */
struct xpcxd_ring {
	u32 ring_id; /**< Ring ID */
	struct xpcxd_submit_ring sub; /**< Submission ring */
	struct xpcxd_compl_ring cmp; /**< Completion ring */
	struct napi_struct napi; /**< NAPI structure */
	enum xpcxd_ring_type type; /**< Type of the ring */
	struct netdev_queue *queue; /**< Network device queue */
	struct xpcxd_priv *xd; /**< XPCXD private data */
	u16 cmpl_thold; /**< Completion threshold */
	struct u64_stats_sync syncp; /**< Synchronization point for statistics */
	struct xpcxd_stats stats; /**< Statistics per ring */
	u16 db_count; /**< Doorbell count */
	struct page_pool *page_pool; /**< Page pool */
	bool tx_rx_enabled; /**< Flag indicating if transmit/receive is enabled */
	struct hrtimer time_isr; /**< Timer for interrupt service routine */
	struct hrtimer tx_coales_isr; /**< Timer for transmit coalescing interrupt service routine */
	spinlock_t tx_lock; /**< Spinlock for transmit operations */
	/* Credits are calculated as delta between rx_fill budget and actual number of BDs that we succseeded to fill */
	/* Those credits will be used on next rx_fill as an addition to the budget */
	u32 rx_credits;
};

/**
 * @enum xpcxd_device_state
 * @brief Enumeration for the states of the XPCXD device.
 */
enum xpcxd_device_state {
	XPCXD_FLAG_DEV_ADMIN_RDY, /**< Device is administratively ready */
	XPCXD_FLAG_DEV_INIT, /**< Device is being initialized */
	XPCXD_FLAG_DEV_FAILED, /**< Device initialization failed */
	XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, /**< Device restart is in progress */
	XPCXD_FLAG_DEV_DEAD /**< Device is dead */
};

/**
 * @enum xpcxd_rss_mode
 * @brief Enumeration for the RSS (Receive Side Scaling) modes of the XPCXD device.
 */
enum xpcxd_rss_mode {
	XPCXD_RSS_MODE_EXPLICIT = 0, /**< Explicit mode */
	XPCXD_RSS_MODE_HASH_INDEX = 1, /**< Hash index mode */
	XPCXD_RSS_MODE_RSS_GROUP_ID = 2, /**< RSS group ID mode */
	XPCXD_RSS_MODE_FULL = 3 /**< Full mode (QID converted to RSS group ID) */
};

/**
 * @struct xpcxd_priv
 * @brief Structure representing the private data of the xpcxd driver.
 */
struct xpcxd_priv {
	struct net_device *netdev; /**< Pointer to the network device structure */
	struct device *hw_dev; /**< Pointer to the hardware device structure */

	union {
		u8 mac[6]; /**< MAC address */
		u64 mac_addr; /**< MAC address as a 64-bit integer */
	};
	bool up_state; /**< Flag indicating if the device is up */
	bool oper_status; /**< Flag indicating the operational status of the device */

	u16 num_rings; /**< Number of rings */

	u8 num_rx_queues; /**< Number of receive queues */
	u8 num_tx_queues; /**< Number of transmit queues */

	struct xpcxd_ring rxr[XPCXD_MAX_RING_NUM]; /**< Array of receive rings */
	struct xpcxd_ring txr[XPCXD_MAX_RING_NUM]; /**< Array of transmit rings */

	struct u64_stats_sync syncp; /**< Synchronization structure for 64-bit statistics */
	struct xpcxd_stats stats; /**< Statistics for the xpcxd driver */
	struct rtnl_link_stats64 stats64; /**< Accumulated statistics per interface */

	struct workqueue_struct *wq; /**< Workqueue structure for handling tasks */
	struct work_struct service_task; /**< Work structure for the service task */
	void __iomem *regs; /**< Pointer to the device registers */
	struct xpcxd_doorbell *rx_db; /**< Pointer to the receive doorbell */
	struct xpcxd_doorbell *tx_db; /**< Pointer to the transmit doorbell */
	unsigned long dev_flags; /**< Flags for device configuration */
	u16 num_rx_desc; /**< Number of receive descriptors */
	u16 num_tx_desc; /**< Number of transmit descriptors */
	int irq; /**< Interrupt number */

#define XPCXD_FLAG_DUMP_TX_STAT			(u32)(1 << 0)	/* Dump all Tx related counters */
#define XPCXD_FLAG_DUMP_RX_STAT			(u32)(1 << 1)	/* Dump all Rx related counters*/
#define XPCXD_FLAG_CLEAR_TX_STAT		(u32)(1 << 2)	/* Clear all Tx related counters */
#define XPCXD_FLAG_CLEAR_RX_STAT		(u32)(1 << 3)	/* Clear all Rx related counters*/
#define XPCXD_FLAG_STOP_ON_NEXT_TX		(u32)(1 << 4)	/* Raise trigger and stop all Tx/Rx on next Tx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_RX		(u32)(1 << 5)	/* Raise trigger and stop all Tx/Rx on next Rx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_ISR		(u32)(1 << 6)	/* Raise trigger and stop on next timer isr */
#define XPCXD_FLAG_DROP_ALL_TX			(u32)(1 << 7)	/* Set drop before sending to NIC for all Tx packets */
#define XPCXD_FLAG_DROP_ALL_RX			(u32)(1 << 8)	/* Set drop before receiving from NIC for all Rx packets */
#define XPCXD_FLAG_IGNORE_RX_L3_CHKSUM	(u32)(1 << 9)	/* Ignore error print and count on L3 checksum error */
#define XPCXD_FLAG_IGNORE_RX_L4_CHKSUM	(u32)(1 << 10)	/* Ignore error print and count on L4 checksum error */
#define XPCXD_FLAG_STOP_RX_L3_CHKSUM	(u32)(1 << 11)	/* Stop on L3 checksum error */
#define XPCXD_FLAG_STOP_RX_L4_CHKSUM	(u32)(1 << 12)	/* Stop on L4 checksum error */
#define XPCXD_FLAG_STOP_ON_RX_THRESHOLD	(u32)(1 << 13)	/* Stop on ring space threshold */
#define XPCXD_FLAG_ENABLE_TX_ERR_INT	(u32)(1 << 14)	/* Enable Tx error interrupt */
#define XPCXD_FLAG_ENABLE_RX_ERR_INT	(u32)(1 << 15)	/* Enable Rx error interrupt */
#define XPCXD_FLAG_INSERT_EMPTY_BD		(u32)(1 << 16)	/* Enable insertion of empty Buffer Descriptors */
#define XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR	(u32)(1 << 17)	/* Drop badly aligned Tx packets */

	u32 priv_flags; /**< Private flags */

	u32 rx_buf_size; /**< Size of the receive buffer */
	u32 tx_buf_size; /**< Size of the transmit buffer */
};

/**
 * @brief RSS Qid Table structure
 */
struct xpcxd_rss_qid_tbl {
	u8 group_base;
	u8 group_size;
};

/** 
 * @brief Spare register write values 
 */
typedef enum {
	g_cnt_init_done = 0x1,
	g_cnt_if_up = 0x2,
	g_cnt_packet_tx = 0x4,
	g_cnt_packet_rx_fill = 0x8,
	g_cnt_tx_stop = 0x10,
} dbg_cnt_t;

/**
 * @brief Enumeration of configuration items for XPCXD.
 */
typedef enum {
	xpcxd_tx_coales_size = 0, /**< Number of packets in a Tx batch */
	xpcxd_tx_coales_time = 1, /**< Time in X2 cycles for Tx coalescing */
	xpcxd_rx_coales_size = 2, /**< Number of packets in an Rx batch */
	xpcxd_rx_coales_time = 3, /**< Time in X2 cycles for Rx coalescing */
	xpcxd_int_enable = 4, /**< Interrupt enable flag */

	xpcxd_rx_drop_all = 5, /**< Drop all received packets flag */
	xpcxd_tx_drop_all = 6, /**< Drop all transmitted packets flag */
	xpcxd_tx_checksum_bypass = 7, /**< Bypass Tx checksum calculation flag */
	xpcxd_rx_checksum_bypass = 8, /**< Bypass Rx checksum verification flag */
	xpcxd_check_l3_checksum = 9, /**< Check L3 checksum flag */
	xpcxd_check_l4_checksum = 10, /**< Check L4 checksum flag */
	xpcxd_rx_shaper = 11, /**< Rx shaper configuration */
	xpcxd_tx_db_skip = 12, /**< Number of Tx descriptors to skip */

	xpcxd_enable_tx_err_int = 13, /**< Enable Tx error interrupt flag */
	xpcxd_enable_rx_err_int = 14, /**< Enable Rx error interrupt flag */
	xpcxd_event_trace = 15, /**< Event trace configuration */

	xpcxd_last_cfg_item = xpcxd_event_trace + 1 /**< Last configuration item */
} xpcxd_config_item_t;

/**
 * @brief Enumeration representing the bypass modes for xpcxd.
 */
enum xpcxd_bypass_mode {
	xpcxd_no_bypass = 0,            /**< No bypass mode */
	xpcxd_selective_bypass = 1,     /**< Selective bypass mode */
	xpcxd_global_bypass = 2         /**< Global bypass mode */
};

/**
 * Initializes the xpcxd driver.
 *
 * @param _pxdev A pointer to the device structure.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_init(void *_pxdev);

/**
 * Closes the xpcxd driver.
 *
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_close(void);

/**
 * Registers a network device with the xpcxd driver.
 *
 * @param if_name The name of the network interface.
 * @param do_rtnl_lock Whether to acquire the rtnl lock.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_register_netdev(char *if_name, bool do_rtnl_lock);

/**
 * Unregisters a network device from the xpcxd driver.
 *
 * @param netdev The network device to unregister.
 * @param do_rtnl_lock Whether to acquire the rtnl lock.
 */
void xpcxd_unregister_netdev(struct net_device *netdev, bool do_rtnl_lock);

/**
 * Initializes the hardware for the xpcxd driver.
 *
 * @param num_of_rings The number of rings to initialize.
 * @param tx_ring_size The size of the transmit ring.
 * @param rx_ring_size The size of the receive ring.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_hw_init(u32 num_of_rings, u16 tx_ring_size, u16 rx_ring_size);

/**
 * Activates or deactivates the hardware for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate the hardware.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_hw_activate(bool activate);

/**
 * Registers the network link with the rtnetlink subsystem.
 *
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rtnl_link_register(void);

/**
 * Unregisters the network link from the rtnetlink subsystem.
 */
void xpcxd_rtnl_link_unregister(void);

/**
 * Sets the state of the network interface.
 *
 * @param netdev The network device.
 * @param status The desired state of the interface.
 * @param carrier_state The desired carrier state of the interface.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_set_if_state(struct net_device *netdev, bool status, bool carrier_state);

/**
 * Sets the ethtool operations for the network device.
 *
 * @param netdev The network device.
 */
void xpcxd_set_ethtool_ops(struct net_device *netdev);

/**
 * Gets the available space in the transmit sub-ring.
 *
 * @param ring The transmit ring.
 * @return The available space in the sub-ring.
 */
u32 xpcxd_get_tx_sub_ring_space(struct xpcxd_ring *ring);

/**
 * Gets the available space in the receive sub-ring.
 *
 * @param ring The receive ring.
 * @return The available space in the sub-ring.
 */
u32 xpcxd_get_rx_sub_ring_space(struct xpcxd_ring *ring);

/**
 * Gets the available space in the completion ring.
 *
 * @param ring The completion ring.
 * @return The available space in the ring.
 */
u32 xpcxd_get_cmpl_ring_space(struct xpcxd_ring *ring);

/**
 * Disables receive processing for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to disable.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_rx_disable(struct net_device *netdev, u32 ring_id);

/**
 * Activates or deactivates receive processing for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate receive processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_activate(bool activate);

/**
 * Activates or deactivates transmit processing for the xpcxd driver.
 *
 * @param activate Whether to activate or deactivate transmit processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_activate(bool activate);

/**
 * Disables transmit processing for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to disable.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_tx_disable(struct net_device *netdev, u32 ring_id);

/**
 * Enables receive processing for the network device.
 *
 * @param netdev The network device.
 * @param rx_activate Whether to activate receive processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_rx_enable(struct net_device *netdev, bool rx_activate);

/**
 * Enables transmit processing for the network device.
 *
 * @param netdev The network device.
 * @param tx_activate Whether to activate transmit processing.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_dev_tx_enable(struct net_device *netdev, bool tx_activate);

/**
 * Writes the RSS hash key for the xpcxd driver.
 */
void xpcxd_rss_hash_key_write(void);

/**
 * Clears the transmit statistics registers for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_clear_regs(struct net_device *netdev);

/**
 * Clears the transmit statistics for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to clear the statistics for.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id);

/**
 * Dumps the short transmit statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_dump_short(struct net_device *netdev);

/**
 * Dumps the transmit statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_tx_stat_dump(struct net_device *netdev);

/**
 * Clears the receive statistics registers for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_clear_regs(struct net_device *netdev);

/**
 * Clears the receive statistics for a specific ring of the network device.
 *
 * @param netdev The network device.
 * @param ring_id The ID of the ring to clear the statistics for.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_clear_per_ring(struct net_device *netdev, uint32_t ring_id);

/**
 * Dumps the short receive statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_dump_short(struct net_device *netdev);

/**
 * Dumps the receive statistics for the network device.
 *
 * @param netdev The network device.
 * @return 0 on success, or a negative error code on failure.
 */
int xpcxd_rx_stat_dump(struct net_device *netdev);

/**
 * Aligns the skb buffer to the specified alignment.
 *
 * @param skb The skb buffer to align.
 * @param align The alignment value.
 */
void xpcxd_skb_align(struct sk_buff *skb, int align);

/**
 * Gets the 64-bit statistics for the network device.
 *
 * @param netdev The network device.
 * @param stats The structure to store the statistics.
 */
void xpcxd_get_stats64(struct net_device *netdev, struct rtnl_link_stats64 *stats);

/**
 * Transmits an skb buffer through the network device.
 *
 * @param skb The skb buffer to transmit.
 * @param netdev The network device.
 * @return The transmission status.
 */
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev);

/**
 * Gets the underflow count for receive processing.
 *
 * @return The underflow count.
 */
int xpcxd_rx_get_underflow_cnt(void);

/**
 * Gets the underflow count for transmit processing.
 *
 * @return The underflow count.
 */
int xpcxd_tx_get_underflow_cnt(void);

/**
 * Interrupt service routine for the transmit coalescing timer.
 *
 * @param timer The hrtimer structure.
 * @return The hrtimer restart value.
 */
enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer);

/**
 * Increment packet statistics for the given ring.
 *
 * @param ring The xpcxd_ring structure representing the ring.
 * @param len The length of the packet.
 */
static inline void xpcxd_pkt_stats_inc(struct xpcxd_ring *ring, u32 len)
{
	u64_stats_update_begin(&ring->syncp);
	ring->stats.packets++;
	ring->stats.bytes += len;
	u64_stats_update_end(&ring->syncp);
	return;
}

#if __has_include(<net/page_pool.h>)
#include <net/page_pool.h>
#define __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
#else
#include <net/page_pool/types.h>
#include <net/page_pool/helpers.h>
#endif

#ifdef __XPCXD_PAGE_POOL_PERF__

/**
 * Create a page pool with the given parameters.
 *
 * @param params The parameters for creating the page pool.
 * @return The created page pool.
 */
static inline struct page_pool *xpcxd_page_pool_create(const struct page_pool_params *params)
{
	return page_pool_create(params);
}

/**
 * Allocate pages from the device-specific page pool.
 *
 * @param pool The page pool from which to allocate pages.
 * @return The allocated page.
 */
static inline struct page *xpcxd_page_pool_dev_alloc_pages(struct page_pool *pool)
{
	return page_pool_dev_alloc_pages(pool);
}

/**
 * Get the DMA address of the given page.
 *
 * @param page The page for which to get the DMA address.
 * @return The DMA address of the page.
 */
static inline dma_addr_t xpcxd_page_pool_get_dma_addr(struct page *page)
{
	// xpcxd_trace_printk("page_pool_get_dma_addr: %lu", page_to_pfn(page));
	return page_pool_get_dma_addr(page);
}

/**
 * Recycle a page directly to the page pool.
 *
 * @param pool The page pool to which the page should be recycled.
 * @param page The page to be recycled.
 */
static inline int xpcxd_page_pool_recycle_direct(struct page_pool *pool, struct page *page)
{
	// xpcxd_trace_printk("page_pool_recycle_direct: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_recycle_direct(pool, page);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt: page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

/**
 * Put a full page into the page pool.
 *
 * @param pool The page pool to which the page should be put.
 * @param page The page to be put.
 * @param allow_direct Whether direct recycling is allowed.
 */
static inline int xpcxd_page_pool_put_full_page(struct page_pool *pool,
				      struct page *page, bool allow_direct)
{
	// xpcxd_trace_printk("page_pool_put_full_page: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_put_full_page(pool, page, allow_direct);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt on page_pool_put_full_page(): page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

/**
 * Release a page back to the page pool.
 *
 * @param pool The page pool to which the page should be released.
 * @param page The page to be released.
 * @return 0 on success, or a non-zero error code on failure.
 */
static inline int xpcxd_page_pool_release_page(struct page_pool *pool,
				      struct page *page)
{
	// xpcxd_trace_printk("page_pool_put_full_page: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
#ifdef __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
		page_pool_release_page(pool, page);
#else
		page_pool_put_full_page(pool, page, false);
#endif
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt on page_pool_release_page(): page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

#else
#define xpcxd_page_pool_create page_pool_create
#define xpcxd_page_pool_dev_alloc_pages page_pool_dev_alloc_pages
#define xpcxd_page_pool_get_dma_addr page_pool_get_dma_addr
// #define xpcxd_page_pool_recycle_direct page_pool_recycle_direct
#define xpcxd_page_pool_put_full_page page_pool_put_full_page
#ifdef __XPCI_HAVE_PAGE_POOL_RELEASE_PAGE__
#define xpcxd_page_pool_release_page(pool, page) page_pool_release_page(pool, page)
#else
#define xpcxd_page_pool_release_page(pool, page) page_pool_put_full_page(pool, page, false)
#endif

/**
 * Recycle a page directly to the page pool.
 *
 * @param pool The page pool to which the page should be recycled.
 * @param page The page to be recycled.
 */
static inline int xpcxd_page_pool_recycle_direct(struct page_pool *pool, struct page *page)
{
	// xpcxd_trace_printk("page_pool_recycle_direct: %lu", page_to_pfn(page));

	if (page_ref_count(page) == 1) {
		page_pool_recycle_direct(pool, page);
	} else {
		xpcxd_trace_printk(
			"Invalid ref_cnt: page: [%p] pfn: [%lu] ref_cnt: [%d]",
			page, page_to_pfn(page), page_ref_count(page));
		return 1;
	}

	return 0;
}

#endif

#endif /* XPCXD_H_ */
