// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver common definitions
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#ifndef XPCXD_H_
#define XPCXD_H_

#include <asm/byteorder.h>
#include <linux/netdevice.h>
#include <linux/hrtimer.h>
#include "xpcxd_regs.h"
#include "xnetdev_common.h"

#ifndef __LITTLE_ENDIAN
#define __LITTLE_ENDIAN -1
#endif
#define __BYTE_ORDER __LITTLE_ENDIAN

typedef uint64_t xpcxd_ring_handle_t;

#define XPCXD_NETDEV_DRV_NAME "xpcxd_netdev"

#define MAX_CFG_ITEM_LEN 32

#define XPCXD_NET_DEV_NAME_SIZE 64
#define XPCXD_IF_NAME_SIZE 64

#define XPCXD_DEFAULT_RING_SIZE 256
#define XPCXD_MAX_RING_NUM 8

#define XPCXD_NO_LIMIT 0

#define XPCXD_RING_DSC_BUFFERS 256

#define XPCXD_HW_SHIM_SIZE 3

#define XPCXD_NUM_OF_RSS_QUEUES 8
#define XPCXD_RSS_SECRET_KEY_SIZE 40

/**
 * Netlink parameters to create Packet over PCI (PCXD) netdev
 * ip link add NAME type pcxd
 */
enum xpcxd_spec {
	IFLA_XPCXD_UNSPEC,

	IFLA_XPCXD_IF_CFG,
	IFLA_XPCXD_IF_OP,
	IFLA_XPCXD_IF_NAME,
	IFLA_XPCXD_IF_STATE,
	IFLA_XPCXD_IF_MODE,
	IFLA_XPCXD_CFG_NUM_OF_RINGS,
	IFLA_XPCXD_CFG_TX_RING_SIZE,
	IFLA_XPCXD_CFG_RX_RING_SIZE,

	__IFLA_XPCXD_MAX
};
#define IFLA_XPCXD_MAX (__IFLA_XPCXD_MAX - 1)

/**
 * @brief Packet over PCI (PCXD) interface operations: ADD/DELETE/UPDATE
 */
enum xpcxd_if_op {
  XPCXD_IF_OP_UNKNOWN = 0,          	/**< Unknown parameter */
  XPCXD_IF_OP_ADD = 1,              	/**< Add interface */
  XPCXD_IF_OP_UPDATE = 2,               /**< Update interface */
  XPCXD_IF_OP_DEL = 3,                  /**< Delete interface */
  XPCXD_IF_OP_MAX = XPCXD_IF_OP_DEL,   	/**< Max value */
};

/**
 * Interface operational state
 */
enum xpcxd_if_state {
	XPCXD_IF_UNCHANGED,
	XPCXD_IF_UP,
	XPCXD_IF_DOWN
};

/**
 * Interface mode
 */
enum xpcxd_mode {
	XPCXD_MODE_UNKNOWN,
	XPCXD_MODE_INIT,
	XPCXD_MODE_STOP,
	XPCXD_MODE_RESUME,
	XPCXD_MODE_SHUTDOWN,
};

#define XPCXD_NAPI_POLL_WEIGHT 8

#define XPCXD_MAX_RING_SIZE    32768
#define XPCXD_NUM_TXD_PER_PKT  2
#define XPCXD_TX_STOP_THOLD    XPCXD_NUM_TXD_PER_PKT

/* make IP header 4 byte aligned */
// #define XPCXD_DATA_START_OFS   2

// #define XPCXD_SKB_SIZE_MIN     1536
// #define XPCXD_SKB_RX_HEADROOM     XPCXD_DATA_START_OFS
#define XPCXD_SKB_DATA_SIZE    1536 // (XPCXD_SKB_SIZE_MIN - XPCXD_SKB_RX_HEADROOM)

#define RX_OFFSET xpcxd_loopback?0:XSW_RX_SHIM_HDR_SIZE
#define TX_OFFSET xpcxd_loopback?0:XSW_TX_SHIM_HDR_SIZE

#define XPCXD_ALIGNMENT_64 64
#define XPCXD_ALIGNMENT_256 256
#define XPCXD_SKB_RX_HEADROOM SKB_DATA_ALIGN(/*NET_SKB_PAD + */ NET_IP_ALIGN)
#define XPCXD_SKB_SHINFO_SIZE (SKB_DATA_ALIGN(sizeof(struct skb_shared_info)))
#define XPCXD_SKB_TAIL_ROOM (XPCXD_SKB_SHINFO_SIZE)

#define XPCXD_FRAG_OFFSET (XPCXD_SKB_RX_HEADROOM)
#define XPCXD_FRAG_DATA_SIZE SKB_DATA_ALIGN(PAGE_SIZE - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM)

#define XPCXD_DEFAULT_MTU_SIZE 10200
#define XPCXD_MAX_MTU_SIZE ((PAGE_SIZE * 4) - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM) /* 16064 */

#define XPCXD_MAX_RX_BUF_SIZE (XPCXD_MAX_MTU_SIZE + XPCXD_SKB_RX_HEADROOM + XPCXD_SKB_TAIL_ROOM)

enum xpcxd_page_state {
	XPCXD_PAGE_INIT = 0,
	XPCXD_PAGE_FREE = 1,
	XPCXD_PAGE_ALLOCATED = 2,
	XPCXD_PAGE_PASSED_TO_STACK = 3,
};

struct xpcxd_sw_desc {
	struct sk_buff *skb;
	DEFINE_DMA_UNMAP_ADDR(sw_dma_addr);
	DEFINE_DMA_UNMAP_LEN(dma_len);
	struct page *page;
	dma_addr_t addr;
	enum xpcxd_page_state page_state;
	u32 prod_idx;
};

struct xpcxd_submit_ring {
	struct xpcxd_desc *desc;	/* Submit and completion descriptors, allocated with Coherent DMA malloc */
	struct xpcxd_sw_desc *sw;	/* Software descriptors, allocated in host memory with kvzalloc() */
	struct xpcxd_doorbell *db;
	dma_addr_t dma_addr;
	size_t dma_size;
	struct xpcxd_atomic_fifo_ctrl *rfl_cns;
	dma_addr_t rfl_cns_dma_addr;
	size_t rfl_cns_dma_size;
	u16 size; /* Ring size */
	u16 mask; /* Mask */
	u16 prod; /* Producer index */
	u16 cons; /* Consumer index */
	u16 sub_cns_ptr;
	u16 sub_cns_ptr_prev;
};

struct xpcxd_compl_ring {
	struct xpcxd_desc *desc;
	dma_addr_t dma_addr;
	size_t dma_size;
	struct xpcxd_atomic_fifo_ctrl *rfl_prd;
	dma_addr_t rfl_prd_dma_addr;
	size_t rfl_prd_dma_size;
	u16 size;
	u16 mask;
	u16 cons; 				/* Completion Consumer pointer is SW only */
	u16 cmpl_prd_ptr; 		/* Completion Production pointer is taken from HW */
	u16 cmpl_prd_ptr_prev;	/* Previous HW Completion Production pointer */
	u16 prev_cns_valid;

	u32 round_cnt;
};

struct xpcxd_stats {
	/* Statistics per ring */
    u64 packets;
    u64 bytes;
    u64 errors;
    u64 dropped;
	u64 fifo_errors;

	u64 rx_multicast;
	u64 rx_broadcast;
	u64 rx_unicast;
	u64 tx_multicast;
	u64 tx_broadcast;
	u64 tx_unicast;
	u64 hw_csum_rx_error;

	u64 rx_vlan_packets; /* TODO: Not supported yet */
	u64 tx_vlan_packets;
	u64 rx_drop_events;

	/* Proprietry XPCXD statistics */
	u64 rx_underflow_events;

	u64 rx_sub_threshold;
	u64 rx_cmpl_threshold;

	u64 rx_cns_catched_prd;

	u64 rx_page_alloc_err;
	u64 rx_dma_get_err;
	u64 rx_wrong_page_state;

	u64 tx_underflow_events;

	u64 tx_sub_threshold;
	u64 tx_cmpl_threshold;

	u64 tx_alignment_error;
	u64 tx_shim_error;

	/* Debug counters per ring */
	u32 cmpl_irq_cnt;
	u32 prev_cmpl_irq_cnt;
	u32 prev_packets;
	unsigned long cmpl_prev_jiffy;
	unsigned long xmit_prev_jiffy;
	unsigned long rx_prev_jiffy;
	bool int_enabled;
};

enum xpcxd_ring_type {
	XPCXD_RING_RX = 1,
	XPCXD_RING_TX = 2,
};

struct xpcxd_ring {
	u32 ring_id;
	struct xpcxd_submit_ring sub;
	struct xpcxd_compl_ring cmp;
	struct napi_struct napi;
	enum xpcxd_ring_type type;
	struct netdev_queue *queue;
	struct xpcxd_priv *xd;
	u16 cmpl_thold;
	struct u64_stats_sync syncp;
	struct xpcxd_stats stats;         /* Statistics per ring */

	u16 db_count;

	struct page_pool *page_pool;

	bool tx_rx_enabled;

	struct hrtimer time_isr;
	struct hrtimer tx_coales_isr;

	spinlock_t tx_lock;
};

enum xpcxd_device_state {
	XPCXD_FLAG_DEV_ADMIN_RDY,
	XPCXD_FLAG_DEV_INIT,
	XPCXD_FLAG_DEV_FAILED,
	XPCXD_FLAG_DEV_RESTART_IN_PROGRESS,
	XPCXD_FLAG_DEV_DEAD
};

enum xpcxd_rss_mode {
	XPCXD_RSS_MODE_EXPLICIT = 0,		/* Explicit mode */
	XPCXD_RSS_MODE_HASH_INDEX = 1,		/* Hash index mode */
	XPCXD_RSS_MODE_RSS_GROUP_ID = 2,	/* RSS group ID*/
	XPCXD_RSS_MODE_FULL = 3, 			/* QID converted to RSS group ID */
};

/**
 * Net Dev private structure
 */
struct xpcxd_priv {
	struct net_device *netdev;
	struct device *hw_dev;

	union {
		u8 mac[6];
		u64 mac_addr;
	};
	bool up_state;
	bool oper_status;

	u16 num_rings;

	u8 num_rx_queues;
	u8 num_tx_queues;

	struct xpcxd_ring rxr[XPCXD_MAX_RING_NUM];
	struct xpcxd_ring txr[XPCXD_MAX_RING_NUM];

	struct u64_stats_sync syncp;
	struct xpcxd_stats stats;        
	struct rtnl_link_stats64 stats64;  /* Accumulated statistics per interface */

	struct workqueue_struct *wq;
	struct work_struct service_task;
	void __iomem *regs;
	struct xpcxd_doorbell *rx_db;
	struct xpcxd_doorbell *tx_db;
	unsigned long dev_flags;
	u16 num_rx_desc;
	u16 num_tx_desc;
	int irq;

	bool napi_active;

#define XPCXD_FLAG_DUMP_TX_STAT			(u32)(1 << 0)	/* Dump all Tx related counters */
#define XPCXD_FLAG_DUMP_RX_STAT			(u32)(1 << 1)	/* Dump all Rx related counters*/
#define XPCXD_FLAG_STOP_ON_NEXT_TX		(u32)(1 << 2)	/* Raise trigger and stop all Tx/Rx on next Tx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_RX		(u32)(1 << 3)	/* Raise trigger and stop all Tx/Rx on next Rx packet*/
#define XPCXD_FLAG_STOP_ON_NEXT_ISR		(u32)(1 << 4)	/* Raise trigger and stop on next timer isr */
#define XPCXD_FLAG_DROP_ALL_TX			(u32)(1 << 5)	/* Set drop before sending to NIC for all Tx packets */
#define XPCXD_FLAG_DROP_ALL_RX			(u32)(1 << 6)	/* Set drop before receiving from NIC for all Rx packets */
#define XPCXD_FLAG_IGNORE_RX_L3_CHKSUM	(u32)(1 << 9)	/* Ignore error print and count on L3 checksum error */
#define XPCXD_FLAG_IGNORE_RX_L4_CHKSUM	(u32)(1 << 10)	/* Ignore error print and count on L4 checksum error */
#define XPCXD_FLAG_STOP_RX_L3_CHKSUM	(u32)(1 << 11)	/* Stop on L3 checksum error */
#define XPCXD_FLAG_STOP_RX_L4_CHKSUM	(u32)(1 << 12)	/* Stop on L4 checksum error */
#define XPCXD_FLAG_STOP_ON_RX_THRESHOLD	(u32)(1 << 13)	/* Stop on ring space threshold */
#define XPCXD_FLAG_ENABLE_TX_ERR_INT	(u32)(1 << 14)	/* Enable Tx error interrupt */
#define XPCXD_FLAG_ENABLE_RX_ERR_INT	(u32)(1 << 15)	/* Enable Rx error interrupt */
#define XPCXD_FLAG_INSERT_EMPTY_BD		(u32)(1 << 16)	/* Enable insertion of empty Buffer Descriptors */
#define XPCXD_FLAG_DROP_ON_TX_ALIGNMENT_ERR	(u32)(1 << 17)	/* Drop badly aligned Tx packets */

	u32 priv_flags;

	u32 rx_buf_size;
	u32 tx_buf_size;
};

/**
 * RSS Qid Table structure
 */
struct xpcxd_rss_qid_tbl {
	u8 group_base;
	u8 group_size;
};

/* Spare register write values */
typedef enum {
	g_cnt_init_done = 0x1,
	g_cnt_if_up = 0x2,
	g_cnt_packet_tx = 0x4,
	g_cnt_packet_rx_fill = 0x8,
	g_cnt_tx_stop = 0x10,
} dbg_cnt_t;

typedef enum {
	xpcxd_tx_coales_size = 0, /* Number of packet if Tx batch */
	xpcxd_tx_coales_time = 1, /* In X2 cycles */
	xpcxd_rx_coales_size = 2, /* Number of packet if Rx batch */
	xpcxd_rx_coales_time = 3, /* In X2 cycles */
	xpcxd_int_enable = 4,

	xpcxd_rx_drop_all = 5,
	xpcxd_tx_drop_all = 6,
	xpcxd_tx_checksum_bypass = 7,
	xpcxd_rx_checksum_bypass = 8,
	xpcxd_check_l3_checksum = 9,
	xpcxd_check_l4_checksum = 10,
	xpcxd_rx_shaper = 11,
	xpcxd_tx_db_skip = 12,

	xpcxd_enable_tx_err_int = 13,
	xpcxd_enable_rx_err_int = 14,

	xpcxd_last_cfg_item = xpcxd_enable_rx_err_int + 1
} xpcxd_cfg_tbl_int;

enum xpcxd_bypass_mode {
	xpcxd_no_bypass = 0,
	xpcxd_selective_bypass = 1,
	xpcxd_global_bypass = 2,
};

int xpcxd_init(void *_pxdev);
int xpcxd_close(void);
int xpcxd_register_netdev(char *if_name, bool do_rtnl_lock);
void xpcxd_unregister_netdev(struct net_device *netdev,
			    bool do_rtnl_lock);
int xpcxd_hw_init(u32 num_of_rings, u16 tx_ring_size, u16 rx_ring_size);
int xpcxd_hw_activate(bool activate);
int xpcxd_rtnl_link_register(void);
void xpcxd_rtnl_link_unregister(void);
int xpcxd_set_if_state(struct net_device *netdev, bool status, bool carrier_state);
void xpcxd_set_ethtool_ops(struct net_device *netdev);
u32 xpcxd_get_tx_sub_ring_space(struct xpcxd_ring *ring);
u32 xpcxd_get_rx_sub_ring_space(struct xpcxd_ring *ring);
u32 xpcxd_get_cmpl_ring_space(struct xpcxd_ring *ring);
int xpcxd_dev_rx_disable(struct net_device *netdev, u32 ring_id);
int xpcxd_rx_activate(bool activate);
int xpcxd_tx_activate(bool activate);
int xpcxd_dev_tx_disable(struct net_device *netdev, u32 ring_id);
int xpcxd_dev_rx_enable(struct net_device *netdev, bool rx_activate);
int xpcxd_dev_tx_enable(struct net_device *netdev, bool tx_activate);
void xpcxd_rss_hash_key_write(void);
int xpcxd_tx_stat_clear(struct net_device *netdev, uint32_t ring_id);
int xpcxd_tx_stat_dump_short(struct net_device *netdev);
int xpcxd_tx_stat_dump(struct net_device *netdev);
int xpcxd_rx_stat_clear(struct net_device *netdev, uint32_t ring_id);
int xpcxd_rx_stat_dump_short(struct net_device *netdev);
int xpcxd_rx_stat_dump(struct net_device *netdev);
void xpcxd_skb_align(struct sk_buff *skb, int align);
void xpcxd_get_stats64(struct net_device *netdev,
			      struct rtnl_link_stats64 *stats);
netdev_tx_t xpcxd_xmit(struct sk_buff *skb, struct net_device *netdev);
int xpcxd_rx_get_underflow_cnt(void);
int xpcxd_tx_get_underflow_cnt(void);
enum hrtimer_restart xpcxd_ring_tx_coales_isr(struct hrtimer *timer);

static inline void xpcxd_pkt_stats_inc(struct xpcxd_ring *ring, u32 len)
{
	u64_stats_update_begin(&ring->syncp);
	ring->stats.packets++;
	ring->stats.bytes += len;

	u64_stats_update_end(&ring->syncp);

	return;
}

#ifdef __XPCXD_PAGE_POOL_PERF__
#include <net/page_pool.h>

static inline struct page_pool *xpcxd_page_pool_create(const struct page_pool_params *params)
{
	return page_pool_create(params);
}

static inline struct page *xpcxd_page_pool_dev_alloc_pages(struct page_pool *pool)
{
	return page_pool_dev_alloc_pages(pool);
}

static inline dma_addr_t xpcxd_page_pool_get_dma_addr(struct page *page)
{
	// trace_printk("page_pool_get_dma_addr: %lu", page_to_pfn(page));

	return page_pool_get_dma_addr(page);
}

static inline void xpcxd_page_pool_recycle_direct(struct page_pool *pool, struct page *page)
{
	// trace_printk("page_pool_recycle_direct: %lu", page_to_pfn(page));

	page_pool_recycle_direct(pool, page);
}

// static inline void xpcxd_page_pool_put_page(struct page_pool *pool,
//  				      struct page *page, bool allow_direct)
// {
//  	trace_printk("page_pool_put_page: %lu", page_to_pfn(page));

//  	page_pool_put_page(pool, page, allow_direct);
// }

static inline void xpcxd_page_pool_put_full_page(struct page_pool *pool,
				      struct page *page, bool allow_direct)
{
	trace_printk("page_pool_put_full_page: %lu", page_to_pfn(page));

	page_pool_put_full_page(pool, page, allow_direct);
}

#else
#define xpcxd_page_pool_create page_pool_create
#define xpcxd_page_pool_dev_alloc_pages page_pool_dev_alloc_pages
#define xpcxd_page_pool_get_dma_addr page_pool_get_dma_addr
#define xpcxd_page_pool_recycle_direct page_pool_recycle_direct
// #define xpcxd_page_pool_put_page page_pool_put_page
#define xpcxd_page_pool_put_full_page page_pool_put_full_page
#endif

#endif /* XPCXD_H_ */
