// SPDX-License-Identifier: GPL-2.0

/*
 * XPCI driver debug definitions
 *
 * Copyright (c) 2019-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_PCXD_DBG_H_
#define XPCI_PCXD_DBG_H_

#include "xpci_dbg.h"

extern int xpci_debug_level;
extern int xpcxd_msglvl_level;

#define __XPCI_DEV_PRINTS__
#ifdef __XPCI_DEV_PRINTS__

#define __FL__ "F:[%-24s] L:[%-4d]"

// - NETIF_MSG_DRV
// - NETIF_MSG_PROBE
// - NETIF_MSG_LINK
// - NETIF_MSG_TIMER
// - NETIF_MSG_IFDOWN
// - NETIF_MSG_IFUP
// - NETIF_MSG_RX_ERR
// - NETIF_MSG_TX_ERR
// - NETIF_MSG_TX_QUEUED
// - NETIF_MSG_INTR
// - NETIF_MSG_TX_DONE
// - NETIF_MSG_RX_STATUS
// - NETIF_MSG_PKTDATA
// - NETIF_MSG_HW
// - NETIF_MSG_WOL

#define XPCXD_NETIF_MSG_DEFAULT (NETIF_MSG_DRV | \
 NETIF_MSG_IFUP | \
 NETIF_MSG_IFDOWN | \
 NETIF_MSG_RX_ERR | \
 NETIF_MSG_TX_ERR | \
 NETIF_MSG_TIMER)
#define XPCXD_NETIF_MSG_ALL 0xFFFFFFFF

#define xpcxd_set_msglvl_all() xpcxd_msglvl_level = XPCXD_NETIF_MSG_ALL;

/* error conditions */
#define xpcxd_err(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__ERR) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_err("ERR:XPCIDEV | "__FL__" | " fmt "\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_err_netdev(msglvl, netdev,fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__ERR) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_ERR, \
					netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#ifdef __XPCXD_DEBUG_NOTICE_LVL__
/* normal but significant condition */
#define xpcxd_notice(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_notice(	\
				"XPCIDEV | "__FL__" | " fmt	\
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_NOTICE, netdev, \
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}
#else
#define xpcxd_notice(msglvl, fmt, ...)
#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)
#endif /* __XPCXD_DEBUG_NOTICE_LVL__ */

#ifdef __XPCXD_DEBUG_INFO_LVL__
/* informational */
#define xpcxd_info(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__INFO) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_info(	\
				"XPCIDEV | "__FL__" | " fmt	\
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_info_netdev(msglvl, dev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__INFO) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_INFO, netdev, \
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}
#else
#define xpcxd_info(msglvl, fmt, ...)
#define xpcxd_info_netdev(msglvl, dev, fmt, ...)
#endif /* __XPCXD_DEBUG_INFO_LVL__ */

#ifdef __XPCXD_DEBUG_DBG_LVL__
/* debug-level messages */
#define xpcxd_dbg(msglvl, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__DBG) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			pr_info("XPCIDEV | "__FL__" | " fmt	\
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)	\
	{	\
		if (unlikely((xpci_debug_level >= XPCI_DBG_LEVEL__DBG) && \
		    (msglvl & xpcxd_msglvl_level))) {	\
			netdev_printk(KERN_DEBUG, netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}
#else 
#define xpcxd_dbg(msglvl, fmt, ...)
#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)
#endif /* __XPCXD_DEBUG_DBG_LVL__ */

#define xpcxd_msg(str) pr_info("---:XPCIDEV | "__FL__" | %s\n", str);
#else
#define xpcxd_err(msglvl, fmt, args...)
#define xpcxd_err_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_notice(msglvl, fmt, args...)
#define xpcxd_notice_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_info(msglvl, fmt, args...)
#define xpcxd_info_netdev(msglvl, netdev, fmt, ...)
#define xpcxd_dbg(msglvl, fmt, args...)
#define xpcxd_dbg_netdev(msglvl, netdev, fmt, ...)
#endif

#endif /* XPCI_DBG_H_ */
