// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver HW registers R/W support
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/rtnetlink.h>
#include <net/rtnetlink.h>
#include <linux/netlink.h>

#include "xpci_dbg.h"
#include "xpci_common.h"
#include "xpcxd.h"
#include "xreg.h"

/********************************************************************************************/

enum _int {
	XDRV_STATUS_SUCCESS = 0,
	XDRV_STATUS_ERR_IND_BSY = 1,
	XDRV_STATUS_ERR_IND_ERR = 2,
	XDRV_STATUS_ERR_BAD_PARAMETER = 3,
};

typedef u32 xdrv_status_t;
typedef u32 xdrv_sram_id_t;

typedef struct _xdrv_dpu_coordinates {
	u8 dpu_y : 3;
	u8 rsv_y : 1;
	u8 dpu_x : 3;
	u8 rsv_x : 1;
} xdrv_dpu_coordinates_t;

typedef union _xdrv_dpu_id_t {
	u8 id_value;
	xdrv_dpu_coordinates_t id_xy;
} xdrv_dpu_id_t;

typedef struct {
	const u8 *mem_value;
	const u16 mem_size;
} mem_value_t;

typedef union {
	u64 reg_val;
	mem_value_t mem_val;
} record_value_t;

/********************************************************************************************/

#define XDRV_IND_CTRL_RD 0
#define XDRV_IND_CTRL_WR 1
#define XDRV_IND_CTRL_INV 1
#define XDRV_IND_ACCESS_TIMEOUT 100
#define XDRV_PFE_IMEM_ROW_SIZE                                                 \
	XDRV_ROUND_TO_BYTE_SIZE(XREG_PFE_MEMCFG_IMEM0_SRAM_SIZE)
#define XDRV_PFE_SP_ROW_SIZE                                                   \
	XDRV_ROUND_TO_BYTE_SIZE(XREG_PFE_MEMCFG_SP_SRAM_SIZE)

static char *pcxd_mem_sel_name[] = {XREG_PCXD_MEMCFG_MSEL_NAMES_ARRAY};

/***************************/
/* Routines                */
/***************************/

/***********************************************************************/
/* Generic read/write functions to SRAMs via indirect access mechanism */
/***********************************************************************/

static void xpci_swap_data(unsigned char *data, const unsigned size)
{
	unsigned char temp;
	int i = 0;

	for (i = 0; i < size / 2; i++) {
		temp = data[i];
		data[i] = data[size - i - 1];
		data[size - i - 1] = temp;
	}
}

static int xdrv_read_register_data_helper(xdrv_reg_address_t register_address,
					  uint64_t *data, bool htobe_enable)
{
	record_value_t value = { 0 };

	*data = xpci_read64(NULL, register_address, true);
	value.reg_val = *data;

	// Data is always received in LE - convert to BE if enabled
	if (htobe_enable) {
		xpci_betoh_data((uint8_t *)data, sizeof(uint64_t));
	}

	return 0;
}

static int xdrv_read_register_data(xdrv_reg_address_t register_address,
				   uint64_t *data)
{
	// Data is received in LE - convert to BE
	return (xdrv_read_register_data_helper(register_address, data, true));
}

static int xdrv_write_register_data_helper(xdrv_reg_address_t register_address,
					   uint64_t data, bool betoh_enable)
{
	record_value_t value = { 0 };

	// xprint_hex_dump(NULL, "--Before--", DUMP_PREFIX_OFFSET, 16, 1, &data, sizeof(uint64_t), true);
	if (betoh_enable) {
		xpci_betoh_data((uint8_t *)&data, sizeof(uint64_t));
	}
	// xprint_hex_dump(NULL, "--After---", DUMP_PREFIX_OFFSET, 16, 1, &data, sizeof(uint64_t), true);
	value.reg_val = data;

	xpci_write64(NULL, register_address, data);

	return 0;
}

static int xdrv_write_register_data(xdrv_reg_address_t register_address,
				    uint64_t data)
{
	bool endian_convert = true;

	// Data is BE - convert to LE
	return (xdrv_write_register_data_helper(register_address, data, endian_convert));
}

static bool xdrv_mem_ind_is_busy(const xreg_pcxd_intg_ind_status_t status)
{
	return (XREG_PCXD_INTG_IND_STATUS_BSY_GET(status));
}

static bool xdrv_mem_ind_is_error(const xreg_pcxd_intg_ind_status_t status)
{
	return (XREG_PCXD_INTG_IND_STATUS_ERR_GET(status));
}

static int xdrv_mem_ind_wait_for_ready(u32 inst,
				       xreg_pcxd_intg_ind_status_t status)
{
	int count = 0;
	u64 st = 0;
	int ret = 0;

	for (count = 0; count < XDRV_IND_ACCESS_TIMEOUT; count++) {
		st = xpci_read64(
			"XREG_PCXD_INTG_IND_STATUS_ADDR",
			XREG_PCXD_INTG_IND_STATUS_ADDR_INST(inst),
			false);
		status.v = st;
		if (!status.v && !xdrv_mem_ind_is_busy(status)) {
			return XDRV_STATUS_SUCCESS;
		}
	}

	return !ret ? XDRV_STATUS_ERR_IND_BSY : ret;
}

static int xdrv_mem_ind_check_status(xdrv_reg_address_t block_addr, u32 inst,
				     bool check_error)
{
	xreg_pcxd_intg_ind_status_t status = { 0 };
	int ret = 0;

	XREG_PCXD_INTG_IND_STATUS_CLR(status);
	ret = xdrv_mem_ind_wait_for_ready(inst, status);
	switch (ret) {
	case XDRV_STATUS_SUCCESS:
		if (check_error) {
			if (xdrv_mem_ind_is_error(status)) {
				xpci_err("Indirect access ERROR - block_addr, inst: %016llx, %u",
			 		(u64)block_addr, inst);
				ret = XDRV_STATUS_ERR_IND_ERR;
				goto error;
			}
		}
		break;
	case XDRV_STATUS_ERR_IND_BSY:
		xpci_err("Indirect access BUSY - block_addr, inst: %016llx, %u",
			 (u64)block_addr, inst);
		break;
	default:
		xpci_err("ERROR reading status - block_addr, inst: %016llx, %u",
			 (u64)block_addr, inst);
	}

error:
	return ret;
}

static int xdrv_mem_ind_write_helper(u32 inst, xdrv_sram_id_t msel, u32 row,
				     u32 size, const u8 *data)
{
	xreg_pcxd_intg_ind_ctrl_t ctrl;
	xreg_pcxd_intg_ind_row_num_t row_num;
	int regs_number = (size + XREG_REG_SIZE - 1) / XREG_REG_SIZE;
	int bytes = size % XREG_REG_SIZE;
	u64 reg_buff = 0;
	u8 *data_ptr;
	int data_offs, reg_offs;
	int ret = 0;

	data_ptr = (u8 *)data;
	reg_offs = XREG_PCXD_INTG_IND_DATA_NUM_OF_COPIES - regs_number;

	// write trailing bytes first
	if (bytes) {
		xpci_dbg("write trailing bytes first");
		memcpy((char *)(&reg_buff) + (XREG_REG_SIZE - bytes), data_ptr,
		       bytes);
		ret = xdrv_write_register_data(
			XREG_PCXD_INTG_IND_DATA_ADDR_INST_OFFSET(inst,
								 reg_offs),
			reg_buff);
		if (ret) {
			xpci_err("xdrv_write_register_data() failed: %d", ret);
			return -1;
		}
		regs_number--;
		data_ptr += bytes;
		reg_offs += 1;
	}

	// write full data registers
	// Note: Data is right-justified to IND_DATA[last-reg]
	// Note: Data  must be copied to 8B-aligned buffer
	// xpci_dbg("write full data registers");
	for (data_offs = 0; (data_offs < regs_number) && (!ret);
	     data_offs++, reg_offs++) {
		memcpy(&reg_buff, data_ptr, XREG_REG_SIZE);
		ret = xdrv_write_register_data(
			XREG_PCXD_INTG_IND_DATA_ADDR_INST_OFFSET(inst,
								 reg_offs),
			reg_buff);
		if (ret) {
			xpci_err("xdrv_write_register_data() failed: %d", ret);
			return -1;
		}
		data_ptr += XREG_REG_SIZE;
	}

	// write row number
	// xpci_dbg("write row number");
	XREG_PCXD_INTG_IND_ROW_NUM_INIT_RESET_VAL(row_num);
	XREG_PCXD_INTG_IND_ROW_NUM_SET(row_num, row);
	xpci_write64("XREG_PCXD_INTG_IND_ROW_NUM_ADDR_INST",
		XREG_PCXD_INTG_IND_ROW_NUM_ADDR_INST(inst),
		XREG_PCXD_INTG_IND_ROW_NUM_GET(row_num));

	// set up control register and invoke command
	// xpci_dbg("set up control register and invoke command");
	XREG_PCXD_INTG_IND_CTRL_INIT_RESET_VAL(ctrl);
	XREG_PCXD_INTG_IND_CTRL_MSEL_SET(ctrl, msel);
	XREG_PCXD_INTG_IND_CTRL_WR_SET(ctrl, XDRV_IND_CTRL_WR);
	XREG_PCXD_INTG_IND_CTRL_INV_SET(ctrl, XDRV_IND_CTRL_INV);
	xpci_write64("XREG_PCXD_INTG_IND_CTRL_ADDR_INST",
		XREG_PCXD_INTG_IND_CTRL_ADDR_INST(inst),
		XREG_PCXD_INTG_IND_CTRL_GET(ctrl));

	return 0;
}

int xdrv_mem_ind_write(char *reg_name, xdrv_sram_id_t msel, u32 row, u32 size,
		       const u8 *data)
{
	int ret = 0;
	u32 inst = 0;
	xdrv_reg_address_t block_addr;

	if (!data) {
		xpci_err("Data is NULL");
		return -1;
	}

	// xprint_hex_dump(NULL, "--Before--", DUMP_PREFIX_OFFSET, 16, 1, data, size, true);

	xpci_htobe_data((uint8_t *)data, size);

	// xprint_hex_dump(NULL, "--After---", DUMP_PREFIX_OFFSET, 16, 1, data, size, true);

	block_addr =
		XREG_PCXD_MEMCFG_BLOCK_ADDR; /* TODO: To check if this is correct */

	xpci_dbg("IND WRITE: [%s] block_addr: 0x%x msel: [%s:%d] row: %d size: %d data ptr: [%p]",
		reg_name?reg_name:"", block_addr, pcxd_mem_sel_name[msel], (u32) msel, row, size, data);

	// check for readiness
	ret = xdrv_mem_ind_check_status(block_addr, inst, false);
	if (ret) {
		xpci_err("xdrv_mem_ind_check_status() failed: %d", ret);
		return -1;
	}

	// Write the data
	ret = xdrv_mem_ind_write_helper(inst, msel, row, size, data);
	if (ret) {
		xpci_err("xdrv_mem_ind_write_helper() failed: %d", ret);
		return -1;
	}

	// check for errors
	ret = xdrv_mem_ind_check_status(block_addr, inst, true);
	if (ret) {
		xpci_err("xdrv_mem_ind_check_status() failed: %d", ret);
		return -1;
	}

	return 0;
}

int xdrv_mem_ind_read(char *reg_name, xdrv_sram_id_t msel, u32 row, u32 size,
		      u8 *data)
{
	xreg_pcxd_intg_ind_ctrl_t ctrl;
	xreg_pcxd_intg_ind_row_num_t row_num = {0};
	int regs_number = (size + XREG_REG_SIZE - 1) / XREG_REG_SIZE;
	int bytes = size % XREG_REG_SIZE;
	u64 reg_buff = 0;
	u32 inst = 0;
	u8 *data_ptr;
	int data_offs, reg_offs;
	xdrv_reg_address_t block_addr;
	int ret = 0;

	if (!data) {
		xpci_err("Data is NULL");
		return -1;
	}

	block_addr =
		XREG_PCXD_MEMCFG_BLOCK_ADDR; /* TODO: To check if this is correct */

	xpci_dbg("IND READ: [%s] block_addr: 0x%x msel: [%s:%d] row: %d size: %d data ptr: [%p]",
		reg_name?reg_name:"", block_addr, pcxd_mem_sel_name[msel], (u32) msel, row, size, data);

	// check for readiness
	ret = xdrv_mem_ind_check_status(block_addr, inst, false);
	if (ret) {
		xpci_err("xdrv_mem_ind_check_status() failed: %d", ret);
		return -1;
	}

	// write row number
	XREG_PCXD_INTG_IND_ROW_NUM_INIT_RESET_VAL(row_num);
	XREG_PCXD_INTG_IND_ROW_NUM_SET(row_num, row);
	xpci_write64("XREG_PCXD_INTG_IND_ROW_NUM_ADDR_INST",
		XREG_PCXD_INTG_IND_ROW_NUM_ADDR_INST(inst),
		XREG_PCXD_INTG_IND_ROW_NUM_GET(row_num));

	// set up control register and invoke command
	XREG_PCXD_INTG_IND_CTRL_INIT_RESET_VAL(ctrl);
	XREG_PCXD_INTG_IND_CTRL_MSEL_SET(ctrl, msel);
	XREG_PCXD_INTG_IND_CTRL_WR_SET(ctrl, XDRV_IND_CTRL_RD);
	XREG_PCXD_INTG_IND_CTRL_INV_SET(ctrl, XDRV_IND_CTRL_INV);
	xpci_write64("XREG_PCXD_INTG_IND_CTRL_ADDR_INST",
		XREG_PCXD_INTG_IND_CTRL_ADDR_INST(inst),
		XREG_PCXD_INTG_IND_ROW_NUM_GET(ctrl));

	// check for errors
	ret = xdrv_mem_ind_check_status(block_addr, inst, true);
	if (ret) {
		xpci_err("xdrv_mem_ind_check_status() failed: %d", ret);
		return -1;
	}

	data_ptr = data;
	reg_offs = XREG_PCXD_INTG_IND_DATA_NUM_OF_COPIES - regs_number;
	if (bytes) {
		ret = xdrv_read_register_data(
			XREG_PCXD_INTG_IND_DATA_ADDR_INST_OFFSET(
				inst, reg_offs),
			&reg_buff);
		if (ret) {
			xpci_err("xdrv_read_register_data() failed: %d", ret);
			return -1;
		}
		memcpy(data_ptr, (char *)(&reg_buff) + (XREG_REG_SIZE - bytes),
		       bytes);
		regs_number--;
		data_ptr += bytes;
		reg_offs += 1;
	}

	// Read full data registers
	// Note: data is right-justified to IND_DATA[last-reg]
	// Note: Data  must be copied to 8B-aligned buffer
	for (data_offs = 0; (data_offs < regs_number) && (!ret);
	     data_offs++, reg_offs++) {
		ret = xdrv_read_register_data(
			XREG_PCXD_INTG_IND_DATA_ADDR_INST_OFFSET(inst,
								 reg_offs),
			&reg_buff);
		if (ret) {
			xpci_err("xdrv_read_register_data() failed: %d", ret);
			return -1;
		}
		memcpy(data_ptr, &reg_buff, XREG_REG_SIZE);
		data_ptr += XREG_REG_SIZE;
	}

	// xprint_hex_dump(NULL, "--Before--", DUMP_PREFIX_OFFSET, 16, 1, data, size, true);

	xpci_htobe_data((uint8_t *)data, size);

	// xprint_hex_dump(NULL, "--After---", DUMP_PREFIX_OFFSET, 16, 1, data, size, true);

	return 0;
}

void xpci_htobe_data(unsigned char *data, u32 size)
{
#if __BYTE_ORDER == __LITTLE_ENDIAN
	// xpci_dbg("H ---> TO ---> BE");
	xpci_swap_data(data, size);
#endif
}

void xpci_betoh_data(unsigned char *data, u32 size)
{
#if __BYTE_ORDER == __LITTLE_ENDIAN
	// xpci_dbg("BE ---> TO ---> H");
	xpci_swap_data(data, size);
#endif
}

u32 xpcxd_get_version(uint64_t *version, uint64_t *block_id, uint64_t *block_release)
{
	xreg_pcxd_version_t xreg_version = { 0 };
	struct xreg reg = {.addr = XREG_PCXD_VERSION_ADDR};

	reg.value = xpci_read64("XREG_PCXD_VERSION_ADDR", reg.addr, true);

	XREG_PCXD_VERSION_SET(xreg_version, reg.value);

	*version = XREG_PCXD_VERSION_VERSION_GET(xreg_version);
	*block_id = XREG_PCXD_VERSION_VERSION_GET(xreg_version);
	*block_release = XREG_PCXD_VERSION_VERSION_GET(xreg_version);

	return 0;
}
