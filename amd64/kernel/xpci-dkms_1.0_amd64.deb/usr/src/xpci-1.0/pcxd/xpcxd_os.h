// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver OS abstraction layer
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#ifndef XPCXD_OS_H_
#define XPCXD_OS_H_

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>

static inline dma_addr_t xpcxd_dma_map_single(struct device *dev, void *cpu_addr, size_t size,
               enum dma_data_direction direction) {
    return dma_map_single(dev, cpu_addr, size, direction);
}

static inline void xpcxd_dma_unmap_single(struct device *dev, dma_addr_t dma_addr, size_t size,
                 enum dma_data_direction direction)
{
    dma_unmap_single(dev, dma_addr, size, direction);
}

static inline void
xpcxd_dma_sync_single_for_cpu(struct device *dev, dma_addr_t addr,
				    size_t size,
				    enum dma_data_direction dir)
{
	dma_sync_single_for_cpu(dev, addr,size, dir);
}

static inline void
xpcxd_dma_sync_single_range_for_cpu(struct device *dev, dma_addr_t addr,
				    unsigned long offset, size_t size,
				    enum dma_data_direction dir)
{
	dma_sync_single_range_for_cpu(dev, addr, offset, size, dir);
}

static inline struct sk_buff * xpcxd_netdev_alloc_skb(struct net_device * dev, unsigned int length) {
  return netdev_alloc_skb(dev, length);
}

static inline struct sk_buff * xpcxd_napi_alloc_skb(struct napi_struct *napi, unsigned int length) {
  return napi_alloc_skb(napi, length);
}

static inline void xpcxd_dma_wmb(void) {
  dma_wmb();
}

static inline void xpcxd_dma_rmb(void) {
  dma_rmb();
}

#endif /* XPCXD_OS_H_ */
