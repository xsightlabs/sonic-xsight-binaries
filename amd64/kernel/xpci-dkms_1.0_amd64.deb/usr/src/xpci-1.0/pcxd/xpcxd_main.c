// SPDX-License-Identifier: GPL-2.0

/*
 * Packet over PCI driver init and configuration 
 *
 * Copyright (c) 2022-present Xsight Labs Inc.
 *
 */

#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include <linux/version.h>
#include <linux/delay.h>
#include <linux/if_ether.h>
#include <linux/netdevice.h>
#include <linux/etherdevice.h>
#include <linux/version.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include <linux/jiffies.h>
#include <linux/if_vlan.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
#include <linux/panic_notifier.h>
#endif
#include <net/ip.h>
#include <net/addrconf.h>
#include <net/net_namespace.h>
#include <net/dsa.h>
#include <net/genetlink.h>
#include <net/page_pool.h>
#include <net/busy_poll.h>

#include "xpcxd_dbg.h"
#include "xpci_common.h"
#include "xpci_main.h"
#include "xpci_irq.h"
#include "xnetdev_common.h"
#include "xreg.h"
#include "xpcxd.h"
#include "xpcxd_os.h"

/* Including xpci_trace.h with CREATE_TRACE_POINTS defined will generate the
 * xpci and xpcxd tracepoint functions. This must be done exactly once across the
 * xpci driver.
 */
#define CREATE_TRACE_POINTS
#include "xpci_trace.h"
#undef CREATE_TRACE_POINTS

#define XPCXD_ATTACH_DEV_NAME_LEN 64

#ifndef __XPCXD_NAPI_ALLOC_SKB__
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
#define __XPCXD_NAPI_ALLOC_SKB__ /* Use legacy Rx for old kernels */
#endif
#endif /* __XPCXD_NAPI_ALLOC_SKB__ */

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
	#define netif_tx_napi_add netif_napi_add_tx_weight
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
extern struct atomic_notifier_head panic_notifier_list;
#endif

int xpcxd_msglvl_level = XPCXD_NETIF_MSG_DEFAULT;

/********************************/
/* sysctl changeable parameters */
/********************************/

static int xpcxd_tx_coales_size_cmd = 1;
module_param_named(pcxd_tx_coales_size, xpcxd_tx_coales_size_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_tx_coales_size,
		 "Tx coalescing batch size: 0 - Disable, Default = 1");

static int xpcxd_tx_coales_time_cmd = 2000000;
module_param_named(pcxd_tx_coales_time, xpcxd_tx_coales_time_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_tx_coales_time,
		 "Tx coalescing time: 0 - Disable, Default = 2000000 (1 == 256 cycles)");

static int xpcxd_rx_coales_size_cmd = 1;
module_param_named(pcxd_rx_coales_size, xpcxd_rx_coales_size_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_rx_coales_size,
		 "Rx coalescing batch size: 0 - Disable, Default = 1");

static int xpcxd_rx_coales_time_cmd = 2000000;
module_param_named(pcxd_rx_coales_time, xpcxd_rx_coales_time_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_rx_coales_time,
		 "Rx coalescing time: 0 - Disable, Default = 2000000 (1 == 256 cycles)");

int xpcxd_tx_drop_all_cmd = 0;
module_param_named(pcxd_tx_drop_all, xpcxd_tx_drop_all_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_tx_drop_all,
		 "Drop all Tx packets before send: 1 - Enable, Default = 0");

int xpcxd_rx_drop_all_cmd = 0;
module_param_named(pcxd_rx_drop_all, xpcxd_rx_drop_all_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_rx_drop_all,
		 "Drop all Rx packets (loopback tests): 1 - Enable, Default = 0");

static int xpcxd_tx_checksum_bypass_cmd = 0;
module_param_named(pcxd_tx_checksum_bypass, xpcxd_tx_checksum_bypass_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_tx_checksum_bypass,
		 "Check Tx checksum (Tx HW offloading bypass): 2 - Global, 1 - Selective, 0 - No bypass, Default = 0");

static int xpcxd_rx_checksum_bypass_cmd = 0;
module_param_named(pcxd_rx_checksum_bypass, xpcxd_rx_checksum_bypass_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_rx_checksum_bypass,
		 "Check Rx checksum (Rx HW offloading bypass): 2 - Global, 1 - Selective, 0 - No bypass, Default = 0");

static int xpcxd_check_l3_checksum_cmd = 1;
module_param_named(pcxd_check_l3_checksum, xpcxd_check_l3_checksum_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_check_l3_checksum,
		 "Check L3 checksum (L3 HW offloading): 1 - Enable, Default = 1");

static int xpcxd_check_l4_checksum_cmd = 1;
module_param_named(pcxd_check_l4_checksum, xpcxd_check_l4_checksum_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_check_l4_checksum,
		 "Check L4 checksum (L4 HW offloading): 1 - Enable, Default = 1");

static int xpcxd_rx_shaper_cmd = 1;
module_param_named(pcxd_rx_shaper, xpcxd_rx_shaper_cmd,
		   uint, 0644);
MODULE_PARM_DESC(pcxd_rx_shaper,
		 "Rx Shaper: 1 - Enable, Default = 1");

int xpcxd_tx_db_skip_cmd = 1;
module_param_named(pcxd_tx_db_skip, xpcxd_tx_db_skip_cmd,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_db_skip_cmd,
         "Skip value for Tx doorbell, Default = 1");

/*****************************/
/* Init time only parameters */
/*****************************/

int xpcxd_loopback = 0;
module_param_named(pcxd_loopback, xpcxd_loopback, uint, 0644);
MODULE_PARM_DESC(pcxd_loopback, "0 = disabled, 1 = enabled, Default = 0");

int xpcxd_tx_enabled = 1; /* Set by ethtool */
module_param_named(pcxd_tx_enabled, xpcxd_tx_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_enabled, "0 = disabled, 1 = enabled, Default = 1");

int xpcxd_rx_enabled = 1; /* Set by ethtool */
module_param_named(pcxd_rx_enabled, xpcxd_rx_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_enabled, "0 = disabled, 1 = enabled, Default = 1");

static int xpcxd_int_mode = 0;
module_param_named(pcxd_int_mode, xpcxd_int_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_int_mode,
		 "0 = Interrupt, 1 = Hybrid, 2 - Polling, Default = 0");

int xpcxd_rss_enabled = 1;
module_param_named(pcxd_rss_enabled, xpcxd_rss_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_rss_enabled, "1 - Enabled, Default = 0 - Disabled");

static int xpcxd_rss_mode = 3;
module_param_named(pcxd_rss_mode, xpcxd_rss_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_rss_mode, "RSS Mode: 0 - Explict, 1 - Hash Index, 2 - Group ID, 3 - Full, Default = 0");

int xpcxd_pfc_enabled = 0;
module_param_named(pcxd_pfc_enabled, xpcxd_pfc_enabled, uint, 0644);
MODULE_PARM_DESC(pcxd_pfc_enabled, "Rx PFC: 1 - Enabled, Default = 0 - Disabled");

int xpcxd_tx_sbm_rfl_mode = 1;
module_param_named(pcxd_tx_sbm_rfl_mode, xpcxd_tx_sbm_rfl_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_sbm_rfl_mode,
		 "Tx submission reflection mode: 1 - Set, Default = 1");

static int xpcxd_rx_sbm_rfl_mode = 0;
module_param_named(pcxd_rx_sbm_rfl_mode, xpcxd_rx_sbm_rfl_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_sbm_rfl_mode,
		 "Rx submission reflection mode: 1 - Set, Default = 1");

int xpcxd_tx_cmp_rfl_mode = 1;
module_param_named(pcxd_tx_cmp_rfl_mode, xpcxd_tx_cmp_rfl_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_cmp_rfl_mode,
		 "Tx completion reflection mode: 1 - Set, Default = 1");

static int xpcxd_rx_cmp_rfl_mode = 1;
module_param_named(pcxd_rx_cmp_rfl_mode, xpcxd_tx_cmp_rfl_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_cmp_rfl_mode,
		 "Rx completion reflection mode: 1 - Set, Default = 1");

static int xpcxd_tx_coales_mode = 1;
module_param_named(pcxd_tx_coales_mode, xpcxd_tx_coales_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_coales_mode,
		 "Tx coalescing mode and timer: 1 - Set, Default = 1");

static int xpcxd_rx_coales_mode = 1;
module_param_named(pcxd_rx_coales_mode, xpcxd_rx_coales_mode, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_coales_mode,
		 "Rx coalescing mode and time: 1 - Set, Default = 1");

static int xpcxd_tx_budget = 256;
module_param_named(pcxd_tx_budget, xpcxd_tx_budget, uint, 0644);
MODULE_PARM_DESC(pcxd_tx_budget,
		 "Tx NAPI budget: Default = 256");

static int xpcxd_rx_budget = 128;
module_param_named(pcxd_rx_budget, xpcxd_rx_budget, uint, 0644);
MODULE_PARM_DESC(pcxd_rx_budget,
		 "Tx NAPI budget: Default = 128");

static int xpcxd_intr_jitter_max = 0;
module_param_named(pcxd_intr_jitter_max, xpcxd_intr_jitter_max,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_intr_jitter_max,
		 "Max interrupt jitter before stop (in mksec): Default = 0 (disabled))");

static int xpcxd_timer_isr_mode = 0;
module_param_named(pcxd_timer_isr_mode, xpcxd_timer_isr_mode,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_timer_isr_mode,
		 "Use periodic timer interrupt for stats dump: Default = 0 (disabled), 1 - Enabled)");

static int xpcxd_timer_isr_wakeup_time = 1000;
module_param_named(pcxd_timer_isr_wakeup_time, xpcxd_timer_isr_wakeup_time,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_timer_isr_wakeup_time,
		 "Timer interrupt wakeup time: Default = 1000 (ms)");

static int xpcxd_tx_coales_isr_mode = 0;
module_param_named(pcxd_tx_coales_isr_mode, xpcxd_tx_coales_isr_mode,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_coales_isr_mode,
		 "Tx coalescing timer interrupt: Default = 0 (disabled), 1 - Enabled)");

static int xpcxd_tx_coales_isr_wakeup_time = 1000;
module_param_named(pcxd_tx_coales_isr_wakeup_time, xpcxd_tx_coales_isr_wakeup_time,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_coales_isr_wakeup_time,
		 "Tx coalescing timer wakeup time: Default = 1000 (ms)");

int xpcxd_ring_threshold = 20;
module_param_named(pcxd_ring_threshold, xpcxd_ring_threshold,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_ring_threshold,
		 "Ring threshold in % (ring space left): Default = 20");

int xpcxd_pci_relaxed_ordering = 1;
module_param_named(pci_relaxed_ordering, xpcxd_pci_relaxed_ordering,
		   uint, 0644);
MODULE_PARM_DESC(xpcxd_pci_relaxed_ordering,
		 "PCXB PCI Relaxed ordering: Default = 1");

int xpcxd_l3_loopback_offset = ETH_HLEN;
module_param_named(pcxd_l3_loopback_offset, xpcxd_l3_loopback_offset,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_l3_loopback_offset,
         "Default offset value for L3 offset in loopback mode: Default = 14");

int xpcxd_num_of_rings = 1;
module_param_named(num_of_rings, xpcxd_num_of_rings,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_num_of_rings,
         "Number of rings (Standalone mode): Default = 1");

int xpcxd_tx_ring_size = 512;
module_param_named(tx_ring_size, xpcxd_tx_ring_size,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_ring_size,
         "Transmit ring size: Default = 512");

int xpcxd_rx_ring_size = 512;
module_param_named(rx_ring_size, xpcxd_rx_ring_size,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_rx_ring_size,
         "Receive ring size: Default = 512");

int xpcxd_mode_standalone = 0;
module_param_named(mode_standalone, xpcxd_mode_standalone,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_mode_standalone,
         "Standalone mode - PCXD NetDev and HW init without RTNL API: Default = 0");

int xpcxd_rx_valid_mode = 0;
module_param_named(pcxd_rx_valid_mode, xpcxd_rx_valid_mode,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_rx_valid_mode,
         "Valid - 1 / Toggle - 0: Default = 0");

static int xpcxd_enable_tx_err_int_cmd = 1;
module_param_named(enable_tx_err_int, xpcxd_enable_tx_err_int_cmd,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_enable_tx_err_int_cmd,
         "Tx error interrupt handler enabled: Default = 1");

static int xpcxd_enable_rx_err_int_cmd = 1;
module_param_named(enable_rx_err_int, xpcxd_enable_rx_err_int_cmd,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_enable_rx_err_int_cmd,
         "Rx error interrupt handler enabled: Default = 1");

int xpcxd_tx_drop_on_alignment_err = 0;
module_param_named(pcxd_tx_drop_on_alignment_err, xpcxd_tx_drop_on_alignment_err,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_tx_drop_on_alignment_err,
         "Drop Tx packets on SKB/DMA alignment error: Default = 0");

int xpcxd_default_mtu = XPCXD_DEFAULT_MTU_SIZE;
module_param_named(pcxd_default_mtu, xpcxd_default_mtu,
           uint, 0644);
MODULE_PARM_DESC(xpcxd_default_mtu,
         "Default MTU: Default = 10200");

int xpcxd_rx_fill_slow_start_coeff = 16;
module_param_named(pcxd_rx_fill_slow_start_coeff, xpcxd_rx_fill_slow_start_coeff,
           uint, 0644);
MODULE_PARM_DESC(pcxd_rx_fill_slow_start_coeff,
         "Slow start cofficient after no memory event: Default = 16");

static int xpcxd_stat_dump_on_remove = 1;
module_param_named(pcxd_stat_dump_on_remove, xpcxd_stat_dump_on_remove,
           uint, 0644);
MODULE_PARM_DESC(pcxd_stat_dump_on_remove,
         "Dump Rx and Tx statistics on driver remove: Default = 1 (Yes)");

static int xpcxd_legacy_skb_alloc = 0;
module_param_named(pcxd_legacy_skb_alloc, xpcxd_legacy_skb_alloc,
           uint, 0644);
MODULE_PARM_DESC(pcxd_legacy_skb_alloc,
         "Use legacy skb allocation method: Default = 0 (No)");

#define __XPCXD_CMD_START_END_TRACE__

#ifdef __XPCXD_CMD_TRACES__
#ifdef __XPCXD_CMD_START_END_TRACE__
static bool start_rx_trace = false;
static uint rx_trace_runner = 0;
static uint rx_trace_wall = 100000;

/* Self-muted trace - record */
#define xpcxd_opt_trace(...) if (start_rx_trace) { \
	xpcxd_trace(__VA_ARGS__); \
	rx_trace_runner++; \
	if ((rx_trace_runner >= rx_trace_wall) && rx_trace_wall) \
		start_rx_trace = false; \
}
#else
static bool start_rx_trace = true;

#define xpcxd_opt_trace(...) \
	xpcxd_trace(__VA_ARGS__);
#endif
#else
#define xpcxd_opt_trace(...)
#endif

int xpcxd_tx_packets_stop = 0;
int xpcxd_rx_packets_stop = 0;
int xpcxd_stop_on_next_isr = 0;
int xpcxd_rx_ignore_l3_checksum_err = 1; /* Don't drop packet on L3 checksum error by default */
int xpcxd_rx_ignore_l4_checksum_err = 1; /* Don't drop packet on L4 checksum error by default */
int xpcxd_rx_stop_on_l3_checksum_err = 0; /* Don't stop on L3 checksum error by default */
int xpcxd_rx_stop_on_l4_checksum_err = 0; /* Don't stop on L4 checksum error by default */
int xpcxd_rx_ring_threshold_stop = 0;
int xpcxd_enable_tx_err_interrupt = 0; /* Place holder for various Tx interrupt enables */
int xpcxd_enable_rx_err_interrupt = 0; /* Place holder for various Rx interrupt enables */
int xpcxd_insert_empty_bd = 0;

static struct ctl_table_header *xpcxd_netdev_sysctl_header;

static struct net_device *xpcxd_netdev = NULL;
static struct xdev *g_pxdev = NULL;

static irqreturn_t (*xpcxd_interrupt)(int irq, void *arg);

static u32 g_error = 0;

static bool arm_timer_isr = true;

static ktime_t time_isr_ktime = 0;
ktime_t tx_coalescing_ktime = 0;

bool hw_ready = false;

uint xpcxd_cfg_tbl[xpcxd_last_cfg_item] = { 0 };

extern int xpci_debug_level;

extern void xpci_print_pkt(char *trace_point, struct net_device *netdev,
			   struct sk_buff *skb, u16 offset, enum xpci_tx_rx tx_rx);

extern u16 xpcxd_get_tx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id);

static void xpcxd_intg_spare_write(u16 cnt)
{
	xreg_pcxd_intg_spare_t intg_spare = { 0 };

	XREG_PCXD_INTG_SPARE_SPARE_SET(intg_spare, cnt);

	xpci_write64("XREG_PCXD_INTG_SPARE", XREG_PCXD_INTG_SPARE_ADDR,
		     XREG_PCXD_INTG_SPARE_GET(intg_spare));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_rss_indrct_tbl_write(u32 reg_offset, u16 ring_id[XPCXD_MAX_RING_NUM])
{
	xreg_pcxd_rx_rss_indrct_tbl_t ind_tbl = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_0_SET(ind_tbl, ring_id[0]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_1_SET(ind_tbl, ring_id[1]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_2_SET(ind_tbl, ring_id[2]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_3_SET(ind_tbl, ring_id[3]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_4_SET(ind_tbl, ring_id[4]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_5_SET(ind_tbl, ring_id[5]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_6_SET(ind_tbl, ring_id[6]);
	XREG_PCXD_RX_RSS_INDRCT_TBL_RING_ID_7_SET(ind_tbl, ring_id[7]);

	// xpci_htobe_data((uint8_t *) &ind_tbl, sizeof(u64));

	xpci_write64("XREG_PCXD_RX_RSS_INDRCT_TBL", XREG_PCXD_RX_RSS_INDRCT_TBL_ADDR_INST_OFFSET(0, reg_offset),
		     XREG_PCXD_RX_RSS_INDRCT_TBL_GET(ind_tbl));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_rss_qid_tbl_write(u32 reg_offset, struct xpcxd_rss_qid_tbl qid_tbl[XPCXD_NUM_OF_RSS_QUEUES])
{
	xreg_pcxd_rx_rss_qid_tbl_t qid_tbl_reg = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_0_SET(qid_tbl_reg, qid_tbl[0].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_0_SET(qid_tbl_reg, qid_tbl[0].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_1_SET(qid_tbl_reg, qid_tbl[1].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_1_SET(qid_tbl_reg, qid_tbl[1].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_2_SET(qid_tbl_reg, qid_tbl[2].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_2_SET(qid_tbl_reg, qid_tbl[2].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_3_SET(qid_tbl_reg, qid_tbl[3].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_3_SET(qid_tbl_reg, qid_tbl[3].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_4_SET(qid_tbl_reg, qid_tbl[4].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_4_SET(qid_tbl_reg, qid_tbl[4].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_5_SET(qid_tbl_reg, qid_tbl[5].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_5_SET(qid_tbl_reg, qid_tbl[5].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_6_SET(qid_tbl_reg, qid_tbl[6].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_6_SET(qid_tbl_reg, qid_tbl[6].group_size);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_BASE_7_SET(qid_tbl_reg, qid_tbl[7].group_base);
	XREG_PCXD_RX_RSS_QID_TBL_GROUP_SIZE_7_SET(qid_tbl_reg, qid_tbl[7].group_size);

	// xpci_htobe_data((uint8_t *) &qid_tbl_reg, sizeof(u64));

	xpci_write64("PCXD_RX_RSS_QID_TBL", XREG_PCXD_RX_RSS_QID_TBL_ADDR_INST_OFFSET(0, reg_offset),
		     XREG_PCXD_RX_RSS_QID_TBL_GET(qid_tbl_reg));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

/* MSFT Recommended secret key */
u8 rss_secret_key[XPCXD_RSS_SECRET_KEY_SIZE] = {
	0x6d, 0x5a, 0x56, 0xda, 0x25, 0x5b, 0x0e, 0xc2,
	0x41, 0x67, 0x25, 0x3d, 0x43, 0xa3, 0x8f, 0xb0,
	0xd0, 0xca, 0x2b, 0xcb, 0xae, 0x7b, 0x30, 0xb4,
	0x77, 0xcb, 0x2d, 0xa3, 0x80, 0x30, 0xf2, 0x0c,
	0x6a, 0x42, 0xb7, 0x3b, 0xbe, 0xac, 0x01, 0xfa
};

void xpcxd_rss_hash_key_write(void)
{
	xreg_pcxd_rx_rss_secret_key_t rss_key = { 0 };
	u32 i = 0;

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	for (i = 0; i < XREG_PCXD_RX_RSS_SECRET_KEY_NUM_OF_COPIES; i++) {
		XREG_PCXD_RX_RSS_SECRET_KEY_SET(rss_key, *((u64*) &rss_secret_key[i * 8]));

		xpci_htobe_data((uint8_t *) &rss_key, sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RSS SECRET Key[%d]: [0x%llx]",
			(XREG_PCXD_RX_RSS_SECRET_KEY_NUM_OF_COPIES - i - 1),
			*((u64*) &rss_key));

		xpci_write64("XREG_PCXD_RX_RSS_SECRET_KEY", XREG_PCXD_RX_RSS_SECRET_KEY_ADDR + ((XREG_PCXD_RX_RSS_SECRET_KEY_NUM_OF_COPIES - i - 1) * XREG_REG_SIZE),
				XREG_PCXD_RX_RSS_SECRET_KEY_GET(rss_key));
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_err_prs0(xreg_pcxd_rx_stts_err_prs0_t *err_prs)
{
	struct xreg reg = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	reg.value = xpci_read64("XREG_PCXD_RX_STTS_ERR_PRS0", XREG_PCXD_RX_STTS_ERR_PRS0_ADDR, true);
	*err_prs = *((xreg_pcxd_rx_stts_err_prs0_t *) &reg.value);

	xpcxd_info(NETIF_MSG_DRV, "Parser errors: L4: %d Non IP: %d IPv4 Prot Viol: %d IPv6 HDR Viol: %d",
		XREG_PCXD_RX_STTS_ERR_PRS0_PKT_L4_ONLY_CS_EN_GET(*err_prs),
		XREG_PCXD_RX_STTS_ERR_PRS0_PRS_NON_IP_PKT_GET(*err_prs),
		XREG_PCXD_RX_STTS_ERR_PRS0_PRS_IPV4_PROT_VIOL_GET(*err_prs),
		XREG_PCXD_RX_STTS_ERR_PRS0_PRS_IPV6_HDR_VIOL_GET(*err_prs));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

#ifdef __XPCXD_RSS_STATS__
// TODO: move to ethtool
static void xpcxd_rss_stat(void)
{
	u64 rss_grp_id, rss_indr_tbl, rss_qid_tbl, rss_ring_id;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	rss_grp_id = xpci_read64("XREG_PCXD_RX_STTS_RSS_GRP_ID", XREG_PCXD_RX_STTS_RSS_GRP_ID_ADDR, true);
	rss_indr_tbl = xpci_read64("XREG_PCXD_RX_STTS_RSS_INDR_TBL", XREG_PCXD_RX_STTS_RSS_INDR_TBL_ADDR, true);
	rss_qid_tbl = xpci_read64("XREG_PCXD_RX_STTS_RSS_QID_TBL", XREG_PCXD_RX_STTS_RSS_QID_TBL_ADDR, true);
	rss_ring_id = xpci_read64("XREG_PCXD_RX_STTS_RSS_RING_ID", XREG_PCXD_RX_STTS_RSS_RING_ID_ADDR, true);

	xpcxd_dbg(NETIF_MSG_DRV, "RSS counters: Group ID: %lld Indirect Tbl: %lld QID Tbl: %lld Ring ID: %lld",
		rss_grp_id, rss_indr_tbl, rss_qid_tbl, rss_ring_id);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}
#endif

#define XPCXD_RX_PFC_RP_SIZE 8

static uint8_t pcxd_rx_pfc_grp_map_tbl[XPCXD_RX_PFC_RP_SIZE] = {0, 0, 0, 0, 0, 0, 0, 0};
static uint64_t pcxd_rx_pfc_ocp_high_th_tbl[XREG_PCXD_RX_PFC_OCP_HIGH_TH_NUM_OF_COPIES] = {0, 0, 0, 0, 0, 0, 0, 0};
static uint64_t pcxd_rx_pfc_ocp_low_th_tbl[XREG_PCXD_RX_PFC_OCP_LOW_TH_NUM_OF_COPIES] = {0, 0, 0, 0, 0, 0, 0, 0};

static int xpcxd_pfc_config(void)
{
	xreg_pcxd_rx_pfc_grp_map_t pcxd_rx_pfc_grp_map = {0};
	xreg_pcxd_rx_pfc_ocp_high_th_t pcxd_rx_pfc_ocp_high_th = {0};
	xreg_pcxd_rx_pfc_ocp_low_th_t pcxd_rx_pfc_ocp_low_th = {0};
	u32 i = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	XREG_PCXD_RX_PFC_GRP_MAP_GRP_0_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[0]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_1_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[1]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_2_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[2]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_3_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[3]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_4_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[4]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_5_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[5]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_6_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[6]);
	XREG_PCXD_RX_PFC_GRP_MAP_GRP_7_SET(pcxd_rx_pfc_grp_map, pcxd_rx_pfc_grp_map_tbl[7]);

	xpci_htobe_data((uint8_t *) &pcxd_rx_pfc_grp_map, sizeof(u64));

	xpcxd_dbg(NETIF_MSG_DRV, "RX PFC GRP: [0x%llx]",
		*((u64*) &pcxd_rx_pfc_grp_map));

	xpci_write64("XREG_PCXD_RX_PFC_GRP_MAP", XREG_PCXD_RX_PFC_GRP_MAP_ADDR,
			XREG_PCXD_RX_PFC_GRP_MAP_GET(pcxd_rx_pfc_grp_map));

	for (i = 0; i < XREG_PCXD_RX_PFC_OCP_HIGH_TH_NUM_OF_COPIES; i++) {

		XREG_PCXD_RX_PFC_OCP_HIGH_TH_SET(pcxd_rx_pfc_ocp_high_th, *((u64*) &pcxd_rx_pfc_ocp_high_th_tbl[i]));

		xpci_htobe_data((uint8_t *) &pcxd_rx_pfc_ocp_high_th, sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RX_PFC_OCP_HIGH_TH[%d]: [0x%llx]",
			i,
			*((u64*) &pcxd_rx_pfc_ocp_high_th));
	}

	for (i = 0; i < XREG_PCXD_RX_PFC_OCP_LOW_TH_NUM_OF_COPIES; i++) {

		XREG_PCXD_RX_PFC_OCP_LOW_TH_SET(pcxd_rx_pfc_ocp_low_th, *((u64*) &pcxd_rx_pfc_ocp_low_th_tbl[i]));

		xpci_htobe_data((uint8_t *) &pcxd_rx_pfc_ocp_low_th, sizeof(u64));

		xpcxd_dbg(NETIF_MSG_DRV, "RX_PFC_OCP_LOW_TH[%d]: [0x%llx]",
			i,
			*((u64*) &pcxd_rx_pfc_ocp_low_th));
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

#define GRP_SIZE 8
#define BASE_RING 0

static int xpcxd_rss_config(void)
{
	u16 ring_ids[XPCXD_MAX_RING_NUM] = {0, 0, 0, 0, 0, 0, 0, 0}; /* TODO: Fix hardcoded value to configurable indirection table */
	/* Group size encoding is: 1 --> 0, 2 --> 1, 4 --> 2, 8 --> 3*/
	u8 group_size_trans_tbl[9] = {0, 0, 1, 0, 2, 0, 0, 0, 3};
	struct xpcxd_rss_qid_tbl qid_tbl[XPCXD_NUM_OF_RSS_QUEUES] = {
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]},
			{BASE_RING, group_size_trans_tbl[GRP_SIZE]} }; /* TODO: Fill from configuration */
	u32 i = 0;

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	for (i = 0; i < XREG_PCXD_RX_RSS_INDRCT_TBL_NUM_OF_COPIES; i++) {
		xpcxd_rss_indrct_tbl_write(i, ring_ids);
	};

	for (i = 0; i < XREG_PCXD_RX_RSS_QID_TBL_NUM_OF_COPIES; i++) {
		xpcxd_rss_qid_tbl_write(i, qid_tbl);
	};

	xpcxd_rss_hash_key_write();

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_tx_rx_loopback_set(u32 ring_id, bool enable)
{
	xreg_pcxd_memcfg_tx_brg_lpb_t tx_brg_lpb = { 0 };
	u32 rss_value = 0;
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_TX_TARGET_SET: %d <-- Loopback",
		 enable ? 1 : 0);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_TX_TARGET_SET(
		tx_brg_lpb,  enable ? 1 : 0); /* 0 - IFU / 1 - Loopback/Bridge */
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_RX_TARGET_SET: %d <-- Loopback",
		 enable ? 0 : 1);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_RX_TARGET_SET(
		tx_brg_lpb,
		enable ? 0 : 1); /* 0 - Loopback / 1 - Bridge (Firmware complex) */
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_RSS_MODE_SET: %d <-- 0 - Explicit, 1 - Hash index, 2 - Group ID, 3 - Full", xpcxd_rss_mode);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_RSS_MODE_SET(tx_brg_lpb,
						 xpcxd_rss_mode); /* 0 - RSS Mode - ring_id explicitly set | 1 - hash index */
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_RSS_CTRL_SET: %d <-- Default RSS ring",
		 ring_id);
	switch (xpcxd_rss_mode) {
		case XPCXD_RSS_MODE_EXPLICIT: /* Explicit mode */
			rss_value = ring_id;
			break;
		case XPCXD_RSS_MODE_HASH_INDEX: /* Hash index mode */
			rss_value = ring_id;
			break;
		case XPCXD_RSS_MODE_RSS_GROUP_ID: /* RSS group ID*/
			rss_value = 0x1; /* TODO: Fix according to spec*/
			break;
		case XPCXD_RSS_MODE_FULL: /* QID converted to RSS group ID */
			rss_value = 0;
			break;
		default:
			rss_value = 0;
	}
	XREG_PCXD_MEMCFG_TX_BRG_LPB_RSS_CTRL_SET(
		tx_brg_lpb,
		(xpcxd_rss_enabled && xpcxd_loopback) ?
			ring_id :
			rss_value); /* Default - no RSS mode : RSS Ring - always 0 */

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_DO_L3_CHKS_SET: %d",
		xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_DO_L3_CHKS_SET(tx_brg_lpb,
		xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_DO_L4_CHKS_SET: %d",
		xpcxd_cfg_tbl[xpcxd_check_l4_checksum] & enable);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_DO_L4_CHKS_SET(tx_brg_lpb,
		xpcxd_cfg_tbl[xpcxd_check_l4_checksum] & enable);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_L3_OFF_OVRD_SET: %d",
		/*xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable*/ 1);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_L3_OFF_OVRD_SET(tx_brg_lpb,
		/*xpcxd_cfg_tbl[xpcxd_check_l3_checksum] & enable*/ 1);
	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_BRG_LPB_L3_OFFSET_SET: %d",
		 xpcxd_l3_loopback_offset + 3);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_L3_OFFSET_SET(tx_brg_lpb, xpcxd_l3_loopback_offset + 3);
	XREG_PCXD_MEMCFG_TX_BRG_LPB_TRIM_HDR_SET(tx_brg_lpb, 0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_BRG_LPB",
		XREG_PCXD_MEMCFG_TX_BRG_LPB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_busy_ring_tbl_t) /* Size */,
		(void *)&tx_brg_lpb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	ret = xdrv_mem_ind_read(
		"XREG_PCXD_MEMCFG_TX_BRG_LPB",
		XREG_PCXD_MEMCFG_TX_BRG_LPB_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_busy_ring_tbl_t) /* Size */,
		(void *)&tx_brg_lpb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
		return -1;
	}

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

/*static*/ void xpcxd_set_error(struct net_device *netdev, struct sk_buff *skb,
			    enum xpci_tx_rx tx_rx, u32 stop_val, char *msg)
{
	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpci_debug_level = XPCI_DBG_LEVEL__MAX;
	xpcxd_set_msglvl_all();

	xpcxd_err(NETIF_MSG_DRV, "<<<SET RX/TX STOP>>>");

	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "%s", msg);
	} else {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "%s", msg);
	}

	if (skb)
		xpci_print_pkt(msg, netdev, skb, RX_OFFSET, tx_rx);

	xpcxd_intg_spare_write(stop_val);

	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
	g_error = 1;

	/* Do not arm timer ISR anymore and do not poll statistics */
	arm_timer_isr = false;

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static int xpcxd_tx_coales_size_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_tx_coales_size];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "pcxd_tx_coales_size changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_tx_coales_size]);

	return ret;
}

static int xpcxd_tx_coales_time_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_tx_coales_time];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "pcxd_tx_coales_time changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_tx_coales_time]);

	return ret;
}

static int xpcxd_rx_coales_size_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_rx_coales_size];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "pcxd_rx_coales_size changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_rx_coales_size]);

	return ret;
}

static int xpcxd_rx_coales_time_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_rx_coales_time];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "pcxd_rx_coales_time changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_rx_coales_time]);

	return ret;
}

static int xpcxd_check_l3_checksum_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_check_l3_checksum];
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = NULL;
	u32 ring_id = 0;

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "pcxd_check_l3_checksum changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_check_l3_checksum]);

	if (netdev) {
		net_priv = netdev_priv(netdev);

		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			ret = xpcxd_tx_rx_loopback_set(ring_id, xpcxd_loopback);
			if (unlikely(ret)) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						"open: RX/TX loopback set failed: %d",
						ret);
				return -1;
			}
		}
	}

	return ret;
}

static int xpcxd_check_l4_checksum_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_check_l4_checksum];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "xpcxd_check_l4_checksum changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_check_l4_checksum]);

	return ret;
}

static int xpcxd_tx_db_skip_proc(struct ctl_table *table, int write,
				   void *buffer, size_t *lenp, loff_t *ppos)
{
	int ret = 0;
	int __maybe_unused old_value = xpcxd_cfg_tbl[xpcxd_tx_db_skip];

	ret = proc_dointvec_minmax(table, write, buffer, lenp, ppos);

	if (write)
		xpcxd_dbg(NETIF_MSG_DRV, "xpcxd_tx_db_skip changed from: %d ---> %d", old_value, xpcxd_cfg_tbl[xpcxd_tx_db_skip]);

	return ret;
}

static struct ctl_table xpcxd_netdev_ctl_table[] = {
	{
		.procname = "pcxd_tx_coales_size",
		.data = &xpcxd_cfg_tbl[xpcxd_tx_coales_size],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_tx_coales_size_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_tx_coales_time",
		.data = &xpcxd_cfg_tbl[xpcxd_tx_coales_time],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_tx_coales_time_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_rx_coales_size",
		.data = &xpcxd_cfg_tbl[xpcxd_rx_coales_size],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_rx_coales_size_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_rx_coales_time",
		.data = &xpcxd_cfg_tbl[xpcxd_rx_coales_time],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_rx_coales_time_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{
		.procname = "pcxd_check_l3_checksum",
		.data = &xpcxd_cfg_tbl[xpcxd_check_l3_checksum],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_check_l3_checksum_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_ONE,
#endif
	},
	{
		.procname = "pcxd_check_l4_checksum",
		.data = &xpcxd_cfg_tbl[xpcxd_check_l4_checksum],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_check_l4_checksum_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_ONE,
#endif
	},
	{
		.procname = "pcxd_tx_db_skip",
		.data = &xpcxd_cfg_tbl[xpcxd_tx_db_skip],
		.maxlen = sizeof(int),
		.mode = 0644,
		.proc_handler = xpcxd_tx_db_skip_proc,
#if LINUX_VERSION_CODE > KERNEL_VERSION(5, 0, 0)
		.extra1 = SYSCTL_ZERO,
		.extra2 = SYSCTL_INT_MAX,
#endif
	},
	{}
};


#define XPCXB_RELAXED_ORDERING ((uint64_t) 2 << 32)

static int xpcxd_relaxed_ordering(void)
{
	xreg_pcxb_pcxd_client_attr_t pcxd_client_attr = { 0 };
	uint64_t reset_v = 0;

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	reset_v = xpci_read64("XREG_PCXB_PCXD_CLIENT_ATTR", XREG_PCXB_PCXD_CLIENT_ATTR_ADDR, true);

	reset_v = reset_v | XPCXB_RELAXED_ORDERING;
	xpcxd_dbg(NETIF_MSG_DRV, "PCXB_PCXD_CLIENT_ATTR_SET: [%llx]", reset_v);

	XREG_PCXB_PCXD_CLIENT_ATTR_SET(pcxd_client_attr, reset_v);

	xpci_write64("XREG_PCXB_PCXD_CLIENT_ATTR", XREG_PCXB_PCXD_CLIENT_ATTR_ADDR,
		     XREG_PCXB_PCXD_CLIENT_ATTR_GET(pcxd_client_attr));

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_lat_cfg(void)
{
	xreg_pcxb_pci_lat_cfg_t pcxd_lat_cfg = { 0 };

	XREG_PCXB_PCI_LAT_CFG_EN_SET(pcxd_lat_cfg, 1);

	xpci_write64("XREG_PCXB_PCI_LAT_CFG_ADDR", XREG_PCXB_PCI_LAT_CFG_ADDR,
		     XREG_PCXB_PCI_LAT_CFG_GET(pcxd_lat_cfg));

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_netdev_sysctl_init(void)
{
	int orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__INFO;

	xpcxd_netdev_sysctl_header = register_net_sysctl(
		&init_net, "net/xpci", xpcxd_netdev_ctl_table);
	if (xpcxd_netdev_sysctl_header == NULL) {
		xpcxd_err(NETIF_MSG_DRV, "Can register net_sysctl");
		return -ENOMEM;
	}

	xpcxd_cfg_tbl[xpcxd_tx_coales_size] = xpcxd_tx_coales_size_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_coales_time] = xpcxd_tx_coales_time_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_coales_size] = xpcxd_rx_coales_size_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_coales_time] = xpcxd_rx_coales_time_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = xpcxd_rx_drop_all_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = xpcxd_tx_drop_all_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] = xpcxd_tx_checksum_bypass_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] = xpcxd_rx_checksum_bypass_cmd;
	xpcxd_cfg_tbl[xpcxd_check_l3_checksum] = xpcxd_check_l3_checksum_cmd;
	xpcxd_cfg_tbl[xpcxd_check_l4_checksum] = xpcxd_check_l4_checksum_cmd;
	xpcxd_cfg_tbl[xpcxd_rx_shaper] = xpcxd_rx_shaper_cmd;
	xpcxd_cfg_tbl[xpcxd_tx_db_skip] = xpcxd_tx_db_skip_cmd;
	xpcxd_cfg_tbl[xpcxd_enable_tx_err_int] = xpcxd_enable_tx_err_int_cmd;
	xpcxd_cfg_tbl[xpcxd_enable_rx_err_int] = xpcxd_enable_rx_err_int_cmd;

	xpcxd_info(NETIF_MSG_DRV, "----XSIGHT PCXD NET DEV Dynamic configuration ----");
	xpcxd_info(NETIF_MSG_DRV, "Number of rings              : [%d]",
		  xpcxd_num_of_rings);
	xpcxd_info(NETIF_MSG_DRV, "Transmit ring size           : [%d]",
		  xpcxd_tx_ring_size);
	xpcxd_info(NETIF_MSG_DRV, "Receive ring size            : [%d]",
		  xpcxd_rx_ring_size);
	if (xpcxd_mode_standalone) 
			xpcxd_notice(NETIF_MSG_DRV,  "PCXD mode standalone     : [%s]", "ENABLED");
	if (xpcxd_loopback) 
			xpcxd_notice(NETIF_MSG_DRV,  "PCXD loopback            : [%s]", "ENABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx                      : [%s]",
		   xpcxd_tx_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx                      : [%s]",
		   xpcxd_rx_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Interrupt mode          : [%s:%d]",
		   !xpcxd_int_mode ? "INTERRUPT" : "HYBRID:1 or POLLING:2",
		   xpcxd_int_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD RSS                     : [%s]",
		   xpcxd_rss_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD RSS mode                : [%d]",
		   xpcxd_rss_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD RX PFC                  : [%s]",
		   xpcxd_pfc_enabled ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx sbm Reflection mode  : [%d]",
		   xpcxd_tx_sbm_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx sub Reflection mode  : [%d]",
		   xpcxd_rx_sbm_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx cmp Reflection mode  : [%d]",
		   xpcxd_tx_cmp_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx cmp Reflection mode  : [%d]",
		   xpcxd_rx_cmp_rfl_mode);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx Coalescing mode      : [%s]",
		   xpcxd_tx_coales_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing size      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_tx_coales_size]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing time      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx Coalescing mode      : [%s]",
		   xpcxd_rx_coales_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx coalescing size      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_rx_coales_size]);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx coalescing time      : [%d]",
		   xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	if (xpcxd_cfg_tbl[xpcxd_rx_drop_all])
		xpcxd_notice(NETIF_MSG_DRV, "PCXD Rx Drop All         : [%s ---> %d]", "ENABLED", xpcxd_cfg_tbl[xpcxd_rx_drop_all]);
	if (xpcxd_cfg_tbl[xpcxd_tx_drop_all])
		xpcxd_notice(NETIF_MSG_DRV, "PCXD Tx Drop All         : [%s]", "ENABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx NAPI Budget          : [%d]", xpcxd_tx_budget);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Rx NAPI Budget          : [%d]", xpcxd_rx_budget);
	xpcxd_info(NETIF_MSG_DRV, "PCXD Max delta between interrupts: [%d]",
		  xpcxd_intr_jitter_max);
	xpcxd_info(NETIF_MSG_DRV, "PCXD timer software interrupt: [%s]",
		  xpcxd_timer_isr_mode ? "ENABLED" : "DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "PCXD Tx coalescing software interrupt: [%s]",
		  xpcxd_tx_coales_isr_mode ? "ENABLED" : "DISABLED");
	if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass])
		xpcxd_notice(NETIF_MSG_DRV, "Tx Checksum bypass: [Enabled] Mode: [%s]",
			xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]==xpcxd_selective_bypass?"Selective":"Global");
	if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass])
		xpcxd_notice(NETIF_MSG_DRV, "Rx Checksum bypass: [Enabled] Mode: [%s]",
			xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]==xpcxd_selective_bypass?"Selective":"Global");
	xpcxd_info(NETIF_MSG_DRV, "L3 Checksum: [%s]",
		  xpcxd_cfg_tbl[xpcxd_check_l3_checksum] ? "ON" : "OFF");
	xpcxd_info(NETIF_MSG_DRV, "L4 Checksum: [%s]",
		  xpcxd_cfg_tbl[xpcxd_check_l4_checksum] ? "ON" : "OFF");
	xpcxd_info(NETIF_MSG_DRV, "Tx Ring space threshold in percents: [%d]",
		  xpcxd_ring_threshold);
	xpcxd_info(NETIF_MSG_DRV, "Relaxed ordering: [%s]",
		  xpcxd_pci_relaxed_ordering ? "ENABLED" : "DISABLED");
	if (xpcxd_cfg_tbl[xpcxd_rx_shaper]) {
		xpcxd_notice(NETIF_MSG_DRV, "Rx Shaper: [Enabled]");
	}
	xpcxd_info(NETIF_MSG_DRV, "Tx Doorbell Skip: [%d]",
		xpcxd_cfg_tbl[xpcxd_tx_db_skip]);
	xpcxd_info(NETIF_MSG_DRV, "Tx Error Interrupt: [%s]",
		xpcxd_cfg_tbl[xpcxd_enable_tx_err_int]?"ENABLED":"DISABLED");
	xpcxd_info(NETIF_MSG_DRV, "Rx Error Interrupt: [%s]",
		xpcxd_cfg_tbl[xpcxd_enable_rx_err_int]?"ENABLED":"DISABLED");

	xpcxd_info(NETIF_MSG_DRV, "---------------------------------------------");


	xpci_debug_level = orig_debug_level;

	return 0;
}

u32 xpcxd_get_tx_sub_ring_space(struct xpcxd_ring *ring)
{
	u32 ring_space = 0;

	if (ring->sub.prod >= ring->sub.sub_cns_ptr)
		ring_space = (ring->sub.size - ((ring->sub.prod - ring->sub.sub_cns_ptr) /*& ring->sub.mask*/));
	else
		ring_space = (ring->sub.sub_cns_ptr - ring->sub.prod) /*& ring->sub.mask*/;

	return ring_space;
}

u32 xpcxd_get_rx_sub_ring_space(struct xpcxd_ring *ring)
{
	u32 ring_space = 0;

	if (ring->sub.prod >= ring->sub.cons/*ring->sub.sub_cns_ptr*/)
		ring_space = (ring->sub.prod - ring->sub.cons/*ring->sub.sub_cns_ptr*/) /*& ring->sub.mask*/;
	else
		ring_space = (ring->sub.size - (/*ring->sub.sub_cns_ptr*/ring->sub.cons - ring->sub.prod) /*& ring->sub.mask*/);

	return ring_space;
}

u32 xpcxd_get_cmpl_ring_space(struct xpcxd_ring *ring)
{
	u32 ring_space = 0;

	if (ring->cmp.cmpl_prd_ptr >= ring->cmp.cons) {
		ring_space = (ring->cmp.size - ((ring->cmp.cmpl_prd_ptr - ring->cmp.cons) /*& ring->cmp.mask*/));
	} else {
		ring_space = (ring->cmp.cons - ring->cmp.cmpl_prd_ptr) /*& ring->cmp.mask*/;
	}

	return ring_space;
}

#ifdef __XPCXD_RX_DEBUG__
static u32 rx_db_write = 0;
#endif

static void xpcxd_rx_db_write(struct net_device *netdev, u16 ring_id,
			      u16 prod_idx)
{
    struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_rx_db_t rx_dbv = { 0 };
	uint32_t rx_sub_space = 0;
	uint32_t rx_cmpl_space = 0;
	uint32_t mode = 0; // 0 - Inceremental | 1 - Absolute
	struct xpcxd_ring *rxr = &net_priv->rxr[ring_id];

	rx_sub_space = rxr->sub.size - xpcxd_get_rx_sub_ring_space(rxr); /* Calculate free ring space */
	rx_cmpl_space = xpcxd_get_cmpl_ring_space(rxr);

	if (rx_sub_space < ((rxr->sub.size / 100) * xpcxd_ring_threshold)) {
		rxr->stats.rx_sub_threshold++;
	}

	if (rx_cmpl_space < ((rxr->cmp.size / 100) * xpcxd_ring_threshold)) {
		rxr->stats.rx_cmpl_threshold++;
	}

#ifdef __XPCXD_RX_DEBUG__
	if (rx_db_write < 10) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"RX_DB: Ring: %d Mode: %d prod_idx: %d Rx SUB space: %d CMPL space: %d SUB: p:%d c:%d CMPL: p:%d c:%d",
				ring_id, mode, prod_idx, rx_sub_space, rx_cmpl_space,
				rxr->sub.prod, rxr->sub.cons,
				rxr->cmp.cmpl_prd_ptr, rxr->cmp.cons);
		rx_db_write++;
	}
#endif

	XREG_PCXD_RX_DB_RIND_ID_SET(rx_dbv, ring_id);
	XREG_PCXD_RX_DB_MODE_SET(rx_dbv, mode);
	XREG_PCXD_RX_DB_VALUE_SET(rx_dbv, prod_idx);

	xpci_write64("XREG_PCXD_RX_DB", XREG_PCXD_RX_DB_ADDR,
		     XREG_PCXD_RX_DB_GET(rx_dbv));

	xpcxd_opt_trace(rx_db_write, ring_id, prod_idx, 0);

	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static void xpcxd_rx_dump_debug_stats(struct net_device *netdev,
				     bool short_stats)
{
	u32 orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__NOTICE;
	if (short_stats) {
		xpcxd_rx_stat_dump_short(netdev);
	} else {
		xpcxd_rx_stat_dump(netdev);
	}
	xpci_debug_level = orig_debug_level;
}

static void xpcxd_tx_dump_debug_stats(struct net_device *netdev,
				     bool short_stats)
{
	u32 orig_debug_level = xpci_debug_level;

	xpci_debug_level = XPCI_DBG_LEVEL__NOTICE;
	if (short_stats) {
		xpcxd_tx_stat_dump_short(netdev);
	} else {
		xpcxd_tx_stat_dump(netdev);
	}
	xpci_debug_level = orig_debug_level;
}

void xpcxd_skb_align(struct sk_buff *skb, int align)
{
    int off = ((unsigned long)skb->data) & (align - 1);

    if (off) {
		// xpcxd_dbg(NETIF_MSG_RX_STATUS, "skb_reserve: align - off: [%d]", align - off);
		xpcxd_opt_trace(rx_skb_align, 0, align - off, 0, 0);

        skb_reserve(skb, align - off);
	}
}

#ifdef __XPCXD_RX_SUB_RFL__
static u16 xpcxd_get_rx_sub_cns_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd = NULL;
	u16 sub_cns_ptr = 0;

	if (xpcxd_rx_cmp_rfl_mode) {
		// TODO: Check if it's absolutely needed
		// Relevant for IA-64
		xpcxd_dma_rmb();

		rfl_prd = net_priv->rxr[ring_id].cmp.rfl_prd;

		xpcxd_dbg_netdev(
			NETIF_MSG_DRV,
			netdev,
			"---> PCXD SUB RX: value: [0x%llx] ring_index_head: [0x%x] ring_index_tail: [0x%x]",
			rfl_prd->value, rfl_prd->ring_index_head,
			rfl_prd->ring_index_tail);

		sub_cns_ptr = rfl_prd->ring_index_head & net_priv->rxr[ring_id].sub.mask;
	}

	return sub_cns_ptr;
}
#endif /* __XPCXD_RX_SUB_RFL__ */

static u16 xpcxd_get_rx_cmpl_prod_ptr(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_atomic_fifo_ctrl *rfl_prd = NULL;
	xreg_pcxd_memcfg_rx_rng_stts_tbl_t rng_stts = { 0 };
	u16 cmpl_prd_ptr = 0;
	int ret;

	if (xpcxd_rx_cmp_rfl_mode) {
		// TODO: Check if it's absolutely needed
		// Relevant for IA-64
		xpcxd_dma_rmb();

		rfl_prd = net_priv->rxr[ring_id].cmp.rfl_prd;
		// xpcxd_dbg_netdev(
		// 	NETIF_MSG_DRV,
		// 	netdev,
		// 	"---> [%d] PCXD CMPL RX: value: [0x%llx] ring_index_head: [0x%x] ring_index_tail: [0x%x]",
		// 	rfl_prd->value, rfl_prd->ring_index_head,
		// 	rfl_prd->ring_index_tail);
		cmpl_prd_ptr = rfl_prd->ring_index_head & net_priv->rxr[ring_id].cmp.mask;
	} else {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_RNG_STTS_TBL",
			XREG_PCXD_MEMCFG_RX_RNG_STTS_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_rng_stts_tbl_t) /* Size */,
			(void *)&rng_stts);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return 0;
		}

		cmpl_prd_ptr = XREG_PCXD_MEMCFG_RX_RNG_STTS_TBL_CRD_PRD_PTR_GET(
			rng_stts);
		xpcxd_dbg_netdev(
			NETIF_MSG_DRV,
			netdev,
			"---> [%d] PCXD CMPL RX: RX_RNG_STTS_TBL_CRD_PRD_PTR: 0x%x | %u",
			ring_id, cmpl_prd_ptr, cmpl_prd_ptr);
	}

	return cmpl_prd_ptr;
}

/* Credits are calculated as delta between rx_fill budget and actual number of BDs that we succseeded to fill */
/* Those credits will be used on next rx_fill as an addition to the budget */
static u32 rx_credits = 0;

#ifdef __XPCXD_ALLOC_TEST__
static u32 xpcxd_alloc_error = 0;
static u32 xpcxd_alloc_error_num = 0;
static bool xpcxd_print_start = true;
static bool xpcxd_print_finish = true;

static u32 rx_max_errors = 100000;
static u32 rx_errors_freq = 1000;
#endif 

static int xpcxd_rx_fill(struct net_device *netdev, struct napi_struct *napi, u32 ring_id,
			 struct xpcxd_ring *rxr, u16 n, u16 *processed, bool db_write)
{
	struct xpcxd_sw_desc *sw_desc = NULL;
	u32 bd_len = 0;
	u16 prod_idx = 0;
	u16 i = 0;
#ifdef __XPCXD_RX_SUB_RFL__
	u16 sub_cns = 0;
#endif /* __XPCXD_RX_SUB_RFL__ */

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "IN: num: %d rxr: %p", n, rxr);

#ifdef __XPCXD_RX_SUB_RFL__
	sub_cns =
		xpcxd_get_rx_sub_cns_ptr(xpcxd_netdev, ring_id);
#endif /* __XPCXD_RX_SUB_RFL__ */

	xpcxd_opt_trace(rx_fill_start, ring_id, n, rxr->sub.prod & rxr->sub.mask /* prod_idx */);

	for (i = 0; i < n; i++) {
		prod_idx = rxr->sub.prod & rxr->sub.mask;

		sw_desc = &rxr->sub.sw[prod_idx];

		// xpcxd_opt_trace(rx_action_fill_next, ring_id, prod_idx, sw_desc->page_state);

		if (xpcxd_legacy_skb_alloc) {
			bd_len = netdev->max_mtu;
		} else {
			bd_len = XPCXD_FRAG_DATA_SIZE;
		}

		// xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
		// 		 "IN [%d]: num: %d rxr: %p prod_idx: %d sub_cns: %d sw_desc: %p", ring_id, n, rxr,
		// 		 prod_idx, sub_cns, sw_desc);

		if (unlikely(!sw_desc)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "sw_desc error");
			return -ENOMEM;
		}

#ifdef __XPCXD_ALLOC_TEST__
		xpcxd_alloc_error++;
#endif

		if ((sw_desc->page_state != XPCXD_PAGE_PASSED_TO_STACK) &&
		    (sw_desc->page_state != XPCXD_PAGE_FREE) &&
			db_write) {
			rxr->stats.rx_wrong_page_state++;
			// xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
			// 		"Wrong page state: [%d] sw_desc[%d]", sw_desc->page_state, prod_idx);
		}

		/* If page is already allocated and not consumed yet - just skip an additional alloc and stop */
		/* Such a situation can happen if SUB ring is running faster than CMPL and reaches it's tail */
		if (sw_desc->page_state == XPCXD_PAGE_ALLOCATED) {
			// start_rx_trace = true;

			xpcxd_opt_trace(rx_action_fill_tail_stop, ring_id, i, prod_idx);
			goto bd_fill;
		}

		sw_desc->page_state = XPCXD_PAGE_FREE;

		sw_desc->page = xpcxd_page_pool_dev_alloc_pages(rxr->page_pool);
		// xpcxd_opt_trace(rx_action_end, ring_id, prod_idx, 0);
		if (unlikely(!sw_desc->page)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"Page pool dev alloc error: sw_desc[%d]", prod_idx);

			rxr->stats.rx_page_alloc_err++;
			rxr->stats.errors++;

			start_rx_trace = true;

#ifdef __XPCXD_ALLOC_TEST__
			xpcxd_opt_trace(rx_action_fill_alloc_err, ring_id, prod_idx, xpcxd_alloc_error);
			xpcxd_alloc_error_num++;
			xpcxd_alloc_error = 0;
#endif
			sw_desc->page = NULL;

			rx_credits = n - i;

#ifdef __XPCXD_TRACE_PRINTK__
			trace_printk("page_pool_dev_alloc_pages() error");
#endif

			xpcxd_opt_trace(rx_action_fill_dma_err, ring_id, i, rx_credits);

			break;
		}

#ifdef __XPCXD_ALLOC_TEST__
		if (unlikely((sw_desc->page->pp_magic & ~0x3UL) != PP_SIGNATURE)) {
			xpcxd_opt_trace(rx_action_fill_signature_err, ring_id, i, rx_credits);

#ifdef __XPCXD_TRACE_PRINTK__
			trace_printk("Wrong page: pfn: [%lu]",
				page_to_pfn(sw_desc->page));
#endif

			panic("Manual panic from the XPCI module - wrong page\n");
		}
#endif

		sw_desc->page_state = XPCXD_PAGE_ALLOCATED;

#ifdef __XPCXD_ALLOC_TEST__
		if ((xpcxd_alloc_error % rx_errors_freq == 0) &&
		    (xpcxd_alloc_error_num < rx_max_errors) && 
			db_write) {
			if (xpcxd_print_start) {
				xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
						"DMA addr error: [%d] sw_desc[%d]", xpcxd_alloc_error, prod_idx);
				xpcxd_print_start = false;
			}

			rxr->stats.errors++;
			// rxr->stats.rx_page_alloc_err++;
			rxr->stats.rx_dma_get_err++;

			start_rx_trace = true;

			xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page);

			xpcxd_opt_trace(rx_action_fill_alloc_sim_err, ring_id, prod_idx, xpcxd_alloc_error);
			xpcxd_alloc_error_num++;
			xpcxd_alloc_error = 0;

			sw_desc->page = NULL;
			sw_desc->page_state = XPCXD_PAGE_FREE;

			rx_credits = n - i;

			xpcxd_opt_trace(rx_action_fill_dma_err, ring_id, i, rx_credits);

			break;
		}

		if ((xpcxd_alloc_error_num >= rx_max_errors) && (xpcxd_print_finish)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"Error injection finished");
			xpcxd_print_finish = false;
		}
#endif /* __XPCXD_ALLOC_TEST__*/

		sw_desc->addr = xpcxd_page_pool_get_dma_addr(sw_desc->page);
		if (unlikely(!sw_desc->addr)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"sw_desc->addr error: [%lld] pfn: [%lu]", sw_desc->addr, page_to_pfn(sw_desc->page));
			rxr->stats.rx_dma_get_err++;
			rxr->stats.errors++;

			start_rx_trace = true;

#ifdef __XPCXD_TRACE_PRINTK__
			trace_printk("page_pool_get_dma_addr() error. page: [%p] pfn: [%lu]", 
				sw_desc->page, page_to_pfn(sw_desc->page));
#endif

			xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page);

#ifdef __XPCXD_ALLOC_TEST__
			xpcxd_alloc_error_num++;
			xpcxd_alloc_error = 0;
#endif
			sw_desc->page = NULL;
			sw_desc->page_state = XPCXD_PAGE_FREE;

			rx_credits = n - i;

			xpcxd_opt_trace(rx_action_fill_dma_err, ring_id, i, rx_credits);

			break;
		}

		// xpcxd_opt_trace(rx_action_pool_dev_alloc_page, ring_id, i, page_to_pfn(sw_desc->page));

#ifdef CONFIG_PAGE_POOL_STATS /* Could be used from v5.18.0 */
{
		struct page_pool_stats pool_stats = {};

		page_pool_get_stats(rxr->page_pool, &pool_stats);

		xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
				"POOL ALLOC STATS: fast: [%lld] slow: [%lld] sow_high_order: [%lld] empty: [%lld] refill: [%lld] waive: [%lld]",
				pool_stats.alloc_stats.fast,
				pool_stats.alloc_stats.slow,
				pool_stats.alloc_stats.sow_high_order,
				pool_stats.alloc_stats.empty,
				pool_stats.alloc_stats.refill,
				pool_stats.alloc_stats.waive);

		xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev,
				"POOL RECYCLE STATS: fast: [%lld] cached: [%lld] cache_full: [%lld] ring: [%lld] ring_full: [%lld] released_refcnt: [%lld]",
				pool_stats.recycle_stats.cached,
				pool_stats.recycle_stats.cache_full,
				pool_stats.recycle_stats.ring,
				pool_stats.recycle_stats.ring_full,
				pool_stats.recycle_stats.released_refcnt);	
}
#endif

bd_fill:

		/* W0 */
		rxr->sub.desc[prod_idx].rx_bd.ctrl_no_cpl =
			0; /* 0 - Generate completion for this frame */
		rxr->sub.desc[prod_idx].rx_bd.int_en =
			!xpcxd_rx_cmp_rfl_mode; /* 1 - Generate on packet completion */
		rxr->sub.desc[prod_idx].rx_bd.eof = 1; /* End of frame */

		sw_desc->prod_idx = prod_idx;

		/* W1 */
		rxr->sub.desc[prod_idx].rx_bd.len = bd_len;

		if (xpcxd_legacy_skb_alloc) {
			/* W2 */
			rxr->sub.desc[prod_idx].rx_bd.dst_buf_addr_lsb =
				((u64)(sw_desc->addr) & 0x00000000FFFFFFFF);
		} else {
			/* W2 */
			rxr->sub.desc[prod_idx].rx_bd.dst_buf_addr_lsb =
				(((u64)(sw_desc->addr) & 0x00000000FFFFFFFF)) + XPCXD_FRAG_OFFSET;
		}

		/* W3 */
		rxr->sub.desc[prod_idx].rx_bd.dst_buf_addr_msb =
			((u64)(sw_desc->addr) & 0xFFFFFFFF00000000);

		// xpcxd_opt_trace(rx_fill_bd, ring_id, prod_idx,
		// 		sw_desc,
		// 	    rxr->sub.desc[prod_idx].rx_bd.eof,
		// 	    rxr->sub.desc[prod_idx].rx_bd.len,
		// 		rxr->sub.desc[prod_idx].rx_bd.dst_buf_addr_lsb,
		// 		rxr->sub.desc[prod_idx].rx_bd.dst_buf_addr_msb);

		// TODO: Check if it's absolutely needed
		// Relevant for IA-64
		// xpcxd_dma_wmb();

		rxr->sub.prod++;

		/* Internal counter WRAP check */
		if (rxr->sub.prod >= rxr->sub.size)
			rxr->sub.prod = 0;

		// xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "NEXT [%d] rxr->sub.prod: %d rxr->sub.size: %d", i, rxr->sub.prod, rxr->sub.size);
	}
	if (likely(i)) {
		/* DoorBell is skipped for the first Rx fill and given lateri, after activation */
		if (db_write) {

			// Finish all memory transactions before HW access the desriptors  
			xpcxd_dma_wmb();

			xpcxd_opt_trace(rx_action_fill_rx_db_ring, ring_id, i, 0);

			xpcxd_rx_db_write(netdev, ring_id, i);
		}
	}

	xpcxd_opt_trace(rx_fill_finish, ring_id, i, 0);

	*processed = i;

	// end:
	// xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT");

	return 0;
}

static u32 xpcxd_page_pool_free(struct net_device *netdev,
			 struct xpcxd_ring *ring)
{
	struct xpcxd_sw_desc *sw_desc = NULL;
	u16 i = 0;

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "IN[%d]", ring->ring_id);

	xpcxd_opt_trace(rx_action_pool_free_start, ring->ring_id, 0, 0);

	for (i = 0; i < ring->sub.size; i++) {
		sw_desc = &ring->sub.sw[i];

		xpcxd_opt_trace(rx_action_pool_free_page, ring->ring_id, i, sw_desc->page_state);

		if (sw_desc && sw_desc->skb) {
			dev_kfree_skb(sw_desc->skb);
		}

		if (sw_desc && ring->page_pool && sw_desc->page && (sw_desc->page_state == XPCXD_PAGE_ALLOCATED)) {
			page_pool_release_page(ring->page_pool, sw_desc->page);

			if (page_ref_count(sw_desc->page) != 1) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"REF COUNT ERR: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
					ring->ring_id, i, sw_desc->skb, sw_desc->page, sw_desc->page_state, page_ref_count(sw_desc->page));		
			}

			if (page_count(sw_desc->page) != 1) {
				xpcxd_err_netdev(
					NETIF_MSG_DRV, netdev,
					"PAGE COUNT ERR: [%d]: num: %d skb: [%p] page: [%p] state: [%d] ref_cnt: [%d]",
					ring->ring_id, i, sw_desc->skb, sw_desc->page, sw_desc->page_state, page_count(sw_desc->page));
				// dump_page(sw_desc->page, "Debugging inflight page");		
			}
		}
	}

	xpcxd_opt_trace(rx_action_pool_free_done, ring->ring_id, 0, 0);

	if (ring->page_pool) {
		xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "Destroying Rx page pool");
		page_pool_destroy(ring->page_pool);
		ring->page_pool = NULL;
	}

	usleep_range(500, 1000); /* From 0.5 up to 1 ms */

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT");

	return 0;
}

static u32 xpcxd_rx_db_init(struct net_device *netdev, struct xpcxd_ring *rxr,
			    u16 ring_id)
{
	u16 prod_idx = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN: ring_id: %d", ring_id);

	prod_idx = rxr->sub.prod & rxr->sub.mask;

	// Doorbell ring done in rx_fill
	xpcxd_dbg(NETIF_MSG_DRV, "RINGING to RX DOORBELL: rxr->sub.size: %d", rxr->sub.size);
	xpcxd_rx_db_write(netdev, ring_id, rxr->sub.size);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

#ifdef __XPCXD_RX_DEBUG__
void xpcxd_consume_skb(struct net_device *netdev, struct sk_buff *skb)
{
	struct skb_shared_info *shinfo = skb_shinfo(skb);
	int i = 0;

	// xpcxd_dbg_netdev(
	// 	NETIF_MSG_RX_STATUS, netdev,
	// 	"---> [%d] PCXD CMPL RX: IN: skb: [%p] skb->len: [%d]",
	// 	0,
	// 	skb,
	// 	skb->len);

	if (!skb_unref(skb)) {
		xpcxd_err_netdev(NETIF_MSG_RX_STATUS, netdev,
				 "---> [%d] PCXD CMPL RX: UNREF: skb: [%p]",
				 0,
				 skb);
		return;
	}

	xpcxd_opt_trace(rx_poll_consume_skb, 
			0, 0, 
			skb, skb->len,
			0,
			0,
			0,
			0,
			0,
			0);

	for (i = 0; i < shinfo->nr_frags; i++)
		xpcxd_dbg_netdev(
			NETIF_MSG_RX_STATUS, netdev,
			"---> [%d] PCXD CMPL RX: Fragments: skb: [%p] shinfo->frags[%d]: %p",
			0,
			skb,
			i,
			&shinfo->frags[i]);

	// xpcxd_dbg_netdev(
	// 	NETIF_MSG_RX_STATUS, netdev,
	// 	"---> [%d] PCXD CMPL RX: Before kfree_skb(): skb: [%p]",
	// 	0,
	// 	skb);

	// trace_consume_skb(skb);
	__kfree_skb(skb);
}
#else
inline void xpcxd_consume_skb(struct net_device *netdev, struct sk_buff *skb) {
	consume_skb(skb);
}
#endif

static void xpcxd_print_multipage_skb_data(char *msg, struct net_device *netdev, struct sk_buff *skb) {
    struct skb_shared_info *shinfo;
    int i;

    if (!skb) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "skb is NULL");
        return;
    }

    // Print linear part of skb
    if (skb->len) {
		xprint_hex_dump(netdev, msg,
				DUMP_PREFIX_OFFSET, 16, 1, skb->data, skb_headlen(skb), true);
    }

    // Get the shared info structure for the skb
    shinfo = skb_shinfo(skb);

    // Iterate over each fragment (page) in the skb
    for (i = 0; i < shinfo->nr_frags; i++) {
        skb_frag_t *frag = &shinfo->frags[i];
        void *vaddr;
        unsigned int size = skb_frag_size(frag);

        // Map the fragment to virtual address space
        vaddr = kmap_atomic(skb_frag_page(frag));

        // Print the fragment's data
        xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Fragment %d data: ", i);
        xprint_hex_dump(netdev, msg, DUMP_PREFIX_OFFSET, 16, 1, vaddr + XPCXD_FRAG_OFFSET/*+ frag->page_offset*/, size, true);

        // Unmap the fragment
        kunmap_atomic(vaddr);
    }
}

static int xpcxd_add_fragments(struct net_device *netdev, u16 ring_id,
			       struct sk_buff *skb,
			       struct xpcxd_ring *rxr, int len,
				   u32 cur_desc, u16 num_desc)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_submit_ring *rxsr = &net_priv->rxr[ring_id].sub;
	u32 next_desc = 1;
	int len_left = len;
	u32 frag_size = 0;
	u32 desc_index = 0;
	struct xpcxd_sw_desc *sw_desc_ptr = NULL;

	desc_index = cur_desc + next_desc;

	for (next_desc = 1; next_desc < num_desc; next_desc++) {
		
		if (desc_index >= rxsr->size) {
			desc_index = 0;

			sw_desc_ptr = &rxr->sub.sw[desc_index];

			xpcxd_opt_trace(rx_poll_index_wrap, ring_id, 0, 
				skb, skb->len,
				num_desc,
				desc_index, 
				sw_desc_ptr, sw_desc_ptr->page, 
				len, frag_size);
		} else {
			sw_desc_ptr = &rxr->sub.sw[desc_index];

			xpcxd_opt_trace(rx_poll_index_next, ring_id, 0, 
				skb, skb->len,
				num_desc,
				desc_index, 
				sw_desc_ptr, sw_desc_ptr->page, 
				len, frag_size);
		}

		len_left -= XPCXD_FRAG_DATA_SIZE;
		if (len_left > XPCXD_FRAG_DATA_SIZE) {
			frag_size = XPCXD_FRAG_DATA_SIZE;
		} else {
			frag_size = len_left;
		}

		xpcxd_opt_trace(rx_poll_add_frag, ring_id, 0, 
				skb, skb->len,
				num_desc,
				desc_index, 
				sw_desc_ptr, sw_desc_ptr->page, 
				len, frag_size);

		skb_add_rx_frag(skb, /*next_desc - 1*/skb_shinfo(skb)->nr_frags, sw_desc_ptr->page,
			XPCXD_FRAG_OFFSET, frag_size, XPCXD_FRAG_DATA_SIZE);

		/* Invalidate cache lines that may have been written to by
		* device so that we avoid corrupting memory.
		*/
		xpcxd_dma_sync_single_range_for_cpu(
			net_priv->hw_dev, sw_desc_ptr->addr,
			XPCXD_FRAG_OFFSET, frag_size,
			DMA_FROM_DEVICE);

		// if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
		// 	xprint_hex_dump(netdev, "--- RX DATA FRAG 1 ---",
		// 			DUMP_PREFIX_OFFSET, 16, 1, sw_desc_ptr->page,
		// 			frag_size + XPCXD_FRAG_OFFSET, true);
		// }

		xpcxd_dma_sync_single_for_cpu(net_priv->hw_dev,
							sw_desc_ptr->addr,
							PAGE_SIZE,
							DMA_FROM_DEVICE);

		// if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
		// 	xprint_hex_dump(netdev, "--- RX DATA FRAG 2 ---",
		// 			DUMP_PREFIX_OFFSET, 16, 1, sw_desc_ptr->page,
		// 			PAGE_SIZE, true);
		// }

		desc_index++;
	}

	return 0;
}

/* Function to pad skb to the nearest multiple of 64 bytes */
int xpcxd_pad_skb_to_64(struct sk_buff *skb)
{
    unsigned int pad_len;
    unsigned int mod = skb->len % 64;

    /* Calculate the amount of padding needed */
    if (mod != 0)
        pad_len = 64 - mod;
    else
        pad_len = 0;

    /* Add padding if needed */
    if (pad_len > 0) {
        if (skb_pad(skb, pad_len)) {
			xpcxd_err(
					NETIF_MSG_RX_STATUS,
					"---> [%d] PCXD CMPL RX: SKB PUT : skb: [%p] pad_len: [%d]",
					0, skb, pad_len);

            return -ENOMEM;  /* Failed to pad skb */
		}
        skb_put(skb, pad_len);  /* Adjust the length to include padding */
    }

    return 0;
}

#ifdef __XPCXD_ICMP_TRACE__
extern void xpcxd_check_icmp_echo(struct sk_buff *skb, struct net_device *netdev);
#endif

static bool xpcxd_rx_cmpl(struct net_device *netdev, struct napi_struct *napi,
			  struct xpcxd_ring *rxr, u32 ring_id, u16 budget,
			  u16 *done_packets)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_compl_ring *rxcr = &net_priv->rxr[ring_id].cmp;
	struct xpcxd_submit_ring *rxsr = &net_priv->rxr[ring_id].sub;
	struct sk_buff *skb = NULL;
	struct xpcxd_desc cmpl;
	struct xpcxd_sw_desc *sw_desc;
	u16 cmpl_prd_ptr = 0;
	u16 max = rxcr->size;
	int n = 0, k = 0, len = 0;
	int alloc_len = 0;
	bool rx_done = false;
	bool l3_csum = false;
	bool l4_csum = false;
	const struct ethhdr *eth = NULL;
	const struct iphdr *iph = NULL;
	const struct ipv6hdr *ip6h = NULL;
	u16 processed = 0;
	u16 cmpl_idx = 0;

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "---> [%d] PCXD CMPL RX: IN", ring_id);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	// tracing_on();
#endif

// #ifdef __XPCXD_CMD_START_END_TRACE__
    start_rx_trace = true; /* Start traces only when packets started */
// #endif

	rxcr->cmpl_prd_ptr =
		xpcxd_get_rx_cmpl_prod_ptr(xpcxd_netdev, ring_id);

	cmpl_prd_ptr = rxcr->cmpl_prd_ptr;

// #ifdef __XPCXD_RX_DEBUG__
	/* For a special cases where we want an early Rx drop. No processing */
	if (xpcxd_cfg_tbl[xpcxd_rx_drop_all] == 2) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_drop_all)", 
					ring_id);
		rx_done = true;
		rxr->stats.errors++;
		goto error;
	}

	if (xpcxd_rx_packets_stop) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"---> [%d] PCXD CMPL RX: --> Stopped by xpcxd_rx_packets_stop)", ring_id);
		rx_done = true;
		rxr->stats.errors++;
		goto error;
	}
// #endif

	if (unlikely((budget != XPCXD_NO_LIMIT) && (budget < max)))
		max = budget;

	rxcr->round_cnt++;

	xpcxd_opt_trace(rx_poll_start, ring_id, max, 0);

	while (k < max) {
		cmpl_idx = rxcr->cons & rxcr->mask;

		// xpcxd_opt_trace(rx_poll_next, ring_id, n, 0);

		xpcxd_dma_rmb();

		cmpl.w64[0] = rxcr->desc[cmpl_idx].w64[0];
		cmpl.w64[1] = rxcr->desc[cmpl_idx].w64[1];

#ifdef __XPCXD_RX_DEBUG__
		xprint_hex_dump(netdev, "--- RX Cmpl W[0]---",
				DUMP_PREFIX_OFFSET, 16, 1, &cmpl.w64[0],
				sizeof(u64), true);
		xprint_hex_dump(netdev, "--- RX Cmpl W[1]---",
				DUMP_PREFIX_OFFSET, 16, 1, &cmpl.w64[1],
				sizeof(u64), true);
#endif /* __XPCXD_RX_DEBUG__ */

// #ifdef __XPCXD_RX_DEBUG__
		if (unlikely((xpcxd_cfg_tbl[xpcxd_rx_drop_all] == 2)) || unlikely(xpcxd_rx_packets_stop)) {
			rx_done = true;
			goto done;
		}
// #endif /* __XPCXD_RX_DEBUG__ */

		if (unlikely(cmpl_idx == cmpl_prd_ptr)) {
			u16 prev_valid = 0;
			struct xpcxd_desc last_cmpl;

			if (cmpl_idx == 0) {
				prev_valid = rxcr->size - 1; 
			} else {
				prev_valid = cmpl_idx - 1;
			}

			last_cmpl.w64[0] = rxcr->desc[prev_valid].w64[0];

			rxcr->prev_cns_valid = last_cmpl.rxc.cmp_ctrl_valid;

			/* We are silently assume that if rx_cmpl() been called and cmpl_idx == cmpl_prd_ptr   */
			/* This means that cmpl head reached a producer tail and we need to start Rx as usual */
			if ((n == 0) && (rxcr->prev_cns_valid != cmpl.rxc.cmp_ctrl_valid)) {
				xpcxd_dbg_netdev(
					NETIF_MSG_RX_ERR, netdev,
					"---> [%d] [rnd:%d] PCXD CMPL RX: Flip -1- DETECTED cmpl_idx:%d cmpl_prd_ptr:%d rxcr->cons: %d cmpl.rxc.cmp_ctrl_valid: 0x%x rxcr->prev_cns_valid: 0x%x",
					ring_id, rxcr->round_cnt, cmpl_idx, cmpl_prd_ptr,
					rxcr->cons,
					cmpl.rxc.cmp_ctrl_valid,
					rxcr->prev_cns_valid);
				rxcr->prev_cns_valid =
					cmpl.rxc.cmp_ctrl_valid;
				rxr->stats.rx_cns_catched_prd++;
				goto next;
			} else {
				rxcr->prev_cns_valid =
					cmpl.rxc.cmp_ctrl_valid;

				rx_done = true;
				xpcxd_opt_trace(rx_poll_stop, ring_id, n, 0);
				goto done;
			}
		}

		if (unlikely(rxcr->prev_cns_valid != cmpl.rxc.cmp_ctrl_valid))
			rxcr->prev_cns_valid = cmpl.rxc.cmp_ctrl_valid;

		len = cmpl.rxc.len;

		sw_desc = &rxr->sub.sw[cmpl.rxc.desc_index];
		// xpcxd_opt_trace(rx_poll_sw_desc_index, ring_id, cmpl.rxc.desc_index, len);

		if (unlikely(!sw_desc)) {
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR,
				netdev,
				"---> [%d] PCXD CMPL RX: -ERR-: sw_desc is NULL", ring_id);
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"---> [%d] [rnd:%d] PCXD CMPL RX: -ERR-: prev_cns_valid: 0x%x --> cmp_ctrl_valid: 0x%x OR cmpl_idx:%d cmpl_prd_ptr:%d rxcr->cons: %d rxcr->mask: %d",
				ring_id, rxcr->round_cnt, rxcr->prev_cns_valid, cmpl.rxc.cmp_ctrl_valid, cmpl_idx,
				cmpl_prd_ptr, rxcr->cons, rxcr->mask);
			rx_done = true;
			rxr->stats.errors++;

			/* STOP ALL Rx/Tx activity in this case */
			xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
			xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
			g_error = 1;

			goto error;
		}

		if (unlikely(!sw_desc->page) || unlikely(sw_desc->page_state <= XPCXD_PAGE_FREE)) {
			xpcxd_err_netdev(NETIF_MSG_RX_STATUS, netdev,
					"skb build failed - no page allocated");
			rxr->stats.errors++;
			rxr->stats.dropped++;

			xpcxd_opt_trace(rx_skb_build_err, ring_id, 0, 0, 0);

			goto next;		
		}

#ifdef __XPCXD_DEBUG__
		if (unlikely(sw_desc->page_state <= XPCXD_PAGE_FREE)) {
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"---> [%d] PCXD CMPL RX: -ERR-: sw_desc->page_state [%d] is NOT correct",
				ring_id,
				sw_desc->page_state);
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"---> [%d] [rnd:%d] PCXD CMPL RX: -ERR-: prev_cns_valid: 0x%x --> cmp_ctrl_valid: 0x%x OR cmpl_idx:%d cmpl_prd_ptr:%d rxcr->cons: %d rxcr->mask: %d",
				ring_id, rxcr->round_cnt, rxcr->prev_cns_valid,
				cmpl.rxc.cmp_ctrl_valid, cmpl_idx, cmpl_prd_ptr,
				rxcr->cons, rxcr->mask);
			rx_done = true;
			rxr->stats.errors++;

			/* STOP ALL Rx/Tx activity in this case */
			xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
			xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
			g_error = 1;

			goto error;
		}
#endif
		if (unlikely(!sw_desc->addr)) {
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR,
				netdev,
				"---> [%d] PCXD CMPL RX: -ERR-: sw_desc->addr is NULL", ring_id);
			xpcxd_err_netdev(
				NETIF_MSG_RX_ERR, netdev,
				"---> [%d] PCXD CMPL RX: -ERR-: prev_cns_valid: 0x%x --> cmp_ctrl_valid: 0x%x OR cmpl_idx:%d cmpl_prd_ptr:%d rxcr->cons: %d rxcr->mask: %d",
				ring_id, rxcr->prev_cns_valid, cmpl.rxc.cmp_ctrl_valid, cmpl_idx,
				cmpl_prd_ptr, rxcr->cons, rxcr->mask);
			rx_done = true;
			rxr->stats.errors++;

			/* STOP ALL Rx/Tx activity in this case */
			xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
			xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
			g_error = 1;

			goto error;
		}

		if (xpcxd_legacy_skb_alloc) {
			/* Invalidate cache lines that may have been written to by
			* device so that we avoid corrupting memory.
			*/
			xpcxd_dma_sync_single_for_cpu(net_priv->hw_dev, sw_desc->addr,
								len, DMA_FROM_DEVICE);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				xprint_hex_dump(netdev, "--- RX DATA FROM PAGE ---",
					DUMP_PREFIX_OFFSET, 16, 1, page_address(sw_desc->page),
					len + XPCXD_SKB_RX_HEADROOM, true);
			}

			skb = napi_alloc_skb(napi, len + XPCXD_ALIGNMENT_256);
			if (unlikely(!skb)) {
				xpcxd_err_netdev(NETIF_MSG_RX_STATUS, netdev,
						"skb alloc failed");
				rxr->stats.errors++;
				goto error;
			}

			skb_reserve(skb, XPCXD_ALIGNMENT_256);

			/* Use skb_put to extend the used data area */
			skb_put(skb, len);

			memcpy(skb->data, page_address(sw_desc->page), len);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				xprint_hex_dump(netdev, "--- RX DATA AFTER COPY ---",
						DUMP_PREFIX_OFFSET, 16, 1, skb->data,
						skb->len, true);
				xpci_print_pkt("RX AFTER COPY ", netdev, skb, RX_OFFSET, xpci_rx);
			}

			/* Data payload copied into SKB, page ready for recycle */
			// xpcxd_page_pool_put_full_page(rxr->page_pool, sw_desc->page, true);
			xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page);
			sw_desc->page_state = XPCXD_PAGE_FREE;

			n++;
		} else {
			xpcxd_dma_sync_single_range_for_cpu(
				net_priv->hw_dev,
				sw_desc->addr,
				XPCXD_FRAG_OFFSET,
				len < XPCXD_FRAG_DATA_SIZE ? len : XPCXD_FRAG_DATA_SIZE,
				DMA_FROM_DEVICE);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				xprint_hex_dump(netdev, "--- RX DATA FROM PAGE ---",
					DUMP_PREFIX_OFFSET, 16, 1, page_address(sw_desc->page)/* + XPCXD_SKB_RX_HEADROOM */,
					len + XPCXD_SKB_RX_HEADROOM, true);
			}

/********************************************************************************
 *                         Packet structure
 * 
 *          Head Room	: XPCXD_SKB_RX_HEADROOM
 *          Data		: PAGE_SIZE - XPCXD_SKB_RX_HEADROOM - XPCXD_SKB_TAIL_ROOM
 *          Tail Room	: XPCXD_SKB_SHINFO_SIZE
 *
 ********************************************************************************/

			if (len < XPCXD_FRAG_DATA_SIZE) {
				alloc_len = len + XPCXD_SKB_RX_HEADROOM + XPCXD_SKB_TAIL_ROOM;
			} else {
				alloc_len = XPCXD_FRAG_DATA_SIZE + XPCXD_SKB_RX_HEADROOM + XPCXD_SKB_TAIL_ROOM;
			}
			alloc_len = SKB_DATA_ALIGN(alloc_len);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
			skb = napi_build_skb(page_address(sw_desc->page), alloc_len);
#else
			skb = build_skb(page_address(sw_desc->page), alloc_len);
#endif /* LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0) */
			if (unlikely(!skb)) {
#ifdef __XPCXD_TRACE_PRINTK__
				trace_printk("build_skb() error: skb: [%p] page: [%p] pfn: [%lu]",
					skb, sw_desc->page, page_to_pfn(sw_desc->page));
#endif
				xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page);
				// xpcxd_page_pool_put_full_page(rxr->page_pool, sw_desc->page, true);
				sw_desc->page_state = XPCXD_PAGE_FREE;
				xpcxd_err_netdev(NETIF_MSG_RX_ERR, netdev,
						"skb build failed");
				rxr->stats.errors++;
				goto error;
			}

			n++;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 14, 0)
			skb_mark_for_recycle(skb);
#else
			if (!xpcxd_legacy_skb_alloc) {
				// We should never reach here for kernel < 5.14.0
				// xpcxd_page_pool_put_full_page(rxr->page_pool, sw_desc->page, true);
				xpcxd_page_pool_recycle_direct(rxr->page_pool, sw_desc->page);
				sw_desc->page_state = XPCXD_PAGE_FREE;
				xpcxd_err_netdev(NETIF_MSG_RX_STATUS, netdev,
						"skb build failed");
				rxr->stats.errors++;
				goto error;
			}
#endif

			xpcxd_skb_align(skb, XPCXD_ALIGNMENT_256);

			skb_put(skb, len < XPCXD_FRAG_DATA_SIZE?len:XPCXD_FRAG_DATA_SIZE);

			skb_reset_mac_header(skb);
			skb_reset_network_header(skb);
			skb_reset_transport_header(skb);

			if (unlikely(cmpl.rxc.num_desc > 1)) {
				xpcxd_add_fragments(netdev, ring_id, skb, rxr, len, cmpl.rxc.desc_index, cmpl.rxc.num_desc);
				n += (cmpl.rxc.num_desc - 1);
			}
		}
		xpcxd_dbg_netdev(
			NETIF_MSG_RX_STATUS, netdev, CLR_GREEN
			"---> [%d] PCXD CMPL RX: -SKB AFTER PUT: skb: [%p] len: [%d] skb->tail: [%d] skb->end: [%d] skb->len: [%d] netdev->mtu: [%d]" CLR_RST,
			ring_id, skb, len, skb->tail, skb->end, skb->len, netdev->mtu);

		// xpcxd_opt_trace(rx_poll_new_skb, 
		// 		ring_id, cmpl.rxc.desc_index,
		// 		skb, skb->len,
		// 		cmpl.rxc.num_desc,
		// 		cmpl.rxc.desc_index,
		// 		sw_desc,
		// 		sw_desc->page,
		// 		netdev->mtu, /* len_left */
		// 		0); /* frag_size */

		if (skb->len > netdev->mtu) {
			xpcxd_dbg_netdev(
				NETIF_MSG_RX_ERR,
				netdev,
				"---> [%d] PCXD CMPL RX: packet drop: skb->len: [%d] > MTU: [%d]", ring_id, len, netdev->mtu);

			xpcxd_opt_trace(rx_poll_mtu_too_big, ring_id, n, skb->len);
			xpcxd_consume_skb(netdev, skb);
			
			rxr->stats.dropped++;
			rxr->stats.errors++;

			sw_desc->page_state = XPCXD_PAGE_FREE;
			goto next;
		}

		k++;

		/* make sure skb ip_summed is CHECKSUM_NONE */
		skb_checksum_none_assert(skb);
	
		if (unlikely(cmpl.rxc.cmp_ctrl_l3_chks_err)) {
			if (!xpcxd_rx_ignore_l3_checksum_err) {
				xreg_pcxd_rx_stts_err_prs0_t err_prs0 = { 0 };

				xpcxd_err_netdev(
					NETIF_MSG_RX_ERR, netdev,
					"---> [%d] PCXD CMPL RX: L3 Checksum error", ring_id);

				xpcxd_err_prs0(&err_prs0);
			}

			/* We are collecting CRC errors per ring and not per net device */
			rxr->stats.errors++;
			rxr->stats.hw_csum_rx_error++;

			/* Drop if no error ignore mode been set */
			if (!xpcxd_rx_ignore_l3_checksum_err || xpcxd_rx_stop_on_l3_checksum_err) {
				rx_done = true;
				goto error;
			}
		} else {
			// xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "---> RX CMPL RX: skb: [%p] L3 Checksum OK", skb);
			l3_csum = true;

			if (unlikely(ip_fast_csum((u8 *)ip_hdr(skb), ip_hdr(skb)->ihl))) {
				
				rxr->stats.errors++;

				/* Drop if no error ignore mode been set */
				if (!xpcxd_rx_ignore_l3_checksum_err || xpcxd_rx_stop_on_l3_checksum_err) {
					rx_done = true;
					goto error;
				}
			}
		}

		if (unlikely(cmpl.rxc.cmp_ctrl_l4_chks_err)) {
			rxr->stats.errors++;
			rxr->stats.hw_csum_rx_error++;

			/* Drop if no error ignore mode been set */
			if (!xpcxd_rx_ignore_l4_checksum_err || xpcxd_rx_stop_on_l4_checksum_err) {
				rx_done = true;
				goto error;
			}
		} else {

			l4_csum = true;

			/* TCP or UDP packet with a valid checksum */

			/* 
			* https://elixir.bootlin.com/linux/v5.15.160/source/include/linux/skbuff.h#L889
			* 
			* CHECKSUM_UNNECESSARY:
			*
			*   The hardware you're dealing with doesn't calculate the full checksum
			*   (as in CHECKSUM_COMPLETE), but it does parse headers and verify checksums
			*   for specific protocols. For such packets it will set CHECKSUM_UNNECESSARY
			*   if their checksums are okay. skb->csum is still undefined in this case
			*   though. A driver or device must never modify the checksum field in the
			*   packet even if checksum is verified.
			*/

			skb->ip_summed = CHECKSUM_UNNECESSARY;
			skb->csum_level = 1;
		}

		if (xpcxd_num_of_rings > 1) {
			skb_record_rx_queue(skb, ring_id);
			if ((netdev->features & NETIF_F_RXHASH) && (xpcxd_rss_mode == XPCXD_RSS_MODE_FULL))
				skb_set_hash(skb, cmpl.rxc.rss_hash, PKT_HASH_TYPE_L4);
		}

		// ******************************
		// TODO: REMOVE AFTER SHIM CONFIG
		// ******************************
#ifdef __XPCXD_LOOPBACK__
		if (unlikely(xpcxd_loopback)) {
			skb_pull(skb, XPCXD_HW_SHIM_SIZE);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				// xprint_hex_dump(netdev, "--- RX DATA AFTER TRIM ---",
				// 		DUMP_PREFIX_OFFSET, 16, 1, skb->data,
				// 		skb->len, true);
				xpcxd_print_multipage_skb_data("--- RX DATA AFTER TRIM ---", netdev, skb);
				xpci_print_pkt("RX AFTER AFTER TRIM", netdev, skb, RX_OFFSET, xpci_rx);
			}			
		}
#endif /* __XPCXD_LOOPBACK__ */

		skb->protocol = eth_type_trans(skb, netdev);

		if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA))
			xpcxd_print_multipage_skb_data("--- RX DATA ---", netdev, skb);

		xpcxd_pkt_stats_inc(rxr, len);

		/* Update statistics for this device */
		netdev->stats.rx_packets++;
		netdev->stats.rx_bytes += skb->len;

		eth = eth_hdr(skb);

		/* Calculate per packet statistics */
		if (likely(eth->h_proto == htons(ETH_P_IP))) {
			iph = ip_hdr(skb);
			if (iph->daddr == htonl(INADDR_BROADCAST)) {
				rxr->stats.rx_broadcast++;
			} else if (iph->daddr >= htonl(224 << 24) && iph->daddr <= htonl(239 << 24 | 255 << 16 | 255 << 8 | 255)) {
				rxr->stats.rx_multicast++;
			} else {
				rxr->stats.rx_unicast++;
			}
		} else {
			if (likely(eth->h_proto == htons(ETH_P_IPV6))) {
				ip6h = ipv6_hdr(skb);
				if (ipv6_addr_is_multicast(&ip6h->daddr)) {
					rxr->stats.rx_multicast++;
				} else {
					rxr->stats.rx_unicast++;
				}
			} else {
				if (likely(eth->h_proto == htons(ETH_P_ARP))) {
					if (is_broadcast_ether_addr(eth->h_dest)) {
						rxr->stats.rx_broadcast++;
					} else {
						rxr->stats.rx_unicast++;
					}
				}
			}
		}

		/* Let's do all the work and calculate statistics */
		/* And simulate drop all after that               */
		if (unlikely(xpcxd_cfg_tbl[xpcxd_rx_drop_all])) {
#ifdef __XPCXD_RETURN_SKB__
			bool rec_success = false;
#endif
			xpcxd_info_netdev(
				NETIF_MSG_RX_STATUS, netdev,
				"---> [%d] PCXD CMPL RX: --> packet drop (by xpcxd_rx_drop_all)", ring_id);

			if (unlikely(xpcxd_msglvl_level & NETIF_MSG_PKTDATA)) {
				// xprint_hex_dump(netdev, "--- RX DATA ---",
				// 		DUMP_PREFIX_OFFSET, 16, 1, skb->data,
				// 		skb->len, true);
				xpcxd_print_multipage_skb_data("--- RX DATA ---", netdev, skb);
				// xpci_print_pkt("RX", netdev, skb, RX_OFFSET, xpci_rx);
			}

			rxr->stats.dropped++;

			xpcxd_consume_skb(netdev, skb);

			xpcxd_opt_trace(rx_skb_consume, ring_id, 0, skb, 0);

			sw_desc->page_state = XPCXD_PAGE_FREE;

			goto next;
		}

#ifdef __XPCXD_DEBUG__
		if (unlikely(xpcxd_rx_packets_stop)) {

			xprint_hex_dump(netdev, "--- RX Cmpl W[0] STOP ---",
					DUMP_PREFIX_OFFSET, 16, 1, &cmpl.w64[0],
					sizeof(u64), true);
			xprint_hex_dump(netdev, "--- RX Cmpl W[1] STOP ---",
					DUMP_PREFIX_OFFSET, 16, 1, &cmpl.w64[1],
					sizeof(u64), true);

			xprint_hex_dump(netdev, "--- RX STOP ---",
				DUMP_PREFIX_OFFSET, 16, 1, skb->data,
				skb->len, true);

			xpcxd_err_netdev(NETIF_MSG_RX_ERR, netdev,
				"---> [%d] PCXD CMPL RX: STOP: cmpl_prd_ptr: %d rxcr->cons: %d rxcr->size: %d",
				ring_id, cmpl_prd_ptr, rxcr->cons, rxcr->size);
			xpci_print_pkt("RX STOP", netdev, skb, RX_OFFSET, xpci_rx);

			xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
			xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
			g_error = 1;
			xpcxd_intg_spare_write(g_cnt_init_done /*0x1*/);

			xpcxd_info_netdev(
				NETIF_MSG_RX_STATUS, netdev,
				"---> [%d] PCXD CMPL RX: --> packet drop (by xpcxd_rx_packets_stop)", ring_id);

			rxr->stats.dropped++;

			if (xpcxd_legacy_skb_alloc) {
				dev_kfree_skb(sw_desc->skb);
				sw_desc->skb = NULL;
			} else {
				xpcxd_consume_skb(netdev, skb);
				sw_desc->page_state = XPCXD_PAGE_FREE;
			}
			goto next;
		}
#endif /* __XPCXD_DEBUG__ */

		if (!xpcxd_legacy_skb_alloc) {
			if ((page_ref_count(sw_desc->page) != 1) ||
				(sw_desc->page_state != XPCXD_PAGE_ALLOCATED)) {
				xpcxd_err_netdev(
					NETIF_MSG_RX_ERR, netdev,
					"---> [%d] PCXD CMPL RX: REF CNT -PCXDERR-: skb: [%p] sw_desc->page: [%p] sw_desc->addr: [%lld] page refcnt: [%d]",
					ring_id, skb, sw_desc->page, sw_desc->addr, page_ref_count(sw_desc->page));

				rx_done = true;
				rxr->stats.errors++;

				/* STOP ALL Rx/Tx activity in this case */
				xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
				xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
				g_error = 1;

				xpcxd_opt_trace(rx_skb_page_err, ring_id, 0, skb, page_to_pfn(sw_desc->page));

				goto error;
			}
		}

#ifdef __XPCXD_ICMP_TRACE__
		xpcxd_check_icmp_echo(skb, netdev);
#endif

		sw_desc->page_state = XPCXD_PAGE_PASSED_TO_STACK;

		// trace_printk("skb passed to stack skb: [%p] page: [%p] pfn: [%lu]",
		// 			skb, sw_desc->page, page_to_pfn(sw_desc->page));

		// xpcxd_opt_trace(rx_skb_pass_to_stack, ring_id, skb->len, skb, page_to_pfn(sw_desc->page));
		// trace_printk("rx_skb_pass_to_stack: rind_id: %d skb: [%p] skb->len: %d pfn: [%lu]",
		// 	ring_id, skb, skb->len, page_to_pfn(sw_desc->page));

		skb_mark_napi_id(skb, napi);
		netif_receive_skb(skb);

next:
		rxcr->cons++;

		/* Internal counter WRAP check */
		if (rxcr->cons >= rxcr->size)
			rxcr->cons = 0;

		rxsr->cons++;

		/* Internal counter WRAP check */
		if (rxsr->cons >= rxsr->size)
			rxsr->cons = 0;

		xpcxd_get_cmpl_ring_space(rxr);
	};

done:
	if (likely(n)) {
		if (rx_credits) {
			u32 rx_sub_free_space = rxr->sub.size - xpcxd_get_rx_sub_ring_space(rxr);
			if ((n + rx_credits) < rx_sub_free_space) {
				n = n + rx_credits;
			}
			xpcxd_opt_trace(rx_poll_space_check, ring_id, n, rx_credits);
			rx_credits = 0;
		}
		xpcxd_rx_fill(netdev, napi, ring_id, rxr, n, &processed, true);
	}

	xpcxd_info_netdev(NETIF_MSG_RX_STATUS, netdev, "---> [%d] PCXD CMPL RX: FILL DONE", ring_id);

error:
	*done_packets = k;
	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT");

	xpcxd_opt_trace(rx_poll_done, ring_id, k, n);

	return rx_done;
}

static bool xpcxd_tx_cmpl(struct net_device *netdev, u32 ring_id, u16 budget, u16 *done_packets)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *txr = &net_priv->txr[ring_id];
	struct xpcxd_compl_ring *txcr = &net_priv->txr[ring_id].cmp;
	struct xpcxd_submit_ring *txsr = &net_priv->txr[ring_id].sub;
	u16 max = txcr->size;
	struct xpcxd_desc cmpl = { 0 };
	u16 i;
	u32 tx_pkts = 0, tx_bytes = 0;
	u16 cmpl_prd_ptr = 0;
	u16 tx_space = 0;
	bool tx_done = false;

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> [%d] PCXD CMPL TX: IN", ring_id);

	txr->cmp.cmpl_prd_ptr = xpcxd_get_tx_cmpl_prod_ptr(xpcxd_netdev, ring_id);

	cmpl_prd_ptr = txcr->cmpl_prd_ptr;

	if (unlikely((budget != XPCXD_NO_LIMIT) && (budget < max)))
		max = budget;

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD CMPL TX: TXCR DUMP: txcr->size: %d mask: 0x%x cmpl_prd_ptr: %d cons: %d",
		ring_id, txcr->size, txcr->mask, cmpl_prd_ptr, txcr->cons);

	xpcxd_dbg_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> [%d] PCXD CMPL TX: TX POLL from 0 up to MAX: %d cmpl_prd_ptr: %d budget:%d",
		ring_id, max, cmpl_prd_ptr, budget);

	for (i = 0; i < max; i++) {
		u16 cmpl_idx = txcr->cons & txcr->mask;
		struct xpcxd_sw_desc *sw_desc;

		xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD CMPL TX: [%d] cmpl_idx: %d",
				ring_id, i, cmpl_idx);

		if (cmpl_idx == cmpl_prd_ptr) {
			xpcxd_info_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD CMPL TX: STOP cmpl_idx:%d == cmpl_prd_ptr:%d ---> jump to done",
				ring_id, cmpl_idx, cmpl_prd_ptr);
			tx_done = true;
			goto done;
		}

		cmpl.w64[0] = txcr->desc[cmpl_idx].w64[0];
		cmpl.w64[1] = txcr->desc[cmpl_idx].w64[1];

		if (!cmpl.txc.cmp_ctrl_valid) {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR,
				netdev,
				"---> [%d] PCXD CMPL TX: VALID ERR cmp_ctrl_valid: 0x%x OR cmpl_idx:%d cmpl_prd_ptr:%d txcr->cons: %d txcr->mask: %d",
				ring_id, cmpl.txc.cmp_ctrl_valid, cmpl_idx, cmpl_prd_ptr,
				txcr->cons, txcr->mask);
		}

		// ------------------------------------------------------
		// Set completion descriptor bit invalid for future usage
		cmpl.txc.cmp_ctrl_valid = 0;
		// ------------------------------------------------------

		sw_desc = &(txsr->sw[cmpl.txc.desc_index]);

		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD CMPL TX: [%d] cmpl_idx: %d sw_desc: [%p] sw_dma_addr: [%llx] dma_len: [%d] skb: %p",
			ring_id, i, cmpl_idx, sw_desc, dma_unmap_addr(sw_desc, sw_dma_addr), dma_unmap_len(sw_desc, dma_len), sw_desc->skb);
		if (likely(sw_desc->skb)) {
			tx_pkts++;
			tx_bytes += sw_desc->skb->len;
			dev_kfree_skb(sw_desc->skb);
			sw_desc->skb = NULL;
		} else {
			xpcxd_err_netdev(
				NETIF_MSG_TX_ERR, netdev,
				"---> [%d] PCXD CMPL TX: [%d] cmpl_prd_ptr: [%d] sw_desc: [%p] is empty descrptor",
				ring_id, i, cmpl_prd_ptr, sw_desc);
			xpcxd_set_error(netdev, NULL, xpci_rx, 0x1/*g_cnt_tx_stop*/, "TX ERROR: empty descrptor");
			goto done;
		}

		xpcxd_dma_unmap_single(net_priv->hw_dev,
				 dma_unmap_addr(sw_desc, sw_dma_addr),
				 dma_unmap_len(sw_desc, dma_len),
				 DMA_TO_DEVICE);

		txcr->cons++;

		/* Internal counter WRAP check */
		if (txcr->cons >= txcr->size) {
			txcr->cons = 0;
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> PCXD CMPL TX: WRAP: txcr->cons: %d txcr->size: %d",
				txcr->cons, txcr->size);
		} else {
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> PCXD CMPL TX: NEXT: txcr->cons: %d txcr->size: %d",
				txcr->cons, txcr->size);
		}

		txsr->cons = txsr->cons + cmpl.txc.num_desc;
		/* Internal counter WRAP check */
		if (txsr->cons >= txsr->size) {
			txsr->cons = 0;
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> PCXD SUB TX: WRAP: txsr->cons: %d txsr->size: %d",
				txsr->cons, txsr->size);
		} else {
			xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> PCXD SUB TX: NEXT: txsr->cons: %d txsr->size: %d",
				txsr->cons, txsr->size);
		}

		xpcxd_dbg_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"---> [%d] PCXD CMPL TX: [%d] NEXT txcr->cons: %d txr->cons: %d cmpl.txc.num_desc: %d",
			ring_id, i, txcr->cons, txsr->cons,
			cmpl.txc.num_desc);
	}

done:
	tx_space = xpcxd_get_tx_sub_ring_space(txr);
	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> [%d] PCXD CMPL TX: Free space: %d",
			ring_id, tx_space);

	if (unlikely(netif_tx_queue_stopped(txr->queue))) {
		if (likely(tx_space >= XPCXD_TX_STOP_THOLD)) {
			xpcxd_dbg_netdev(
				NETIF_MSG_TX_QUEUED, netdev,
				"---> [%d] PCXD CMPL TX: starting tx queue",
				ring_id);
			netif_tx_wake_queue(txr->queue);
		}
	}

	xpcxd_info_netdev(NETIF_MSG_TX_QUEUED, netdev, "---> [%d] PCXD CMPL TX: OUT: i: %d tx_pkts: %d",
			ring_id, i, tx_pkts);

	*done_packets = tx_pkts;

	return tx_done;
}

static int xpcxd_rx_poll(struct napi_struct *napi, int budget)
{
	struct xpcxd_ring *rxr =
		container_of(napi, struct xpcxd_ring, napi);
	struct net_device *netdev = napi->dev;
	u32 ring_id = rxr ? rxr->ring_id : 0;
	u16 rx_pkts = 0;
	int vec = ring_id + XPCI_X2_RX_CMP_INT_MIN;
	bool rx_done = false;

	xpcxd_info_netdev(
		NETIF_MSG_RX_STATUS, netdev,
		"---> [%d] PCXD NAPI RX: IN vec: %d rxr: %p", ring_id, vec, rxr);

	rx_done = xpcxd_rx_cmpl(netdev, napi, rxr, ring_id, budget, &rx_pkts);
	if (unlikely(rx_done)) {
		// xpcxd_info_netdev(
		// 	NETIF_MSG_RX_STATUS, netdev,
		// 	"[%d] RX NAPI COMPLETE", ring_id);
		xpcxd_opt_trace(rx_napi_complete, ring_id, rx_pkts, 0);
		napi_complete(napi);
		if (!rxr->stats.int_enabled) {
			// xpcxd_info_netdev(NETIF_MSG_INTR, netdev, "Interrupt Enable");
			xpcxd_opt_trace(rx_enable_irq, ring_id, vec, 0);
			xpci_enable_msix_interrupt(g_pxdev, vec);
			rxr->stats.int_enabled = true;
		}
	} else {
		xpcxd_opt_trace(rx_napi_next, ring_id, rx_pkts, 0);
		// xpcxd_info_netdev(
		// 	NETIF_MSG_RX_STATUS, netdev,
		// 	"[%d] RX NAPI NEXT - budget of: %d finished rx_pkts: %d",
		// 	ring_id, budget, rx_pkts);
	}

	xpcxd_dbg_netdev(NETIF_MSG_RX_STATUS, netdev, "OUT: budget: %d rx_pkts: %d", budget, rx_pkts);

	return rx_pkts;
}

static int xpcxd_tx_poll(struct napi_struct *napi, int budget)
{
	struct xpcxd_ring *txr =
		container_of(napi, struct xpcxd_ring, napi);
	struct net_device *netdev = napi->dev;
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = txr ? txr->ring_id : 0;
	u16 tx_pkts = 0;
	int vec = ring_id + XPCI_X2_TX_CMP_INT_MIN;
	bool tx_done = false;

	xpcxd_info_netdev(
		NETIF_MSG_TX_QUEUED, netdev,
		"---> PCXD NAPI TX: IN");

	netif_tx_lock(netdev);

	if (txr->stats.int_enabled) {
		xpci_disable_msix_interrupt(g_pxdev, vec);
		txr->stats.int_enabled = false;
	}
	tx_done = xpcxd_tx_cmpl(netdev, ring_id, budget, &tx_pkts);
	if (unlikely(tx_done)) {
		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"TX NAPI COMPLETE - budget of: %d tx_pkts: %d", budget,
			tx_pkts);
		napi_complete(napi);
		if (!txr->stats.int_enabled) {
			xpci_enable_msix_interrupt(g_pxdev, vec);
			txr->stats.int_enabled = true;
		}
	} else {
		xpcxd_info_netdev(
			NETIF_MSG_TX_QUEUED, netdev,
			"TX NAPI NEXT - budget of: %d finished tx_pkts: %d",
			budget, tx_pkts);
	}
	netif_tx_unlock(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_TX_QUEUED, netdev, "OUT");

	return tx_pkts;
}

static u32 db_rate_sum = 0;
static u32 db_count = 0;

static enum hrtimer_restart xpcxd_ring_time_isr(struct hrtimer *timer)
{
	struct xpcxd_ring *ring;

	// xpcxd_dbg("IN");

	ring = container_of(timer, struct xpcxd_ring, time_isr);

    if (arm_timer_isr) {
		xpcxd_err(NETIF_MSG_TIMER, "[%s] Ring[%d] Pkts: [%lld] Cmpl Prd: [%d] Sub Ring Space: [%d<--|p:%d|c:%d] Cmpl Ring Space: [%d<--|p:%d|c:%d] Irq Cnt: [%d] Int: [%s] DB Rate: [%d] Status: [%s]",
			(ring->type == XPCXD_RING_TX)?"TX":"RX",
			ring->ring_id,
			// ring->stats.bytes,
			ring->stats.packets,
			// ring->stats.drops,
			// ring->stats.errors,
			// ring->type == XPCXD_RING_TX?ring->stats.cmpl_irq_cnt:ring->stats.cmpl_irq_cnt,
			ring->cmp.cmpl_prd_ptr,
			(ring->type == XPCXD_RING_TX)?xpcxd_get_tx_sub_ring_space(ring):(ring->sub.size - xpcxd_get_rx_sub_ring_space(ring)),
			ring->sub.prod,
			ring->sub.cons,
			xpcxd_get_cmpl_ring_space(ring),
			ring->cmp.cmpl_prd_ptr,
			ring->cmp.cons,
			ring->stats.cmpl_irq_cnt,
			ring->stats.int_enabled?"EN":"DIS",
			(ring->type == XPCXD_RING_RX)?(db_count?(db_rate_sum / db_count):0):0,
			g_error?"STOPPED on ERROR":"RUNNING");
	}

	if (arm_timer_isr)
		hrtimer_forward_now(timer, time_isr_ktime);

	if (xpcxd_stop_on_next_isr) {
		xpci_debug_level = XPCI_DBG_LEVEL__DBG;
		xpcxd_set_msglvl_all();
		xpcxd_err(NETIF_MSG_DRV,
			"STOPPED by USER: stop on next ISR requested");
		xpcxd_intg_spare_write(0x1 /*g_cnt_tx_stop*/);
		xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
		xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 2;
		g_error = 1;
	}

	// xpcxd_dbg("OUT");

	if (arm_timer_isr) {
      return HRTIMER_RESTART;
    } else {
      return HRTIMER_NORESTART;
    }
}
// #endif

static irqreturn_t xpcxd_tx_err_intr_handler(int irq, void *xpci_irq)
{
	return xpci_handle_interrupt(irq, xpci_irq);
}

static irqreturn_t xpcxd_rx_err_intr_handler(int irq, void *xpci_irq)
{
	return xpci_handle_interrupt(irq, xpci_irq);
}

static irqreturn_t xpcxd_tx_cmpl_intr(int irq, void *xpci_irq)
{
	struct xdev *pxdev = (struct xdev *)xpci_irq;
	struct xpcxd_priv *net_priv = netdev_priv(xpcxd_netdev);
	struct xpcxd_ring *txr = NULL;
	int vec = pxdev->irq_map[irq];
	u32 ring_id = vec - XPCI_X2_TX_CMP_INT_MIN;

	txr = &net_priv->txr[ring_id];

	txr->stats.cmpl_irq_cnt++;

	if (txr->stats.int_enabled) {
		xpci_disable_msix_interrupt(g_pxdev, vec);
		napi_schedule_irqoff(&txr->napi);
		txr->stats.int_enabled = false;
		txr->cmp.cmpl_prd_ptr_prev = txr->cmp.cmpl_prd_ptr;

		return IRQ_HANDLED;
	}

	return IRQ_NONE;
}

static irqreturn_t xpcxd_rx_cmpl_intr(int irq, void *xpci_irq)
{
	struct xdev *pxdev = (struct xdev *)xpci_irq;
	struct xpcxd_priv *net_priv = netdev_priv(xpcxd_netdev);
	struct xpcxd_ring *rxr = NULL;
	int vec = pxdev->irq_map[irq];
	u32 ring_id = vec - XPCI_X2_RX_CMP_INT_MIN;

	rxr = &net_priv->rxr[ring_id];

	rxr->stats.cmpl_irq_cnt++;

	if (rxr->stats.int_enabled) {
		xpcxd_opt_trace(rx_disable_irq, ring_id, vec, 0);
		xpci_disable_msix_interrupt(g_pxdev, vec);
		napi_schedule_irqoff(&rxr->napi);
		rxr->stats.int_enabled = false;
		rxr->cmp.cmpl_prd_ptr_prev = rxr->cmp.cmpl_prd_ptr;

		return IRQ_HANDLED;
	}

	return IRQ_NONE;
}

static void xpcxd_ring_init(struct net_device *netdev, struct xpcxd_ring *ring,
			    u16 num_desc, enum xpcxd_ring_type type)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 num_sub_desc = num_desc;
	u32 num_cmpl_desc = (type == XPCXD_RING_RX)?num_desc:(num_desc/2);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: num_sub_desc: %d num_cmpl_desc: %d", num_sub_desc, num_cmpl_desc);

	ring->xd = net_priv;

	ring->sub.size = num_sub_desc;
	ring->sub.mask = num_sub_desc - 1;
	ring->sub.prod = 0;
	ring->sub.cons = 0;

	ring->cmp.size = num_cmpl_desc;
	ring->cmp.mask = num_cmpl_desc - 1;
	ring->cmp.cons = 0;
	ring->cmpl_thold = num_cmpl_desc / 2;

	ring->cmp.round_cnt = 0;

	memset(&ring->stats, 0, sizeof(struct xpcxd_stats));

	ring->stats.int_enabled = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static void xpcxd_ring_delete(struct net_device *netdev,
			      struct xpcxd_ring *ring)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (ring->type == XPCXD_RING_RX) {
		xpcxd_page_pool_free(netdev, ring);
		if (xpcxd_stat_dump_on_remove)
			xpcxd_rx_dump_debug_stats(netdev, true);
	} else {
		if (xpcxd_stat_dump_on_remove)
			xpcxd_tx_dump_debug_stats(netdev, true);
	}

	if (ring->sub.desc) {
		dma_free_coherent(net_priv->hw_dev, ring->sub.dma_size,
				  ring->sub.desc, ring->sub.dma_addr);

		ring->sub.desc = NULL;
		ring->sub.dma_addr = 0;
		ring->sub.dma_size = 0;
	}

	if (ring->cmp.desc) {
		dma_free_coherent(net_priv->hw_dev, ring->cmp.dma_size,
				  ring->cmp.desc, ring->cmp.dma_addr);

		ring->cmp.desc = NULL;
		ring->cmp.dma_addr = 0;
		ring->cmp.dma_size = 0;
	}

	if (ring->cmp.rfl_prd) {
		dma_free_coherent(net_priv->hw_dev, ring->cmp.rfl_prd_dma_size,
				ring->cmp.desc, ring->cmp.rfl_prd_dma_addr);

		ring->cmp.rfl_prd = NULL;
		ring->cmp.rfl_prd_dma_addr = 0;
		ring->cmp.rfl_prd_dma_size = 0;
	}

	if (ring->sub.rfl_cns) {
		dma_free_coherent(net_priv->hw_dev, ring->sub.rfl_cns_dma_size,
				ring->cmp.desc, ring->sub.rfl_cns_dma_addr);

		ring->sub.rfl_cns = NULL;
		ring->sub.rfl_cns_dma_addr = 0;
		ring->sub.rfl_cns_dma_size = 0;
	}

	if (ring->sub.sw) {
		kvfree(ring->sub.sw);
		ring->sub.sw = NULL;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

static int xpcxd_ring_setup(struct net_device *netdev, u32 ring_id,
			    enum xpcxd_ring_type type)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *ring = NULL;
	u16 num_desc = (type == XPCXD_RING_RX) ? net_priv->num_rx_desc :
						 net_priv->num_tx_desc;
	size_t ring_size = sizeof(struct xpcxd_desc) * num_desc;
	int err;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: ring_id: %d type: %s num_desc: %d",
			ring_id, (type == XPCXD_RING_RX ? "RX" : "TX"),
			num_desc);

	if (type == XPCXD_RING_RX)
		ring = &net_priv->rxr[ring_id];
	else
		ring = &net_priv->txr[ring_id];

	ring->ring_id = ring_id;
	ring->type = type;
	ring->sub.dma_size = ring_size;
	ring->tx_rx_enabled = (type == XPCXD_RING_RX) ? xpcxd_rx_enabled : xpcxd_tx_enabled;
	ring->db_count = 0;

	// ring->packets = 0;
	// ring->bytes = 0;
	memset(&ring->stats, 0, sizeof(struct xpcxd_stats));

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "dma_alloc_coherent(ring->sub.dma_size=%d)",
			(int)ring->sub.dma_size);
	ring->sub.desc =
		dma_alloc_coherent(net_priv->hw_dev, ring->sub.dma_size,
				   &ring->sub.dma_addr,
				   GFP_KERNEL /* | GFP_DMA*/);

	if (ring->sub.desc == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring->cmp.dma_size = ring_size;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "dma_alloc_coherent(ring->cmp.dma_size=%d)",
			(int)ring->cmp.dma_size);
	ring->cmp.desc =
		dma_alloc_coherent(net_priv->hw_dev, ring->cmp.dma_size,
				   &ring->cmp.dma_addr,
				   GFP_KERNEL /* | GFP_DMA*/);

	if (ring->cmp.desc == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring->cmp.rfl_prd_dma_size = sizeof(struct xpcxd_atomic_fifo_ctrl);
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "dma_alloc_coherent(cmp rfl prd dma_size=%d)",
			(int)ring->cmp.rfl_prd_dma_size);
	ring->cmp.rfl_prd =
		dma_alloc_coherent(net_priv->hw_dev, ring->cmp.rfl_prd_dma_size,
				   &ring->cmp.rfl_prd_dma_addr,
				   GFP_KERNEL);

	if (ring->cmp.rfl_prd == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring->sub.rfl_cns_dma_size = sizeof(struct xpcxd_atomic_fifo_ctrl);
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "dma_alloc_coherent(sub rfl cns dma_size=%d)",
			(int)ring->sub.rfl_cns_dma_size);
	ring->sub.rfl_cns =
		dma_alloc_coherent(net_priv->hw_dev, ring->sub.rfl_cns_dma_size,
				   &ring->sub.rfl_cns_dma_addr,
				   GFP_KERNEL);

	if (ring->sub.rfl_cns == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}

	ring_size = sizeof(struct xpcxd_sw_desc) * num_desc;
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
			 "SW descriptors ring_size(%d) (bytes)",
			 (int)ring_size);
	ring->sub.sw = kvzalloc(ring_size, GFP_KERNEL);
	if (ring->sub.sw == NULL) {
		err = -ENOMEM;
		goto cleanup;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "kvzalloc() ring->sub.sw: [%p]", ring->sub.sw);

	ring->page_pool = NULL;

	if (type == XPCXD_RING_RX) {
		/* Create a page_pool and register it with rxq */
		struct page_pool_params pp_params = { 0 };
		int i;
		/* We silently assume that Rx buffer is more than (PAGE_SIZE / 2). PAGE_SIZE is 4k on x86_64 */

		if (xpcxd_legacy_skb_alloc) {
			pp_params.order     = net_priv->rx_buf_size / PAGE_SIZE;
			pp_params.flags     = PP_FLAG_DMA_MAP | PP_FLAG_DMA_SYNC_DEV /*| ~PP_FLAG_PAGE_FRAG*/;

			pp_params.pool_size = num_desc;
			pp_params.nid       = NUMA_NO_NODE; // dev_to_node(net_priv->hw_dev);
			pp_params.dev       = net_priv->hw_dev;
			pp_params.dma_dir   = DMA_FROM_DEVICE;
			pp_params.offset 	= 0;
			pp_params.max_len   = (net_priv->rx_buf_size); 
		} else {
			pp_params.order     = 0;
			pp_params.flags     = PP_FLAG_DMA_MAP /*| PP_FLAG_DMA_SYNC_DEV*/ /*| ~PP_FLAG_PAGE_FRAG*/;
			pp_params.pool_size = num_desc;
			pp_params.nid       = NUMA_NO_NODE; // dev_to_node(net_priv->hw_dev);
			pp_params.dev       = net_priv->hw_dev;
			pp_params.dma_dir   = DMA_FROM_DEVICE;
			pp_params.offset 	= 0;
			pp_params.max_len   = PAGE_SIZE; // XPCXD_FRAG_DATA_SIZE /* - XDP_PACKET_HEADROOM*/;
			// - SKB_DATA_ALIGN(sizeof(struct skb_shared_info)));
		}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 4, 0)
		pp_params.napi 		= ring->napi;
#endif

		/* page_pool can be used even when there is no rq->xdp_prog,
		 * given page_pool does not handle DMA mapping there is no
		 * required state to clear. And page_pool gracefully handle
		 * elevated refcnt.
		 */
		ring->page_pool = xpcxd_page_pool_create(&pp_params);
		if (IS_ERR(ring->page_pool)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "Rx Page page_pool alloc error");
			ring->page_pool = NULL;
			err = -ENOMEM;
			goto cleanup;
		}

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				"[%d] RX xpcxd_page_pool_create(): order: %d pool_size: %d max_len: %d",
				ring_id, pp_params.order, pp_params.pool_size, pp_params.max_len);

		for (i = 0; i < ring_size; i++)
			ring->sub.sw->page_state = XPCXD_PAGE_FREE;

		ring->sub.db = net_priv->rx_db;
	} else {
		ring->sub.db = net_priv->tx_db;

		spin_lock_init(&ring->tx_lock);
	}

	xpcxd_ring_init(netdev, ring, num_desc, type);

	/* Numebr of Tx descriptors is * 2 because of the pair MD/BD in each transmit */
	/* Because of that the real number of completions is / 2 (Numebr of Tx desc) */
	if (type == XPCXD_RING_TX)
		ring->cmp.mask = (num_desc / 2) - 1;
	
	if (xpcxd_timer_isr_mode) {
		hrtimer_init(&ring->time_isr,
				CLOCK_MONOTONIC, HRTIMER_MODE_REL);

		ring->time_isr.function =
			&xpcxd_ring_time_isr;

		time_isr_ktime = ms_to_ktime(xpcxd_timer_isr_wakeup_time);

		xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "Arming Timer ISR");
		hrtimer_start(&ring->time_isr,
					ms_to_ktime(xpcxd_timer_isr_wakeup_time),
					HRTIMER_MODE_REL);
	}

	if ((type == XPCXD_RING_TX) && xpcxd_tx_coales_isr_mode) {
		hrtimer_init(&ring->tx_coales_isr,
				CLOCK_MONOTONIC, HRTIMER_MODE_REL);

		ring->tx_coales_isr.function =
			&xpcxd_ring_tx_coales_isr;

		tx_coalescing_ktime = ms_to_ktime(xpcxd_tx_coales_isr_wakeup_time);

		xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "Arming Tx Coalescing ISR");
		hrtimer_start(&ring->tx_coales_isr,
					ms_to_ktime(xpcxd_tx_coales_isr_wakeup_time),
					HRTIMER_MODE_REL);
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
cleanup:
	if (ring->page_pool) 
		page_pool_destroy(ring->page_pool);

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "ERR OUT");

	xpcxd_ring_delete(netdev, ring);
	return err;
}

static int xpcxd_rx_ring_configure(struct net_device *netdev, u32 ring_id,
				   bool active)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_rx_sbm_rng_tbl_t rx_sbm_rng_tbl = { 0 };
	xreg_pcxd_memcfg_rx_prf_rgl_rng_tbl_t rx_prf_rgl_rng_tbl = { 0 };
	xreg_pcxd_memcfg_rx_cmp_rng_tbl_t rx_cmp_rng_tb = { 0 };
	xreg_pcxd_memcfg_rx_rng_rfl_ctrl_tbl_t rx_rng_rfl_ctrl = { 0 };
	xreg_pcxd_memcfg_rx_rng_rfl_addr_tbl_t rx_rng_rfl_addr = { 0 };
	u16 num_desc = XPCXD_RING_DSC_BUFFERS / net_priv->num_rings;
	u16 buff_offset = ring_id * num_desc;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Granularity is in 4K Pages - TODO: Check */
	xpcxd_dbg(NETIF_MSG_DRV,
		"RX_SBM_RNG_TBL_SBM_RING_BASE_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].sub.desc,
		(u64)net_priv->rxr[ring_id].sub.dma_addr);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_BASE_ADRS_SET(
		rx_sbm_rng_tbl, (u64)net_priv->rxr[ring_id].sub.dma_addr);
	/* Size to be in ^2 --> see __roundup_pow_of_two() */
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_SIZE[%d]: 0x%x", ring_id,
		net_priv->rxr[ring_id].sub.size);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_SIZE_SET(
		rx_sbm_rng_tbl, net_priv->rxr[ring_id].sub.size);

	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET[%d]: %d", ring_id,
		buff_offset);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET(
		rx_sbm_rng_tbl,
		buff_offset);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET[%d]: %d", ring_id,
		num_desc);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET(
		rx_sbm_rng_tbl,
		num_desc);

	// Reflection on Submit
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET:%d",
		 xpcxd_rx_sbm_rfl_mode);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET(
		rx_sbm_rng_tbl, xpcxd_rx_sbm_rfl_mode);
	// f. set, for active ring
	xpcxd_dbg(NETIF_MSG_DRV, "RX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET:%d", active);
	XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET(rx_sbm_rng_tbl,
							     active);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_SBM_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_sbm_rng_tbl_t) /* Size */,
		(void *)&rx_sbm_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV, "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE_SET:%d", 0);
	XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE_SET(
		rx_prf_rgl_rng_tbl, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN_SET:%d", 0);
	XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN_SET(
		rx_prf_rgl_rng_tbl, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL_SET:%d", 0);
	XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL_SET(
		rx_prf_rgl_rng_tbl, 0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_PRF_RGL_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_prf_rgl_rng_tbl_t) /* Size */,
		(void *)&rx_prf_rgl_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	// Addr in 4K pages
	xpcxd_dbg(NETIF_MSG_DRV,
		"RX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].cmp.desc,
		(u64)net_priv->rxr[ring_id].cmp.dma_addr);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET(
		rx_cmp_rng_tb, (u64)net_priv->rxr[ring_id].cmp.dma_addr);
	// Set size in ^2 values
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_SIZE_SET[%d]: %d", ring_id,
		 net_priv->rxr[ring_id].cmp.size);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_SIZE_SET(
		rx_cmp_rng_tb, net_priv->rxr[ring_id].cmp.size);
	// Cmpl Reflection
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET[%d]: %d", ring_id,
		 xpcxd_rx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET(
		rx_cmp_rng_tb, xpcxd_rx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET[%d]: %d", ring_id,
		 xpcxd_rx_coales_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET(
		rx_cmp_rng_tb, xpcxd_rx_coales_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET[%d]: %d", ring_id,
		 xpcxd_rx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET(
		rx_cmp_rng_tb, xpcxd_rx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET[%d]: %d", ring_id,
		 !xpcxd_rx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET(
		rx_cmp_rng_tb, !xpcxd_rx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET[%d]: %d", ring_id,
		 !xpcxd_rx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET(
		rx_cmp_rng_tb, !xpcxd_rx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_CLS_DSC_NUM_SET(
		rx_cmp_rng_tb, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET[%d]: %d", ring_id,
		xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET(
		rx_cmp_rng_tb, xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET[%d]: %d", ring_id,
		xpcxd_rx_coales_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET(
		rx_cmp_rng_tb, xpcxd_rx_coales_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_ADR_ECHO_MODE_SET(
		rx_cmp_rng_tb, 0);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_CRD_CMP_ENG_DSC_VLD_MODE_SET(
		rx_cmp_rng_tb, xpcxd_rx_valid_mode);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_FRM_DATA_ENDIAN_TYPE_SET(rx_cmp_rng_tb,
								 0);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_FRM_MDATA_ENDIAN_TYPE_SET(rx_cmp_rng_tb,
								  0);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_FNC_INT_CLS_MODE_SET(rx_cmp_rng_tb, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "RX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET: 0x%x", 0xFE);
	XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET(rx_cmp_rng_tb,
							    0xFE);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL",
		XREG_PCXD_MEMCFG_RX_CMP_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_cmp_rng_tbl_t) /* Size */,
		(void *)&rx_cmp_rng_tb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV, "RX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET:[%d]",
		xpcxd_cfg_tbl[xpcxd_rx_coales_size]);
	XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET(
		rx_rng_rfl_ctrl, xpcxd_cfg_tbl[xpcxd_rx_coales_size]);

	xpcxd_dbg(NETIF_MSG_DRV, "RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET:[%s]",
		xpcxd_cfg_tbl[xpcxd_rx_coales_time]?"ENABLED":"DISABLED");
	XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET(
		rx_rng_rfl_ctrl, xpcxd_cfg_tbl[xpcxd_rx_coales_time]?1:0);

	xpcxd_dbg(NETIF_MSG_DRV, "RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET:[%d]",
		xpcxd_cfg_tbl[xpcxd_rx_coales_time]);
	XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET(
		rx_rng_rfl_ctrl, xpcxd_cfg_tbl[xpcxd_rx_coales_time]);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL",
		XREG_PCXD_MEMCFG_RX_RNG_RFL_CTRL_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_rng_rfl_ctrl_tbl_t) /* Size */,
		(void *)&rx_rng_rfl_ctrl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

#ifdef __XPCXD_RX_SUB_RFL__
	xpcxd_dbg(NETIF_MSG_DRV,
		"RX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].sub.rfl_cns,
		(u64)net_priv->rxr[ring_id].sub.rfl_cns_dma_addr);
	XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET(
		rx_rng_rfl_addr,
		(u64)net_priv->rxr[ring_id].sub.rfl_cns_dma_addr);
#endif

	xpcxd_dbg(NETIF_MSG_DRV,
		"RX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->rxr[ring_id].cmp.rfl_prd,
		(u64)net_priv->rxr[ring_id].cmp.rfl_prd_dma_addr);
	XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET(
		rx_rng_rfl_addr,
		(u64)net_priv->rxr[ring_id].cmp.rfl_prd_dma_addr);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL",
		XREG_PCXD_MEMCFG_RX_RNG_RFL_ADDR_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_rng_rfl_addr_tbl_t) /* Size */,
		(void *)&rx_rng_rfl_addr);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]) {
		xreg_pcxd_rx_prsr_bypass_t rx_prsr_bypass = {0};

		if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] == xpcxd_selective_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				"RX_PRSR_BYPASS_SELECTIVE_SET[%d]: [0x%d]",
				ring_id, xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]);
			XREG_PCXD_RX_PRSR_BYPASS_SELECTIVE_SET(
				rx_prsr_bypass,
				1);
		}

		if (xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass] == xpcxd_global_bypass) {
			xpcxd_dbg(NETIF_MSG_DRV,
				"RX_PRSR_BYPASS_GLOBAL_SET[%d]: [0x%d]",
				ring_id, xpcxd_cfg_tbl[xpcxd_rx_checksum_bypass]);
			XREG_PCXD_RX_PRSR_BYPASS_GLOBAL_SET(
				rx_prsr_bypass,
				1);
		}

		xpci_write64("XREG_PCXD_RX_PRSR_BYPASS_ADDR",
				XREG_PCXD_RX_PRSR_BYPASS_ADDR,
				XREG_PCXD_RX_PRSR_BYPASS_GET(rx_prsr_bypass));

		xpcxd_dbg(NETIF_MSG_DRV,
			"-----------------------------------------------------------------");
	}

	if (xpcxd_cfg_tbl[xpcxd_rx_shaper]) {
		xreg_pcxd_memcfg_rx_ch_tm_shp_tbl_t rx_ch_tm_shp_tb = { 0 };
		xreg_pcxd_rx_shp_glb_actv_t rx_shp_glb_actv = { 0 };

		xpcxd_dbg(NETIF_MSG_DRV,
			"PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MAX_BURST_SIZE_SET[%d]: [0x%x]",
			ring_id,
			0x100);
		XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MAX_BURST_SIZE_SET(
			rx_ch_tm_shp_tb,
			0x100);

		xpcxd_dbg(NETIF_MSG_DRV,
			"PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_SIZE_SET[%d]: [0x%x]",
			ring_id,
			0x9c);
		XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_SIZE_SET(
			rx_ch_tm_shp_tb,
			0x9c);

		xpcxd_dbg(NETIF_MSG_DRV,
			"PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_PERIOD_SET[%d]: [0x%x]",
			ring_id,
			0x7D);
		XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_TOKEN_INC_PERIOD_SET(
			rx_ch_tm_shp_tb,
			0x7D);

		xpcxd_dbg(NETIF_MSG_DRV,
			"PCXD_MEMCFG_RX_CH_TM_SHP_TBL_BYPASS_SET[%d]: [0x%d]",
			ring_id,
			0x0);
		XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_BYPASS_SET(
			rx_ch_tm_shp_tb,
			0x0);

		ret = xdrv_mem_ind_write(
			"XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_ADDR",
			XREG_PCXD_MEMCFG_RX_CH_TM_SHP_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_ch_tm_shp_tbl_t) /* Size */,
			(void *)&rx_ch_tm_shp_tb);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
			return -1;
		}

		xpcxd_dbg(NETIF_MSG_DRV,
			"XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_SET[%d]: [0x%d]",
			ring_id, 1);
		XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_SET(
			rx_shp_glb_actv,
			1);

		xpcxd_dbg(NETIF_MSG_DRV,
			"XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_GET[%d]: [0x%d]",
			ring_id, XREG_PCXD_RX_SHP_GLB_ACTV_ACTV_GET(rx_shp_glb_actv));

		xpci_write64("XREG_PCXD_RX_SHP_GLB_ACTV_ADDR",
				XREG_PCXD_RX_SHP_GLB_ACTV_ADDR,
				XREG_PCXD_RX_SHP_GLB_ACTV_GET(rx_shp_glb_actv));
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV,  netdev, "OUT");

	return 0;
}

/* TODO: Remove this routine when it will be removed from the PCXD block design */
static int xpcxd_msix_control(void)
{
	xreg_pcxd_msix_ctrl_t msix_ctrl = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MSIX_CTRL_VEC_OFFSET_SET: [%d]", 1);
	XREG_PCXD_MSIX_CTRL_VEC_OFFSET_SET(
		msix_ctrl,
		1); /* 2 bits field, Offset is rounded to 16, must be 1 */

	xpci_write64("XREG_PCXD_MSIX_CTRL", XREG_PCXD_MSIX_CTRL_ADDR,
		     XREG_PCXD_MSIX_CTRL_GET(msix_ctrl));

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

int xpcxd_rx_activate(bool activate)
{
	xreg_pcxd_rx_glb_active_t rx_glb_active = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "RX_GLB_ACTIVE_SET: [%s]", activate ? "SET" : "CLEAR");
	XREG_PCXD_RX_GLB_ACTIVE_SET(rx_glb_active, activate);

	xpci_write64("XREG_PCXD_RX_GLB_ACTIVE_ADDR",
		     XREG_PCXD_RX_GLB_ACTIVE_ADDR,
		     XREG_PCXD_RX_GLB_ACTIVE_GET(rx_glb_active));

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_rx_ring_active(u32 ring_num, bool activate)
{
	xreg_pcxd_memcfg_rx_ring_actv_tbl_t rx_ring_active = { 0 };
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "RX_RING_ACTV_TBL_ACTV_SET[%d]: [%s]", ring_num,
		 activate ? "SET" : "CLEAR");
	XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL_SET(rx_ring_active, activate);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL",
		XREG_PCXD_MEMCFG_RX_RING_ACTV_TBL_MSEL_ID /* Msel */,
		ring_num /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_ring_actv_tbl_t) /* Size */,
		(void *)&rx_ring_active);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_tx_ring_configure(struct net_device *netdev, u32 ring_id,
				   bool active)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_tx_pause_ring_tbl_t tx_pause_tbl = { 0 };
	xreg_pcxd_memcfg_tx_sbm_rng_tbl_t tx_sbm_rng_tbl = { 0 };
	xreg_pcxd_memcfg_tx_prf_rgl_rng_tbl_t tx_prf_rgl_rng_tbl = { 0 };
	xreg_pcxd_memcfg_tx_cmp_rng_tbl_t tx_cmp_rng_tb = { 0 };
	xreg_pcxd_memcfg_tx_rng_rfl_ctrl_tbl_t tx_rng_rfl_ctrl = { 0 };
	xreg_pcxd_memcfg_tx_rng_rfl_addr_tbl_t tx_rng_rfl_addr = { 0 };
	u16 num_desc = XPCXD_RING_DSC_BUFFERS / net_priv->num_rings;
	u16 buff_offset = ring_id * num_desc;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV,  netdev, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_PAUSE_SET[%d]: %d",
		 ring_id, 0);
	XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_PAUSE_SET(tx_pause_tbl, 0);
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_pause_ring_tbl_t) /* Size */,
		(void *)&tx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	/* Granularity is in 4K Pages --> TODO: Check */
	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_SBM_RNG_TBL_SBM_RING_BASE_ADRS[%d]: [0x%llx] --> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].sub.desc,
		(u64)net_priv->txr[ring_id].sub.dma_addr);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_BASE_ADRS_SET(
		tx_sbm_rng_tbl, (u64)net_priv->txr[ring_id].sub.dma_addr);
	/* Size to be in ^2 --> see __roundup_pow_of_two() */
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_SIZE[%d]: 0x%x", ring_id,
		 net_priv->txr[ring_id].sub.size);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_SIZE_SET(
		tx_sbm_rng_tbl, net_priv->txr[ring_id].sub.size);

	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET[%d]: %d",
		ring_id,
		buff_offset);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_OFST_SET(
		tx_sbm_rng_tbl,
		buff_offset);
	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET[%d]: %d",
		ring_id,
		num_desc);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_DSC_BFR_SIZE_SET(
		tx_sbm_rng_tbl,
		num_desc);
	// e. clear
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET:%d",
		 xpcxd_tx_sbm_rfl_mode);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_RFL_EN_SET(
		tx_sbm_rng_tbl, xpcxd_tx_sbm_rfl_mode);
	// f. set, for active ring
	xpcxd_dbg(NETIF_MSG_DRV, "TX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET: %d", active);
	XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_SBM_RING_ACTV_EN_SET(tx_sbm_rng_tbl,
							     active);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_SBM_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_sbm_rng_tbl_t) /* Size */,
		(void *)&tx_sbm_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_RGL_MODE_SET(
		tx_prf_rgl_rng_tbl, 0);
	XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_EN_SET(
		tx_prf_rgl_rng_tbl, 0);
	XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_SRD_PRF_ENG_EXP_TMR_VAL_SET(
		tx_prf_rgl_rng_tbl, 0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_PRF_RGL_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_prf_rgl_rng_tbl_t) /* Size */,
		(void *)&tx_prf_rgl_rng_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	// Addr in 4K pages --> TODO: Check
	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET[%d]: [0x%llx] --> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].cmp.desc,
		(u64)net_priv->txr[ring_id].cmp.dma_addr);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_BASE_ADRS_SET(
		tx_cmp_rng_tb, (u64)net_priv->txr[ring_id].cmp.dma_addr);
	// Set size in ^2 values
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_SIZE_SET[%d]: %d", ring_id,
		 net_priv->txr[ring_id].cmp.size);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_SIZE_SET(
		tx_cmp_rng_tb, net_priv->txr[ring_id].cmp.size);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET[%d]: %d", ring_id,
		xpcxd_tx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_EN_SET(
		tx_cmp_rng_tb, xpcxd_tx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET[%d]: %d", ring_id,
		 xpcxd_tx_coales_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_CLS_EN_SET(
		tx_cmp_rng_tb, xpcxd_tx_coales_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET[%d]: %d", ring_id,
		 xpcxd_tx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_RFL_INT_EN_SET(
		tx_cmp_rng_tb, xpcxd_tx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET[%d]: %d", ring_id,
		 !xpcxd_tx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_HW_INT_EN_SET(
		tx_cmp_rng_tb, !xpcxd_tx_cmp_rfl_mode);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET[%d]: %d", ring_id,
		 !xpcxd_tx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CMP_RING_SW_INT_EN_SET(
		tx_cmp_rng_tb, !xpcxd_tx_cmp_rfl_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_CLS_DSC_NUM_SET(
		tx_cmp_rng_tb, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET[%d]: %d", ring_id,
		xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_VAL_SET(
		tx_cmp_rng_tb, xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET[%d]: %d", ring_id,
		xpcxd_tx_coales_mode);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_EXP_TMR_EN_SET(
		tx_cmp_rng_tb, xpcxd_tx_coales_mode);

	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_ADR_ECHO_MODE_SET(
		tx_cmp_rng_tb, 0);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_CRD_CMP_ENG_DSC_VLD_MODE_SET(
		tx_cmp_rng_tb,
		1); /* Software sets valid bit to zero each time cmpl desc consumed */
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_TM_SHP_EN_SET(tx_cmp_rng_tb, 0);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_FRM_DATA_ENDIAN_TYPE_SET(tx_cmp_rng_tb,
								 0);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_FRM_MDATA_ENDIAN_TYPE_SET(tx_cmp_rng_tb,
								  0);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_FNC_INT_CLS_MODE_SET(tx_cmp_rng_tb, 0);
	xpcxd_dbg(NETIF_MSG_DRV, "TX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET: 0x%x", 0xFE);
	XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_FNC_INT_CLS_VAL_SET(tx_cmp_rng_tb,
							    0xFE);

	xpcxd_dbg(NETIF_MSG_DRV, "XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL[%d]", ring_id);
	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL",
		XREG_PCXD_MEMCFG_TX_CMP_RNG_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_cmp_rng_tbl_t) /* Size */,
		(void *)&tx_cmp_rng_tb);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV, "TX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET:[%d]",
		xpcxd_cfg_tbl[xpcxd_tx_coales_size]);
	XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_CRD_SRD_RFL_CLS_VAL_SET(
		tx_rng_rfl_ctrl, xpcxd_cfg_tbl[xpcxd_tx_coales_size]);

	xpcxd_dbg(NETIF_MSG_DRV, "TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET:[%s]",
		"ENABLED");
	XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_EN_SET(
		tx_rng_rfl_ctrl, 1);

	xpcxd_dbg(NETIF_MSG_DRV, "TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET:[%d]",
		xpcxd_cfg_tbl[xpcxd_tx_coales_time]);
	XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_RFL_CLS_EXP_TMR_VAL_SET(
		tx_rng_rfl_ctrl, xpcxd_cfg_tbl[xpcxd_tx_coales_time]);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL",
		XREG_PCXD_MEMCFG_TX_RNG_RFL_CTRL_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_rng_rfl_ctrl_tbl_t) /* Size */,
		(void *)&tx_rng_rfl_ctrl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].cmp.rfl_prd,
		(u64)net_priv->txr[ring_id].cmp.rfl_prd_dma_addr);
	XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_CRD_PRD_RFL_ADRS_SET(
		tx_rng_rfl_addr,
		(u64)net_priv->txr[ring_id].cmp.rfl_prd_dma_addr);
	xpcxd_dbg(NETIF_MSG_DRV,
		"TX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET[%d]: [0x%llx] ---> DMA: [0x%llx]",
		ring_id, (u64)net_priv->txr[ring_id].sub.rfl_cns,
		(u64)net_priv->txr[ring_id].sub.rfl_cns_dma_addr);
	XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_SRD_CNS_RFL_ADRS_SET(
		tx_rng_rfl_addr,
		(u64)net_priv->txr[ring_id].sub.rfl_cns_dma_addr);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL",
		XREG_PCXD_MEMCFG_TX_RNG_RFL_ADDR_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_rng_rfl_addr_tbl_t) /* Size */,
		(void *)&tx_rng_rfl_addr);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");


	if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]) {
		xreg_pcxd_tx_prsr_bypass_t tx_prsr_bypass = {0};

		if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] == xpcxd_selective_bypass) {
		xpcxd_dbg(NETIF_MSG_DRV,
			"TX_PRSR_BYPASS_SELECTIVE_SET[%d]: [0x%d]",
				ring_id, xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]);
#ifdef __XPCXD_TX_PRSR_BYPASS_SELECTIVE_SET__
		XREG_PCXD_TX_PRSR_BYPASS_SELECTIVE_SET(
			tx_prsr_bypass,
			1);
#else
		xpcxd_dbg(NETIF_MSG_DRV,
			"skip setting TX_PRSR_BYPASS_SELECTIVE_SET[%d]", ring_id);
#endif
		}

		if (xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass] == xpcxd_global_bypass) {
		xpcxd_dbg(NETIF_MSG_DRV,
			"TX_PRSR_BYPASS_GLOBAL_SET[%d]: [0x%d]",
				ring_id, xpcxd_cfg_tbl[xpcxd_tx_checksum_bypass]);
		XREG_PCXD_TX_PRSR_BYPASS_GLOBAL_SET(
			tx_prsr_bypass,
			1);
	}

	xpci_write64("XREG_PCXD_TX_PRSR_BYPASS_ADDR",
			XREG_PCXD_TX_PRSR_BYPASS_ADDR,
			XREG_PCXD_TX_PRSR_BYPASS_GET(tx_prsr_bypass));

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV,  netdev, "OUT");

	return 0;
}

int xpcxd_tx_activate(bool activate)
{
	xreg_pcxd_tx_glb_active_t tx_glb_active = { 0 };

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "TX_GLB_ACTIVE_SET: [%s]", activate ? "SET" : "CLEAR");
	XREG_PCXD_TX_GLB_ACTIVE_SET(tx_glb_active, activate);

	xpci_write64("XREG_PCXD_TX_GLB_ACTIVE_ADDR",
		     XREG_PCXD_TX_GLB_ACTIVE_ADDR,
		     XREG_PCXD_TX_GLB_ACTIVE_GET(tx_glb_active));

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_tx_ring_active(u32 ring_num, bool activate)
{
	xreg_pcxd_memcfg_tx_ring_actv_tbl_t tx_ring_active = { 0 };
	int ret = 0;

	// xpcxd_dbg(NETIF_MSG_DRV, "IN");

	xpcxd_dbg(NETIF_MSG_DRV, "TX_RING_ACTV_TBL_ACTV_SET[%d]: [%s]", ring_num,
		 activate ? "SET" : "CLEAR");
	XREG_PCXD_MEMCFG_TX_RING_ACTV_TBL_SET(tx_ring_active, activate);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_RING_ACTV_TBL",
		XREG_PCXD_MEMCFG_TX_RING_ACTV_TBL_MSEL_ID /* Msel */,
		ring_num /* Row */,
		sizeof(xreg_pcxd_memcfg_tx_ring_actv_tbl_t) /* Size */,
		(void *)&tx_ring_active);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return -1;
	}

	xpcxd_dbg(NETIF_MSG_DRV,
		"-----------------------------------------------------------------");

	// xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static int xpcxd_rx_pause_set(u32 ring_id, bool set)
{
	xreg_pcxd_memcfg_rx_pause_ring_tbl_t rx_pause_tbl = {0};
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_RX_PAUSE_RING_TBL_SET[%d]: [%s]", ring_id,
		set?"SET":"CLEAR");
	XREG_PCXD_MEMCFG_RX_PAUSE_RING_TBL_SET(
		rx_pause_tbl, set?1:0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_RX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_RX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_pause_ring_tbl_t) /* Size */,
		(void *)&rx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return ret;
	}

	return 0;
}

static int xpcxd_tx_pause_set(u32 ring_id, bool set)
{
	xreg_pcxd_memcfg_rx_pause_ring_tbl_t tx_pause_tbl = {0};
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD_MEMCFG_TX_PAUSE_RING_TBL_SET[%d]: [%s]", ring_id,
		set?"SET":"CLEAR");
	XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_SET(
		tx_pause_tbl, set?1:0);

	ret = xdrv_mem_ind_write(
		"XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL",
		XREG_PCXD_MEMCFG_TX_PAUSE_RING_TBL_MSEL_ID /* Msel */,
		ring_id /* Row */,
		sizeof(xreg_pcxd_memcfg_rx_pause_ring_tbl_t) /* Size */,
		(void *)&tx_pause_tbl);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_write() failed: %d", ret);
		return ret;
	}

	return 0;
}

int xpcxd_dev_rx_disable(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_rx_busy_ring_tbl_t rx_busy_tbl = {0};
	bool busy = true;
	int i = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV,  netdev, "IN");

	/* 1. Set PAUSE ring bit */
	xpcxd_rx_pause_set(ring_id, true);

	/* 2. Wait for the busy ring bit */
	for (i = 0; i < 100; i++) {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_RX_BUSY_RING_TBL",
			XREG_PCXD_MEMCFG_RX_BUSY_RING_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_rx_busy_ring_tbl_t) /* Size */,
			(void *)&rx_busy_tbl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return -1;
		}

		if (!XREG_PCXD_MEMCFG_RX_BUSY_RING_TBL_BUSY_GET(rx_busy_tbl)) {
			busy = false;
			break;
		}

		xpcxd_err(NETIF_MSG_DRV, "Rx ring busy - waiting");
		udelay(10);
	}

	if (busy) {
		xpcxd_err(NETIF_MSG_DRV, "Rx ring still busy - can't perform graceful stop");

		xpcxd_rx_dump_debug_stats(netdev, false);

		return -1;
	}

	/* 3. Deactivate the ring */
	xpcxd_rx_ring_active(ring_id, false);

	net_priv->rxr[ring_id].tx_rx_enabled = false;

	xpcxd_dbg_netdev(NETIF_MSG_DRV,  netdev, "OUT");

	return 0;
}

int xpcxd_dev_tx_disable(struct net_device *netdev, u32 ring_id)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	xreg_pcxd_memcfg_rx_busy_ring_tbl_t tx_busy_tbl = {0};
	bool busy = true;
	int i = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* 1. Set PAUSE ring bit */
	xpcxd_tx_pause_set(ring_id, true);

	/* 2. Wait for the busy ring bit */
	for (i = 0; i < 100; i++) {
		ret = xdrv_mem_ind_read(
			"XREG_PCXD_MEMCFG_TX_BUSY_RING_TBL",
			XREG_PCXD_MEMCFG_TX_BUSY_RING_TBL_MSEL_ID /* Msel */,
			ring_id /* Row */,
			sizeof(xreg_pcxd_memcfg_tx_busy_ring_tbl_t) /* Size */,
			(void *)&tx_busy_tbl);
		if (ret) {
			xpcxd_err(NETIF_MSG_DRV, "xdrv_mem_ind_read() failed: %d", ret);
			return ret;
		}

		if (!XREG_PCXD_MEMCFG_TX_BUSY_RING_TBL_BUSY_GET(tx_busy_tbl)) {
			busy = false;
			break;
		}

		xpcxd_err(NETIF_MSG_DRV, "Tx ring busy - waiting");
		udelay(10);
	}

	if (busy) {
		xpcxd_err(NETIF_MSG_DRV, "Tx ring still busy - can't perform graceful stop");
		return -1;
	}

	/* 3. Deactivate the ring */
	xpcxd_tx_ring_active(ring_id, false);

	net_priv->txr[ring_id].tx_rx_enabled = false;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_dev_rx_enable(struct net_device *netdev, bool rx_activate)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_rx_pause_set(ring_id, false);
		xpcxd_rx_ring_active(ring_id, true);
	}

	xpcxd_rx_activate(rx_activate);

	net_priv->rxr[ring_id].tx_rx_enabled = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

int xpcxd_dev_tx_enable(struct net_device *netdev, bool tx_activate)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_tx_pause_set(ring_id, false);
		xpcxd_tx_ring_active(ring_id, true);
	}

	xpcxd_tx_activate(tx_activate);

	net_priv->txr[ring_id].tx_rx_enabled = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static void xpcxd_tx_graceful_stop_init(void)
{
	xreg_pcxd_tx_graceful_stop_init_t tx_gcfl_stop_init = { 0 };

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	XREG_PCXD_TX_GRACEFUL_STOP_INIT_SET(tx_gcfl_stop_init, 0);

	xpci_write64("XREG_PCXD_TX_GRACEFUL_STOP_INIT",
		     XREG_PCXD_TX_GRACEFUL_STOP_INIT_ADDR,
		     XREG_PCXD_TX_GRACEFUL_STOP_INIT_GET(tx_gcfl_stop_init));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static void xpcxd_rx_graceful_stop_init(void)
{
	xreg_pcxd_rx_graceful_stop_init_t rx_gcfl_stop_init = { 0 };

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	XREG_PCXD_RX_GRACEFUL_STOP_INIT_SET(rx_gcfl_stop_init, 0);

	xpci_write64("XREG_PCXD_RX_GRACEFUL_STOP_INIT",
		     XREG_PCXD_RX_GRACEFUL_STOP_INIT_ADDR,
		     XREG_PCXD_RX_GRACEFUL_STOP_INIT_GET(rx_gcfl_stop_init));

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

static int xpcxd_dev_reset(struct net_device *netdev)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	// xpcxd_dev_disable(netdev);
	// xpcxd_dev_enable(netdev);
	xpcxd_tx_graceful_stop_init();
	xpcxd_rx_graceful_stop_init();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static void xpcxd_disable_interrupts(void)
{
	int vec;

	for (vec = XPCI_X2_PCXD_INT_FIRST; vec < XPCI_X2_PCXD_INT_MAX; vec++) {
		if (!g_pxdev->irq_tbl[vec].allocated)
			continue;
		xpci_dbg("Disabling interrupt vector [%s]:%d", 
			g_pxdev->irq_tbl[vec].name, vec);
		xpci_disable_msix_interrupt(g_pxdev, vec);
	}
}

static int xpcxd_config(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct xpcxd_ring *rxr = NULL;
	u32 ring_id = 0;
	int ret = 0;
	int orig_debug_level = xpci_debug_level;
	char if_name[XPCXD_IF_NAME_SIZE] = {0};
	u16 processed = 0;

	xpci_debug_level = XPCI_DBG_LEVEL__INFO;

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev,
			  "--- Device configuration started ---");

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: num_rx_desc: %d num_tx_desc:%d ", 
		net_priv->num_rx_desc,
		net_priv->num_tx_desc);

	net_priv->num_rx_desc = __roundup_pow_of_two(net_priv->num_rx_desc);
	if (net_priv->num_rx_desc > XPCXD_MAX_RING_SIZE)
		net_priv->num_rx_desc = XPCXD_MAX_RING_SIZE;

	net_priv->num_tx_desc = __roundup_pow_of_two(net_priv->num_tx_desc *
						     XPCXD_NUM_TXD_PER_PKT);
	if (net_priv->num_tx_desc > XPCXD_MAX_RING_SIZE)
		net_priv->num_tx_desc = XPCXD_MAX_RING_SIZE;

	if (net_priv->num_rings > XPCXD_MAX_RING_NUM) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"open: Wrong number of rings: %d MAX: %d",
				net_priv->num_rings, XPCXD_MAX_RING_NUM);
		return -EINVAL;
	}

	/* If budget > ring size then NAPI will stall */
	/* Fix the budget if needed                   */
	if (xpcxd_rx_budget > net_priv->num_rx_desc) {
		xpcxd_err_netdev(NETIF_MSG_DRV,
			netdev, "Rx budget adjusted: %d --> %d",
			xpcxd_rx_budget, net_priv->num_rx_desc);
		xpcxd_rx_budget = net_priv->num_rx_desc;
	}

	if (xpcxd_tx_budget > net_priv->num_tx_desc) {
		xpcxd_err_netdev(NETIF_MSG_DRV,
			netdev, "Tx budget adjusted: %d --> %d",
			xpcxd_tx_budget, net_priv->num_tx_desc);
		xpcxd_tx_budget = net_priv->num_tx_desc;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "TXR start: [%p]",
			 net_priv->txr);

	// NAPI Add
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV,
			netdev, "netif_napi_add() Ring[%d] Rxr: [%p] Txr: [%p]",
			ring_id, &net_priv->rxr[ring_id],
			&net_priv->txr[ring_id]);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 1, 0)
		netif_napi_add(netdev, &net_priv->rxr[ring_id].napi,
			       xpcxd_rx_poll);
#else
		netif_napi_add(netdev, &net_priv->rxr[ring_id].napi,
			       xpcxd_rx_poll, xpcxd_rx_budget);
#endif
		netif_tx_napi_add(netdev, &net_priv->txr[ring_id].napi,
				  xpcxd_tx_poll, xpcxd_tx_budget);

		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev,
				   "napi_enable() Ring[%d] Rxr: [%p] Txr: [%p]",
				   ring_id, &net_priv->rxr[ring_id],
				   &net_priv->txr[ring_id]);
		napi_enable(&net_priv->rxr[ring_id].napi);
		napi_enable(&net_priv->txr[ring_id].napi);
	}

	if (xpcxd_rss_enabled) {
		ret = xpcxd_rss_config();
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RSS Configuration failed: %d",
					ret);
			goto cleanup;
		}
	}

	/* TODO: Change this very simple approach to more flexible and configurable way */
	net_priv->num_rx_queues = net_priv->num_rings;
	net_priv->num_tx_queues = net_priv->num_rings;

	net_priv->rx_buf_size = xpcxd_default_mtu - XPCXD_FRAG_OFFSET;
	net_priv->tx_buf_size = xpcxd_default_mtu;

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "RX Page size: %d TX Page size: %d", 
		net_priv->rx_buf_size,
		net_priv->tx_buf_size);

	if (xpcxd_pfc_enabled) {
		ret = xpcxd_pfc_config();
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: Rx PFC Configuration failed: %d",
					ret);
			goto cleanup;
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		rxr = &net_priv->rxr[ring_id];

		xpcxd_tx_pause_set(ring_id, false);

		ret = xpcxd_ring_setup(netdev, ring_id, XPCXD_RING_TX);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: TX ring setup failed: %d", ret);
			goto cleanup;
		}

		ret = xpcxd_tx_ring_configure(netdev, ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: TX ring configure failed: %d",
					ret);
			goto cleanup;
		}

		ret = xpcxd_tx_stat_clear(netdev, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RX ring clear stat failed: %d",
					ret);
			goto cleanup;
		}

		ret = xpcxd_tx_ring_active(ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: TX ring activate failed: %d",
					ret);
			goto cleanup;
		}

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev,
				    "xpcxd_ring_setup(RX) rx desc %u",
				    net_priv->num_rx_desc);

		xpcxd_rx_pause_set(ring_id, false);

		ret = xpcxd_ring_setup(netdev, ring_id, XPCXD_RING_RX);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					 "open: RX ring setup failed");
			goto cleanup;
		}

		ret = xpcxd_rx_ring_configure(netdev, ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RX ring configure failed: %d",
					ret);
			goto cleanup;
		}

		ret = xpcxd_rx_stat_clear(netdev, ring_id);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RX ring clear stat failed: %d",
					ret);
			goto cleanup;
		}

		ret = xpcxd_rx_ring_active(ring_id, true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RX ring activate failed: %d",
					ret);
			goto cleanup;
		}

		xpcxd_rx_fill(netdev, &net_priv->rxr[ring_id].napi, ring_id, rxr, net_priv->num_rx_desc, &processed, false);

		net_priv->txr[ring_id].queue = netdev_get_tx_queue(netdev, 0);

		xpcxd_interrupt = xpcxd_tx_cmpl_intr;

		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "old state: [%s] --> UP",
				   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

		ret = xpcxd_tx_rx_loopback_set(ring_id, xpcxd_loopback);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"open: RX/TX loopback set failed: %d",
					ret);
			goto cleanup;
		}

		sprintf(if_name, "%s-%s", xpcxd_netdev->name, "RX_CMP_INT");
		ret = xpci_register_interrupt(
			g_pxdev, (XPCI_X2_RX_CMP_INT_MIN + ring_id),
			if_name, xpcxd_rx_cmpl_intr);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"Register RX_ERR_INT failed: %d", ret);
			goto cleanup;
		}

		sprintf(if_name, "%s-%s", xpcxd_netdev->name, "TX_CMP_INT");
		ret = xpci_register_interrupt(
			g_pxdev, (XPCI_X2_TX_CMP_INT_MIN + ring_id),
			if_name, xpcxd_tx_cmpl_intr);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"Register TX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	// xpcxd_intg_spare_write(g_cnt_init_done /*0x1*/);

	if (xpcxd_cfg_tbl[xpcxd_enable_tx_err_int]) {
		ret = xpci_register_interrupt(g_pxdev, XPCI_X2_TX_ERR_INT, "TX_ERR_INT",
						xpcxd_tx_err_intr_handler);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Register TX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	if (xpcxd_cfg_tbl[xpcxd_enable_rx_err_int]) {
		ret = xpci_register_interrupt(g_pxdev, XPCI_X2_RX_ERR_INT, "RX_ERR_INT",
						xpcxd_rx_err_intr_handler);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Register RX_ERR_INT failed: %d", ret);
			goto cleanup;
		}
	}

	if (xpcxd_pci_relaxed_ordering) {
		xpcxd_relaxed_ordering();
		xpcxd_lat_cfg();
	}

	xpcxd_msix_control();

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "--- Device configuration completed ---");

	xpci_debug_level = orig_debug_level;

	return 0;

cleanup:
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		if (net_priv->rxr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->rxr[ring_id]);
		if (net_priv->txr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->txr[ring_id]);
	}

	xpci_debug_level = orig_debug_level;

	return ret;
}

/* Entry point for interface activation by OS (IFF_UP): enable all DMA, Rings, etc. */
static int xpcxd_open(struct net_device *netdev)
{
	// struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (xpcxd_mode_standalone) {
		ret = xpcxd_hw_init(xpcxd_num_of_rings, xpcxd_tx_ring_size, xpcxd_rx_ring_size);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"xpcxd_hw_init() failed: %d", ret);
			return ret;
		}

		ret = xpcxd_hw_activate(true);
		if (unlikely(ret)) {
			xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
					"xpcxd_hw_activate() failed: %d", ret);
			return ret;
		}

		// netif_tx_start_all_queues(netdev); /* can transmit now */

		// xpcxd_intg_spare_write(g_cnt_if_up);

		// net_priv->up_state = true;

		xpcxd_set_if_state(netdev, true, true);
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static bool xpcxd_stop_done = false;

/* This function is called when a network device transitions to the DOWN state */
static int xpcxd_stop(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	xpcxd_opt_trace(rx_action_stop, 0, 0, 0);

	if (xpcxd_stop_done) {
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Already stopped");
		return 0;
	}

	/* TODO: Much more work needed here to disable all the DMA, Rings, etc. */

	xpcxd_notice_netdev(NETIF_MSG_IFDOWN, netdev, "old state: [%s] --> DOWN",
			   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	xpcxd_disable_interrupts();

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_opt_trace(rx_action_tx_disable, ring_id, 0, 0);

		ret = xpcxd_dev_tx_disable(netdev, ring_id);
		if (ret)
			xpcxd_err_netdev(NETIF_MSG_IFDOWN, netdev, "Ring Rx disable failed: %d", ret);

		xpcxd_opt_trace(rx_action_rx_disable, ring_id, 0, 0);

		ret = xpcxd_dev_rx_disable(netdev, ring_id);
		if (ret)
			xpcxd_err_netdev(NETIF_MSG_IFDOWN, netdev, "Ring Tx disable failed: %d", ret);
	}

	xpcxd_tx_activate(false);
	xpcxd_rx_activate(false);

	xpcxd_info_netdev(NETIF_MSG_IFDOWN, netdev, "TX disabled");
	netif_stop_queue(netdev); /* can't transmit any more */

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_opt_trace(rx_action_napi_disable, ring_id, 0, 0);

		napi_disable(&net_priv->rxr[ring_id].napi);
		napi_disable(&net_priv->txr[ring_id].napi);

		if (net_priv->rxr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->rxr[ring_id]);
		if (net_priv->txr[ring_id].sub.desc)
			xpcxd_ring_delete(netdev, &net_priv->txr[ring_id]);
	}

	net_priv->up_state = false;

	xpcxd_stop_done = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_do_ioctl(struct net_device *netdev, struct ifreq *ifr, int cmd)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	switch (cmd) {
	/* Most of the default things are already supported in core/dev_ioctl.c */
	default:
		xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Operation not supported: %d", cmd);
		return -EOPNOTSUPP;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_change_mtu(struct net_device *netdev, int new_mtu)
{
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if ((new_mtu < ETH_ZLEN) || (new_mtu > XPCXD_MAX_MTU_SIZE)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Wrong MTU value: %d", new_mtu);
		return -EINVAL;
	}

	/* TODO: Check how to propagate change MTU to HW */

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "New MTU set to: %d", new_mtu);
	netdev->mtu = new_mtu;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

static int xpcxd_set_mac_address(struct net_device *netdev, void *p)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	struct sockaddr *addr = p;
	int ret = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	if (!is_valid_ether_addr(addr->sa_data)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "MAC address not given");
		return -EADDRNOTAVAIL;
	}

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "NEW MAC address: %pM ", addr->sa_data);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, addr->sa_data);
#else
	memcpy(netdev->dev_addr, addr->sa_data, netdev->addr_len);
#endif

	net_priv->mac_addr = ether_addr_to_u64(netdev->dev_addr);
	ret = eth_prepare_mac_addr_change(netdev, p);
	if (ret < 0) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Can't MAC address: %d", ret);
		return ret;
	}

	eth_mac_addr(netdev, p);

	/* TODO: Check if new MAC should be set in HW */

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 6, 0)
void xpcxd_tx_timeout(struct net_device *netdev)
#else
void xpcxd_tx_timeout(struct net_device *netdev,
					  unsigned int txqueue)
#endif
{
	// TODO : Implement together with dev->watchdog_timeot
	xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "---> PCXD TX: Timeout");

	netif_trans_update(netdev); /* prevent tx timeout */
	netif_wake_queue (netdev);

	return;
}

void xpcxd_set_multicast_list(struct net_device *netdev)
{
	/* Empty callback just for teamd compatibility */
	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "xpcxd_set_multicast_list not implemented");

	return;
}

#ifdef __XPCXD_STATS64__
void xpcxd_get_stats64(struct net_device *netdev,
			      struct rtnl_link_stats64 *stats)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ring_id;
	struct xpcxd_ring *ring = NULL;

	// xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	memset(stats, 0, sizeof(struct rtnl_link_stats64));

	rcu_read_lock();
	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {

		ring = &net_priv->rxr[ring_id];

		if (ring) {
			stats->rx_packets += ring->stats.packets;
			stats->rx_bytes += ring->stats.bytes;
			stats->rx_errors += ring->stats.errors;
			stats->rx_dropped += ring->stats.dropped;
			stats->multicast += ring->stats.rx_multicast;
			stats->rx_crc_errors += ring->stats.hw_csum_rx_error;;

			// xpcxd_dbg_netdev(
			// 	NETIF_MSG_DRV, netdev,
			// 	"Ring Rx [%d]: Packets: %lld Bytes: %lld Errors: %lld Drops: %lld",
			// 	ring_id, ring->stats.packets, ring->stats.bytes, stats->rx_errors, stats->rx_dropped);
		}
	}

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		ring = &net_priv->txr[ring_id];

		if (ring) {
			stats->tx_packets += ring->stats.packets;
			stats->tx_bytes += ring->stats.bytes;
			stats->tx_errors += ring->stats.errors;
			stats->tx_dropped += ring->stats.dropped;

			// xpcxd_dbg_netdev(
			// 	NETIF_MSG_DRV, netdev,
			// 	"Ring Tx [%d]: ring->stats.packets: %lld ring->stats.bytes: %lld",
			// 	ring_id, ring->stats.packets, ring->stats.bytes);
		}
	}

	// xpcxd_dbg_netdev(
	// 	NETIF_MSG_DRV, netdev,
	// 	"Total Rx [%d]: Packets: %lld Bytes: %lld",
	// 	ring_id, stats->rx_packets, stats->rx_bytes);

	// xpcxd_dbg_netdev(
	// 	NETIF_MSG_DRV, netdev,
	// 	"Total Tx [%d]: Packets: %lld Bytes: %lld",
	// 	ring_id, stats->tx_packets, stats->tx_bytes);

	rcu_read_unlock();
}
#endif /* __XPCXD_STATS64__ */

static const struct net_device_ops xpcxd_ops = {
	// .ndo_init = xpcxd_netdevice_init, /* Load */
	// .ndo_uninit = xpcxd_netdevice_uninit, /* Uload */
	.ndo_open = xpcxd_open, /* UP */
	.ndo_stop = xpcxd_stop, /* DOWN */
	.ndo_start_xmit = xpcxd_xmit,
	.ndo_tx_timeout = xpcxd_tx_timeout,
	.ndo_set_rx_mode = xpcxd_set_multicast_list,
	// .ndo_get_stats = xpcxd_get_stats,
	.ndo_do_ioctl = xpcxd_do_ioctl,
	.ndo_change_mtu = xpcxd_change_mtu,
	.ndo_set_mac_address = xpcxd_set_mac_address,
#ifdef __XPCXD_STATS64__
	.ndo_get_stats64 = xpcxd_get_stats64,
#endif /* __XPCXD_STATS64__ */
};

/*
 * Helper for alloc_netdev()
 */
static void xpci_setup(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = NULL;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	u8 mac_addr[ETH_ALEN] = {0};
#endif

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* Set various defaults */
	// ether_setup(netdev);

	/* Initialize the device structure. */
	netdev->netdev_ops = &xpcxd_ops;
	xpcxd_set_ethtool_ops(netdev);

	/* Fill in device structure with ethernet-generic values. */
	netdev->type = ARPHRD_ETHER;
	netdev->priv_flags |= IFF_LIVE_ADDR_CHANGE | IFF_NO_QUEUE; /* | ~IFF_UP;*/
	if (xpcxd_check_l4_checksum) {
		netdev->features = NETIF_F_HW_CSUM | NETIF_F_RXCSUM;
	}
	if (xpcxd_rss_enabled) {
		netdev->features = NETIF_F_RXHASH;
	}
	netdev->hw_features |= netdev->features;
	netdev->hw_enc_features |= netdev->features;
	netdev->hard_header_len = ETH_HLEN;
	netdev->tx_queue_len = 1000;
	
	/* According to RFC-791:
	 * Every internet module must be able to forward a datagram of 68
	 * octets without further fragmentation.  This is because an Internet
	 * header may be up to 60 octets, and the minimum fragment is 8 octets.
	 */
	netdev->min_mtu = ETH_MIN_MTU;
	netdev->mtu = xpcxd_default_mtu;
	netdev->max_mtu = XPCXD_MAX_MTU_SIZE;

	net_priv = netdev_priv(netdev);
	memset(net_priv, 0, sizeof(struct xpcxd_priv));
	net_priv->up_state = false;
	net_priv->oper_status = false;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, mac_addr);
#else
	memset(netdev->dev_addr, 0, ETH_ALEN);
#endif

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");
}

int xpcxd_set_if_state(struct net_device *netdev, bool status, bool carrier_state)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	
	netdev = xpcxd_netdev;

	xpcxd_dbg_netdev(NETIF_MSG_LINK, netdev, "IN");

	xpcxd_notice_netdev(NETIF_MSG_IFUP, netdev, "Set Interface interface state: %s",
			   (status ? "UP" : "DOWN"));

	if (status) {
		netif_tx_start_all_queues(netdev); /* can transmit now */

		// xpcxd_intg_spare_write(g_cnt_if_up);

		net_priv->up_state = true;
		
		dev_change_flags(netdev, netdev->flags | IFF_UP, NULL);
	} else {
		dev_change_flags(netdev, netdev->flags & ~IFF_UP, NULL);
	}

	if (carrier_state) {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Carrier ON");
		netif_carrier_on(netdev);

		xpcxd_opt_trace(rx_action_carrier_on, 0, 0, 0);
	} else {
		xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Carrier OFF");
		netif_carrier_off(netdev);

		xpcxd_opt_trace(rx_action_carrier_off, 0, 0, 0);
	}

	net_priv->oper_status = status;

	xpcxd_dbg_netdev(NETIF_MSG_LINK, netdev, "OUT");

	return 0;
}

static void xpcxd_service_task(struct work_struct *work)
{
	struct xpcxd_priv *net_priv;
	struct net_device *netdev;
	int ret;
	bool was_up;

	net_priv = container_of(work, struct xpcxd_priv, service_task);
	netdev = net_priv->netdev;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	/* restart the device */
	rtnl_lock();
	was_up = netif_carrier_ok(netdev);
	if (likely(was_up)) {
		set_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, &net_priv->dev_flags);
		xpcxd_close();
		clear_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, &net_priv->dev_flags);
	}
	ret = xpcxd_dev_reset(netdev);
	if (ret)
		goto exit;
	if (likely(was_up)) {
		set_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, &net_priv->dev_flags);
		ret = xpcxd_open(netdev);
		clear_bit(XPCXD_FLAG_DEV_RESTART_IN_PROGRESS, &net_priv->dev_flags);
		if (ret) {
			goto exit;
		}
	}
	clear_bit(XPCXD_FLAG_DEV_FAILED, &net_priv->dev_flags);

exit:
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "device restart failed");
		set_bit(XPCXD_FLAG_DEV_DEAD, &net_priv->dev_flags);
	}
	rtnl_unlock();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return;
}

static int xpcxd_dev_init(struct net_device *netdev)
{
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN");

	net_priv->netdev = netdev;

	ret = xpcxd_dev_reset(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "init: device reset failed");
		goto error;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Allocate workqueue");
	net_priv->wq = alloc_ordered_workqueue("xpcxd", 0);
	if (unlikely(net_priv->wq == NULL)) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"init: alloc_ordered_workqueue() failed");
		ret = -ENOMEM;
		goto error;
	}
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "INIT_WORK");
	INIT_WORK(&net_priv->service_task, xpcxd_service_task);

	net_priv->napi_active = false;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error:
	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "ERR: OUT");

	return ret;
}

int xpcxd_register_netdev(char *if_name, bool do_rtnl_lock)
{
	struct net_device *netdev = NULL;
	struct xpcxd_priv *net_priv = NULL;
	struct inet6_dev *idev = NULL;
	static const u8 xsight_oui[3] = { 0x00, 0x11, 0x11 };
	int ret = 0;

	// strncpy(dev_name, if_name, XPCXD_NET_DEV_NAME_SIZE);
	xpcxd_info(NETIF_MSG_DRV, "Allocating new PCXD netdev [%s]", if_name);
	netdev = alloc_netdev(sizeof(*net_priv), if_name, NET_NAME_UNKNOWN, ether_setup);
	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "alloc_netdev() [%s] failed", if_name);
		ret = -EINVAL;
		goto error_exit;
	}

	if (!netdev) {
		xpcxd_err(NETIF_MSG_DRV, "Invalid netdev");
		ret = -EINVAL;
		goto error_exit;
	}

	xpcxd_netdev = netdev;

	xpcxd_info(NETIF_MSG_DRV, "New PCXD netdev [%s][%p]", if_name, netdev);

	xpci_setup(netdev);

	net_priv = netdev_priv(netdev);

	/* Set device MAC address */
	memcpy(net_priv->mac, xsight_oui, 3);
	/* get_random_bytes(net_priv->mac + 3, 3); */
	net_priv->mac[3] = 0x19;
	net_priv->mac[4] = 0x72;
	net_priv->mac[5] = 0; // phy_port;

	// TODO: Check during HW integration
	if (g_pxdev)
		net_priv->hw_dev = &g_pxdev->pdev->dev;

	idev = __in6_dev_get(netdev);
	if (idev) {
		idev->cnf.disable_ipv6 = 1;
	}

	/* TODO: Open ! */
	/* netdev->priv_flags |= (ethdev->priv_flags); */

#ifdef __XPCXD_INIT__
	/*
	* TODO: 3. PCI - NETDEV link
	* Set the sysfs device type for the network logical device to allow
	* fine-grained identification of different network device types. For
	* example Ethernet, Wirelss LAN, Bluetooth, WiMAX etc.
	*/
	SET_NETDEV_DEV(netdev, &pdev->dev);
#endif /* __XPCXD_INIT__ */

	net_priv->napi_active = true;

	if (do_rtnl_lock)
		rtnl_lock();

	// strscpy(netdev->name, "xpcxd0", sizeof(netdev->name));
	// if (dev_alloc_name(netdev, if_name) < 0) {
	// 	xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Net Device dev_alloc_name() failed");
	// 	goto error_unlock;
	// }
	ret = register_netdevice(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "Net Device register failed: %d", ret);
		goto error_unlock;
	}

	ret = xpcxd_dev_init(netdev);
	if (ret)
		goto error_exit;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 0, 0)
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST, NULL);
#else
	dev_change_flags(netdev, IFF_BROADCAST | IFF_MULTICAST);
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 15, 0)
	eth_hw_addr_set(netdev, net_priv->mac);
#else
	memcpy(netdev->dev_addr, net_priv->mac, ETH_ALEN);
#endif
	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "MAC address SET: [%pM]", netdev->dev_addr);

	/* Initial interface state is always DOWN */
	xpcxd_set_if_state(netdev, true, false);

	netdev_update_features(netdev);

	dev_disable_lro(netdev);

	xpcxd_notice_netdev(NETIF_MSG_DRV, netdev, "Device state: [%s]",
			   (netdev->flags & IFF_UP) ? "UP" : "DOWN");

	if (do_rtnl_lock)
		rtnl_unlock();

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error_unlock:
	if (do_rtnl_lock)
		rtnl_unlock();

	if (netdev) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "free_netdev()");
		free_netdev(netdev);
	}

error_exit:

	xpcxd_err(NETIF_MSG_DRV, "[%s]: ERR OUT", if_name);

	return ret;
}

int xpcxd_hw_init(u32 _num_of_rings, u16 _tx_ring_size, u16 _rx_ring_size)
{
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	int ret = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	net_priv->num_rings = _num_of_rings;
	net_priv->num_tx_desc = _tx_ring_size;
	net_priv->num_rx_desc = _rx_ring_size;

	// netif_carrier_off(netdev);

	ret = xpcxd_config(netdev);
	if (ret) {
		xpcxd_err_netdev(NETIF_MSG_DRV, netdev,
				"Net Device config failed with error: %d", ret);
		goto error_exit;
	}

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;

error_exit:

	xpcxd_err_netdev(NETIF_MSG_DRV, netdev, "ERR OUT");

	return ret;
}

int xpcxd_hw_activate(bool activate)
{
	struct net_device *netdev = xpcxd_netdev;
	struct xpcxd_priv *net_priv = netdev_priv(netdev);
	u32 ring_id = 0;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	/* Disable Tx before any HW deactivation */
	if (!activate)
		hw_ready = false;

	xpcxd_tx_activate(false);
	xpcxd_rx_activate(false);

	xpcxd_tx_activate(xpcxd_tx_enabled);

	xpcxd_info_netdev(NETIF_MSG_DRV, netdev, "TX enabled");

	xpcxd_rx_activate(xpcxd_rx_enabled);

	for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
		xpcxd_rx_db_init(netdev, &net_priv->rxr[ring_id], ring_id);
	}

	/* Enable Tx only when HW is activated and ready */
	if (activate)
		hw_ready = true;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "OUT");

	return 0;
}

void xpcxd_unregister_netdev(struct net_device *netdev,
			     bool do_rtnl_lock)
{
	struct xpcxd_priv *net_priv = NULL;
	u32 ring_id = 0;

	xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "IN: [%p]", netdev);

	net_priv = netdev_priv(netdev);

	// NAPI Delete
	if (net_priv->napi_active) {
		for (ring_id = 0; ring_id < net_priv->num_rings; ring_id++) {
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "netif_napi_del() Ring[%d]",
					   ring_id);
			netif_napi_del(&net_priv->rxr[ring_id].napi);
			netif_napi_del(&net_priv->txr[ring_id].napi);

			if (hrtimer_active(&net_priv->rxr[ring_id].time_isr)) {
				xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Disabling Rx timer isr");
				hrtimer_cancel(&net_priv->rxr[ring_id].time_isr);
			}

			if (hrtimer_active(&net_priv->txr[ring_id].time_isr)) {
				xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Disabling Tx timer isr");
				hrtimer_cancel(&net_priv->txr[ring_id].time_isr);
			}
		}
		net_priv->napi_active = false;
	}

	netif_tx_disable(netdev);
	netif_carrier_off(netdev);

	if (do_rtnl_lock)
		rtnl_lock();

	if (do_rtnl_lock)
		rtnl_unlock();

	unregister_netdev(netdev); /* It will call our stop function */
	free_netdev(netdev);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
static int dump_pcxd_error(struct notifier_block *self, unsigned long event, void *ptr)
{
    pr_emerg(">>> DIE <<< Event: %lu\n", event);

    // Example: turn off tracing
    tracing_off();

	if (xpcxd_netdev) {
		xpcxd_rx_stat_dump_short(xpcxd_netdev);
		xpcxd_tx_stat_dump_short(xpcxd_netdev);
	}

	return NOTIFY_DONE;
}

static int xpcxd_panic_notifier(struct notifier_block *nb, unsigned long event, void *ptr)
{
	struct net_device *netdev = xpcxd_netdev;
	xpci_debug_level = XPCI_DBG_LEVEL__DBG;

    pr_emerg(">>> PANIC <<< Event: [%lu] netdev: [%p]\n", event, netdev);

    // Example: turn off tracing
    tracing_off();

	if (netdev) {
		struct xpcxd_priv *net_priv = netdev_priv(netdev);
		struct xpcxd_ring *ring = NULL;
		int i;

		ring = &net_priv->rxr[0];

		xpcxd_rx_stat_dump_short(netdev);
		xpcxd_tx_stat_dump_short(netdev);

		for (i = 0; i < net_priv->num_rx_desc; i++) {
			xpcxd_dbg_netdev(NETIF_MSG_DRV, netdev, "Page pfn: %lu State: %d", 
				page_to_pfn(ring->sub.sw->page),
				ring->sub.sw->page_state);
		}
	}

	pr_emerg(">>> Calling ftrace_dump()\n");

	ftrace_dump(DUMP_ALL);

    return NOTIFY_DONE;
}

static struct notifier_block xpcxd_die_notifier = {
	.notifier_call = dump_pcxd_error,
};

static struct notifier_block xpcxd_nb = {
    .notifier_call = xpcxd_panic_notifier,
    .priority = INT_MAX,  // run early
};
#endif

void resize_ftrace_buffer_from_module(void)
{
    static char *envp[] = {
        "HOME=/",
        "TERM=linux",
        "PATH=/sbin:/bin:/usr/sbin:/usr/bin",
        NULL
    };

    static char *argv[] = {
        "/bin/sh",
        "-c",
        "echo 128 > /sys/kernel/tracing/buffer_size_kb",
        NULL
    };

    call_usermodehelper(argv[0], argv, envp, UMH_WAIT_PROC);
}

int xpcxd_init(void *_pxdev)
{
	int ret = 0;
	u64 version = 0;
	u64 block_id = 0;
	u64 block_release = 0;
	struct xdev *pxdev = (struct xdev *)_pxdev;

	xpcxd_dbg(NETIF_MSG_DRV, "xpcxd_init() IN: debug level: %d", xpci_debug_level);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	register_die_notifier(&xpcxd_die_notifier);
	atomic_notifier_chain_register(&panic_notifier_list, &xpcxd_nb);

	resize_ftrace_buffer_from_module();
#endif

	ret = xpcxd_get_version(&version, &block_id, &block_release);
	xpcxd_notice(NETIF_MSG_DRV,
		"PCXD Device version: [0x%llx] block id: [0x%llx] block_release: [0x%llx]",
		version, block_id, block_release);

	ret = xpcxd_netdev_sysctl_init();
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "Sys ctl init failed: %d", ret);
		return ret;
	}

	ret = xpcxd_rtnl_link_register();
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "Rtnl link register failed: %d", ret);
		return ret;
	}

	g_pxdev = pxdev;

	ret = xpcxd_register_netdev("xpcxd0", true);
	if (ret) {
		xpcxd_err(NETIF_MSG_DRV, "xpcxd_register_netdev() failed: %d", ret);
		return ret;
	}

#ifdef __XPCXD_NAPI_ALLOC_SKB__
	xpcxd_legacy_skb_alloc = 1;
#endif
	if (xpcxd_legacy_skb_alloc)
		xpcxd_err(NETIF_MSG_DRV, "Legacy SKB allocation method is used");

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}

static bool xpcxd_close_done = false;

int xpcxd_close(void)
{
	xpci_debug_level = XPCI_DBG_LEVEL__INFO;

	xpcxd_dbg(NETIF_MSG_DRV, "IN");

	/* STOP ALL Rx/Tx activity in this case */
	xpcxd_cfg_tbl[xpcxd_tx_drop_all] = 1;
	xpcxd_cfg_tbl[xpcxd_rx_drop_all] = 1;

	xpcxd_opt_trace(rx_action_close, 0, 0, 0);

	if (xpcxd_close_done) {
		xpcxd_dbg(NETIF_MSG_DRV, "Already done");
		return 0;
	}

	xpcxd_stop(xpcxd_netdev);

#ifdef __XPCXD_TEARDOWN_DEBUG__
	xpcxd_err(NETIF_MSG_DRV, "BEFORE SLEEP");

	msleep(10000); /* 10 s */

	xpcxd_err(NETIF_MSG_DRV, "AFTER SLEEP");
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 12, 0)
	unregister_die_notifier(&xpcxd_die_notifier);
	atomic_notifier_chain_unregister(&panic_notifier_list,
					&xpcxd_nb);
#endif

	xpcxd_close_done = true;

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD RTNL unregister");
	xpcxd_rtnl_link_unregister();

	if (xpcxd_netdev) {
		xpcxd_dbg(NETIF_MSG_DRV, "PCXD Netdev unregister: [%s]", xpcxd_netdev->name);
		xpcxd_unregister_netdev(xpcxd_netdev, true);
	}

	xpcxd_dbg(NETIF_MSG_DRV, "PCXD sysctl unregister");
	unregister_net_sysctl_table(xpcxd_netdev_sysctl_header);

	xpcxd_dbg(NETIF_MSG_DRV, "OUT");

	return 0;
}
