#!/bin/bash
# Copyright (c) Xsight Labs Ltd.
# All rights reserved, subject only to the terms of any applicable license agreement entered into with Xsight Labs Ltd.


set -e

ATTACH_DEVICE="Ethernet0"

#echo '--- Checking attach device ---'
#ip link show ${ATTACH_DEVICE}
#echo '--- Attach device is: OK---'

sudo insmod ./xpci.ko attach_if=${ATTACH_DEVICE} num_of_ports=16 debug_level=5 pci_mode=0 netdev_mode=0 pcxd_mode=1
