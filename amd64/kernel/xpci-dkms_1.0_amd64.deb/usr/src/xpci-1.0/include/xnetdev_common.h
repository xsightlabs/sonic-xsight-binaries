// SPDX-License-Identifier: GPL-2.0

/*
 * Networking Device common definitions
 *
 * Copyright (c) 2017-present Xsight Labs Inc.
 *
 */

#ifndef XNETDEV_COMMON_H_
#define XNETDEV_COMMON_H_

struct __attribute__((__packed__)) xsw_tunnel_header {
	unsigned char dsta[6];
	unsigned char srca[6];
	__be16 type;
};

struct __attribute__((__packed__)) xsw_cpu_rx_shim_header {
#if defined(__LITTLE_ENDIAN_BITFIELD)
    __u8 cookie : 7, reserved1 : 1;
    __u8 die_id : 2, learning_event : 2, reserved2 : 4;
#elif defined(__BIG_ENDIAN_BITFIELD)
    __u8 reserved1 : 1, cookie : 7;
    __u8 reserved2 : 4, learning_event : 2, die_id : 2;
#else
#error "Please fix <asm/byteorder.h>"
#endif
	__u8 trap_reason : 8;
	__u8 port_id : 8;
};

struct __attribute__((__packed__)) xsw_cpu_tx_shim_header {
	__be16 egress_qid;
};

struct __attribute__((__packed__)) xsw_packet_header {
	struct xsw_tunnel_header tunnel_header;
	union {
		struct xsw_cpu_rx_shim_header cpu_rx_shim;
		struct xsw_cpu_tx_shim_header cpu_tx_shim;
	} shim_header;
};

#define XSW_RX_SHIM_HDR_SIZE sizeof(struct xsw_cpu_rx_shim_header) /* 4 */
#define XSW_TX_SHIM_HDR_SIZE sizeof(struct xsw_cpu_tx_shim_header) /* 2 */
#define XSW_TX_SHIM_INJECT_HDR_SIZE (18) /* Refer to xsw_cputxshiminject_t in xdefs_auto.h */
#define XSW_TX_TUN_HDR_SIZE sizeof(struct xsw_tunnel_header) /* 14 */
#define XSW_RX_TUN_HDR_SIZE sizeof(struct xsw_tunnel_header) /* 14 */

#define XSW_SHIM_HEADER_ETHTYPE_EGRESS 0x7777
#define XSW_SHIM_HEADER_ETHTYPE_INJECT 0x7778

#endif /* XNETDEV_COMMON_H_ */
