// SPDX-License-Identifier: GPL-2.0

/*
 * Debug macros and definitions
 *
 * Copyright (c) 2017-present Xsight Labs Inc.
 *
 */

#ifndef XPCI_DBG_H_
#define XPCI_DBG_H_

#define XPCI_DBG_LEVEL__ERR 0x1
#define XPCI_DBG_LEVEL__NOTICE 0x2
#define XPCI_DBG_LEVEL__INFO 0x3
#define XPCI_DBG_LEVEL__DBG 0x4
#define XPCI_DBG_LEVEL__MAX (XPCI_DBG_LEVEL__DBG + 1)

#define XPCI_PKT_TRACE_MUTE 0x0
#define XPCI_PKT_TRACE_1 0x1
#define XPCI_PKT_TRACE_2 0x2
#define XPCI_PKT_TRACE_3 0x3

extern int xpci_debug_level;
extern int xpci_pkt_trace;

#define __XPCI_DEV_PRINTS__
#ifdef __XPCI_DEV_PRINTS__

#define __FL__ "F:[%-24s] L:[%-4d]"

#define CLR_RST "\033[0m"
#define CLR_RED "\033[0;31m"
#define CLR_GREEN "\033[0;32m"
#define CLR_YELLOW "\033[0;33m"
#define CLR_BLUE "\033[0;34m"
#define CLR_LIGHT_BLUE "\033[1;34m"

/* error conditions */
#define xpci_err(fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__ERR) {	\
			pr_err("ERR:XPCIDEV | "__FL__" | " fmt "\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_err_dev(dev,fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__ERR) {	\
			dev_err(dev,"ERR:XPCIDEV | "__FL__" | " fmt "\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_err_netdev(netdev,fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__ERR) {	\
			netdev_printk(KERN_ERR, \
					netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

/* normal but significant condition */
#define xpci_notice(fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) {	\
			pr_notice(	\
				"XPCIDEV | "__FL__" | " fmt	\
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_notice_dev(dev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) {	\
			dev_notice(	\
				dev,	\
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_notice_netdev(netdev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__NOTICE) {	\
			netdev_printk(KERN_NOTICE, netdev, \
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

/* informational */
#define xpci_info(fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__INFO) {	\
			pr_info(	\
				"XPCIDEV | "__FL__" | " fmt	\
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_info_dev(dev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__INFO) {	\
			dev_info(	\
				dev,	\
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_info_netdev(dev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__INFO) {	\
			netdev_printk(KERN_INFO, netdev, \
				"XPCIDEV | "__FL__" | " fmt  \
				"\n",	\
				__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

/* debug-level messages */
#define xpci_dbg(fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__DBG) {	\
			pr_info("XPCIDEV | "__FL__" | " fmt	\
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_dbg_dev(dev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__DBG) {	\
			dev_info(dev,	\
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_dbg_netdev(netdev, fmt, ...)	\
	{	\
		if (xpci_debug_level >= XPCI_DBG_LEVEL__DBG) {	\
			netdev_printk(KERN_DEBUG, netdev, \
					"XPCIDEV | "__FL__" | " fmt \
					"\n",	\
					__FUNCTION__, __LINE__, ##__VA_ARGS__);	\
		}	\
	}

#define xpci_msg(str) pr_info("---:XPCIDEV | "__FL__" | %s\n", str);
#else
#define xpci_err(fmt, args...)
#define xpci_err_netdev(netdev, fmt, ...)
#define xpci_err_dev(dev,fmt, args...)
#define xpci_notice(fmt, args...)
#define xpci_notice_netdev(netdev, fmt, ...)
#define xpci_notice_dev(dev, fmt, args...)
#define xpci_info(fmt, args...)
#define xpci_info_netdev(netdev, fmt, ...)
#define xpci_info_dev(dev, fmt, args...)
#define xpci_dbg(fmt, args...)
#define xpci_dbg_netdev(netdev, fmt, ...)
#define xpci_dbg_dev(dev, fmt, args...)
#endif

#endif /* XPCI_DBG_H_ */
