#!/bin/bash

set -e

ATTACH_DEVICE="Ethernet0"

echo '--- Checking attach device ---'
ip link show ${ATTACH_DEVICE}
echo '--- Attach device is: OK---'

sudo modprobe xpci attach_if=${ATTACH_DEVICE} num_of_ports=16 debug_level=3
