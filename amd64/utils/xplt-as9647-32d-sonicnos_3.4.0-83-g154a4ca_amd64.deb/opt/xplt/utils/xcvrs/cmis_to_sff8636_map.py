# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Xsightlabs Ltd.

# We adopt a Hybrid Approach for SFF-8636 Support in CMIS Framework:
# Incremental Migration: start by implementing SFF-8636 support for the most critical features
# Least Disruption: Minimal changes to existing CMIS functionality
# Flexible: Use simple mapping where it works, dedicated functions where needed
# Maintainable: Clear separation between protocols while keeping code readable
# Scalable: Design to accommodate future enhancements or additional protocols
#
# This mapping dictionary defines the correspondence between CMIS keys and SFF-8636 keys.
# For SFF-8636 modules, use only keys mapped to a string (not None).
# Do not add keys with equal name in both standards.

cmis_to_sff8636_map = {
    # --- Monitoring/Alarms ---
    'MODULE_STATE': None,

    # --- Misc/Other ---
    'SS0_APPLY_CTRL_IMMD': None,
    'DP_DEINIT': None,
    'LOW_PWR_ALLOW_REQ_HW': None,

    # --- BER/Diagnostics ---
    'RESET_ERROR_INFO': None,
    'AUTO_RESTART_GATE_TIME': None,
    'GATE_TIME': None,
    'BER_COUNTER_UPDATE_TIME': None,
    'DIAG_SEL': None,

    'MODULE_FW_REV_MAJOR': 'VENDOR_REV',
    'MODULE_FW_REV_MINOR': None,
    'MOD_MED_TYPE_ENC': 'CONNECTOR',
}
