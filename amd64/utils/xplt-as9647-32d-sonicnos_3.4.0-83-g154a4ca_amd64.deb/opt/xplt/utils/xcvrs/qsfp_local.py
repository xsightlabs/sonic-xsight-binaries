# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

new_mm_keys = {
    # Channel Status Interrupt Flags
    'L_TX_LOS': (1, 'get_bits', 0xA0, 0, 3, 1, 7, 4),
    'L_RX_LOS': (1, 'get_bits', 0xA0, 0, 3, 1, 3, 4),
    'L_TX_EQ_FAULT': (1, 'get_bits', 0xA0, 0, 4, 1, 7, 4),
    'L_TX_XM_FAULT': (1, 'get_bits', 0xA0, 0, 4, 1, 3, 4),
    'L_TX_LOL': (1, 'get_bits', 0xA0, 0, 5, 1, 7, 4),
    'L_RX_LOL': (1, 'get_bits', 0xA0, 0, 5, 1, 3, 4),

    # Control Functions
    'SW_RESET': (1, 'get_bits', 0xA0, 0, 93, 1, 7, 1),
    'RESERVED_118': (0, 'get_int', 0xA0, 0, 118, 1),

    # Rate Select options
    'RATE_SELECT_TYPE': (0, 'get_bits', 0xA0, 0, 121, 1, 3, 2),

    # CDR options
    'CDR_IMPLEMENTED':      (0, 'get_bits', 0xA0, 0, 129, 1, 3, 2),

    # Media Type Compliance Codes Ethernet (Byte 131)
    'COMPLIANCE_CODES_ETHERNET':    (0, 'get_int', 0xA0, 0, 131, 1),
    'COMP_ETH_EXTENDED_CODES':      (0, 'get_bits', 0xA0, 0, 131, 1, 7, 1),
    'COMP_ETH_10GBASE_LRM':         (0, 'get_bits', 0xA0, 0, 131, 1, 6, 1),
    'COMP_ETH_10GBASE_LR':          (0, 'get_bits', 0xA0, 0, 131, 1, 5, 1),
    'COMP_ETH_10GBASE_SR':          (0, 'get_bits', 0xA0, 0, 131, 1, 4, 1),
    'COMP_ETH_40GBASE_CR4':         (0, 'get_bits', 0xA0, 0, 131, 1, 3, 1),
    'COMP_ETH_40GBASE_SR4':         (0, 'get_bits', 0xA0, 0, 131, 1, 2, 1),
    'COMP_ETH_40GBASE_LR4':         (0, 'get_bits', 0xA0, 0, 131, 1, 1, 1),
    'COMP_ETH_40G_ACT_CABL_XLPPI':  (0, 'get_bits', 0xA0, 0, 131, 1, 0, 1),

    # Media Type Compliance Codes SONET (Byte 132)
    'COMPLIANCE_CODES_SONET':   (0, 'get_int', 0xA0, 0, 132, 1),
    # Bits 7-3 Reserved
    'COMP_SONET_OC_48_LONG_REACH':  (0, 'get_bits', 0xA0, 0, 132, 1, 2, 1),
    'COMP_SONET_OC_48_INTR_REACH':  (0, 'get_bits', 0xA0, 0, 132, 1, 1, 1),
    'COMP_SONET_OC_48_SHORT_REACH': (0, 'get_bits', 0xA0, 0, 132, 1, 0, 1),

    # SAS/SATA Compliance Codes (Byte 133)
    'COMPLIANCE_CODES_SAS_SATA': (0, 'get_int', 0xA0, 0, 133, 1),
    'COMP_SAS_24G': (0, 'get_bits', 0xA0, 0, 133, 1, 7, 1),
    'COMP_SAS_12G': (0, 'get_bits', 0xA0, 0, 133, 1, 6, 1),
    'COMP_SAS_6G':  (0, 'get_bits', 0xA0, 0, 133, 1, 5, 1),
    'COMP_SAS_3G':  (0, 'get_bits', 0xA0, 0, 133, 1, 4, 1),
    # Bits 3-0 Reserved

    # Gigabit Ethernet Compliance Codes (Byte 134)
    'COMPLIANCE_CODES_GBE':     (0, 'get_int', 0xA0, 0, 134, 1),
    'COMP_GBE_1000BASE_T':      (0, 'get_bits', 0xA0, 0, 134, 1, 3, 1),
    'COMP_GBE_1000BASE_CX':     (0, 'get_bits', 0xA0, 0, 134, 1, 2, 1),
    'COMP_GBE_1000BASE_LX':     (0, 'get_bits', 0xA0, 0, 134, 1, 1, 1),
    'COMP_GBE_1000BASE_SX':     (0, 'get_bits', 0xA0, 0, 134, 1, 0, 1),
    # Bits 7-4 Reserved

    # Fibre Channel Link Length (Byte 135)
    'COMPLIANCE_CODES_FC_135':  (0, 'get_int', 0xA0, 0, 135, 1),
    'COMP_FC_LENGTH_V':         (0, 'get_bits', 0xA0, 0, 135, 1, 7, 1),
    'COMP_FC_LENGTH_S':         (0, 'get_bits', 0xA0, 0, 135, 1, 6, 1),
    'COMP_FC_LENGTH_I':         (0, 'get_bits', 0xA0, 0, 135, 1, 5, 1),
    'COMP_FC_LENGTH_L':         (0, 'get_bits', 0xA0, 0, 135, 1, 4, 1),
    'COMP_FC_LENGTH_M':         (0, 'get_bits', 0xA0, 0, 135, 1, 3, 1),

    # Fibre Channel Transmitter Technology (Byte 135)
    'COMP_FC_TX_TECHNOLOGY_LC': (0, 'get_bits', 0xA0, 0, 135, 1, 1, 1),
    'COMP_FC_TX_TECHNOLOGY_EL': (0, 'get_bits', 0xA0, 0, 135, 1, 0, 1),
    # Bit 2 Reserved

    # Fibre Channel Transmitter Technology (Byte 136)
    'COMPLIANCE_CODES_FC_136':  (0, 'get_int', 0xA0, 0, 136, 1),
    'COMP_FC_TX_TECHNOLOGY_EI': (0, 'get_bits', 0xA0, 0, 136, 1, 7, 1),
    'COMP_FC_TX_TECHNOLOGY_SN': (0, 'get_bits', 0xA0, 0, 136, 1, 6, 1),
    'COMP_FC_TX_TECHNOLOGY_SL': (0, 'get_bits', 0xA0, 0, 136, 1, 5, 1),
    'COMP_FC_TX_TECHNOLOGY_LL': (0, 'get_bits', 0xA0, 0, 136, 1, 4, 1),
    # Bits 3-0 Reserved

    # Fibre Channel Transmission Media (Byte 137)
    'COMPLIANCE_CODES_FC_137':  (0, 'get_int', 0xA0, 0, 137, 1),
    'COMP_FC_MEDIA_TW':         (0, 'get_bits', 0xA0, 0, 137, 1, 7, 1),
    'COMP_FC_MEDIA_TP':         (0, 'get_bits', 0xA0, 0, 137, 1, 6, 1),
    'COMP_FC_MEDIA_MI':         (0, 'get_bits', 0xA0, 0, 137, 1, 5, 1),
    'COMP_FC_MEDIA_TV':         (0, 'get_bits', 0xA0, 0, 137, 1, 4, 1),
    'COMP_FC_MEDIA_M6':         (0, 'get_bits', 0xA0, 0, 137, 1, 3, 1),
    'COMP_FC_MEDIA_M5':         (0, 'get_bits', 0xA0, 0, 137, 1, 2, 1),
    'COMP_FC_MEDIA_OM3':        (0, 'get_bits', 0xA0, 0, 137, 1, 1, 1),
    'COMP_FC_MEDIA_SM':         (0, 'get_bits', 0xA0, 0, 137, 1, 0, 1),

    # Fibre Channel Speed (Byte 138)
    'COMPLIANCE_CODES_FC_SPEED': (0, 'get_int', 0xA0, 0, 138, 1),
    'COMP_FC_SPEED_1200MBPS':   (0, 'get_bits', 0xA0, 0, 138, 1, 7, 1),
    'COMP_FC_SPEED_800MBPS':    (0, 'get_bits', 0xA0, 0, 138, 1, 6, 1),
    'COMP_FC_SPEED_1600MBPS':   (0, 'get_bits', 0xA0, 0, 138, 1, 5, 1),
    'COMP_FC_SPEED_400MBPS':    (0, 'get_bits', 0xA0, 0, 138, 1, 4, 1),
    'COMP_FC_SPEED_3200MBPS':   (0, 'get_bits', 0xA0, 0, 138, 1, 3, 1),
    'COMP_FC_SPEED_200MBPS':    (0, 'get_bits', 0xA0, 0, 138, 1, 2, 1),
    'COMP_FC_SPEED_EXTENDED':   (0, 'get_bits', 0xA0, 0, 138, 1, 1, 1),
    'COMP_FC_SPEED_100MBPS':    (0, 'get_bits', 0xA0, 0, 138, 1, 0, 1),

    # Extended Rate Select compliance
    'EXT_RATE_SEL_COMPL': (0, 'get_bits', 0xA0, 0, 141, 1, 1, 2),

    # Optional Signals and Equalization Capabilities (Byte 193)
    # Bit 7 Reserved
    'LPMODE_TXDIS_CONFIGURABLE':    (0, 'get_bits', 0xA0, 0, 193, 1, 6, 1),
    'INTL_RXLOSL_CONFIGURABLE':     (0, 'get_bits', 0xA0, 0, 193, 1, 5, 1),
    'TX_EQ_ADAPTIVE_FREEZE':        (0, 'get_bits', 0xA0, 0, 193, 1, 4, 1),
    'TX_EQ_AUTO_ADAPT_CAP':         (0, 'get_bits', 0xA0, 0, 193, 1, 3, 1),
    'TX_EQ_FIXED_PROG_SET':         (0, 'get_bits', 0xA0, 0, 193, 1, 2, 1),
    'RX_EQ_EMPHASIS_FIXED_PROG':    (0, 'get_bits', 0xA0, 0, 193, 1, 1, 1),
    'RX_EQ_AMPLITUDE_FIXED_PROG':   (0, 'get_bits', 0xA0, 0, 193, 1, 0, 1),

    # Optional Features Implemented (Byte 194)
    'TX_CDR_ON_OFF_CTRL':   (0, 'get_bits', 0xA0, 0, 194, 1, 7, 1),
    'RX_CDR_ON_OFF_CTRL':   (0, 'get_bits', 0xA0, 0, 194, 1, 6, 1),
    'TX_CDR_LOL_FLAG':      (0, 'get_bits', 0xA0, 0, 194, 1, 5, 1),
    'RX_CDR_LOL_FLAG':      (0, 'get_bits', 0xA0, 0, 194, 1, 4, 1),
    'RX_SQUELCH_DISABLE':   (0, 'get_bits', 0xA0, 0, 194, 1, 3, 1),
    'RX_OUTPUT_DISABLE':    (0, 'get_bits', 0xA0, 0, 194, 1, 2, 1),
    'TX_SQUELCH_DISABLE':   (0, 'get_bits', 0xA0, 0, 194, 1, 1, 1),
    'TX_SQUELCH':           (0, 'get_bits', 0xA0, 0, 194, 1, 0, 1),

    # Optional Features and Pages (Byte 195)
    'MEMORY_PAGE_02_CAP':   (0, 'get_bits', 0xA0, 0, 195, 1, 7, 1),
    'MEMORY_PAGE_01H_CAP':  (0, 'get_bits', 0xA0, 0, 195, 1, 6, 1),
    'RATE_SELECT_CAP':      (0, 'get_bits', 0xA0, 0, 195, 1, 5, 1),
    'TX_DISABLE_CAP':       (0, 'get_bits', 0xA0, 0, 195, 1, 4, 1),
    'TX_FAULT_CAP':         (0, 'get_bits', 0xA0, 0, 195, 1, 3, 1),
    'TX_SQUELCH_CAP':       (0, 'get_bits', 0xA0, 0, 195, 1, 2, 1),
    'TX_LOSS_OF_SIGNAL':    (0, 'get_bits', 0xA0, 0, 195, 1, 1, 1),
    'PAGES_20_21_CAP':      (0, 'get_bits', 0xA0, 0, 195, 1, 0, 1),

    # Diagnostic Monitoring Type
    'DIAG_TX_PWR_MEAS_SUPPORT': (0, 'get_bits', 0xA0, 0, 220, 1, 2, 1),
    'DIAG_RX_PWR_MEAS_TYPE': (0, 'get_bits', 0xA0, 0, 220, 1, 3, 1),
    'DIAG_SUPPLY_VOLT_MON_IMPL': (0, 'get_bits', 0xA0, 0, 220, 1, 4, 1),
    'DIAG_TEMP_MON_IMPL': (0, 'get_bits', 0xA0, 0, 220, 1, 5, 1),

    # Enhanced Options
    'DIAG_MONITOR_TYPE': (0, 'get_int', 0xA0, 0, 220, 1),
    'ENH_OPT_INIT_COMPLETE_IMPL': (0, 'get_bits', 0xA0, 0, 221, 1, 4, 1),
    'ENH_OPT_RATE_SEL_DECLARATION': (0, 'get_bits', 0xA0, 0, 221, 1, 3, 1),
    'ENH_OPT_TC_READINESS_IMPL': (0, 'get_bits', 0xA0, 0, 221, 1, 1, 1),
    'ENH_OPT_SW_RESET_IMPL': (0, 'get_bits', 0xA0, 0, 221, 1, 0, 1),

    # Tx Input Equalizer options
    'MAX_TX_INPUT_EQ_SUPPORT': (0, 'get_bits', 0xA0, 3, 224, 1, 7, 4),

    # Rx Output Emphasis options
    'MAX_RX_OUT_EMPHASIS_SUPPORT': (0, 'get_bits', 0xA0, 3, 224, 1, 3, 4),
    'RX_OUT_EMPHASIS_TYPE': (0, 'get_bits', 0xA0, 3, 225, 1, 5, 2),

    # Rx Output Amplitude options
    'RX_OUT_AMPLITUDE_SUPPORT': (0, 'get_bits', 0xA0, 3, 225, 1, 3, 4),

    # Optional Controls and FEC Capabilities (Page 03h, Byte 227)
    'HOST_SIDE_FEC_CTRL_CAP':      (0, 'get_bits', 0xA0, 3, 227, 1, 7, 1),
    'MEDIA_SIDE_FEC_CTRL_CAP':     (0, 'get_bits', 0xA0, 3, 227, 1, 6, 1),
    # Bits [5:4] Reserved
    'TX_FORCE_SQUELCH_CAP':        (0, 'get_bits', 0xA0, 3, 227, 1, 3, 1),
    'RX_LOS_FAST_MODE_CAP':        (0, 'get_bits', 0xA0, 3, 227, 1, 2, 1),
    'TX_DISABLE_FAST_MODE_CAP':    (0, 'get_bits', 0xA0, 3, 227, 1, 1, 1),

    'MAX_TC_STABILIZATION_TIME': (0, 'get_int', 0xA0, 3, 228, 1),
    'MAX_CTLE_SETTLING_TIME':    (0, 'get_int', 0xA0, 3, 229, 1),

    # Host- and Media-Side FEC Control (Page 03h, Byte 230)
    'HOST_SIDE_FEC_ENABLE':  (0, 'get_bits', 0xA0, 3, 230, 1, 7, 1),
    'MEDIA_SIDE_FEC_ENABLE': (0, 'get_bits', 0xA0, 3, 230, 1, 6, 1),
    # Bits [5:0] Reserved

    # Force Squelch Control (Page 03h, Byte 231)
    # Bits [7:4] Reserved
    'TX4_FORCE_SQUELCH':     (0, 'get_bits', 0xA0, 3, 231, 1, 3, 1),
    'TX3_FORCE_SQUELCH':     (0, 'get_bits', 0xA0, 3, 231, 1, 2, 1),
    'TX2_FORCE_SQUELCH':     (0, 'get_bits', 0xA0, 3, 231, 1, 1, 1),
    'TX1_FORCE_SQUELCH':     (0, 'get_bits', 0xA0, 3, 231, 1, 0, 1),

    # Tx Adaptive Equalizer Freeze (Byte 233)
    'TX1_AE_FREEZE': (0, 'get_bits', 0xA0, 3, 233, 1, 3, 1),
    'TX2_AE_FREEZE': (0, 'get_bits', 0xA0, 3, 233, 1, 2, 1),
    'TX3_AE_FREEZE': (0, 'get_bits', 0xA0, 3, 233, 1, 1, 1),
    'TX4_AE_FREEZE': (0, 'get_bits', 0xA0, 3, 233, 1, 0, 1),

    # Tx Input Equalizer Control (Bytes 234-235)
    'TX1_INPUT_EQ_CTRL': (0, 'get_bits', 0xA0, 3, 234, 1, 7, 4),
    'TX2_INPUT_EQ_CTRL': (0, 'get_bits', 0xA0, 3, 234, 1, 3, 4),
    'TX3_INPUT_EQ_CTRL': (0, 'get_bits', 0xA0, 3, 235, 1, 7, 4),
    'TX4_INPUT_EQ_CTRL': (0, 'get_bits', 0xA0, 3, 235, 1, 3, 4),

    # Rx Output Emphasis Control (Bytes 236-237)
    'RX1_OUTPUT_EMPH_CTRL': (0, 'get_bits', 0xA0, 3, 236, 1, 7, 4),
    'RX2_OUTPUT_EMPH_CTRL': (0, 'get_bits', 0xA0, 3, 236, 1, 3, 4),
    'RX3_OUTPUT_EMPH_CTRL': (0, 'get_bits', 0xA0, 3, 237, 1, 7, 4),
    'RX4_OUTPUT_EMPH_CTRL': (0, 'get_bits', 0xA0, 3, 237, 1, 3, 4),

    # Rx Output Amplitude Control (Bytes 238-239)
    'RX1_OUTPUT_AMPL_CTRL': (0, 'get_bits', 0xA0, 3, 238, 1, 7, 4),
    'RX2_OUTPUT_AMPL_CTRL': (0, 'get_bits', 0xA0, 3, 238, 1, 3, 4),
    'RX3_OUTPUT_AMPL_CTRL': (0, 'get_bits', 0xA0, 3, 239, 1, 7, 4),
    'RX4_OUTPUT_AMPL_CTRL': (0, 'get_bits', 0xA0, 3, 239, 1, 3, 4),

    # Rx/Tx Squelch Disable Control (Byte 240)
    'RX4_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 7, 1),
    'RX3_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 6, 1),
    'RX2_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 5, 1),
    'RX1_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 4, 1),
    'TX4_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 3, 1),
    'TX3_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 2, 1),
    'TX2_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 1, 1),
    'TX1_SQ_DISABLE': (0, 'get_bits', 0xA0, 3, 240, 1, 0, 1),

    # Rx/Tx Output Disable and Tx Adaptive EQ Control (Byte 241)
    'RX4_OUTPUT_DISABLE':   (0, 'get_bits', 0xA0, 3, 241, 1, 7, 1),
    'RX3_OUTPUT_DISABLE':   (0, 'get_bits', 0xA0, 3, 241, 1, 6, 1),
    'RX2_OUTPUT_DISABLE':   (0, 'get_bits', 0xA0, 3, 241, 1, 5, 1),
    'RX1_OUTPUT_DISABLE':   (0, 'get_bits', 0xA0, 3, 241, 1, 4, 1),
    'TX4_ADAPT_EQ_CTRL':    (0, 'get_bits', 0xA0, 3, 241, 1, 3, 1),
    'TX3_ADAPT_EQ_CTRL':    (0, 'get_bits', 0xA0, 3, 241, 1, 2, 1),
    'TX2_ADAPT_EQ_CTRL':    (0, 'get_bits', 0xA0, 3, 241, 1, 1, 1),
    'TX1_ADAPT_EQ_CTRL':    (0, 'get_bits', 0xA0, 3, 241, 1, 0, 1),

    # FEC control
    'FEC_CTRL_ENABLE': (1, 'get_bits', 0xA0, 3, 230, 1, 7, 2),
}
new_wm_keys = {
    'SW_RESET': 'set_bits',
    'RESERVED_118': 'set_int',
    'POWER_SET': 'set_bits',
    'POWER_OVERRIDE': 'set_bits',
    'FEC_CTRL_ENABLE': 'set_bits',
}

# Add these keys to the memory map, and write map for QSFP+ and QSFP28 devices
def add_qsfp_keys(port):
    QSFP_PLUS = 0xD
    QSFP28 = 0x11
    if (port.port_type != QSFP_PLUS) and (port.port_type != QSFP28):
        return
    port.mmap.update(new_mm_keys)
    port.wmap.update(new_wm_keys)
