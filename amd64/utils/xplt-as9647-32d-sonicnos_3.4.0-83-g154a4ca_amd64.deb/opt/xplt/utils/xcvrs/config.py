#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import argparse
import time
import sys
import os
from vendor_info import part_numbers, app_dict, fec_modes
import helpers
from helpers import is_sff_8636_module

config_modes = [
    'One config for all at once',
    'All configs one by one',
]

breakout_modes = [
    '8H800-8M800',
    '4H400-4M400',
    '2H200-2M200',
    '1H100-1M100',
    '8H400-8M400',
    '4H200-4M200',
    '2H100-2M100',
    '1H50-1M50',
    '4H100-4M100',
]

parser = argparse.ArgumentParser(description='Configure supported optical modules',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type=int,
                    nargs='?',
                    default=None,
                    action=helpers.PortAction,
                    help=f'Starting port. If given alone, only this port is processed; otherwise, all ports are processed')

parser.add_argument('last',
                    type=int,
                    nargs='?',
                    default=None,
                    action=helpers.PortAction,
                    help=f'Ending port number. If provided, ports from first to last (inclusive) are processed')

parser.add_argument('-u',
                    '--url',
                    type=str,
                    help='Hostname or IP address of the oomjsonsvr server')

parser.add_argument('-s',
                    '--standalone',
                    action='store_true',
                    help='Standalone mode')

parser.add_argument('-a',
                    '--autoconfig',
                    action='store_true',
                    help='Automatically select and configure the application based on the selected breakout mode.')

parser.add_argument('--skipfir',
                    action='store_true',
                    help='Skip FIR profile configuration for the modules. Useful for modules that do not require FIR configuration.')

parser.add_argument('-m',
                    '--mode',
                    type=int,
                    choices=[i for i in range(1, (len(config_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, config_modes[i])
                                   for i in range(len(config_modes))))

parser.add_argument('-b',
                    '--breakout',
                    default=4,
                    type=int,
                    choices=[i for i in range(1, (len(breakout_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, breakout_modes[i])
                                   for i in range(len(breakout_modes))))

parser.add_argument('--PN',
                    type=str,
                    choices=part_numbers,
                    default="T-OS8CNS-N00",
                    help=(
                        'Specify the part number to use when running in "One config for all at once" mode (-m 1).\n'
                        'Choose from the supported part numbers below (default: T-OS8CNS-N00):\n' +
                        ''.join('[{}] - {}\n'.format(i + 1, part_numbers[i])
                                for i in range(len(part_numbers)))
                    ))

parser.add_argument('-v',
                    '--verbose',
                    action='count',
                    default=0,
                    help='Increase verbosity level (e.g., -v, -vv, -vvv). Default is 0 (no verbosity).')

args = parser.parse_args()

if args.standalone:
    import oom
    if args.url != None:
        oom.oomlib.setshim("oomjsonshim", args.url)
else:
    try:
        import oomlwclient as oom
        oom.oomlwclient_init(args.url)
    except:
        if args.verbose > 1:
            print("Running in standalone mode")
        import oom
        if args.url != None:
            oom.oomlib.setshim("oomjsonshim", args.url)

# We do not configure the FIR (profile) by default.
# To configure module's FIR, add its part number to this list.
set_fir_modules = []

profiles = {
    '1064281000': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    '2253611007': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'T-DP4CNH-N00': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'T-OP8CDT-N00': {
        '8H800-8M800': (106, 0),
        '4H400-4M400': (106, 0),
        '2H200-2M200': (106, 0),
        '1H100-1M100': (106, 0),
        '8H400-8M400': (106, 0),
        '4H200-4M200': (106, 0),
        '2H100-2M100': (106, 0),
        '1H50-1M50':   (106, 0)
    },
    'CAC82X321M1MB0HW': {
        '8H800-8M800': (50, 0),
        '4H400-4M400': (50, 0),
        '2H200-2M200': (50, 0),
        '1H100-1M100': (50, 0),
        '8H400-8M400': (50, 0),
        '4H200-4M200': (50, 0),
        '2H100-2M100': (50, 0),
        '1H50-1M50':   (50, 0)
    },
    'CAC825321A1AC0HW': {
        '8H800-8M800': (85, 7),
        '4H400-4M400': (85, 5),
        '2H200-2M200': (85, 3),
        '1H100-1M100': (85, 1),
        '8H400-8M400': (85, 7),
        '4H200-4M200': (85, 5),
        '2H100-2M100': (85, 3),
        '1H50-1M50':   (85, 1)
    },
    'T-OS8CNS-N00': {
        '8H800-8M800': (106, 4),
        '4H400-4M400': (106, 6),
        '2H200-2M200': (106, 8),
        '1H100-1M100': (106, 10),
        '8H400-8M400': (106, 11),
        '4H200-4M200': (106, 12),
        '2H100-2M100': (106, 13),
        '1H50-1M50':   (106, 13)
    },
    'T-OH8CNH-N00': {
        '8H800-8M800': (106, 9),
        '4H400-4M400': (106, 7),
        '2H200-2M200': (106, 8),
        '1H100-1M100': (106, 8),
        '8H400-8M400': (106, 3),
        '4H200-4M200': (106, 3),
        '2H100-2M100': (106, 3),
        '1H50-1M50':   (106, 3)
    },
    '2476103-5': {
        '8H800-8M800': (106, 1),
        '4H400-4M400': (106, 3),
        '2H200-2M200': (106, 3),
        '1H100-1M100': (106, 3),
        '8H400-8M400': (106, 5),
        '4H200-4M200': (106, 6),
        '2H100-2M100': (106, 6),
        '1H50-1M50':   (106, 6)
    },
    'ET8001-SR8': {
        '8H800-8M800': (106, 1),
        '4H400-4M400': (106, 2),
        '2H200-2M200': (106, 3),
        '1H100-1M100': (106, 4),
        '8H400-8M400': (106, 4),
        '4H200-4M200': (106, 4),
        '2H100-2M100': (106, 4),
        '1H50-1M50':   (106, 4)
    }
}

def configure_fec(pi, v_pn, brkout):
    if v_pn in fec_modes:
        fecm = fec_modes[v_pn].get(brkout)
        if fecm is not None:
            if args.verbose > 1:
                print(f"Configuring FEC mode: {fecm}")
            config_fec = f"sudo {calib} {pi} --set_fec {fecm}"

            a = os.popen(config_fec).read()
            if args.verbose > 1: print(a)
        else:
            if args.verbose > 1:
                print(f"FEC mode not found for {v_pn} with breakout mode {brkout}")
    else:
        if args.verbose > 1:
            print(f"FEC mode not found for {v_pn}")

calib = "/opt/xplt/utils/xcvrs/calib.py"

if args.standalone:
    calib = calib + " -s"

def main():
    portlist, max_ports = helpers.get_port_list(oom)
    first, last = helpers.check_port_max_number(args.first, args.last, max_ports)

    brkout = breakout_modes[args.breakout - 1]
    if args.verbose > 1:
        print(f"Selected breakout mode: [{args.breakout}] - {brkout}")

    if args.mode == 1:
        pn = args.PN
        try:
            pni = part_numbers.index(pn) + 1  # P/N index in part_numbers list, starting from 1
        except ValueError:
            print(f"Part number {pn} not found in part_numbers list.")
            sys.exit(1)

        print(f"Configuring ports {first} to {last} with breakout mode: {brkout}")
        if not args.autoconfig and pn in profiles and brkout in profiles[pn]:
            app_id = profiles[pn][brkout][1]
            set_app = f"sudo {calib} {first} {last} --PN {pni} --set_app {app_id}"
        else:
            set_app = f"sudo {calib} {first} {last} --PN {pni} --set_app {brkout}"

        # Build FEC configuration command if FEC mode is available
        fecm = fec_modes.get(pn, {}).get(brkout)
        if fecm is not None:
            if args.verbose > 1:
                print(f"PN: {pn}, Breakout: {brkout}, FEC mode: {fecm}")
            config_fec = f"sudo {calib} {first} {last} --PN {pni} --set_fec {fecm}"
        else:
            if args.verbose > 1:
                print(f"FEC mode not found for {pn}")
            config_fec = None

        cmds = [f"sudo {calib} {first} {last} --PN {pni} -u"]
        if config_fec is not None:
            cmds.append(config_fec)
        if args.skipfir or pn not in set_fir_modules:
            if args.verbose > 1:
                print(f"Skipping FIR configuration for {pn}")
        else:
            cmds.append(f"sudo {calib} {first} {last} --PN {pni} -p {profiles[pn][brkout][0]}")
        cmds.append(set_app)
        cmds.append(f"sudo {calib} {first} {last} --PN {pni} -l 4 0xff off")

        for idx, cmd in enumerate(cmds):
            if args.verbose > 1: print(cmd)
            a = os.popen(cmd).read()
            if idx == 0: time.sleep(1)
            if args.verbose > 0: print(a)
    else:
        first -= 1
        for i in range (first, last):
            port = portlist[i]
            pi = i + 1

            modtype = oom.type_to_str(port.port_type)
            if modtype == 'UNKNOWN':
                modtype = 'No Module'
                continue

            v_pn = oom.oom_get_keyvalue(port, 'VENDOR_PN').strip()
            if args.autoconfig or v_pn not in part_numbers:
                a = os.popen(f"sudo {calib} {pi} -u").read()
                if args.verbose > 1: print(a)
                time.sleep(1)
                if not is_sff_8636_module(port):
                    a = os.popen(f"sudo {calib} {pi} --set_app {brkout}").read()
                    if args.verbose > 0: print(a)
                    a = os.popen(f"sudo {calib} {pi} -l 4 0xff off").read()
                    if args.verbose > 1: print(a)
                else:
                    configure_fec(pi, v_pn, brkout)
                continue

            for pn in part_numbers:
                if pn == v_pn:
                    a = os.popen(f"sudo {calib} {pi} -u").read()
                    if args.verbose > 1: print(a)
                    time.sleep(1)
                    if not args.skipfir and pn in set_fir_modules:
                        a = os.popen(f"sudo {calib} {pi} -p {profiles[pn][brkout][0]}").read()
                        if args.verbose > 1: print(a)
                    if not is_sff_8636_module(port):
                        if pn in profiles and profiles[pn][brkout][1] != 0:
                            a = os.popen(f"sudo {calib} {pi} --set_app {profiles[pn][brkout][1]}").read()
                            if args.verbose > 0: print(a)
                        a = os.popen(f"sudo {calib} {pi} -l 4 0xff off").read()
                        if args.verbose > 1: print(a)
                    else:
                        configure_fec(pi, v_pn, brkout)
                    break

if __name__ == "__main__":
    main()
