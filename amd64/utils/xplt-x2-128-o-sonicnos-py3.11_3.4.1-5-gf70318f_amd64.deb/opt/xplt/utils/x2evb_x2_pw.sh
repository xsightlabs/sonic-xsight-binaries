#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

progname=$(basename $0)
verbose=0
nodered=0
polling=0
usercmd=''

function usage() {
    cat << help

Usage: $progname [-h] [-n] [-s RATE] [-v LEVEL] [-u CMD]
    -h, --help             Show this help message and exit
    -n, --nodered          Node-red formatted output
    -p, --polling RATE     Measure in loop at RATE seconds, ^C to exit
    -v, --verbose LEVEL    More verbose output, range 1..2
    -u, --usercmd CMD      user defined command string to use with -n
Examples:
    sudo ./$progname
    sudo ./$progname -v1
    sudo ./$progname -n -p1
    sudo ./$progname -n -p2 -u "nc -q 1 localhost 2233"

help
}

OPTS=$(getopt -o "hnp:v:u:" --long "help,nodered,polling:,verbose:,usercmd:" \
     -n "$progname" -- "$@")

eval set -- "$OPTS"

while true; do
    case "$1" in
        -h | --help ) usage; exit 0 ;;
        -n | --nodered ) nodered=1; shift ;;
        -p | --polling ) polling="$2"; shift 2 ;;
        -v | --verbose ) verbose="$2"; shift 2 ;;
        -u | --usercmd ) usercmd="$2"; shift 2 ;;
        -- ) shift; break ;;
        * ) break ;;
    esac
done

xpli > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "$progname: Failed to run xpli, exiting"
    exit 1
fi

keys=(
    VDD_CORE
    VDD_SD
    VDD_L1
    VDD_L2
    VDD_L3
    VDD_L4
    VDD_H1
    VDD_H2
    VDD_H3
    VDD_H4
)

declare -A voltages
declare -A currents
declare -A powers

function collect_readings() {
    VX=$(echo "$3" | grep $1 | tr -s ' ' | cut -d " " -f2)
    VD=$(echo $(($VX)))
    AX=$(echo "$4" | grep $1 | tr -s ' ' | cut -d " " -f2)
    AD=$(awk "BEGIN {printf \"%.1f\",$(echo $(($AX))) / 1000}")
    PW=$(awk "BEGIN {printf \"%.2f\",$VD * $AD / 1000}")
    voltages[$2]=$VD
    currents[$2]=$AD
    powers[$2]=$PW
    TP=$(awk "BEGIN {printf \"%.2f\",$TP + $PW}")
}

function display_readings() {
    if [ $nodered -eq 1 ]; then
        if [ $(echo -n "$usercmd" | wc -m) -gt 0 ]; then
            echo $TP | eval $usercmd
        else
            printf '%s\n' $TP
        fi
        return
    else
        separator=$(printf '%.0s-' {1..86})
        format='%8s'
        [ $polling -eq 0 ] && printf '\n'
        printf '%s power(W) %11s' X2 $TP
    fi
    if [ $verbose -gt 0 ]; then
        printf '\n'$separator
        printf '\n      '
        for key in ${keys[@]}; do
            printf $format ${key}
        done
        printf '\nP(W): '
        for key in ${keys[@]}; do
            printf $format ${powers[$key]}
        done
    fi
    if [ $verbose -gt 1 ]; then
        printf '\nI(A): '
        for key in ${keys[@]}; do
            printf $format ${currents[$key]}
        done
        printf '\nV(mV):'
        for key in ${keys[@]}; do
            printf $format ${voltages[$key]}
        done
    fi
    printf '\n\n'
}

function read_power() {
    voltages=()
    currents=()
    powers=()
    TP=0

    TABLE_V=$(xpli show voltage 2>/dev/null)
    TABLE_C=$(xpli show current 2>/dev/null)

    # VDD_CORE
    collect_readings VDDCORE VDD_CORE "$TABLE_V" "$TABLE_C"

    # VDD_SD
    collect_readings VDDSD VDD_SD "$TABLE_V" "$TABLE_C"

    # VDD_L1
    collect_readings VDDL_1_2_0 VDD_L1 "$TABLE_V" "$TABLE_C"

    # VDD_L2
    collect_readings VDDL_1_2_1 VDD_L2 "$TABLE_V" "$TABLE_C"

    # VDD_L3
    collect_readings VDDL_3_4_0 VDD_L3 "$TABLE_V" "$TABLE_C"

    # VDD_L4
    collect_readings VDDL_3_4_1 VDD_L4 "$TABLE_V" "$TABLE_C"

    # VDD_H1
    collect_readings VDDH_1_2_0 VDD_H1 "$TABLE_V" "$TABLE_C"

    # VDD_H2
    collect_readings VDDH_1_2_1 VDD_H2 "$TABLE_V" "$TABLE_C"

    # VDD_H3
    collect_readings VDDH_3_4_0 VDD_H3 "$TABLE_V" "$TABLE_C"

    # VDD_H4
    collect_readings VDDH_3_4_1 VDD_H4 "$TABLE_V" "$TABLE_C"

    display_readings
}

if [ $polling -eq 0 ]; then
    read_power
else
    while :; do read_power; sleep $polling; done
fi
