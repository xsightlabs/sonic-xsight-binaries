#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import sys
from test_chip import xpci

XREG_GLC0_DEVICE_ID_AND_SOCKET_ID_ADDR = 0x3EC1120
XREG_GLC1_FLASH_ID_ADDR = 0x3ec8700
XREG_GLC3_FLASH_VERSION_ADDR = 0x3ed8328
XREG_GLC1_FUSE_DATA_ADDR = 0x3ecc000

def xhal_device_get_chip_id():
    glc_data = (pci_dev.read_reg(XREG_GLC0_DEVICE_ID_AND_SOCKET_ID_ADDR, True).value)
    device_id = glc_data & 0x1f
    socket_id = (glc_data >> 32) & 0x03
    return [device_id, socket_id]

def decode_to_ascii(code):
    if code <= 10:
        return "{}".format(code)
    else:
        return chr(ord('A') - 10 + code)

def xhal_device_get_fuses_w0():
    glc_data = (pci_dev.read_reg(XREG_GLC1_FUSE_DATA_ADDR, True).value)
    efuses = list(range(9))
    for idx in range(6):
        efuses[idx] = decode_to_ascii((glc_data >> (idx * 6)) & 0x3f)
    efuses[6] = (glc_data >> 36) & 0x1f
    efuses[7] = (glc_data >> 41) & 0xff
    efuses[8] = (glc_data >> 49) & 0xff
    return efuses

def xhal_device_get_fuses_w1():
    glc_data = (pci_dev.read_reg(XREG_GLC1_FUSE_DATA_ADDR + 8, True).value)
    metal_ver = glc_data & 0x07
    si_ver = (glc_data >> 3) & 0x07
    sub_num = (glc_data >> 6) & 0x07
    prod_num = (glc_data >> 9) & 0x07
    package_rev = (glc_data >> 16) & 0xff
    efuses = [package_rev, prod_num, sub_num, si_ver, metal_ver]
    return efuses

def xhal_device_get_flash_id():
    glc_data = (pci_dev.read_reg(XREG_GLC1_FLASH_ID_ADDR, True).value)
    return glc_data

def xhal_device_get_flash_version():
    glc_data = (pci_dev.read_reg(XREG_GLC3_FLASH_VERSION_ADDR, True).value)
    flash_version = glc_data & 0xffff
    cmd_cnt = (glc_data >> 32) & 0xffff
    flash_ver_id = (glc_data >> 48) & 0xffff
    flash_ver_reg = [flash_version, cmd_cnt, flash_ver_id]
    return flash_ver_reg

fd = open("/dev/xpci", "wb", buffering=0)
pci_dev = xpci(fd)

def main(argv):
    reg = xhal_device_get_fuses_w0()
    print("Lot ID: {}{}{}{}{}{}".format(reg[5], reg[4], reg[3], reg[2], reg[1], reg[0]))
    print("Wafer: {}".format(reg[6]))
    print("X/Y: {}/{}".format(reg[7], reg[8]))
    print("Fuses #1: {}".format(xhal_device_get_fuses_w1()))
    reg = xhal_device_get_chip_id()
    print("Socket ID: {}".format(reg[1]))
    print("Device ID: {}".format(reg[0]))
    reg = xhal_device_get_flash_version()
    print("Flash Version: {}".format(reg[0]))
    print("Flash Version ID: {}".format(reg[2]))
    print("Flash Chip ID: {}".format(hex(xhal_device_get_flash_id())))

if __name__ == '__main__':
    main(sys.argv[1:])
