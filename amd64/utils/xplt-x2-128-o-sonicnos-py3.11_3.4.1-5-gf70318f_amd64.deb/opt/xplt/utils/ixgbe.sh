#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

(return 0 2>/dev/null) && sourced=1 || sourced=0

if [ $sourced == 1 ]; then
        er_exit="return"
        ok_exit="return"
else
        er_exit="exit 1"
        ok_exit="exit 0"
fi

# Set this flag to "true" to install the custom driver version "5.20.9_xs"
USE_CUSTOM_DRIVER=false
NEXUS_REPO=http://x-nexus:8081/repository
CUSTOM_DRV_VER="5.20.9_xs"
GCC_VER=/usr/bin/gcc-9
TAR_FILE=ixgbe-${CUSTOM_DRV_VER}.tar.gz
TAR_DIR=/tmp
TAR=$TAR_DIR/$TAR_FILE
PLATFORM="xplt-x2evb"

function build_custom_driver() {
    mkdir -p $TAR_DIR
    if [ ! -f "$TAR" ]; then
        echo "Cannot find $TAR, try to fetch from the Nexus repo: $NEXUS_REPO"
        wget -nv "$NEXUS_REPO/$PLATFORM/tar/$TAR_FILE" -O "$TAR"
    fi
    if [ ! -f "$TAR" ]; then
        echo "Cannot find $TAR"
        eval "$er_exit"
    fi
    [ -d ixgbe ] && rm -rf ixgbe
    tar -xzvf $TAR >/dev/null 2>&1
    cd ixgbe/src
    make CC=$GCC_VER || eval "$er_exit"
    make CC=$GCC_VER install || eval "$er_exit"
    cd ../..
    rm -rf ixgbe $TAR
    echo "Please reboot the system"
}

function install_driver() {
    KERNEL_VERSION=$(uname -r)
    # Unload ixgbe module
    modprobe -r ixgbe
    if [ "$USE_CUSTOM_DRIVER" == false ]; then
        # Delete custom ixgbe driver
        MOD_DIR="/lib/modules/$KERNEL_VERSION"
        IXGBE_PATH="$MOD_DIR/updates/drivers/net/ethernet/intel/ixgbe"
        sudo rm -rf "$IXGBE_PATH"
    fi
    # Rebuild module dependency, regenerate initramfs, load the module
    depmod -a
    update-initramfs -u -k "$KERNEL_VERSION"
    modprobe ixgbe
}

eth_info=$(ethtool -i eth10g0 2>/dev/null)
version_line=$(echo "$eth_info" | grep "version:" | head -n1)
current_version=$(echo "$version_line" | awk '{print $2}')
if [ "$USE_CUSTOM_DRIVER" == true ]; then
    if [ "$current_version" == "$CUSTOM_DRV_VER" ]; then
        echo "ixgbe driver is of the latest custom $CUSTOM_DRV_VER version"
    else
        build_custom_driver
        install_driver
    fi
else
    if [ "$current_version" == "$CUSTOM_DRV_VER" ]; then
        # Restore original driver
        install_driver
    fi
fi
