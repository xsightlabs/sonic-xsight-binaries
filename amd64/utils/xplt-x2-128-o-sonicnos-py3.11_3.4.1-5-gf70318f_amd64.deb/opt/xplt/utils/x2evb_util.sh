#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

# Usage: x2evb_util.sh [init|deinit]
#

UTILS=/opt/xplt/utils

if [[ -d $UTILS/xcvrs ]]; then
	$UTILS/xcvrs/xcvr_setup.sh $1
else
	$UTILS/x2cmp_util.sh $1
fi
