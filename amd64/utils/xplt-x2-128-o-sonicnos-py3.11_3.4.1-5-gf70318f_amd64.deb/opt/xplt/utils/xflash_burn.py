#!/opt/xplt/venv/bin/python

# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import os, fcntl
import sys
from ioctl_opt import IOR, IOW, IOC, IOC_READ, IOC_WRITE
import ctypes
import IPython
import argparse
import time
import binascii
import random
from optparse import OptionParser
import subprocess
from multiprocessing import Pool, Manager
from threading import Thread
import subprocess
from queue import Queue  # Updated for Python 3
import json
import re

global_ver = "v_01"
global_verbose = 0
XREG_GLC3_INTG_SPARE = 0x3ed8100
# x2
X2REG_GLC1_REG2APB_CFG = 0x3ECB000
X2REG_GLC1_REG2APB_STATUS = 0x3ECB008

SPIM_INIT_ADDR = 0x00000000
SPIM_BACKUP_INIT_ADDR= 0x00010000
SPIM_SEC_INIT_ADDR = 0x00100000
SPIM_BACKUP_SEC_INIT_ADDR = 0x00110000
SPIM_WARM_INIT_ADDR = 0x00020000
SPIM_WARM_BACKUP_INIT_ADDR = 0x00030000
SPIM_WARM_SEC_INIT_ADDR = 0x00120000
SPIM_WARM_BACKUP_SEC_INIT_ADDR = 0x00130000

###########################################################################
# svlib code
###########################################################################

def bytearray_to_bytestream(ba, space=False, reverse=False):
    """ Converts bytearray (Python) to a string of bytes (2 chars per byte).

    Args:
        ba (bytearray): the bytearray (Python) to convert
        space (boolean): insert space between each byte?
        reverse (boolean): should the bytearray be handled in reverse order
    Returns:
        str: Returns string with 2 chars per byte from bytearray, in upper case

    Raises:
        ValueError: if value is not a bytearray
    """
    if not isinstance(ba, bytearray):
        raise ValueError("bytearray_to_bytestream: input not a bytearray (Python) - %s (%s)" % (ba,type(ba)))
    if reverse:
        s = binascii.hexlify(reversed(ba)).upper()
    else:
        s = binascii.hexlify(ba).upper()

    if space:
        bytestream = " ".join(s[i:i + 2] for i in range(0, len(s), 2))
    else:
        bytestream = s

    return bytestream

###########################################################################
# xpci code
###########################################################################

class _regd(ctypes.Structure):
    _fields_ = [
        ('addr', ctypes.c_uint),
        ('value', ctypes.c_uint64),
    ]

class _cfgd(ctypes.Structure):
    _fields_ = [
        ('data', ctypes.c_uint),
        ('res', ctypes.c_uint64),
    ]

class _capd(ctypes.Structure):
    _fields_ = [
        ('cap', ctypes.c_uint),
    ]

class _cmdd(ctypes.Structure):
    _fields_ = [
        ('value', ctypes.c_uint),
    ]

_XPCI_WRITE_REG = IOW(0x3a, 0x01, _regd)
_XPCI_READ_REG  = IOR(0x3a, 0x02, _regd)
_XPCI_CFG_REG   = IOR(0x3a, 0x03, _regd)
_XPCI_DMA_ALLOC = IOR(0x3a, 0x04, _cfgd)
_XPCI_DMA_FREE  = IOR(0x3a, 0x05, _cfgd)
_XPCI_HW_IRQ_SUPPORT = IOR(0x3a, 0x06, _capd)
_XPCI_X_DEVICE_RESET = IOR(0x3a, 0x07, _cmdd)

class xpci(object):
    """
    Provides methods to access XPCI device's ioctls.
    """
    def __init__(self, device):
        """
        device (file, fileno)
            A file object or a fileno of an open hidraw device node.
        """
        self._device = device

    def _ioctl(self, func, arg, mutate_flag=False):
        result = fcntl.ioctl(self._device, func, arg, mutate_flag)
        if result < 0:
            raise IOError(result)

    def write_reg(self, addr, value):
        xreg = _regd()
        xreg.addr = addr
        xreg.value = value
        if global_verbose > 2:
            print("Xflash_burn:: INFO : Write Addr {} Value {}".format(hex(xreg.addr), hex(xreg.value)))
        self._ioctl(_XPCI_WRITE_REG, xreg, True)

    def read_reg(self, addr):
        xreg = _regd()
        xreg.addr = addr
        self._ioctl(_XPCI_READ_REG, xreg, True)
        if global_verbose>2:
            print("Xflash_burn:: INFO : Read Addr {} Value {}".format(hex(xreg.addr), hex(xreg.value)))
        return xreg

    def cfg_reg(self, addr):
        xreg = _regd()
        xreg.addr = addr
        self._ioctl(_XPCI_CFG_REG, xreg, True)
        if global_verbose > 2:
            print("Xflash_burn:: INFO : Cfg {} Value {}".format(hex(xreg.addr), hex(xreg.value)))
        return xreg

    def dma_alloc(self, data):
        xcfg = _cfgd()
        xcfg.data = data
        self._ioctl(_XPCI_DMA_ALLOC, xcfg, True)
        if global_verbose > 2:
            print("Xflash_burn:: INFO : DMA Alloc {} Value {}".format(hex(xcfg.data), hex(xcfg.res)))
        return xcfg

    def dma_free(self, data):
        xcfg = _cfgd()
        xcfg.data = data
        self._ioctl(_XPCI_DMA_FREE, xcfg, True)
        return xcfg

    def hw_irq_cap_check(self):
        xcap = _capd()
        xcap.cap = 0
        self._ioctl(_XPCI_HW_IRQ_SUPPORT, xcap, True)
        if global_verbose > 2:
            print("Xflash_burn:: INFO : HW IRQ cap check value {}".format(hex(xcap.cap)))
        return xcap

    def x_device_reset(self, cmd):
        xcmd = _cmdd()
        xcmd.value = cmd
        if global_verbose > 2:
            print("Xflash_burn:: INFO : X Device Reset {}".format(hex(xcmd.value)))
        self._ioctl(_XPCI_X_DEVICE_RESET, xcmd, True)

    def auto_int(x):
        return int(x, 0)

###########################################################################
# xdt_flash code
###########################################################################

def write_command(xpci_dev, address, value):
    global X2REG_GLC1_REG2APB_CFG
    val = value +(address << 32) + (1 << 48)
    xpci_dev.write_reg(X2REG_GLC1_REG2APB_CFG, val)

def read_command(xpci_dev, address):
    global X2REG_GLC1_REG2APB_CFG
    global X2REG_GLC1_REG2APB_STATUS
    status = xpci_dev.read_reg(X2REG_GLC1_REG2APB_STATUS)
    busy = status.value & 0x8000000000000000
    while busy == 1:
        status = xpci_dev.read_reg(X2REG_GLC1_REG2APB_STATUS)
        busy = status.value & 0x8000000000000000
    val = (address << 32) + (0 << 48)
    xpci_dev.write_reg(X2REG_GLC1_REG2APB_CFG, val)
    status = xpci_dev.read_reg(X2REG_GLC1_REG2APB_STATUS)
    busy = status.value & 0x8000000000000000
    read_valid = status.value & 0x100000000
    while busy == 1 or read_valid == 0:
        print("STATUS:: {},{},{}".format(status.value,busy,read_valid))
        status = xpci_dev.read_reg(X2REG_GLC1_REG2APB_STATUS)
        busy = status.value & 0x8000000000000000
        read_valid = status.value & 0x100000000
    value = status.value & 0xFFFFFFFF

    msg = "address 0x{:08X} - value 0x{:08X}\n".format(address, value)
    return msg, value

#baud-rate is a divider value
def setup_flash_spi_master(xpci_dev, tmod=0x3, dfs=0x0, ndf=0x7, baudrate=0xFFFF):
    ctrl0 = dfs + (tmod << 8) + (dfs << 16)
    ctrl1 = ndf
    setup_cmds = [
        [0x8, 0x0],       #disable spi master
        [0x0, ctrl0],     #ctrl0
        [0x4, ctrl1],     #ctrl1
        [0x14, baudrate], #0xF000], #0xFFFF],  ##BAUDR:  16 bits
        [0x10, 0x1],      #set chip select
        [0x8, 0x1]]       #enable spi master
    for address, value in setup_cmds:
        write_command(xpci_dev=xpci_dev, address=address, value=value)
        time.sleep(0.0001)
    ready_bytes = read_command(xpci_dev=xpci_dev, address=0x24)[1]
    msg = "Ready Bytes = {}\n".format(ready_bytes)
    return msg

def wait_for_tx_to_finish_short(xpci_dev):
    status_reg = 0x0
    for x in range(1, 1000):
        status_reg = read_command(xpci_dev=xpci_dev, address=0x28)[1]# read the APB SPI status register
        tfe = status_reg & 0x4
        if tfe > 0:
            if global_verbose > 4:
                print("SPI APB SR : {:08b} {}".format(status_reg,x))
            break

def wait_for_tx_fifo_idle(xpci_dev):
    status_reg = 0x0
    for x in range(1, 1000):
        status_reg = read_command(xpci_dev=xpci_dev, address=0x28)[1]# read the APB SPI status register
        busy = status_reg & 0x1
        if busy == 0:
            if global_verbose > 4:
                print("Busy SPI APB SR : {:08b} {}".format(status_reg,x))
            break

def wait_for_respond_short(xpci_dev):
    status_reg = 0x0
    for x in range(1, 1000):
        status_reg = read_command(xpci_dev=xpci_dev, address=0x28)[1]# read the APB SPI status register
        rfne = status_reg & 0x8
        if rfne > 0:
            break

def read_flash_id(xpci_dev, bdr=0xFFFF):
    if global_verbose > 0:
        print("Xflash_burn:: INFO : The APB SPI version ID is 0x{:x}".format(
            read_command(xpci_dev=xpci_dev, address=0x5C)[1]))# get apb  SPI version
        print("Xflash_burn:: INFO : The APB IDR is 0x{:x}".format(
            read_command(xpci_dev=xpci_dev, address=0x58)[1]))
    setup_flash_spi_master(xpci_dev=xpci_dev, tmod=0x3, dfs=0x7, ndf=0x13, baudrate=bdr)
    read_bytes = 0x0
    start_time = time.time()
    flash_id = 0x0
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x9e)
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev,)
    wait_for_respond_short(xpci_dev=xpci_dev,)
    for i in range(0, 21):
        read_bytes = read_command(xpci_dev=xpci_dev, address=0x60)[1]
        flash_id += read_bytes << (i * 8)
    end_time = time.time()
    time.sleep(0.1)
    if global_verbose > 0:
        print("Xflash_burn:: INFO : receive device id bytes :")
        print("Xflash_burn:: INFO : READ ID = 0x{:x}".format(flash_id))
        print("Xflash_burn:: INFO : total {:0d} bytes read time {:0f} ".format(
            i + 1, end_time - start_time))
    msg = "flash id = 0x{:x}\n".format(flash_id)
    return msg, flash_id

# used once
def erase_flash_op(xpci_dev, flash_address, erase_type="4KB", bdr=0xFFFF):
    time.sleep(0.1)
    busy,fl = is_flash_busy(xpci_dev=xpci_dev, bdr=bdr)
    if global_verbose > 4:
        print("busy = 0x{:x}".format(busy))
    enable_write(xpci_dev,bdr)
    setup_flash_spi_master(xpci_dev, tmod=0x1, dfs=0x0, ndf=0x0, baudrate=bdr)
    if erase_type == "4KB":
        write_command(xpci_dev=xpci_dev, address=0x60, value=0x20)  # Flash erase 4KB
    elif erase_type == "32KB":
        write_command(xpci_dev=xpci_dev, address=0x60, value=0x52)  # Flash erase 32KB
    elif erase_type == "sector":
        write_command(xpci_dev=xpci_dev, address=0x60, value=0xD8)  # Flash erase sector
    elif erase_type == "die":
        write_command(xpci_dev=xpci_dev, address=0x60, value=0xC4)  # Flash erase die
    else:
        print("Xflash_burn:: ERROR : not a valid erase_type")
        return
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 16) & 0xFF))  # Address MSB
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 8) & 0xFF))  # Address
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 0) & 0xFF))  # Address LSB
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    for x in range(1, 1000):
        time.sleep(0.001)
        if (is_flash_busy(xpci_dev=xpci_dev, bdr=bdr)[0] == 0):
            break

def enable_write(xpci_dev, bdr=0xFFFF):
    for x in range(1, 3):
        fast_setup_flash_spi_master(xpci_dev,tmod=0x1, dfs=0x0, ndf=0x0, baudrate=bdr)
        write_command(xpci_dev=xpci_dev, address=0x60, value=0x6)  # Flash Write enable
        wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
        status_reg = get_flash_status(xpci_dev=xpci_dev, bdr=bdr)[0]# read the APB SPI status register
        wr_enable_lock = status_reg & 0x2
        if wr_enable_lock > 0:
            break

def disable_write(xpci_dev, bdr=0xFFFF):
    for x in range(1, 3):
        fast_setup_flash_spi_master(xpci_dev,tmod=0x1, dfs=0x0, ndf=0x0, baudrate=bdr)
        write_command(xpci_dev=xpci_dev, address=0x60, value=0x4)  # Flash Write disable
        wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
        status_reg = get_flash_status(xpci_dev=xpci_dev, bdr=bdr)[0]# read the APB SPI status register
        wr_enable_lock = status_reg & 0x2
        if wr_enable_lock == 0:
            break

def write_flash(xpci_dev, flash_address, number_of_bytes, data, bdr=0xFFFF):
    enable_write(xpci_dev, bdr)
    fast_setup_flash_spi_master(xpci_dev, tmod=0x1, dfs=0x0, ndf=0x0, baudrate=bdr)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x2)  # Flash program
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 16) & 0xFF)) # Address MSB
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 8) & 0xFF))  # Address
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 0) & 0xFF))  # Address LSB
    for i in range(0, number_of_bytes):
        wdata=((data >> i * 8) & 0xFF)
        write_command(xpci_dev=xpci_dev, address=0x60, value=wdata)
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)

def temp_write_flash(xpci_dev, flash_address, number_of_bytes, data, bdr=0xFFFF):
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x2)  # Flash program
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 16) & 0xFF)) # Address MSB
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 8) & 0xFF))  # Address
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 0) & 0xFF))  # Address LSB
    for i in range(0, number_of_bytes):
        wdata=((data >> i * 8) & 0xFF)
        write_command(xpci_dev=xpci_dev, address=0x60, value=wdata)
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    if global_verbose > 3:
        print("Write to flash 0x{:x} at adderss 0x{:x}".format(data, flash_address))

def read_flash(xpci_dev, flash_address, number_of_bytes, bdr=0xFFFF):
    msg = 0x0
    fast_setup_flash_spi_master(xpci_dev,tmod=0x3, dfs=0x7, ndf=number_of_bytes - 1, baudrate=bdr)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x3)  # read command
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 16) & 0xFF)) # Address MSB
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 8) & 0xFF))  # Address
    write_command(xpci_dev=xpci_dev, address=0x60, value=((flash_address >> 0) & 0xFF))  # Address LSB
    wait_for_Nbytes_respond(xpci_dev=xpci_dev, nob=number_of_bytes)
    for i in range(0, number_of_bytes):
        byte = read_command(xpci_dev=xpci_dev, address=0x60)[1]
        msg += byte << (i * 8)
    if global_verbose > 3:
        print("Read from flash 0x{:x} from adderss 0x{:x}".format(msg, flash_address))
    return msg

def fast_setup_flash_spi_master(xpci_dev, tmod=0x3, dfs=0x0, ndf = 0x7, baudrate=0xFFFF):
    ctrl0 = dfs + (tmod << 8) + (dfs << 16)
    ctrl1 = ndf
    setup_cmds = [
        [0x8, 0x0],   # disable spi master
        [0x0, ctrl0], # ctrl0
        [0x4, ctrl1], # ctrl1
        [0x8, 0x1]]   # enable spi master
    for address, value in setup_cmds:
        write_command(xpci_dev=xpci_dev, address=address, value=value)

def wait_for_Nbytes_respond(xpci_dev, nob=0x1):
    for x in range(1, 1000):
        r_b = read_command(xpci_dev=xpci_dev, address=0x24)[1]
        if r_b == nob :
            return r_b
        if r_b > 7:
            return r_b

def get_flash_status(xpci_dev, bdr=0xFFFF):
    fast_setup_flash_spi_master(xpci_dev=xpci_dev, tmod=0x3, dfs=0x0, ndf=0x0, baudrate=bdr)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x5)
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    wait_for_respond_short(xpci_dev=xpci_dev)
    status = read_command(xpci_dev=xpci_dev, address=0x60)[1]
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x70)
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    wait_for_respond_short(xpci_dev=xpci_dev)
    flags = read_command(xpci_dev=xpci_dev, address=0x60)[1]
    return status, flags

def is_flash_busy(xpci_dev, bdr=0xFFFF):
    status_reg,fl = get_flash_status(xpci_dev=xpci_dev, bdr=bdr) # read the APB SPI status register
    if global_verbose > 4:
        print("Xflash_burn:: STATUS : read the flash status register {:08X}, flags {:08X} ".format(status_reg,fl))
    return (status_reg, fl)

# not in use 5 sle_eps
def reset_flash_parameters(xpci_dev, bdr=0xFFFF):
    setup_flash_spi_master(xpci_dev=xpci_dev, tmod=0x1 , dfs=0x0 , ndf=0x0, baudrate=bdr)
    if global_verbose > 1:
        print ("Xflash_burn:: INFO : ***Reset flash parameters***")
    write_command(xpci_dev=xpci_dev, address=0x60, value=0xAB) # exit deep power down
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    time.sleep(0.1)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x66) # reset enable
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    time.sleep(0.1)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x99) # reset
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    time.sleep(0.1)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x50) # clear flag status
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    time.sleep(0.1)
    write_command(xpci_dev=xpci_dev, address=0x60, value=0x04) # write disable
    wait_for_tx_to_finish_short(xpci_dev=xpci_dev)
    time.sleep(0.1)

def get_image_version(path):
    if os.path.isfile(path):
        print("Xflash_burn:: INFO : Received file path {}".format(path))
    else:
        print("Xflash_burn:: ERROR : The file {} can't be found.".format(path))
        return 0
    with open(path, "rb") as f:
        data = f.read()
        end_of_image = bytearray_to_bytestream(bytearray(data)).index(b'000000000000000000000018') // 2 + 56
        print("Xflash_burn:: INFO : Found the footer at {}".format(end_of_image))
        data_ba = bytearray(data)
        version_line_bytestream = bytearray_to_bytestream(data_ba)
        if b'CC0F' in version_line_bytestream:
            image_version = version_line_bytestream.index(b'CC0F') - 4
        elif b'CC0A' in version_line_bytestream:
            image_version = version_line_bytestream.index(b'CC0A') - 4
        else:
            print("Xflash_burn:: ERROR : Version does not include CC0A or CC0F!!!")
            return 0
        version_number = (data_ba[image_version // 2 + 1] << 8) + data_ba[image_version // 2]
        print("Xflash_burn:: INFO : Image version is 0x{:x}".format(version_number))

    f.close()
    return version_number

def fix_write_enable():
    config_file_path = "/opt/xplt/xplt"
    with open(config_file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            if global_verbose > 3:
                print(line)
            if "plt" in line :
                if "x2-128-o" in line:
                    from sonic_platform import bmc
                    bmccmd = bmc.get_bmc()
                    # disable_xflash_write_protect() is only available on Bmc, not NullBmc
                    if not hasattr(bmccmd, 'disable_xflash_write_protect'):
                        print("Xflash_burn:: Error : BMC backend does not support disable_xflash_write_protect()")
                        sys.exit(1)
                    output = bmccmd.disable_xflash_write_protect()
                    if global_verbose > 0:
                        print("Output:")
                        print(output.decode("utf-8"))  # Decode from bytes to string
                    data = json.loads(output)
                    # Extract the values
                    res_value = data["result"]
                    res_sp =  re.split(r' ', res_value)
                    if global_verbose > 3:
                        print(res_sp)
                    hex_value = res_sp[5]
                    # Print the extracted variables
                    if global_verbose > 3:
                        print(f"Hex Value 2: {hex_value}")
                    if hex_value != "0x0000000000000033":
                        print("Xflash_burn:: Error : Failed to change the write enable pin state "
                                "please check communication with the FPGA")
                        sys.exit(1)
                else:
                    print("Xflash_burn:: Error : The W# - Write enable pin is driven low please fix it first")
                    if global_verbose > 3:
                        print("not EVB")
                    sys.exit(1)

def read_write_test(bpf=4, flash_address=0x15005, baudr=0x2F00, repeats=1):
    erase_size = "32KB"
    print("Xflash_burn:: INFO : checking the Write enable pin ")
    reg = _regd(0xFF, 0x01020304)
    fd = open("/dev/xpci", "wb", buffering=0)
    xpci_dev = xpci(fd)
    setup_flash_spi_master(xpci_dev=xpci_dev, tmod=0x11 , dfs=0x7 , ndf=0x4, baudrate=baudr)
    read_flash_id(xpci_dev=xpci_dev,bdr=baudr)
    for x in range(1, 10):
        status_reg = get_flash_status(xpci_dev=xpci_dev, bdr=baudr)[0]
        we = status_reg & 0x80
        if we == 0x0:
            print("Xflash_burn:: INFO : The W# - Write enable pin is driven high GOOD to go")
            time.sleep(0.2)
            break
    if we != 0x0:
        fix_write_enable()

    print("Xflash_burn:: INFO : start to erase at address {:08X} in size of {}".format(flash_address, erase_size))
    erase_flash_op(xpci_dev=xpci_dev, flash_address=flash_address, erase_type=erase_size, bdr=baudr)
    print("Xflash_burn:: INFO : set the address to 4 bytes")
    write_command(xpci_dev=xpci_dev, address=0x60, value=0xE9)
    for x in range(repeats):
        wdata = 0x0
        for i in range(0,bpf):
            ran_byte = random.randint(0,0xFF)<<8*i
            wdata += ran_byte
            if global_verbose > 5:
                print("{:08X} {:08X} ".format(wdata,ran_byte))
        print("Xflash_burn:: INFO : enable write {}".format(x))
        status_reg = 1
        while ((status_reg & 0x1) == 1):
            status_reg,fl = is_flash_busy(xpci_dev=xpci_dev, bdr=baudr)
        print("Xflash_burn:: INFO : write to flash_address 0x{:08X} the data 0x{:08X}".format(flash_address, wdata))
        write_flash(xpci_dev=xpci_dev, flash_address=flash_address, number_of_bytes=bpf, data=wdata, bdr=baudr)
        wait_for_tx_fifo_idle(xpci_dev)
        status_reg = 1
        while ((status_reg & 0x1)==1) :
            status_reg,fl = is_flash_busy(xpci_dev=xpci_dev, bdr=baudr)
        if global_verbose > 4:
            print("Xflash_burn:: INFO : read the status register {:08X} ".format(status_reg))
        print("Xflash_burn:: INFO : read the flash_address {:08X} ".format(flash_address))
        rdata = read_flash(xpci_dev=xpci_dev, flash_address=flash_address, number_of_bytes=bpf, bdr=baudr)
        rdata2 = read_flash(xpci_dev=xpci_dev, flash_address=flash_address, number_of_bytes=bpf, bdr=baudr)
        if wdata == rdata:
            print("Xflash_burn:: INFO : read data equal to written data W:{:08X} R:{:08X}".format(wdata, rdata))
        else:
            print("Xflash_burn:: ERROR : read data is not equal to written data W:{:08X} R:{:08X} {:08X} I:{}".format(
                wdata, rdata, rdata2, x))
        flash_address +=  bpf + 1

def write_image_write_read(path, bpf=4, flash_address=0x0, baudr=0x0010, delay_time=0):
    baudrate = baudr
    if os.path.isfile(path):
        print("Xflash_burn:: INFO : Received file path {} ".format(path))
    else:
        print("Xflash_burn:: ERROR : The file {} can't be found.".format(path))
        sys.exit(1)
    size = os.path.getsize(path)
    erase_size = "32KB"
    print("Xflash_burn:: INFO : The size of the file {} is {} B".format(path, size))

    with open(path, "rb") as f:
        data = f.read()
        end_of_image = bytearray_to_bytestream(bytearray(data)).index(b'000000000000000000000018') // 2 + 56
        print("Xflash_burn:: INFO : Found the footer at {}".format(end_of_image))
        if end_of_image > 2072:
            print("Xflash_burn:: Warning : image is too large for the basic Accton board configuration "
                  "only the first 2072 bytes will be read by the chip")
        else:
            print("Xflash_burn:: INFO : image size is {} bytes, 2072 bytes will be written as the "
                  "minimum size".format(end_of_image))
            end_of_image = 2072
        data_ba = bytearray(data)
        version_line_bytestream = bytearray_to_bytestream(data_ba)
        if b'CC0F' in version_line_bytestream:
            image_version = version_line_bytestream.index(b'CC0F') - 4
        elif b'CC0A' in version_line_bytestream:
            image_version = version_line_bytestream.index(b'CC0A') - 4
        else:
            print("Xflash_burn:: ERROR : image version does not include CC0A or CC0F!!!")
            sys.exit(1)
        version_number = (data_ba[image_version // 2 + 1] << 8) + data_ba[image_version // 2]
        print("Xflash_burn:: INFO : Image version is 0x{:x}".format(version_number))
    f.close()

    print("Xflash_burn:: INFO : checking the Write enable pin ")
    reg = _regd(0xFF, 0x01020304)
    fd = open("/dev/xpci", "wb", buffering=0)
    xpci_dev = xpci(fd)

    for x in range(1, 10):
        sr = get_flash_status(xpci_dev=xpci_dev, bdr=baudr)[0]
        we = sr&0x80
        if we == 0x0:
            time.sleep(0.2)
            break
    if we != 0x0:
        fix_write_enable()

    print("Xflash_burn:: INFO : Write enable pin is OK")
    size = end_of_image
    if size < 4096:
        erase_size = "4KB"
    elif size < 32768:
        erase_size ="32KB" # sub_sector
    elif size < 65536:
        erase_size ="sector" # 64KB
    else:
        erase_size = "die"

    print("Xflash_burn:: INFO : The size of the data is {} and erase {} to write the new data at address "
          "0x{:x}".format(size, erase_size, flash_address))
    erase_flash_op(xpci_dev=xpci_dev, flash_address=flash_address, erase_type=erase_size, bdr=baudr)
    print("Xflash_burn:: INFO : ***START programming the flash at address 0x{:x}***".format(flash_address))
    good_tx = 0
    bad_tx = 0
    ttx = 0
    ef_rdata = {}
    ef_wdata = {}
    rewirte = 0
    address = flash_address
    pstart_time = time.time()
    with open(path, "rb") as f:
        data = bytearray(f.read())
    f.close()
    x = 0
    wdata = 0x0
    retry = 0
    write_command(xpci_dev=xpci_dev, address=0x60, value=0xE9)
    while x < end_of_image:
        if rewirte == 0:
            wdata = 0x0
            for i in range(0, bpf):
                wdata += data[x + i] << i * 8
                if global_verbose > 5:
                    print("0x{:x}".format(wdata))
        ttx += bpf
        write_flash(xpci_dev=xpci_dev, flash_address=address, number_of_bytes=bpf, data=wdata, bdr=baudr)
        wait_for_tx_fifo_idle(xpci_dev)
        status_reg = 1
        it = 0
        while ((status_reg & 0x1) == 1) :
            it += 1
            status_reg,fl = is_flash_busy(xpci_dev=xpci_dev, bdr=baudr)
            if status_reg != 0 or fl!= 128:
                pass
            elif it > 120 :
                print ("SR = {:08X} , Flags = {:08X}".format(status_reg, fl))
            elif it > 130 :
                exit(-1)
        rdata=read_flash(xpci_dev=xpci_dev, flash_address=address, number_of_bytes=bpf, bdr=baudr)
        if wdata == rdata:
            if global_verbose > 6:
                print("Xflash_burn :: INFO: Matched write and read from flash at 0x{:08X} ,wdata = 0x{:08X}, "
                      "rdata = 0x{:x} OK !!!".format(address, wdata, rdata))
            rewirte = 0
            good_tx += 1
            x += bpf
            address += bpf
            retry = 0
        else:
            if global_verbose > 0:
                print ("Xflash_burn:: Warning : Mismatched write and read from flash at 0x{:08X} ,wdata = "
                       "0x{:08X}, rdata = 0x{:08X} !!!".format(address, wdata, rdata))
                print ("Xflash_burn:: INFO : Rewrite the  address 0x{:x}".format(address))
            rewirte = 1
            bad_tx += 1
            ef_wdata[address] = wdata
            ef_rdata[address] = rdata
            retry += 1
            if retry > 100:
                baudrate = baudrate 
                print("Xflash_burn:: Error : Failed more than 100 times retry in baud-rate divider "
                      "{:04X}:( address 0x{:08x}".format(baudrate,address))
                time.sleep(0.1)
                retry = 0
            if bad_tx > 1000:
                print("Xflash_burn:: Error : Failed more than 1000 times :( address 0x{:08x}".format(address))
                print("\033[1;31;40mXflash_burn:: ERROR : Failed to burn image \033[0;37;40m")
                return int(1),baudrate

    pend_time = time.time()
    print("\n")
    print("Xflash_burn:: INFO : Total transitions written {} / {} ".format(ttx,bpf))
    print("Xflash_burn:: INFO : Total fixed  transitions written {} ".format(bad_tx))
    print("Xflash_burn:: INFO : Total passed transitions written {} ".format(good_tx))
    print("Xflash_burn:: INFO : Total programming time {0!r} ".format(pend_time - pstart_time))
    print (" ")
    if global_verbose > 1:
        for add in ef_rdata:
            print ("Xflash_burn:: INFO : found Error in address 0x{:x} Write data is "
                   "0x{:x} and fixed it".format(add, ef_wdata[add]))
            print ("Xflash_burn:: INFO :                               Read  data is "
                   "0x{:x}".format(ef_rdata[add]))
    return int(0),baudrate

###########################################################################
#command line tool code
###########################################################################
def set_parser():
    parser = OptionParser()

    parser.add_option("-a",
                      "--address",
                      action="store",
                      dest="address",
                      type="string",
                      help="Set P for primary , S for secondary or B for both boot addresses or WP WS WB")

    parser.add_option("-v",
                      "--verbose",
                      action="store",
                      dest="verbose",
                      type="int",
                      default=0,
                      help="Set verbosity level for debug")

    parser.add_option("-c",
                      "--check",
                      action="store_true",
                      dest="check",
                      help="Read booted version")

    parser.add_option("-i",
                      "--binary_image",
                      action="store_true",
                      dest="binary_image",
                      help="set the image input to be binary , no need to convert")

    parser.add_option("-p",
                      "--path",
                      action="store",
                      dest="path",
                      type="string",
                      default="",
                      help="Write the path to the raw image one byte in line format")

    parser.add_option("-t",
                      "--test",
                      action="store",
                      dest="test",
                      type="int",
                      default=0,
                      help="Run short test with read and write at an empty space")

    parser.add_option("-b",
                      "--bpf",
                      action="store",
                      dest="bpf",
                      type="int",
                      default=4,
                      help="Set number of bytes per packet for test use only")

    (options,args) = parser.parse_args()
    return (parser, options)

def check_cmdline_options(parser, options):
    if options.test == 0 :
        if (options.path is None) or ((options.address is not None) and (options.check is not None)):
            print("***Xflash_burn:: ERROR : Parameters Error****")
            if (options.path is None):
                print("Xflash_burn:: ERROR :: the option -p is mandatory")

            if ((options.address is not None) and (options.check is not None)):
                print("Xflash_burn:: ERROR :: the option -a is not relevant while running in check mode")

            print("***********************************************************************************")
            print("Xflash_burn stand alone tool to burn X chip family flash image")
            print("Xflash_burn version {}".format(global_ver))
            print("***********************************************************************************")
            print("Xflash_burn options:")
            print("-a: address for the image to be burned. Set P for primary , S for secondary or B "
                  "for both boot addresses or WP WS WB")
            print("-c: check - Read booted version")
            print("-p: path to the image in two byte in line format - mandatory")
            print("-v: Set the verbosity level for debugging")
            print("   ")
            parser.print_help()
            sys.exit(1)

        if (options.check is None) and (options.address is None):
            print("Xflash_burn:: Warning :: the option -a is mandatory ")
            print("-a: Set P for primary , S for secondary or B for both boot addresses or WP WS WB")
            print("    ***write to default primary address***")
    else:
        print("RUN TEST MODE")

def main():
    global global_ver
    global global_verbose
    global SPIM_INIT_ADDR
    global SPIM_BACKUP_INIT_ADDR
    global SPIM_SEC_INIT_ADDR
    global SPIM_BACKUP_SEC_INIT_ADDR
    global SPIM_WARM_INIT_ADDR
    global SPIM_WARM_BACKUP_INIT_ADDR
    global SPIM_WARM_SEC_INIT_ADDR
    global SPIM_WARM_BACKUP_SEC_INIT_ADDR
    print("Y88b   d88P  .d888 888                   888       ")
    print(" Y88b d88P  d88P\"  888                   888      ")
    print("  Y88o88P   888    888                   888       ")
    print("   Y888P    888888 888  8888b.  .d8888b  88888b.   ")
    print("   d888b    888    888     \"88b 88K      888 \"88b")
    print("  d88888b   888    888 .d888888 \"Y8888b. 888  888 ")
    print(" d88P Y88b  888    888 888  888      X88 888  888  ")
    print("d88P   Y88b 888    888 \"Y888888  88888P\' 888  888")
    (parser, options) = set_parser()
    check_cmdline_options(parser,options)
    path_to_image = options.path
    check = options.check
    baudrate = 0x0010
    global_verbose = options.verbose
    if options.test != 0:
        read_write_test(bpf=options.bpf, flash_address=0x15000, baudr=baudrate,repeats = options.test)
        exit(1)
    print("Xflash_burn:: INFO : checking the image")
    if (not os.path.exists(path_to_image)):
        print("Xflash_burn:: ERROR : Can't find the image file at the path {}".format(path_to_image))
        sys.exit(1)
    else:
        print("Xflash_burn:: INFO : found the image file at the path {}".format(path_to_image))

    second_address = 0x10000
    infile = path_to_image

    if options.binary_image != True:
        outfile = infile + '.converted.bin'
        if global_verbose > 2:
            print(("Xflash_burn: INFO : found the image at {}".format(infile)))
        print("Xflash_burn:: INFO : converted image will be {}".format(outfile))
        with open(infile, 'r') as fp:
            bytecount = 0
            raw_bytes = bytearray()
            for line in fp.readlines():
                line = line.strip()
                if len(line) != 2:
                    print("Xflash_burn:: INFO : stopping at line: {}".format(line))
                    break
                value = int("0x" + line, 16)
                raw_bytes.append(value)
            current_offset = len(raw_bytes)
            original_data = raw_bytes[:]
            if current_offset < second_address:
                bytes_to_add = second_address-current_offset
                print("Xflash_burn:: INFO : Adding {} bytes".format(bytes_to_add))
                raw_bytes.extend(bytearray(bytes_to_add))
            else:
                print("Xflash_burn:: ERROR : Size is larger than 0x{:08X}???? this was not "
                      "expected...".format(second_address))
                exit(1)
            raw_bytes.extend(original_data)
            print("Xflash_burn:: INFO : final size of bin is {}".format(len(raw_bytes)))

        with open(outfile, 'wb') as fp:
            fp.write(raw_bytes)
    else:
        print(("Xflash_burn: INFO : found the image at {}".format(infile)))
        outfile = infile

    if check == True :
        print("Xflash_burn:: INFO : Run in check mode ")
        print("Xflash_burn:: INFO : check pci allocation: ")
        reg = _regd(0xFF, 0x01020304)
        fd = open("/dev/xpci", "wb", buffering=0)
        xx = xpci(fd)
        if fd != 0 :
            print("Xflash_burn:: INFO : Allocated /dev/xpci")
        else:
            print("Xflash_burn:: INFO : can't allocate pci device")
        print("Xflash_burn:: INFO : getting XREG_GLC3_INTG_SPARE")
        reg_1 = xx.read_reg(XREG_GLC3_INTG_SPARE)
        reg_value = reg_1.value & 0xFFFF
        image_version = get_image_version(outfile)
        if reg_value == image_version:
            print("\033[1;32;40mXflash_burn:: PASS : OK OK OK The image version fits the booted "
                  "version \033[0;37;40m")
        else:
            print("\033[1;31;40mXflash_burn:: ERROR : The image version 0x{:x} DOES NOT fit the "
                  "booted version 0x{:x} \033[0;37;40m".format(image_version, reg_1.value))
            sys.exit(1)
    else:
        burned_p = int(0)
        burned_s = int(0)
        burned_pb = int(0)
        burned_sb = int(0)
        if not ((options.address == "P") or (options.address == "S") or (options.address == "B") or
                (options.address == "WP") or (options.address == "WS") or (options.address == "WB") or
                (options.address == None)):
            print("Xflash_burn:: ERROR : Not supported address {} . please use P , S for secondary or "
                  "B for both boot addresses or WP WS WB".format(options.address))
            sys.exit(1)

        address1 = 0
        address2 = 0
        if (options.address == "P") or (options.address == "B") or (options.address == None):
            address1 = SPIM_INIT_ADDR
            address2 = SPIM_BACKUP_INIT_ADDR
            burned_p,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address1,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
            burned_pb,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address2,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
        if (options.address == "S") or (options.address == "B"):
            address1 = SPIM_SEC_INIT_ADDR
            address2 = SPIM_BACKUP_SEC_INIT_ADDR
            burned_s,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address1,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
            burned_sb,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address2,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
        if (options.address == "WP") or (options.address == "WB") or (options.address == None):
            address1 = SPIM_WARM_INIT_ADDR
            address2 = SPIM_WARM_BACKUP_INIT_ADDR
            burned_p,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address1,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
            burned_pb,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address2,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
        if (options.address == "WS") or (options.address == "WB"):
            address1 = SPIM_WARM_SEC_INIT_ADDR
            address2 = SPIM_WARM_BACKUP_SEC_INIT_ADDR
            burned_s,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address1,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
            burned_sb,baudrate = write_image_write_read(path=outfile,
                                                        bpf=options.bpf,
                                                        flash_address=address2,
                                                        baudr=baudrate,
                                                        delay_time=0.002)
        print("\n\n\n")
        if (burned_p + burned_s + burned_pb + burned_sb) == 0:
            print("\033[1;33;40mXflash_burn:: INFO : Flash burning has finished. At baud-rate "
                  "divider 0X{:04X}".format(baudrate))
            print("Xflash_burn:: INFO : Please verify that the right version has been burned.")
            print("Xflash_burn:: INFO : Reboot the machine and then run the following command:")
            print("Xflash_burn:: INFO : ./xflash_burn.py -c -p {} \033[0;37;40m \n".format(path_to_image))
        else:
            print("Xflash_burn:: ERROR : Failed burning one or more of the flash partitions at "
                  "baud-rate {}".format(baudrate))

if __name__ == '__main__':
    main()
