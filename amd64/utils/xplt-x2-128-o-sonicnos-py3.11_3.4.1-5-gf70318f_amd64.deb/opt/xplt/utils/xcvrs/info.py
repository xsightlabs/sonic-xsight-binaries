#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

from __future__ import print_function
import sys
import argparse
import sff8636
import cmis_local
import qsfp_local
import helpers

column = [
    ('Port',    8, ''),
    ('Vendor', 17, 'VENDOR_NAME'),
    ('Type',   10, ''),
    ('Media',   9, 'MOD_MED_TYPE_ENC'),
    ('P/N',    17, 'VENDOR_PN'),
    ('S/N',    22, 'VENDOR_SN'),
    ('FW Ver',  9, 'MODULE_FW_REV_MAJOR'),
    ('Temp,C',  9, 'TEMPERATURE'),
    ('Volt,V',  9, 'SUPPLY_VOLTAGE'),
    ('State',   9, 'MODULE_STATE'),
    ('Custom', 20, '')
]

name = 0
size = 1
reg = 2

info_len = len(column)
custom = info_len - 1

# Execution time measurement verbosity
time_vbs = False


class InfoAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        for val in values:
            if not 1 <= val <= info_len:
                raise argparse.ArgumentError(self,
                    "info type must be between 1 and {}".format(info_len))
        setattr(namespace, self.dest, values)

parser = argparse.ArgumentParser(description='Prints optical modules information',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type = int,
                    nargs = '?',
                    default = None,
                    action = helpers.PortAction,
                    help = f'Starting port. If given alone, only this port is processed; otherwise, all ports are processed')

parser.add_argument('last',
                    type = int,
                    nargs = '?',
                    default = None,
                    action = helpers.PortAction,
                    help = f'Ending port number. If provided, ports from first to last (inclusive) are processed')

parser.add_argument('-c',
                    '--compact',
                    action = 'store_true',
                    help = 'do not print empty ports')

parser.add_argument('-i',
                    '--info',
                    metavar = "{{1..{}}}".format(info_len),
                    action = InfoAction,
                    nargs = '+',
                    type = int,
                    help = ''.join('[{}] - {}\n'.format(i + 1, column[i][name])
                                for i in range(info_len)))

parser.add_argument('-n',
                    '--noheader',
                    action = 'store_true',
                    help = 'do not print a table header row')

parser.add_argument('-r',
                    metavar = 'arg',
                    type = str,
                    help = 'read value by user defined key, e.g. -r HST_GEN_EN')

parser.add_argument('-s',
                    '--standalone',
                    action ='store_true',
                    help ='standalone mode')

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

parser.add_argument('-v',
                    '--verbose',
                    action = 'store_true',
                    help = 'more verbose print')

def set_info_args(user_args=None):
    """Set info arguments API.

     Args:
        user_args: list of arguments as generated via CLI in a standalone mode.
        Is printed to console when run with -v option.
        See info_api_demo.py example.
     Returns:
        argparse.Namespace object
    """
    if user_args == None:
        raise Exception("No argumens were provided!")

    args = parser.parse_args(user_args, argparse.Namespace())
    parse_info_args(args)
    return args


def parse_info_args(args):
    """Parse info arguments API.

     Args: argparse.Namespace object
     Returns: None
    """
    global oom
    global info
    global oomlwclient

    if args.info == None:
        info = list(range(1, info_len))
    else:
        info = args.info
        info.sort()

    if args.r and info_len not in info:
        info.append(info_len)

    if not args.standalone:
        try:
            import oomlwclient as oom
            oom.oomlwclient_init(args.url)
            helpers.register("oom", oom)  # register oom
            return
        except:
            if args.verbose:
                print("Running in standalone mode")

    import oom
    if args.url != None:
        oom.setshim("oomjsonshim", args.url)
    helpers.register("oom", oom)  # register oom

def get_oom_keyvalue(port, key):
    mapped_key = sff8636.get_mapped_key(key, port)
    return oom.oom_get_keyvalue(port, mapped_key)

helpers.register("get_oom_keyvalue", get_oom_keyvalue)  # register get_oom_keyvalue


def get_module_state_cmis(port):
    return get_oom_keyvalue(port, 'MODULE_STATE')

@helpers.dispatch_by_protocol(get_module_state_cmis, sff8636.get_module_state_sff8636)
def get_module_state(port):
    pass  # Implementation will be dispatched

def cmis_get_module_type(port, verbose):
    return oom.type_to_str(port.port_type)

@helpers.dispatch_by_protocol(cmis_get_module_type, sff8636.get_module_type)
def get_module_type(port, verbose):
    pass  # Implementation will be dispatched

def get_port_info(port, args):
    """Get port information.

     Args:
        port: port object from OMM portlist.
        args: argparse.Namespace object

     Returns:
        tuple of strings from info_regs according to the indexes in the info list.
    """
    data = ()
    modtype = get_module_type(port, args.verbose)
    if modtype == 'UNKNOWN':
        if args.compact:
            return data
        modtype = 'No Module'
    cmis_local.add_qsfpdd_keys(port)
    qsfp_local.add_qsfp_keys(port)
    for i in info:
        idx = i - 1
        if idx == 0:
            data += (port.port_name,)
        elif idx == 2:
            data += (modtype,)
        elif idx == custom:
            val = str(get_oom_keyvalue(port, args.r))
            if val.isdigit():
                data += ("{:X}".format(int(val)),)
            else:
                data += (val,)
        else:
            val = str(get_oom_keyvalue(port, column[idx][reg]))
            if idx == 3:
                if not val:
                    val = '0'
                val = val + ':' + helpers.get_media_type(port)
            elif idx == 6:
                minor = str(get_oom_keyvalue(port, 'MODULE_FW_REV_MINOR'))
                if minor:
                    val = val + '.' + minor
            elif idx in (7, 8):  # Temperature and Voltage
                try:
                    float_val = float(val)
                    if float_val == 0:
                        val = '0'
                    else:
                        val = '{:.2f}'.format(float_val)
                except (ValueError, TypeError):
                    pass
            elif idx == 9:
                state = get_module_state(port)
                if state is not None:
                    try:
                        val = sff8636.module_state[int(state)]
                    except (ValueError, IndexError):
                        pass
            data += (val,)
    return data


@helpers.decor(helpers.timer, helpers.time_vbs)
def get_ports_info(portlist, args):
    """Get all requested ports information.

     Args:
        portlist: OMM portlist object
        args: argparse.Namespace object

     Returns:
        Dictionary of tuples returned by get_port_info().
    """
    max_ports = len(portlist)
    args.first, args.last = helpers.check_port_max_number(args.first, args.last, max_ports)

    data = {}
    for p in range (args.first - 1, args.last):
        port = portlist[p]
        data[p] = get_port_info(port, args)
    return data


def print_port_info(data):
    """Print port information.

     Args:
        data: a tuple of strings returned by get_port_info().

     Returns: None
    """
    if data:
        for idx, i in enumerate(info):
            i -= 1
            print('{:{}}'.format(data[idx][:column[i][size]-1], column[i][size]), end=""),
        print("")


def print_table_caption(noheader):
    """Print table caption.

     Args:
        noheader: args.noheader

     Returns: None
    """
    if not noheader:
        for i in info:
            i -= 1
            value = column[i][name]
            if i == custom:
                value = args.r
            print('{:{}}'.format(value[:column[i][size]-1], column[i][size]), end=""),
        print("")


def print_table_port_by_port(portlist, args):
    """Prints the port table quering a port information one by one.

     Args:
        portlist: OMM portlist object
        args: argparse.Namespace object

     Returns: None
    """
    max_ports = len(portlist)
    args.first, args.last = helpers.check_port_max_number(args.first, args.last, max_ports)

    print_table_caption(args.noheader)

    for p in range (args.first - 1, args.last):
        port = portlist[p]
        data = get_port_info(port, args)
        print_port_info(data)


def print_table_at_once(data, noheader):
    """Prints the port table from dictionary returned by get_ports_info().

     Args:
        data: dictionary of port tuples returned by get_ports_info()
        args: argparse.Namespace object

     Returns: None
    """
    print_table_caption(noheader)
    for key in data:
        print_port_info(data[key])

def get_port_list(args):
    portlist, max_ports = helpers.get_port_list(oom)
    args.first, args.last = helpers.check_port_max_number(args.first, args.last, max_ports)
    return portlist, max_ports, args.first, args.last

@helpers.decor(helpers.timer, time_vbs)
def main(args):
    portlist, max_ports, args.first, args.last = get_port_list(args)
    #print_table_port_by_port(portlist, args)
    data = get_ports_info(portlist, args)
    print_table_at_once(data, args.noheader)

if __name__ == "__main__":
    args = parser.parse_args()
    if args.verbose:
        print("CLI parameters: {}".format(sys.argv[1:]))
    parse_info_args(args)
    main(args)

