# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import sys
import time
from cmis_to_sff8636_map import cmis_to_sff8636_map
from oom.oomlib import oom_get_keyvalue
from oom.decode import mod_id
import helpers
import sff8636

VERBOSE = False         # Used in verbose_print function

module_state = [
    'N/A',
    'LowPwr',
    'PwrUp',
    'Ready',
    'PwrDn',
    'Fault'
]

capability_types = [
    'All capabilities',
    'Compliance keys',                  # compliance_keys
    'Option values keys',               # option_values_keys
    'Diagnostic capabilities',          # diagnostic_capabilities_keys
    'Enhanced Options keys',            # enhanced_options_keys
    'Option Channel control',           # option_channel_control
    'Unapplicable capability',          # Placeholder to maintain same length
                                        # as CMIS capability_types for unified
                                        # argument parser in calib.py when using
                                        # the -c/--capabilities argument
]

# Register capability types with helpers
helpers.register_capabilities_types_and_keys(sff8636=capability_types)

option_values_keys = [
    # Byte 193
    'LPMODE_TXDIS_CONFIGURABLE',
    'INTL_RXLOSL_CONFIGURABLE',
    'TX_EQ_ADAPTIVE_FREEZE',
    'TX_EQ_AUTO_ADAPT_CAP',
    'TX_EQ_FIXED_PROG_SET',
    'RX_EQ_EMPHASIS_FIXED_PROG',
    'RX_EQ_AMPLITUDE_FIXED_PROG',

    # Byte 194
    'TX_CDR_ON_OFF_CTRL',
    'RX_CDR_ON_OFF_CTRL',
    'TX_CDR_LOL_FLAG',
    'RX_CDR_LOL_FLAG',
    'RX_SQUELCH_DISABLE',
    'RX_OUTPUT_DISABLE',
    'TX_SQUELCH_DISABLE',
    'TX_SQUELCH',

    # Byte 195
    'MEMORY_PAGE_02_CAP',
    'MEMORY_PAGE_01H_CAP',
    'RATE_SELECT_CAP',
    'TX_DISABLE_CAP',
    'TX_FAULT_CAP',
    'TX_SQUELCH_CAP',
    'TX_LOSS_OF_SIGNAL',
    'PAGES_20_21_CAP',
]

diagnostic_capabilities_keys = [
    'DIAG_MONITOR_TYPE',
    'DIAG_TEMP_MON_IMPL',
    'DIAG_SUPPLY_VOLT_MON_IMPL',
    'DIAG_RX_PWR_MEAS_TYPE',
    'DIAG_TX_PWR_MEAS_SUPPORT',
]

enhanced_options_keys = [
    'ENHANCED_OPTIONS',
    'ENH_OPT_INIT_COMPLETE_IMPL',
    'ENH_OPT_RATE_SEL_DECLARATION',
    'ENH_OPT_TC_READINESS_IMPL',
    'ENH_OPT_SW_RESET_IMPL',
]

compliance_keys = [
    # Byte 131 – Ethernet
    'COMPLIANCE_CODES_ETHERNET',
    'COMP_ETH_EXTENDED_CODES',
    'COMP_ETH_10GBASE_LRM',
    'COMP_ETH_10GBASE_LR',
    'COMP_ETH_10GBASE_SR',
    'COMP_ETH_40GBASE_CR4',
    'COMP_ETH_40GBASE_SR4',
    'COMP_ETH_40GBASE_LR4',
    'COMP_ETH_40G_ACT_CABL_XLPPI',

    # Byte 132 – SONET
    'COMPLIANCE_CODES_SONET',
    # Bits 7-3 Reserved
    'COMP_SONET_OC_48_LONG_REACH',
    'COMP_SONET_OC_48_INTR_REACH',
    'COMP_SONET_OC_48_SHORT_REACH',

    # Byte 133 – SAS/SATA
    'COMPLIANCE_CODES_SAS_SATA',
    'COMP_SAS_24G',
    'COMP_SAS_12G',
    'COMP_SAS_6G',
    'COMP_SAS_3G',
    # Bits 3-0 Reserved

    # Byte 134 – Gigabit Ethernet
    'COMPLIANCE_CODES_GBE',
    'COMP_GBE_1000BASE_T',
    'COMP_GBE_1000BASE_CX',
    'COMP_GBE_1000BASE_LX',
    'COMP_GBE_1000BASE_SX',
    # Bits 7-4 Reserved

    # Byte 135 – Fibre Channel Transmitter Technology
    'COMPLIANCE_CODES_FC_135',
    'COMP_FC_TX_TECHNOLOGY_LC',
    'COMP_FC_TX_TECHNOLOGY_EL',

    # Byte 136 – Fibre Channel Transmitter Technology
    'COMPLIANCE_CODES_FC_136',
    'COMP_FC_TX_TECHNOLOGY_EI',
    'COMP_FC_TX_TECHNOLOGY_SN',
    'COMP_FC_TX_TECHNOLOGY_SL',
    'COMP_FC_TX_TECHNOLOGY_LL',

    # Byte 137 – Fibre Channel Transmission Media
    'COMPLIANCE_CODES_FC_137',
    'COMP_FC_MEDIA_TW',
    'COMP_FC_MEDIA_TP',
    'COMP_FC_MEDIA_MI',
    'COMP_FC_MEDIA_TV',
    'COMP_FC_MEDIA_M6',
    'COMP_FC_MEDIA_M5',
    'COMP_FC_MEDIA_OM3',
    'COMP_FC_MEDIA_SM',

    # Byte 138 – Fibre Channel Speed
    'COMPLIANCE_CODES_FC_SPEED',
    'COMP_FC_SPEED_1200MBPS',
    'COMP_FC_SPEED_800MBPS',
    'COMP_FC_SPEED_1600MBPS',
    'COMP_FC_SPEED_400MBPS',
    'COMP_FC_SPEED_3200MBPS',
    'COMP_FC_SPEED_200MBPS',
    'COMP_FC_SPEED_EXTENDED',
    'COMP_FC_SPEED_100MBPS',
]

option_channel_control = [
    'MAX_TX_INPUT_EQ_SUPPORT',
    'MAX_RX_OUT_EMPHASIS_SUPPORT',
    'RX_OUT_EMPHASIS_TYPE',
    'RX_OUT_AMPLITUDE_SUPPORT',
    'HOST_SIDE_FEC_CTRL_CAP',
    'MEDIA_SIDE_FEC_CTRL_CAP',
    'TX_FORCE_SQUELCH_CAP',
    'RX_LOS_FAST_MODE_CAP',
    'TX_DISABLE_FAST_MODE_CAP',
    'MAX_TC_STABILIZATION_TIME',
    'MAX_CTLE_SETTLING_TIME',
    'HOST_SIDE_FEC_ENABLE',
    'MEDIA_SIDE_FEC_ENABLE',
    'TX4_FORCE_SQUELCH',
    'TX3_FORCE_SQUELCH',
    'TX2_FORCE_SQUELCH',
    'TX1_FORCE_SQUELCH',
    'TX1_AE_FREEZE',
    'TX2_AE_FREEZE',
    'TX3_AE_FREEZE',
    'TX4_AE_FREEZE',
    'TX1_INPUT_EQ_CTRL',
    'TX2_INPUT_EQ_CTRL',
    'TX3_INPUT_EQ_CTRL',
    'TX4_INPUT_EQ_CTRL',
    'RX1_OUTPUT_EMPH_CTRL',
    'RX2_OUTPUT_EMPH_CTRL',
    'RX3_OUTPUT_EMPH_CTRL',
    'RX4_OUTPUT_EMPH_CTRL',
    'RX1_OUTPUT_AMPL_CTRL',
    'RX2_OUTPUT_AMPL_CTRL',
    'RX3_OUTPUT_AMPL_CTRL',
    'RX4_OUTPUT_AMPL_CTRL',
    'RX4_SQ_DISABLE',
    'RX3_SQ_DISABLE',
    'RX2_SQ_DISABLE',
    'RX1_SQ_DISABLE',
    'TX4_SQ_DISABLE',
    'TX3_SQ_DISABLE',
    'TX2_SQ_DISABLE',
    'TX1_SQ_DISABLE',
    'RX4_OUTPUT_DISABLE',
    'RX3_OUTPUT_DISABLE',
    'RX2_OUTPUT_DISABLE',
    'RX1_OUTPUT_DISABLE',
    'TX4_ADAPT_EQ_CTRL',
    'TX3_ADAPT_EQ_CTRL',
    'TX2_ADAPT_EQ_CTRL',
    'TX1_ADAPT_EQ_CTRL',
]

capabilities_keys = [
    compliance_keys,
    option_values_keys,
    diagnostic_capabilities_keys,
    enhanced_options_keys,
    option_channel_control,
]

# Register capabilities_keys with helpers
helpers.register_capabilities_types_and_keys(sff8636=capabilities_keys)

fec_cfg_types = [
    'FEC: Host Side disabled, Media Side disabled',
    'FEC: Host Side disabled, Media Side enabled',
    'FEC: Host Side enabled,  Media Side disabled',
    'FEC: Host Side enabled,  Media Side enabled',
]

def get_mapped_key(key, port):
    """
    Returns the correct key for the module type.
    For SFF-8636, the key is first searched in the cmis_to_sff8636_map.
    If a mapping is found, it is returned, otherwise, the key itself is returned,
    as it should already exist in the QSFP register table of the OOM package.
    For CMIS, returns the original key.
    """
    if helpers.is_sff_8636_module(port):
        return cmis_to_sff8636_map.get(key, key)
    else:
        return key

helpers.register("get_mapped_key", get_mapped_key)  # register get_mapped_key


def skip_for_sff_8636(func):
    def wrapper(port, *args, **kwargs):
        if helpers.is_sff_8636_module(port):
            print(f"{func.__name__} is not supported for SFF-8636 modules")
            return
        return func(port, *args, **kwargs)
    return wrapper


# QSFP28 compatible Connector Types, SFF-8024 Rev 4.6, Table 4-3.
CONNECTOR_MAP = {
    0x00: 'Undef', # Unknown
    0x07: 'LC',  # Lucent Connector
    0x0B: 'AOC', # Active Optical Cable
    0x0C: 'MPO', # Multifiber Parallel Optics
    0x23: 'PCC', # No Separable Connector (loopback)
}

# Bit maps per SFF-8636 Rev 2.11, Table 6-17 Specification Compliance Codes
# Page 00h Bytes 131-138.
BYTE_131_ETH = {
    0x01: 'AOC',  # 40G Active Cable (XLPPI)
    0x02: 'SMF',  # 40GBASE-LR4
    0x04: 'MMF',  # 40GBASE-SR4
    0x08: 'PCC',  # 40GBASE-CR4
    0x10: 'MMF',  # 10GBASE-SR
    0x20: 'SMF',  # 10GBASE-LR
    0x40: 'MMF',  # 10GBASE-LRM
    0x80: 'EXT',  # See the Transceiver Management section of SFF-8024, Table 4-4
}

BYTE_134_GBE = {
    0x01: 'MMF',  # 1000BASE-SX
    0x02: 'SMF',  # 1000BASE-LX
    0x04: 'PCC',  # 1000BASE-CX
    0x08: 'PCC',  # 1000BASE-T
}
# Additional bytes (132 SONET, 133 SAS/SATA, 135 Fibre Channel, 137 Optical,
# 138 Fibre Channel Speed) are not directly mapped to the media types list.

# Extended Specification Compliance Codes, SFF-8024, Table 4-4 (Rev. 4.13)
EXTENDED_MEDIA_MAP = {
    1: 'AOC',   # 0x01: 100G AOC / 25GAUI C2M AOC
    2: 'MMF',   # 0x02: 100GBASE-SR4 / 25GBASE-SR
    3: 'SMF',   # 0x03: 100GBASE-LR4 / 25GBASE-LR
    4: 'SMF',   # 0x04: 100GBASE-ER4 / 25GBASE-ER
    5: 'MMF',   # 0x05: 100GBASE-SR10
    6: 'SMF',   # 0x06: 100G CWDM4
    7: 'SMF',   # 0x07: 100G PSM4 Parallel SMF
    8: 'ACC',   # 0x08: 100G ACC / 25GAUI C2M ACC
    11: 'PCC',  # 0x0B: 100GBASE-CR4 / 25GBASE-CR CA-25G-L
    12: 'PCC',  # 0x0C: 25GBASE-CR CA-25G-S / 50GBASE-CR2
    13: 'PCC',  # 0x0D: 25GBASE-CR CA-25G-N / 50GBASE-CR2
    14: 'PCC',  # 0x0E: 10 Mb/s Single Pair Ethernet (1000 m)
    16: 'SMF',  # 0x10: 40GBASE-ER4
    17: 'MMF',  # 0x11: 4 × 10GBASE-SR
    18: 'SMF',  # 0x12: 40G PSM4 Parallel SMF
    19: 'SMF',  # 0x13: G959.1 P1I1-2D1 (1310 nm, 2 km)
    20: 'SMF',  # 0x14: G959.1 P1S1-2D2 (1550 nm, 40 km)
    21: 'SMF',  # 0x15: G959.1 P1L1-2D2 (1550 nm, 80 km)
    22: 'PCC',  # 0x16: 10GBASE-T (SFI electrical interface)
    23: 'SMF',  # 0x17: 100G CLR4
    24: 'AOC',  # 0x18: 100G AOC / 25GAUI C2M AOC, BER ≤ 1×10⁻¹²
    25: 'ACC',  # 0x19: 100G ACC / 25GAUI C2M ACC, BER ≤ 1×10⁻¹²
    26: 'SMF',  # 0x1A: 100GE-DWDM2 (2 λ, 80 km)
    27: 'SMF',  # 0x1B: 100G 1550 nm WDM (4 λ)
    28: 'PCC',  # 0x1C: 10GBASE-T Short Reach (30 m)
    29: 'PCC',  # 0x1D: 5GBASE-T
    30: 'PCC',  # 0x1E: 2.5GBASE-T
    31: 'MMF',  # 0x1F: 40G SWDM4
    32: 'MMF',  # 0x20: 100G SWDM4
    33: 'SMF',  # 0x21: 100G PAM4 BiDi (often SMF, may support MMF)
    34: 'SMF',  # 0x22: 4WDM-10 MSA (10 km)
    35: 'SMF',  # 0x23: 4WDM-20 MSA (20 km)
    36: 'SMF',  # 0x24: 4WDM-40 MSA (40 km)
    37: 'SMF',  # 0x25: 100GBASE-DR (no FEC)
    38: 'SMF',  # 0x26: 100GBASE-FR / FR1
    39: 'SMF',  # 0x27: 100GBASE-LR / LR1
    40: 'MMF',  # 0x28: 100GBASE-SR1
    41: 'SMF',  # 0x29: 100GBASE-FR1 (Clause 140)
    42: 'SMF',  # 0x2A: 100GBASE-FR1 or 400GBASE-DR4-2
    43: 'SMF',  # 0x2B: 100GBASE-LR1
    44: 'SMF',  # 0x2C: 100G-LR1-20 MSA
    45: 'SMF',  # 0x2D: 100G-ER1-30 MSA
    46: 'SMF',  # 0x2E: 100G-ER1-40 MSA
    47: 'SMF',  # 0x2F: 100G-LR1-20 MSA
    48: 'ACC',  # 0x30: Active Copper Cable 50/100/200GAUI C2M, BER ≤ 1×10⁻⁶
    49: 'AOC',  # 0x31: Active Optical Cable 50/100/200GAUI C2M, BER ≤ 1×10⁻⁶
    50: 'ACC',  # 0x32: Active Copper Cable, BER ≤ 2.6×10⁻⁴
    51: 'AOC',  # 0x33: Active Optical Cable, BER ≤ 2.6×10⁻⁴
    52: 'SMF',  # 0x34: 100GBASE-ZR (400ZR)
    53: 'SMF',  # 0x35: 100G 1550 nm WDM2 (DWDM2 extended reach)
    54: 'SMF',  # 0x36: 400GBASE-ER8
    55: 'SMF',  # 0x37: 400GBASE-LR8
    56: 'SMF',  # 0x38: 400GBASE-FR8
    57: 'SMF',  # 0x39: 400GBASE-DR4+
    58: 'SMF',  # 0x3A: 400G-LR4-6
    59: 'SMF',  # 0x3B: 400GBASE-LR4-10
    60: 'SMF',  # 0x3C: 400GBASE-ZR (P802.3cw)
    61: 'SMF',  # 0x3D: 400GBASE-ER4-30
    62: 'SMF',  # 0x3E: 400GBASE-ER4-40
    63: 'PCC',  # 0x3F: 100GBASE-CR1 / 200GBASE-CR2 / 400GBASE-CR4
    64: 'PCC',  # 0x40: 50GBASE-CR / 100GBASE-CR2 / 200GBASE-CR4
    65: 'MMF',  # 0x41: 50GBASE-SR / 100GBASE-SR2 / 200GBASE-SR4
    66: 'SMF',  # 0x42: 50GBASE-FR / 200GBASE-DR4
    67: 'SMF',  # 0x43: 200GBASE-FR4
    68: 'SMF',  # 0x44: 200G 1550 nm PSM4
    69: 'SMF',  # 0x45: 50GBASE-LR
    70: 'SMF',  # 0x46: 200GBASE-LR4
    71: 'SMF',  # 0x47: 400GBASE-DR4
    72: 'SMF',  # 0x48: 400GBASE-FR4
    73: 'SMF',  # 0x49: 400GBASE-LR4-6
    74: 'SMF',  # 0x4A: 50GBASE-ER
    75: 'SMF',  # 0x4B: 400G-LR4-10
    76: 'SMF',  # 0x4C: 400GBASE-ZR (Clause 156)
    80: 'SMF',  # 0x50: 800GBASE-DR8 (future standard)
    81: 'SMF',  # 0x51: 800GBASE-FR8
    82: 'SMF',  # 0x52: 800GBASE-LR8
    83: 'SMF',  # 0x53: 800GBASE-ZR (draft)
    127: 'SMF', # 0x7F: 256GFC-SW4 (FC-PI-7P)
    128: 'SMF', # 0x80: 64GFC (FC-PI-7)
    129: 'SMF', # 0x81: 128GFC (FC-PI-8)
    # Reserved/unspecified codes can be mapped to 'EXT' if needed
}

MEDIA_PRIORITY = ['SMF', 'MMF', 'AOC', 'ACC', 'PCC', 'EXT']

def classify_from_sff8636_codes(port, codes):
    oom = helpers.get_registered('oom')
    found = {}
    for mask, media in BYTE_131_ETH.items():
        if codes.get(131, 0) & mask:
            if media == 'EXT':
                try:
                    ext_code = oom.oom_get_keyvalue(port, 'LINK_CODES')
                    if ext_code is not None:
                        # Convert string to integer if needed
                        if isinstance(ext_code, str):
                            ext_code = int(ext_code)
                        ext_media = EXTENDED_MEDIA_MAP.get(ext_code)
                        if ext_media:
                            # Successfully mapped extended code, add the mapped media type
                            found[ext_media] = True
                        else:
                            # Extended code not in our map, keep it as EXT
                            found['EXT'] = True
                    else:
                        # No extended code available, keep it as EXT
                        found['EXT'] = True
                except Exception as e:
                    print(f"Error reading LINK_CODES: {e}", file=sys.stderr)
                    found['EXT'] = True
            else:
                found[media] = True

    for mask, media in BYTE_134_GBE.items():
        if codes.get(134, 0) & mask:
            found[media] = True

    # Return the highest priority media type found
    for m in MEDIA_PRIORITY:
        if m in found:
            return m
    return None

monitoring_keys = [
    'L_TX_RX_LOS',
    'L_TX_EQ_FAULT',
    'L_TX_XM_FAULT',
    'L_TX_RX_LOL',
    'L_TEMP_ALARM_WARN',
    'L_VCC_ALARM_WARN',
    'L_RX1_POWER',
    'L_RX2_POWER',
    'L_RX3_POWER',
    'L_RX4_POWER',
    'L_TX1_BIAS',
    'L_TX2_BIAS',
    'L_TX3_BIAS',
    'L_TX4_BIAS',
    'L_TX1_POWER',
    'L_TX2_POWER',
    'L_TX3_POWER',
    'L_TX4_POWER',
    'VENDOR_SPECIFIC_19',
    'TEMPERATURE',
    'SUPPLY_VOLTAGE',
    'VENDOR_SPECIFIC_30',
]

def mon_collect(port):
    """Collects monitoring data for SFF-8636 modules."""
    helpers.print_keyval_list(port, monitoring_keys)

def power_up_module(port, mode):
    print("Action - SFF8636 Module Power Up")
    oom = helpers.get_registered('oom')

    if mode == 0:
        # Evaluate LPM discrete signal
        oom.oom_set_keyvalue(port, 'POWER_OVERRIDE', 0)
    elif mode == 1:
        # Override LPM HW signal and force high-power mode
        oom.oom_set_keyvalue(port, 'POWER_OVERRIDE', 1)
        oom.oom_set_keyvalue(port, 'POWER_SET', 0)
    else:
        print("Unknown power up mode {}".format(mode))
        return

    for _ in range(60):
        val = hex(int(get_module_state_sff8636(port)))
        if val == hex(2):
            print('Module in ModulePwrUp state')
            time.sleep(2)
        if val == hex(3):
            print('Module in ModuleReady state')
            break

identity_info_keys = [
    # CDR options
    'CDR_IMPLEMENTED',
    'TX_SQUELCH',
    'TX_SQUELCH_DISABLE',
    'RX_OUTPUT_DISABLE',
    'RX_SQUELCH_DISABLE',
    'RX_CDR_LOL_FLAG',
    'TX_CDR_LOL_FLAG',
    'RX_CDR_ON_OFF_CTRL',
    'TX_CDR_ON_OFF_CTRL',

    # Diagnostic Monitoring Type
    'DIAG_MONITOR_TYPE',
    'DIAG_TX_PWR_MEAS_SUPPORT',
    'DIAG_RX_PWR_MEAS_TYPE',
    'DIAG_SUPPLY_VOLT_MON_IMPL',
    'DIAG_TEMP_MON_IMPL',

    # Tx Input Equalizer options
    'TX_EQ_FIXED_PROG_SET',
    'TX_EQ_AUTO_ADAPT_CAP',
    'MAX_TX_INPUT_EQ_SUPPORT',

    # Rx Output Emphasis options
    'RX_EQ_EMPHASIS_FIXED_PROG',
    'MAX_RX_OUT_EMPHASIS_SUPPORT',
    'RX_OUT_EMPHASIS_TYPE',

    # Rx Output Amplitude options
    'RX_EQ_AMPLITUDE_FIXED_PROG',
    'RX_OUT_AMPLITUDE_SUPPORT',

    # Rate Select options
    'RATE_SELECT_CAP',
    'RATE_SELECT_TYPE',
    'EXT_RATE_SEL_COMPL',

    'ENHANCED_OPTIONS',
]

dump_keys = [
    'VENDOR_NAME',
    'VENDOR_PN',
    'VENDOR_SN',
    'VENDOR_REV',
    'MODULE_STATE',
    'CONNECTOR',
    'SPEC_COMPLIANCE',
]

monitoring_bit_keys = [
    'L_TX_RX_LOS',
    'L_TX4_LOS',
    'L_TX3_LOS',
    'L_TX2_LOS',
    'L_TX1_LOS',
    'L_RX4_LOS',
    'L_RX3_LOS',
    'L_RX2_LOS',
    'L_RX1_LOS',
    'L_TX_FAULT',
    'L_TX4_ADAPT_EQ_FAULT',
    'L_TX3_ADAPT_EQ_FAULT',
    'L_TX2_ADAPT_EQ_FAULT',
    'L_TX1_ADAPT_EQ_FAULT',
    'L_TX4_FAULT',
    'L_TX3_FAULT',
    'L_TX2_FAULT',
    'L_TX1_FAULT',
    'L_TX_RX_LOL',
    'L_TX4_LOL',
    'L_TX3_LOL',
    'L_TX2_LOL',
    'L_TX1_LOL',
    'L_RX4_LOL',
    'L_RX3_LOL',
    'L_RX2_LOL',
    'L_RX1_LOL',
    'L_TEMP_ALARM_WARN',
    'L_TEMP_HIGH_ALARM',
    'L_TEMP_LOW_ALARM',
    'L_TEMP_HIGH_WARNING',
    'L_TEMP_LOW_WARNING',
    'INIT_COMPLETE',
    'L_VCC_ALARM_WARN',
    'L_VCC_HIGH_ALARM',
    'L_VCC_LOW_ALARM',
    'L_VCC_HIGH_WARN',
    'L_VCC_LOW_WARN',
    'VENDOR_SPECIFIC_8',
    'L_RX1_RX2_POWER',
    'L_RX1_POWER',
    'L_RX1_POWER_HIGH_ALARM',
    'L_RX1_POWER_LOW_ALARM',
    'L_RX1_POWER_HIGH_WARN',
    'L_RX1_POWER_LOW_WARN',
    'L_RX2_POWER',
    'L_RX2_POWER_HIGH_ALARM',
    'L_RX2_POWER_LOW_ALARM',
    'L_RX2_POWER_HIGH_WARN',
    'L_RX2_POWER_LOW_WARN',
    'L_RX3_RX4_POWER',
    'L_RX3_POWER',
    'L_RX3_POWER_HIGH_ALARM',
    'L_RX3_POWER_LOW_ALARM',
    'L_RX3_POWER_HIGH_WARN',
    'L_RX3_POWER_LOW_WARN',
    'L_RX4_POWER',
    'L_RX4_POWER_HIGH_ALARM',
    'L_RX4_POWER_LOW_ALARM',
    'L_RX4_POWER_HIGH_WARN',
    'L_RX4_POWER_LOW_WARN',
    'L_TX1_TX2_BIAS',
    'L_TX1_BIAS',
    'L_TX1_BIAS_HIGH_ALARM',
    'L_TX1_BIAS_LOW_ALARM',
    'L_TX1_BIAS_HIGH_WARN',
    'L_TX1_BIAS_LOW_WARN',
    'L_TX2_BIAS',
    'L_TX2_BIAS_HIGH_ALARM',
    'L_TX2_BIAS_LOW_ALARM',
    'L_TX2_BIAS_HIGH_WARN',
    'L_TX2_BIAS_LOW_WARN',
    'L_TX3_TX4_BIAS',
    'L_TX3_BIAS',
    'L_TX3_BIAS_HIGH_ALARM',
    'L_TX3_BIAS_LOW_ALARM',
    'L_TX3_BIAS_HIGH_WARN',
    'L_TX3_BIAS_LOW_WARN',
    'L_TX4_BIAS',
    'L_TX4_BIAS_HIGH_ALARM',
    'L_TX4_BIAS_LOW_ALARM',
    'L_TX4_BIAS_HIGH_WARN',
    'L_TX4_BIAS_LOW_WARN',
    'L_TX1_TX2_POWER',
    'L_TX1_POWER',
    'L_TX1_POWER_HIGH_ALARM',
    'L_TX1_POWER_LOW_ALARM',
    'L_TX1_POWER_HIGH_WARN',
    'L_TX1_POWER_LOW_WARN',
    'L_TX2_POWER',
    'L_TX2_POWER_HIGH_ALARM',
    'L_TX2_POWER_LOW_ALARM',
    'L_TX2_POWER_HIGH_WARN',
    'L_TX2_POWER_LOW_WARN',
    'L_TX3_TX4_POWER',
    'L_TX3_POWER',
    'L_TX3_POWER_HIGH_ALARM',
    'L_TX3_POWER_LOW_ALARM',
    'L_TX3_POWER_HIGH_WARN',
    'L_TX3_POWER_LOW_WARN',
    'L_TX4_POWER',
    'L_TX4_POWER_HIGH_ALARM',
    'L_TX4_POWER_LOW_ALARM',
    'L_TX4_POWER_HIGH_WARN',
    'L_TX4_POWER_LOW_WARN',
    'VENDOR_SPECIFIC_19',
    'TEMPERATURE',
    'SUPPLY_VOLTAGE',
    'VENDOR_SPECIFIC_30',
]

def dump_collect(port, pid):
    """Collects dump data for SFF-8636 modules."""
    # Print basic module information
    print('\n{}'.format(mod_id(port.port_type)))
    helpers.print_keyval_list(port, dump_keys)
    # Print options information
    print("\nOptions:\n")
    helpers.print_keyval_list(port, identity_info_keys)
    # Print monitoring bit information
    print("\nModule Monitoring:\n")
    helpers.print_keyval_list(port, monitoring_bit_keys)

def verbose_print(message):
    if VERBOSE:
        print(message)

def get_lpmode_sff8636(port):
    # Get registered values (created once in info.py)
    try:
        import xcvr_pins
    except ImportError:
        raise RuntimeError("xcvr_pins module not available for this device")
    try:
        max_ports = helpers.get_registered('max_ports')
        xcvr_pins_obj = helpers.get_registered('xcvr_pins')
    except RuntimeError:
        try:
            oom = helpers.get_registered('oom')
            portlist, max_ports = helpers.get_port_list(oom)
            xcvr_pins_obj = xcvr_pins.XcvrPins(max_ports)
            helpers.register("max_ports", max_ports)
            helpers.register("xcvr_pins", xcvr_pins_obj)
        except RuntimeError:
            raise RuntimeError("Cannot initialize xcvr_pins: 'oom' not registered and no fallback available")

    name = port.port_name.lower().strip()
    if not name.startswith("port"):
        raise RuntimeError(f"Invalid port name '{port.port_name}'")
    port_num = int(name[4:])
    result = xcvr_pins_obj.get_xcvr_lowpower_pin(port_num)
    if result is None:
        raise RuntimeError(f"Failed to get low power pin state for port {port_num}: port out of range or system error")
    return result == 1


def get_module_type(port, verbose):
    oom = helpers.get_registered('oom')
    modtype = oom.type_to_str(port.port_type)

    if modtype != "QSFP28":
        return modtype

    try:
        enc = int(oom.oom_get_keyvalue(port, 'ENCODING'))
        baudrate = int(oom.oom_get_keyvalue(port, 'BR_NOMINAL'))
        bitrate = baudrate

        if enc == 0x08:  # PAM4
            bitrate *= 2

        if bitrate > 75000:
            modtype = "QSFP112"
        elif bitrate > 37500:
            # Unspecified encoding type causes ambiguity only for bitrates related to QSFP56.
            # At this bitrate, the module type could be either QSFP56 or QSFP112, depending on
            # the encoding.
            if enc == 0x00: # Unspecified
                modtype = "QSFP56?"
                if verbose:
                    print(f"Unspecified encoding (0x00) with bitrate {bitrate} detected for "
                          f"{port.port_name}, defaulting to `{modtype}`")
            else:
                modtype = "QSFP56"
        elif bitrate > 12500:
            modtype = "QSFP28"
        else:
            modtype = "QSFP28?"
            if verbose:
                print(f"Bitrate ({bitrate}) too low for QSFP28 family on {port.port_name}, "
                      f"defaulting to `{modtype}`")

    except Exception as e:
        print(f"Failed to distinguish module type, defaulting to `{modtype}` - {e}")

    return modtype


def get_module_state_sff8636(port):
    """
    Derive SFF-8636 module 'state', mapped to CMIS-style numeric codes.
    """
    get_oom_keyvalue_func = helpers.get_registered("get_oom_keyvalue")

    try:
        # --- Fault Conditions ---
        fault_checks = [
            ('L_TX_FAULT',        'TX Fault'),
            ('L_TEMP_HIGH_ALARM', 'Temp High Alarm'),
            ('L_VCC_HIGH_ALARM',  'VCC High Alarm'),
        ]

        for key, desc in fault_checks:
            val = int(get_oom_keyvalue_func(port, key))
            if val != 0:
                verbose_print(f"Returning FAULT due to {desc}: {val}")
                return module_state.index('Fault')

        # --- Low Power Mode detection ---
        power_override = int(get_oom_keyvalue_func(port, 'POWER_OVERRIDE'))
        verbose_print(f"POWER_OVERRIDE: {power_override}")

        if power_override == 0:
            # LP mode determined by hardware pin
            lp_mode = get_lpmode_sff8636(port)
            if lp_mode is True:
                verbose_print("Returning LOW_PWR due to HW pin Low Power Mode")
                return module_state.index('LowPwr')
        else:
            # LP mode determined by POWER_SET field
            power_set = int(get_oom_keyvalue_func(port, 'POWER_SET'))
            if power_set == 1:
                verbose_print(f"Returning LOW_PWR due to POWER_SET register: {power_set}")
                return module_state.index('LowPwr')

        # --- Default State ---
        return module_state.index('Ready')

    except (KeyError, ValueError, OSError, TypeError, NameError, IndexError) as e:
        verbose_print(f"Exception occurred: {type(e).__name__} - {e}")
        return module_state.index('Fault')


def set_fec_cfg(port, fec_cfg, args_verbose):
    oom = helpers.get_registered('oom')
    if args_verbose > 1:
        print(f'fec_cfg: {fec_cfg}')
    if fec_cfg is not None:
        if not (1 <= fec_cfg <= len(fec_cfg_types)):
            print(f'Error: Invalid FEC control mode {fec_cfg}. Valid range is 1-{len(fec_cfg_types)}')
            return
        if args_verbose > 1:
            print(f'Setting FEC control mode: {fec_cfg}: {fec_cfg_types[fec_cfg - 1]}')
        oom.oom_set_keyvalue(port, 'FEC_CTRL_ENABLE', fec_cfg - 1)

def show_fec_cfg(port, args_verbose):
    oom = helpers.get_registered('oom')
    current_fec = int(oom.oom_get_keyvalue(port, 'FEC_CTRL_ENABLE'))
    if 0 <= current_fec < len(fec_cfg_types):
        print(f'Current FEC control mode: {current_fec + 1}: {fec_cfg_types[current_fec]}')
    else:
        print(f'Current FEC control mode: {current_fec + 1}: Invalid (out of range [0-{len(fec_cfg_types)-1}])')


def print_supported_apps(port, apps=None):
    print('\nNot applicable for SFF-8636 modules')
