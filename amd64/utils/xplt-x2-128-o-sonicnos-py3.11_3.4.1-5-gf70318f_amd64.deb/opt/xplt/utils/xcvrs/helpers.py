# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import argparse
import functools
import sys
import time
from oom.oomlib import port_type_e
from oom.decode import mod_id

PORT_DEFAULT_FIRST = 1

# Media types for CMIS modules (MOD_MED_TYPE_ENC encoding)
MEDIA_TYPES = [
    'Undef',
    'MMF',
    'SMF',
    'PCC',
    'AC',
    'BASE-T'
]

# Execution time measurement verbosity
time_vbs = False

SFF_8636_TYPES = {
    port_type_e['QSFP'],
    port_type_e['QSFP_PLUS'],
    port_type_e['QSFP28'],
}


class UnsupportedFeatureError(Exception):
    """Raised when a feature is not supported for a particular module type"""
    pass


# Registry for callbacks
_function_registry = {}


def register(name, func):
    """Register a callback function by name.

    Args:
        name: String identifier for the function/object
        func: Function or object to register
    """
    if name not in _function_registry:
        _function_registry[name] = func


def get_registered(name):
    """Get the registered callback by name.

    Args:
        name: String identifier for the registered function/object

    Returns:
        The registered function/object

    Raises:
        RuntimeError: If the function/object is not registered
    """
    func = _function_registry.get(name)
    if func is None:
        raise RuntimeError(f"'{name}' not registered. Call register(\"{name}\", {name}) first.")
    return func


def timer(func):
    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start = time.perf_counter()
        value = func(*args, **kwargs)
        stop = time.perf_counter()
        elapsed_time = stop - start
        print(f"{func.__name__}(): {elapsed_time:.4f} secs")
        return value
    return wrapper_timer

def decor(dec, condition):
    def decorator(func):
        if not condition:
            # Return the function unchanged, not decorated.
            return func
        return dec(func)
    return decorator

def is_sff_8636_module(port):
    """
    Returns True if the module type has SFF-8636 compliance; False otherwise.
    """
    return getattr(port, 'port_type', None) in SFF_8636_TYPES


def dispatch_by_protocol(cmis_func, sff8636_func=None):
    """Decorator to dispatch function calls based on module protocol"""
    def decorator(func):
        def wrapper(port, *args, **kwargs):
            if is_sff_8636_module(port):
                if not sff8636_func:
                    raise UnsupportedFeatureError(f"{func.__name__} not supported for SFF-8636")
                #print(f"Using SFF-8636 implementation {sff8636_func.__name__}")
                return sff8636_func(port, *args, **kwargs)
            else:
                #print(f"Using CMIS implementation {cmis_func.__name__}")
                return cmis_func(port, *args, **kwargs)
        return wrapper
    return decorator

class PortAction(argparse.Action):
    """
    PortAction is a custom argparse.Action used to validate port number arguments.
    Ensures that the provided port value is greater than PORT_DEFAULT_FIRST.
    """
    def __call__(self, parser, namespace, value, option_string=None):
        if value is not None:
            if not PORT_DEFAULT_FIRST <= value:
                raise argparse.ArgumentError(self, f"Port number ({value}) must be greater than or equal to {PORT_DEFAULT_FIRST}")
            setattr(namespace, self.dest, value)


@decor(timer, time_vbs)
def get_port_list(oom):
    """
    Get list of ports from the OOM object.

    Args:
        oom: OOM object

    Returns:
        tuple: (portlist, max_ports). Exits if portlist is empty.
     """
    portlist = oom.oom_get_portlist()
    max_ports = len(portlist)
    if max_ports == 0:
         print("Empty portlist, configuration issue?")
         exit()
    return portlist, max_ports

def check_port_max_number(arg_first, arg_last, max_ports):
    """
    Validates and computes the port range (first, last) based on the provided
    arguments and maximum available ports.
    When first is None, used maximum available range of ports.
    When last is None, it is set to the value of first.

    Args:
        arg_first(int, optional): The first port index.
        arg_last (int, optional): The last port index or range.
        max_ports (int): Maximum number of available ports.

    Raises:
        ValueError: If configuration is invalid (missing attributes, invalid
            ranges, or exceeding max_ports).

    Returns:
        tuple: (first, last) port indexes (1-based).
    """
    if max_ports <= 0:
        print("Invalid configuration: no ports available")
        sys.exit(1)

    if arg_first is None:
        first = PORT_DEFAULT_FIRST
        last = max_ports
    else:
        if arg_first < 1:
            print(f"Invalid configuration: 'arg_first'({arg_first}) should be greater than or equal to 1")
            sys.exit(1)
        first = arg_first
        last = arg_last
        if last is None:
            last = arg_first

    if last > max_ports:
        print(f"'last'({last}) port number cannot be greater than 'max_ports'({max_ports})")
        sys.exit(1)
    if first > last:
        print(f"'first'({first}) port number  cannot be greater than 'last'({last}) port number")
        sys.exit(1)
    return first, last


def print_keyval(port, key):
    get_keyval_func = get_registered("get_keyval")
    get_mapped_key_func = get_registered("get_mapped_key")
    mapped_key = get_mapped_key_func(key, port)
    if mapped_key is None:
        return
    keyval = get_keyval_func(port, mapped_key)
    print(keyval)


def print_keyval_list(port, lst):
    for key in range(0, len(lst)):
        print_keyval(port, lst[key])


# Registration for capability types and keys
_capabilities_registry = {
    'cmis_types': None,
    'sff8636_types': None,
    'cmis_keys': None,
    'sff8636_keys': None,
}


def register_capabilities_types_and_keys(cmis=None, sff8636=None):
    """
    Function to register capability types or keys from modules

    Args:
        cmis: List of capability type strings OR list of capability key lists.
            - For types: list of strings, e.g., ['Type1', 'Type2']
            - For keys: list of lists of strings, e.g., [['Key1', 'Key2'], ['Key3']]
        sff8636: List of capability type strings OR list of capability key lists.
            Same format as cmis parameter.

    Raises:
        TypeError: If cmis or sff8636 is not None and not a list
        ValueError: If the list format is invalid (empty list, wrong element types, etc.)

    Note:
        Empty lists are silently ignored. To clear a registration, pass None explicitly.
    """
    global _capabilities_registry

    def _register(param_value, param_name, types_key, keys_key):
        """Helper to register a single parameter"""
        if param_value is None:
            return

        if not isinstance(param_value, list):
            raise TypeError(f"{param_name} must be a list, got {type(param_value).__name__}")

        if len(param_value) == 0:
            # Empty list - silently ignore (could be intentional clearing)
            return

        if isinstance(param_value[0], str):
            # Register as types (list of strings)
            _capabilities_registry[types_key] = param_value
        elif isinstance(param_value[0], list):
            # Register as keys (list of lists)
            # Validate that all elements are lists
            if not all(isinstance(item, list) for item in param_value):
                raise ValueError(f"All elements in {param_name} must be lists when registering keys")
            _capabilities_registry[keys_key] = param_value
        else:
            raise ValueError(
                f"Invalid {param_name} format: expected list of strings or list of lists, "
                f"got list containing {type(param_value[0]).__name__}"
            )

    _register(cmis, 'cmis', 'cmis_types', 'cmis_keys')
    _register(sff8636, 'sff8636', 'sff8636_types', 'sff8636_keys')


def get_capabilities_types_or_keys(port, what='types'):
    """
    Function to get capability types or keys based on module type

    Returns:
        tuple: (value, length)
            value: list of capability types or keys
            length: length of the value list

    Raises:
        ValueError: If 'what' parameter is invalid. Must be 'types' or 'keys'
        RuntimeError: If capability types or keys are not registered
    """
    if what == 'types':
        key = 'sff8636_types' if is_sff_8636_module(port) else 'cmis_types'
        protocol = 'SFF-8636' if is_sff_8636_module(port) else 'CMIS'
    elif what == 'keys':
        key = 'sff8636_keys' if is_sff_8636_module(port) else 'cmis_keys'
        protocol = 'SFF-8636' if is_sff_8636_module(port) else 'CMIS'
    else:
        raise ValueError(f"Invalid 'what' parameter: {what}. Must be 'types' or 'keys'")
    value = _capabilities_registry.get(key)
    if value is None:
        raise RuntimeError(f"{protocol} capability {what} not registered")
    return value, len(value)


# Convenience functions for backward compatibility
def get_capability_types(port):
    """Get capability types based on module type"""
    return get_capabilities_types_or_keys(port, 'types')


def get_capabilities_keys(port):
    """Get capabilities_keys based on module type"""
    return get_capabilities_types_or_keys(port, 'keys')


def get_module_identity(port):
    """Get module identity"""
    if port.port_type == 0:
        return
    print(f'\n{mod_id(port.port_type)}')
    print_keyval(port, 'VENDOR_NAME')
    print_keyval(port, 'VENDOR_PN')
    print_keyval(port, 'VENDOR_SN')

    if is_sff_8636_module(port):
        # SFF-8636 modules use VENDOR_REV
        print_keyval(port, 'VENDOR_REV')
    else:
        # CMIS modules use MODULE_FW_REV_MAJOR and MODULE_FW_REV_MINOR
        print_keyval(port, 'MODULE_FW_REV_MAJOR')
        print_keyval(port, 'MODULE_FW_REV_MINOR')


def get_media_type(port):
    """
    Get media type for a module.

    CMIS: direct MOD_MED_TYPE_ENC index.
    SFF-8636: derive from compliance codes (Table 6-17),
              then fallback to connector (Table 4-3 SFF-8024).

    Args:
        port: OOM port object

    Returns:
        str: One of the media type strings defined in MEDIA_TYPES or Undef
    """
    oom = _function_registry.get("oom")
    if oom is None:
        return 'Undef'

    if not is_sff_8636_module(port):
        # CMIS module: direct MOD_MED_TYPE_ENC index
        val = oom.oom_get_keyvalue(port, 'MOD_MED_TYPE_ENC')
        try:
            return MEDIA_TYPES[int(val)]
        except (ValueError, TypeError, IndexError):
            return 'Undef'

    # SFF-8636 module: derive from compliance codes then fallback to connector
    conn = oom.oom_get_keyvalue(port, 'CONNECTOR')
    try:
        conn_code = int(conn)
    except (ValueError, TypeError):
        conn_code = 0

    codes = {}
    nonzero = False
    for i in range(131, 139):
        v = oom.oom_get_keyvalue(port, f'MED_TYPE_COMPLIANCE_CODES_{i}')
        try:
            b = int(v)
        except (ValueError, TypeError):
            b = 0
        codes[i] = b
        if b:
            nonzero = True

    # Lazy import to avoid circular dependency (sff8636 imports helpers)
    # By the time this function is called, both modules are already loaded,
    # so this import just retrieves the existing module from sys.modules
    try:
        import sff8636
    except ImportError:
        # Can't determine media type for SFF-8636 modules
        return 'Undef'

    if nonzero:
        media = sff8636.classify_from_sff8636_codes(port, codes)
        if media:
            return media

    # Fallback to connector map
    return sff8636.CONNECTOR_MAP.get(conn_code, 'Undef')


def get_capabilities(port, captype: int) -> None:
    """
    Get capabilities based on module type

    Args:
        port: OOM port object
        captype: Capability type index

    Raises:
        ValueError: If capability type is invalid
    """
    get_module_identity(port)

    # Skip printing capabilities for PCC modules
    media_type = get_media_type(port)
    print(f'{"MEDIA_TYPE":28} |{"N/A":4}|{"N/A":3}|  {media_type}')
    if media_type == 'PCC':
        return

    capability_types, capability_types_length = get_capability_types(port)
    capabilities_keys, capabilities_keys_length = get_capabilities_keys(port)

    if captype > capability_types_length:
        raise ValueError(f'Invalid capability type: {captype}. Must be between 1 and {capability_types_length}')

    ALL_CAPABILITIES_INDEX = 1
    SUPPORTED_APPS_INDEX = capability_types_length  # Last item in list

    print_supported_apps_func = get_registered("print_supported_apps")

    if captype == ALL_CAPABILITIES_INDEX:
        max_items = min(capabilities_keys_length, len(capability_types) - 1)
        for i in range(0, max_items):
            print(f'\n{capability_types[i + 1]}:\n')
            print_keyval_list(port, capabilities_keys[i])
        print_supported_apps_func(port)
    elif captype == SUPPORTED_APPS_INDEX:
        print_supported_apps_func(port)
    else:
        if captype <= ALL_CAPABILITIES_INDEX:
            raise ValueError(f'Invalid capability type: {captype}. Must be greater than 1')
        print(f'\n{capability_types[captype - 1]}:\n')
        print_keyval_list(port, capabilities_keys[captype - 2])
