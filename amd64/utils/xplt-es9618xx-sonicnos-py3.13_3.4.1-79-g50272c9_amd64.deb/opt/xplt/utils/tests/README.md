# Thermal control tests

Pytest-based tests for thermal control logic, shared by Accton platforms on
both SONIC and XsightOS. The tests run against the same thermal policy
implementation used by `thermalctld` (SONIC) or `xmon` (XsightOS), with
services temporarily stopped so results are deterministic.

## Prerequisites

- Root (tests stop/start thermal and related services).
- **XPLT installed under `/opt/xplt`** in one of two ways:
  - From the git repository: run `utils/install.sh` (see script help for
    device and OS options).
  - From a Debian package: install the `.deb` built earlier by the same
    script with the `-p` (package) option.
- **XsightOS:** Either XPLT installed as above, or the repo checked out (for
  running from git).
- **SONiC:** The xplt Debian package is part of the SONiC image and is
  installed during SONiC installation. The git repo is typically not on the
  device; run from the installed path only.

## How to run

### From install (on the device)

```bash
sudo /opt/xplt/utils/tests/run_tests.sh
```

On SONiC this runs pytest inside the `pmon` container at
`/opt/xplt/utils/tests/`, testing the thermalctld running there. No git repo
is required.

### From git tree (XsightOS typical; SONiC only when repo is on device)

From the repo root or from `device/accton/common/utils/tests/`:

```bash
sudo device/accton/common/utils/tests/run_tests.sh
# or, from the tests directory:
sudo ./run_tests.sh
```

**Why run from git? (XsightOS)** When xplt is installed at `/opt/xplt`, both
"from install" and "from git" use the same installed sonic_platform (venv).
Running from git uses the **repo's test file** and **repo's xmon.py** (daemon
under test) instead of the copies under `/opt/xplt`. So you can edit tests or
thermal policy (xmon.py) in the repo and run without reinstalling—faster
iteration during development. On SONiC, run-from-git is only for development
when the repo is on the device; normally run from the installed path and test
the thermalctld in the pmon container.

The script detects whether it is running from the git tree or from `/opt/xplt`
and uses the appropriate paths. When run from git on XsightOS it uses the
repo's test file and repo's `xmon.py` (THERMAL_DAEMON_SRC) and, if xplt is
installed at `/opt/xplt`, the installed venv's pytest and sonic_platform (so
chassis is available); otherwise it uses host pytest. When run from git on
SONiC it copies only the repo's `tests/` into the pmon container (at `/tmp/xplt/tests`)
and runs the tests from there, using the installed `sonic_platform` packages
already present in the container. When run from the installed path on SONiC it
runs the tests directly from `/opt/xplt/utils/tests/` inside the pmon container.
Have pytest on the host for XsightOS from git unless xplt is installed at
`/opt/xplt` (venv has pytest).

The script detects SONIC vs XsightOS (via `/etc/sonic/config_db.json`) and:

- **XsightOS:** Stops `xmon.service` and `xled.service`, runs pytest from the
  host, then restarts the services.
- **SONIC:** Stops `system-health.service` and `thermalctld` in the `pmon`
  container, runs pytest inside the container at `/opt/xplt/utils/tests/`,
  then restarts them.

Exit code is the pytest result (0 = pass, non-zero = fail).

## Optional: run pytest yourself

If you need different pytest options (e.g. `-v`, `-k`, coverage):

- **XsightOS (installed):** Stop `xmon` and `xled` first, then from
  `/opt/xplt/utils/tests/` run:
  ```bash
  /opt/xplt/venv/bin/pytest test_thermal_control.py [options]
  ```
  Restart the services when done.

- **XsightOS (from git):** Stop `xmon` and `xled` first, then from
  `device/accton/common/utils/tests/` run (use venv pytest if xplt is
  installed so installed sonic_platform with chassis is used; do not set
  PYTHONPATH):
  ```bash
  THERMAL_DAEMON_SRC="../xmon.py" /opt/xplt/venv/bin/pytest test_thermal_control.py [options]
  ```
  Or with host pytest if venv is not available. Restart the services when done.

- **SONIC:** Stop `system-health.service` and `thermalctld` in the pmon
  container, then (installed path):
  ```bash
  docker exec -w /opt/xplt/utils/tests/ pmon \
    pytest test_thermal_control.py [options]
  ```
  Restart the services when done.

Using `run_tests.sh` is recommended so services are always restored (including
on interrupt).
