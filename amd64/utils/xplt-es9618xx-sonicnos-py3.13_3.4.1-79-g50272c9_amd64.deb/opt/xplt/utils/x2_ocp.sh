#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

if [ "$(id -u)" -ne 0 ] ; then
    echo "This script must be executed with root privileges"
    exit 1
fi

progname=$(basename $0)
verbose=0
nodered=0
polling=0
usercmd=''
configure=0
set_voltage=0
vdd_voltage=''

# Voltage range (Volts) for -V optional value when overriding VDD_CORE for this run
VDD_VOLT_MIN=0.68
VDD_VOLT_MAX=0.75

function usage() {
    cat << help

Usage: $progname [-h] [-n] [-c] [-V [V]] [-s RATE] [-v LEVEL] [-u CMD]
    -h, --help             Show this help message and exit
    -n, --nodered          Node-red formatted output
    -c, --configure        Configure Over Current Protection (OCP) settings
    -V, --set-voltage [V]  Set output voltage (VOUT_COMMAND) for all rails from vout_cmd;
                           optional V overrides VDD_CORE for this run (range $VDD_VOLT_MIN - $VDD_VOLT_MAX)
    -p, --polling RATE     Measure in loop at RATE seconds, ^C to exit
    -v, --verbose LEVEL    More verbose output, range 1..3 (3 = debug)
    -u, --usercmd CMD      user defined command string to use with -n
Examples:
    sudo /opt/xplt/utils/x2_ocp.sh
    sudo /opt/xplt/utils/x2_ocp.sh -c
    sudo /opt/xplt/utils/x2_ocp.sh -V
    sudo /opt/xplt/utils/x2_ocp.sh -V 0.72
    sudo /opt/xplt/utils/x2_ocp.sh -v1
    sudo /opt/xplt/utils/x2_ocp.sh -n -p1
    sudo /opt/xplt/utils/x2_ocp.sh -n -p2 -u "nc -q 1 localhost 2233"

help
}

OPTS=$(getopt -o "hncV::p:v:u:" --long "help,nodered,configure,set-voltage::,polling:,verbose:,usercmd:" \
    -n "$progname" -- "$@")

eval set -- "$OPTS"

while true; do
    case "$1" in
        -h | --help ) usage; exit 0 ;;
        -n | --nodered ) nodered=1; shift ;;
        -c | --configure ) configure=1; shift ;;
        -V | --set-voltage ) set_voltage=1; shift
            if [ -n "${1:-}" ] && [ "$1" != "--" ] && [[ ! "$1" =~ ^- ]]; then
                vdd_voltage="$1"; shift
            elif [ -z "${1:-}" ]; then
                shift
            fi ;;
        -p | --polling ) polling="$2"; shift 2 ;;
        -v | --verbose ) verbose="$2"; shift 2 ;;
        -u | --usercmd ) usercmd="$2"; shift 2 ;;
        -- ) shift; break ;;
        * ) break ;;
    esac
done

# With getopt -V::, -V 0.74 (space) yields -V '' ... -- 0.74; skip empty in -V case so 0.74 stays after --
# Here $1 is the first remaining (non-option) argument, i.e. the voltage when passed as -V 0.74.
if [ $set_voltage -eq 1 ] && [ -z "$vdd_voltage" ] && [ $# -ge 1 ] && [[ "$1" =~ ^[0-9]+\.?[0-9]*$ ]]; then
    vdd_voltage="$1"
    shift
fi

XPLT_INFO=/opt/xplt/xplt
if [ -f "$XPLT_INFO" ]; then
    plt=$(awk -F' = ' '/^plt/{print $2}' "$XPLT_INFO")
else
    echo "Error: $XPLT_INFO not found"
    exit 1
fi

# Define rails as an associative array of "I2CBUS I2C_ADDR DEV_ADDR DEV_IDX"
declare -A rails
hw_rev=""

case "$plt" in
    es9618xx)
        rails=(
            [VDD_CORE]="35 0x60 0060 0x00"
            [VDD_SD]="36 0x61 0061 0x00"
            [VDD_L1]="37 0x64 0064 0x00"
            [VDD_L2]="37 0x64 0064 0x01"
            [VDD_L3]="38 0x65 0065 0x00"
            [VDD_L4]="38 0x65 0065 0x01"
            [VDD_H1]="39 0x40 0040 0x00"
            [VDD_H2]="39 0x40 0040 0x01"
            [VDD_H3]="40 0x41 0041 0x00"
            [VDD_H4]="40 0x41 0041 0x01"
        )
        hw_rev=$(/opt/xplt/utils/hw_rev.sh)
        ;;
    as9647-32d)
        rails=(
            [VDD_CORE]="51 0x60 0060 0x00"
            [VDD_SD]="52 0x61 0061 0x00"
            [VDD_L1]="53 0x64 0064 0x00"
            [VDD_L2]="53 0x64 0064 0x01"
            [VDD_L3]="54 0x65 0065 0x00"
            [VDD_L4]="54 0x65 0065 0x01"
            [VDD_H1]="55 0x40 0040 0x00"
            [VDD_H2]="55 0x40 0040 0x01"
            [VDD_H3]="56 0x41 0041 0x00"
            [VDD_H4]="56 0x41 0041 0x01"
        )
        ;;
    *)
        echo "Error: Unsupported platform '$plt'"
        exit 1
        ;;
esac

keys=(
    VDD_CORE
    VDD_SD
    VDD_L1
    VDD_L2
    VDD_L3
    VDD_L4
    VDD_H1
    VDD_H2
    VDD_H3
    VDD_H4
)

declare -A voltages
declare -A currents
declare -A powers

# Define Over Current Protection (OCP) limits for each rail (in Amps)
declare -A ocp=(
    [VDD_CORE]=160
    [VDD_SD]=56
    [VDD_L1]=18
    [VDD_L2]=18
    [VDD_L3]=18
    [VDD_L4]=18
    [VDD_H1]=18
    [VDD_H2]=18
    [VDD_H3]=18
    [VDD_H4]=18
)
# Define Over Current Protection (OCP) warning levels for each rail (in Amps)
declare -A ocp_warn=(
    [VDD_CORE]=136
    [VDD_SD]=48
    [VDD_L1]=16
    [VDD_L2]=16
    [VDD_L3]=16
    [VDD_L4]=16
    [VDD_H1]=16
    [VDD_H2]=16
    [VDD_H3]=16
    [VDD_H4]=16
)

# Fixed VOUT_COMMAND (0x21) register values per rail (hex). Value = Y * 2^N, N=-12 from VOUT_MODE.
# Y = round(V * 2^12) = round(V * 4096). Examples: 0x0c00 = 0.75 V, 0x1334 = 1.2 V
declare -A vout_cmd=(
    [VDD_CORE]=0x0c00
    [VDD_SD]=0x0c00
    [VDD_L1]=0x0c00
    [VDD_L2]=0x0c00
    [VDD_L3]=0x0c00
    [VDD_L4]=0x0c00
    [VDD_H1]=0x1334
    [VDD_H2]=0x1334
    [VDD_H3]=0x1334
    [VDD_H4]=0x1334
)

driver=$(lsmod | grep _cpld | cut -d" " -f1)
if [[ "$driver" == *"cpld"* ]]; then
    [ $verbose -eq 2 ] && echo Mode: sysfs
    MODE=1
    SYSFS=/sys/bus/i2c/devices
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        dev_path="$SYSFS/${I2CBUS}-${DEV_ADDR}"
        bus_path="$SYSFS/i2c-${I2CBUS}/new_device"
        [ ! -d "$dev_path" ] && echo i2ctools "$I2C_ADDR" > "$bus_path"
    done
else
    [ $verbose -eq 2 ] && echo Mode: i2c-0
    MODE=2
fi

function cleanup_sysfs_nodes() {
    if (( $MODE == 1 )); then
        for key in "${keys[@]}"; do
            read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
            [ -d $SYSFS/${I2CBUS}-${DEV_ADDR} ] && echo $I2C_ADDR > $SYSFS/i2c-${I2CBUS}/delete_device || true
        done
    fi
    exit 0
}

trap cleanup_sysfs_nodes SIGINT

function collect_readings() {
    VX=$(i2cget -f -y $I2CBUS $I2C_ADDR 0x8b w)
    AX=$(i2cget -f -y $I2CBUS $I2C_ADDR 0x8c w)

    if [[ "$hw_rev" == R0A* ]] || [[ "$hw_rev" == R0B* ]]; then
        VD=$(echo $(($VX)))
        AD=$(awk "BEGIN {printf \"%.1f\",$(echo $(($AX))) / 10}")
    else
        VD_E=$(($(i2cget -f -y $I2CBUS $I2C_ADDR 0x20 b) & 0x1F))
        [ "$VD_E" -gt 16 ] && ((VD_E=VD_E-32))
        VD=$(awk "BEGIN {printf \"%.0f\", $((VX)) * 1000 * (2 ^ $VD_E)}")
        AD_M=$((AX & 0x7FF))
        AD_E=$(((AX >> 11) & 0x1F))
        [ "$AD_E" -gt 16 ] && ((AD_E=AD_E-32))
        AD=$(awk "BEGIN {printf \"%.1f\", $AD_M * (2 ^ $AD_E)}")
    fi

    PW=$(awk "BEGIN {printf \"%.2f\",$VD * $AD / 1000}")
    voltages[$key]=$VD
    currents[$key]=$AD
    powers[$key]=$PW
    TP=$(awk "BEGIN {printf \"%.2f\",$TP + $PW}")
}

function display_readings() {
    if [ $nodered -eq 1 ]; then
        if [ $(echo -n "$usercmd" | wc -m) -gt 0 ]; then
            echo $TP | eval $usercmd
        else
            printf '%s\n' $TP
        fi
        return
    else
        separator=$(printf '%.0s-' {1..86})
        format='%8s'
        [ $polling -eq 0 ] && printf '\n'
        printf '%s power(W) %11s' X2 $TP
    fi
    if [ $verbose -gt 0 ]; then
        printf '\n'$separator
        printf '\n      '
        for key in "${keys[@]}"; do
            printf $format ${key}
        done
        printf '\nP(W): '
        for key in "${keys[@]}"; do
            printf $format ${powers[$key]}
        done
    fi
    if [ $verbose -gt 1 ]; then
        printf '\nI(A): '
        for key in "${keys[@]}"; do
            printf $format ${currents[$key]}
        done
        printf '\nV(mV):'
        for key in "${keys[@]}"; do
            printf $format ${voltages[$key]}
        done
    fi
    printf '\n\n'
}

function read_power() {
    voltages=()
    currents=()
    powers=()
    TP=0

    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        if (( $MODE == 1 )); then
            :
        else
            I2CBUS=1
            case $key in
                VDD_CORE) i2cset -f -y $I2CBUS 0x76 0 0x2 ;;
                VDD_SD)   i2cset -f -y $I2CBUS 0x76 0 0x4 ;;
                VDD_L1|VDD_L2) i2cset -f -y $I2CBUS 0x76 0 0x8 ;;
                VDD_L3|VDD_L4) i2cset -f -y $I2CBUS 0x76 0 0x10 ;;
                VDD_H1|VDD_H2) i2cset -f -y $I2CBUS 0x76 0 0x20 ;;
                VDD_H3|VDD_H4) i2cset -f -y $I2CBUS 0x76 0 0x40 ;;
            esac
        fi
        i2cset -f -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX
        collect_readings
    done

    display_readings
}

# Read STATUS_IOUT (0x7b) for every rail
function read_status_iout_all_rails() {
    echo "Checking OCP status"
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        status=$(i2cget -y $I2CBUS $I2C_ADDR 0x7b)
        if [ $? -ne 0 ]; then
            echo "$key: Failed to read STATUS_IOUT on bus $I2CBUS addr $I2C_ADDR"
            continue
        fi
        status_dec=$((status))
        if (( (status_dec & 0x20) != 0 )); then
            echo "$key: Output overcurrent warning (STATUS_IOUT=0x$(printf '%02x' $status_dec))"
        elif (( (status_dec & 0x01) != 0 )); then
            echo "$key: Output over-power warning (STATUS_IOUT=0x$(printf '%02x' $status_dec))"
        elif (( (status_dec & 0x80) != 0 )); then
            echo "$key: Output overcurrent fault (STATUS_IOUT=0x$(printf '%02x' $status_dec))"
        fi
        status=$(i2cset -y $I2CBUS $I2C_ADDR 0x7b $status)
        if [ $? -ne 0 ]; then
            echo "$key: Failed to write STATUS_IOUT on bus $I2CBUS addr $I2C_ADDR"
            continue
        fi
    done
}

function calc_ocp_regval() {
    # $1 = OCP limit (Amps)
    local limit=$1
    local N=1   # Only exponent of 1 is accepted
    # Use rounding instead of truncation for better accuracy
    local Y=$(( (limit + (1 << N) / 2) >> N ))
    # Compose 16-bit value: N in bit 11..15, Y in bit 0..10
    local regval=$(( ((N << 11)) | Y))
    printf "0x%04x" $regval
}

function check_cml_status() {
    STATUS_CML=0x7E
    regval=$(i2cget -y $I2CBUS $I2C_ADDR $STATUS_CML 2>/dev/null)
    [ $verbose -ge 3 ] && echo "$key: STATUS_CML = $regval"
    i2cset -y $I2CBUS $I2C_ADDR $STATUS_CML $regval 2>/dev/null
}

function configure_ocp_all_rails() {
    echo "Configure OCP for all rails"
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        local limit=${ocp[$key]}
        if [ -z "$limit" ]; then
            echo "No OCP limit for $key, skipping."
            continue
        fi
        local regval=$(calc_ocp_regval $limit)
        # No need to select rail via mux if kernel driver handles it
        # Select device page if needed
        i2cset -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX
        # Write OCP register
        i2cset -y $I2CBUS $I2C_ADDR 0x46 $regval w
        [ $verbose -ge 1 ] && echo "$key: Set OCP to $limit A (reg=$regval) on bus $I2CBUS addr $I2C_ADDR" \
            "page $DEV_IDX"
        check_cml_status
        # Configure OCP warning limit if available
        local warn_limit=${ocp_warn[$key]}
        if [ -n "$warn_limit" ]; then
            local warn_regval=$(calc_ocp_regval $warn_limit)
            i2cset -y $I2CBUS $I2C_ADDR 0x4A $warn_regval w
            [ $verbose -ge 1 ] && echo "$key: Set OCP WARN to $warn_limit A (reg=$warn_regval) on bus $I2CBUS" \
                "addr $I2C_ADDR page $DEV_IDX"
            check_cml_status
        fi
        # Configure OC fault response
        oc_fault_resp=0xC0
        i2cset -y $I2CBUS $I2C_ADDR 0x47 $oc_fault_resp
        [ $verbose -ge 1 ] && echo "$key: Set OC fault response to $oc_fault_resp on bus $I2CBUS" \
            "addr $I2C_ADDR page $DEV_IDX"
        check_cml_status
    done
}

# Generic function to read OCP or OCP_WARN registers for all rails
function read_ocp_register_all_rails() {
    local reg_addr="$1"
    local label="$2"
    [ $verbose -ge 1 ] && echo "Reading ${label} values from all rails:"
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        regval=$(i2cget -y $I2CBUS $I2C_ADDR $reg_addr w 2>/dev/null)
        if [ $? -ne 0 ]; then
            echo "$key: Failed to read ${label} register on bus $I2CBUS addr $I2C_ADDR"
        else
            regval_dec=$((regval))
            N=$(( (regval_dec >> 11) & 0x1F ))
            Y=$(( regval_dec & 0x7FF ))
            ocp_val=$(( Y * (1 << N) ))
            [ $verbose -ge 1 ] && printf "%-8s: %s reg=0x%04x  N=%d  Y=%d  %s=%d A (bus %s addr %s)\n" \
                "$key" "$label" "$regval_dec" "$N" "$Y" "$label" "$ocp_val" "$I2CBUS" "$I2C_ADDR"
        fi
    done
}


# Wrapper for OCP
function read_ocp_all_rails() {
    read_ocp_register_all_rails 0x46 "OCP"
}

# Wrapper for OCP_WARN
function read_ocp_warn_all_rails() {
    read_ocp_register_all_rails 0x4A "OCP_WARN"
}

# Validate voltage is in VDD_VOLT_MIN..VDD_VOLT_MAX range. Exits on error.
function validate_vdd_voltage() {
    local val="$1"
    local label="$2"
    local result
    result=$(awk "BEGIN {print ($val >= $VDD_VOLT_MIN && $val <= $VDD_VOLT_MAX) ? 1 : 0}")
    if [ "$result" != "1" ]; then
        echo "Error: $label voltage '$val' out of range ($VDD_VOLT_MIN - $VDD_VOLT_MAX V)"
        exit 1
    fi
}

# Convert voltage (V) to VOUT_COMMAND register value (hex). Value = Y * 2^-12, Y = round(V * 4096).
function voltage_to_vout_reg() {
    local v="$1"
    local Y
    Y=$(awk "BEGIN {printf \"%.0f\", $v * 4096}")
    printf "0x%04x" "${Y:-0}"
}

# Set output voltage (VOUT_COMMAND 0x21) for all rails from vout_cmd (defaults are spec values;
# user must update vout_cmd in file for other values). Same approach as configure_ocp_all_rails.
function configure_voltage_all_rails() {
    echo "Setting output voltage for all rails"
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        local regval=${vout_cmd[$key]}
        if [ -z "$regval" ]; then
            echo "No VOUT value for $key, skipping."
            continue
        fi
        # No need to select rail via mux if kernel driver handles it
        # Select device page if needed
        i2cset -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX
        # Write VOUT_COMMAND (0x21), same word write as OCP (0x46)
        i2cset -y $I2CBUS $I2C_ADDR 0x21 $regval w
        if [ $? -ne 0 ]; then
            echo "$key: Failed to set VOUT_COMMAND to $regval on bus $I2CBUS addr $I2C_ADDR"
        else
            [ $verbose -ge 3 ] && echo "$key: Set VOUT_COMMAND to $regval on bus $I2CBUS addr $I2C_ADDR" \
                "page $DEV_IDX"
        fi
    done
}

if [ $set_voltage -eq 1 ]; then
    if [ -n "$vdd_voltage" ]; then
        validate_vdd_voltage "$vdd_voltage" "VDD_CORE"
        vout_val=$(voltage_to_vout_reg "$vdd_voltage")
        [ $verbose -ge 3 ] && echo "VDD_CORE: voltage before conversion: ${vdd_voltage} V," \
            "after conversion (VOUT_COMMAND): $vout_val"
        vout_cmd[VDD_CORE]=$vout_val
    fi
    configure_voltage_all_rails
fi

if [ $configure -eq 1 ]; then
    configure_ocp_all_rails
    read_ocp_all_rails
    read_ocp_warn_all_rails
    read_status_iout_all_rails
fi

if [ $polling -eq 0 ]; then
    read_power
else
    while :; do
        read_power
        [ $configure -eq 1 ] && read_status_iout_all_rails
        sleep $polling
    done
fi

cleanup_sysfs_nodes
