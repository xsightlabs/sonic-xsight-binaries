#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

set -x
rmmod xpci
# Enable CPU I2C channel to MB.
i2cset -f -y 0 0x77 0x1
sleep 1
# MB_cold_start = 1, do not power cycle the MB.
i2cset -f -y 0 0x68 0x6 0xaf
sleep 1
# Manu_RST = 0, mask the reset signal from MB to CPU avoiding CPU board reset.
i2cset -f -y 0 0x68 0x48 0x00
sleep 1
# MB_cold_start = 0, power cycle the MB. RST_FPGA_CPU is not implemented.
i2cset -f -y 0 0x68 0x6 0x2f
sleep 2
# MB_cold_start = 1, set to default value since this is not a self-clear bit, the MB will not be power cycled.
i2cset -f -y 0 0x68 0x6 0xaf
sleep 2
# Manu_RST = 1, no mask. Set to normal operation.
i2cset -f -y 0 0x68 0x48 0x20
# Disconnect CPU I2C channel from MB.
i2cset -f -y 0 0x77 0

sleep 1
reboot
