#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

i2c_devs=$(ls /dev/i2c* | wc -l)
if (( $i2c_devs > 1 )); then
    echo Mode: sysfs
    XPLTUTILS=/opt/xplt/utils
    CONFIG_DB=/etc/sonic/config_db.json
    if [ -f $CONFIG_DB ]; then
        SYSEEPROM="show platform syseeprom"
        SHUTDOWN="/usr/sbin/shutdown"
    else
        SYSEEPROM="sudo $XPLTUTILS/py $XPLTUTILS/decode-syseeprom"
        SHUTDOWN="/sbin/shutdown"
    fi
    SYSFSDEVS=/sys/bus/i2c/devices
    fpga_ver=$(cat $SYSFSDEVS/1-0068/version)
    driver_loaded=1
else
    echo Mode: i2c-0
    DIAG_MNT_DIR=/mnt/diag
    SYSEEPROM=$DIAG_MNT_DIR/usr/local/accton/sbin/onie-syseeprom-cpu
    SHUTDOWN="/sbin/shutdown"
    [ ! -d "$DIAG_MNT_DIR" ] && sudo mkdir $DIAG_MNT_DIR
    DIAG_SDA=$(sudo fdisk -l | grep 50G | head -n1 | cut -d " " -f1)

    if ! mountpoint -q $DIAG_MNT_DIR; then
        sudo mount -t auto $DIAG_SDA $DIAG_MNT_DIR || eval "$er_exit"
    fi

    cur_vers=$(sudo ./cpldutil -ver | grep "#")
    cpldvers=($(echo "$cur_vers" | cut -d " " -f 3 | sed 's/^0*//'))
    fpga_ver=${cpldvers[0]}
fi

hw_rev=$(sudo $SYSEEPROM | grep 0x27 | awk '{print $5}')

echo "FPGA ver: $fpga_ver"
echo "HW rev:   $hw_rev"

IGNORE=("R01" "R0A")

if [[ " ${IGNORE[*]} " =~ " ${hw_rev} " ]]; then
    echo "Cannot power cycle the box. The HW rev should be higher than $hw_rev"
    exit 1
fi

if [ $fpga_ver -lt "6" ]; then
    echo "Cannot power cycle the box. The FPGA ver should be greater than 5"
    exit 1
fi

echo "Power cycling the switch in 70 seconds..."
sleep 2
# Set FPGA 0x60 [1]=0 to start 60s countdown to power cycle 12V
if [[ $driver_loaded == 1 ]]; then
    set -x
    i2cset -y -f 1 0x68 0x60 0x11
else
    set -x
    i2cset -y -f 0 0x77 0x1
    i2cset -y -f 0 0x68 0x60 0x11
fi

#Shutdown OS within 60s
$SHUTDOWN -H now
