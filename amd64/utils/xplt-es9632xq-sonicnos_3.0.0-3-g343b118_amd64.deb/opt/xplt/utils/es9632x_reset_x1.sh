#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

set -e
source /opt/xplt/utils/ioctl.sh

function ioctl_cmd() {
    local val=$(_IOW $((16#3a)) 7 4)
    printf "/opt/xplt/utils/bin/ioctl -l 4 /dev/xpci 0x%x %d\n" $val $1
}

# XPCI BUS reset
eval $(ioctl_cmd 1)

# X1 reset
driver=`lsmod | grep es9632.*cpld | cut -d" " -f1`
if [[ "$driver" == *"cpld"* ]]; then
    echo "Reset X1 via $driver driver"
    I2C_BUS_NUM=1
else
    echo "Reset X1 via I2C-0 bus master"
    I2C_BUS_NUM=0
    # Enable CPU I2C channel to MB
    i2cset -f -y $I2C_BUS_NUM 0x77 0x1
    sleep 1
fi

orgval=$(i2cget -f -y $I2C_BUS_NUM 0x68 0x8)
newval=$(printf '%x\n' "$(( $orgval & 0x7f ))")
newval=0x$newval
i2cset -f -y $I2C_BUS_NUM 0x68 0x8 $newval
sleep 1
i2cset -f -y $I2C_BUS_NUM 0x68 0x8 $orgval

if [ "$I2C_BUS_NUM" == 0 ]; then
    echo "Switch I2C bus to $I2C_BUS_NUM"
    i2cset -f -y $I2C_BUS_NUM 0x77 0
fi

# Wait for Arava
sleep 15

# BUS reset clear
eval $(ioctl_cmd 2)

# Restore PCI bars
eval $(ioctl_cmd 3)

