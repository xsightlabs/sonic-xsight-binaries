#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

if [ "$(id -u)" -ne 0 ] ; then
    echo "This script must be executed with root privileges"
    exit 1
fi

progname=$(basename $0)
verbose=0
nodered=0
polling=0
usercmd=''

function usage() {
    cat << help

Usage: $progname [-h] [-n] [-s RATE] [-v LEVEL] [-u CMD]
    -h, --help             Show this help message and exit
    -n, --nodered          Node-red formatted output
    -p, --polling RATE     Measure in loop at RATE seconds, ^C to exit
    -v, --verbose LEVEL    More verbose output, range 1..2
    -u, --usercmd CMD      user defined command string to use with -n
Examples:
    sudo ./es9632x_x1_pw.sh
    sudo ./es9632x_x1_pw.sh -v1
    sudo ./es9632x_x1_pw.sh -n -p1
    sudo ./es9632x_x1_pw.sh -n -p2 -u "nc -q 1 localhost 2233"

help
}

OPTS=$(getopt -o "hnp:v:u:" --long "help,nodered,polling:,verbose:,usercmd:" \
     -n "$progname" -- "$@")

eval set -- "$OPTS"

while true; do
    case "$1" in
        -h | --help ) usage; exit 0 ;;
        -n | --nodered ) nodered=1; shift ;;
        -p | --polling ) polling="$2"; shift 2 ;;
        -v | --verbose ) verbose="$2"; shift 2 ;;
        -u | --usercmd ) usercmd="$2"; shift 2 ;;
        -- ) shift; break ;;
        * ) break ;;
    esac
done

driver=`lsmod | grep es9632.*cpld | cut -d" " -f1`
if [[ "$driver" == *"cpld"* ]]; then
    [ $verbose -eq 2 ] && echo Mode: sysfs
    MODE=1
    SYSFS=/sys/bus/i2c/devices
    [ ! -d $SYSFS/58-0060 ] && echo i2ctools 0x60 > $SYSFS/i2c-58/new_device
    [ ! -d $SYSFS/59-0061 ] && echo i2ctools 0x61 > $SYSFS/i2c-59/new_device
    [ ! -d $SYSFS/60-0064 ] && echo i2ctools 0x64 > $SYSFS/i2c-60/new_device
    [ ! -d $SYSFS/61-0040 ] && echo i2ctools 0x40 > $SYSFS/i2c-61/new_device
else
    [ $verbose -eq 2 ] && echo Mode: i2c-0
    MODE=2
fi

keys=(
    VCORE
    VDDT
    VDD_SD1
    VDD_SD2
    VDDR
    VDDH
    VDDP
)

declare -A voltages
declare -A currents
declare -A powers

function collect_readings() {
    VX=$(i2cget -f -y $I2CBUS $1 0x8b w)
    VD=$(echo $(($VX)))
    AX=$(i2cget -f -y $I2CBUS $1 0x8c w)
    AD=$(awk "BEGIN {printf \"%.1f\",$(echo $(($AX))) / 10}")
    PW=$(awk "BEGIN {printf \"%.2f\",$VD * $AD / 1000}")
    voltages[$2]=$VD
    currents[$2]=$AD
    powers[$2]=$PW
    TP=$(awk "BEGIN {printf \"%.2f\",$TP + $PW}")
}

function display_readings() {
    if [ $nodered -eq 1 ]; then
        if [ $(echo -n "$usercmd" | wc -m) -gt 0 ]; then
            echo $TP | eval $usercmd
        else
            printf '%s\n' $TP
        fi
        return
    else
        separator=$(printf '%.0s-' {1..62})
        format='%8s'
        [ $polling -eq 0 ] && printf '\n'
        printf '%s power(W) %11s' X1 $TP
    fi
    if [ $verbose -gt 0 ]; then
        printf '\n'$separator
        printf '\n      '
        for key in ${keys[@]}; do
            printf $format ${key}
        done
        printf '\nP(W): '
        for key in ${keys[@]}; do
            printf $format ${powers[$key]}
        done
    fi
    if [ $verbose -gt 1 ]; then
        printf '\nI(A): '
        for key in ${keys[@]}; do
            printf $format ${currents[$key]}
        done
        printf '\nV(mV):'
        for key in ${keys[@]}; do
            printf $format ${voltages[$key]}
        done
    fi
    printf '\n\n'
}

function read_power() {
    voltages=()
    currents=()
    powers=()
    TP=0

    # VCORE
    if (( $MODE == 1 )); then
        I2CBUS=58
    else
        I2CBUS=0
        i2cset -f -y 0 0x77 0 0x2
        i2cset -f -y 0 0x76 0 0x2
    fi
    i2cset -f -y $I2CBUS 0x60 0x00 0x00
    collect_readings 0x60 VCORE

    # VDDT
    if (( $MODE == 1 )); then
        I2CBUS=59
    else
        I2CBUS=0
        i2cset -f -y 0 0x76 0 0x4
    fi
    i2cset -f -y $I2CBUS 0x61 0x00 0x00
    collect_readings 0x61 VDDT

    # VDD_SD1
    if (( $MODE == 1 )); then
        I2CBUS=60
    else
        I2CBUS=0
        i2cset -f -y 0 0x76 0 0x8
    fi
    i2cset -f -y $I2CBUS 0x64 0x00 0x01
    collect_readings 0x64 VDD_SD1

    # VDD_SD2
    if (( $MODE == 1 )); then
        I2CBUS=59
    else
        I2CBUS=0
        i2cset -f -y 0 0x76 0 0x4
    fi
    i2cset -f -y $I2CBUS 0x61 0x00 0x01
    collect_readings 0x61 VDD_SD2

    #VDDR
    if (( $MODE == 1 )); then
        I2CBUS=60
    else
        I2CBUS=0
        i2cset -f -y 0 0x76 0 0x8
    fi
    i2cset -f -y $I2CBUS 0x64 0x00 0x00
    collect_readings 0x64 VDDR

    #VDDH
    if (( $MODE == 1 )); then
        I2CBUS=61
    else
        I2CBUS=0
        i2cset -f -y 0 0x76 0 0x10
    fi
    i2cset -f -y $I2CBUS 0x40 0x00 0x00
    collect_readings 0x40 VDDH

    #VDDP
    i2cset -f -y $I2CBUS 0x40 0x00 0x01
    collect_readings 0x40 VDDP

    display_readings
}

if [ $polling -eq 0 ]; then
    read_power
else
    while :; do read_power; sleep $polling; done
fi

if (( $MODE == 1 )); then
    [ -d $SYSFS/58-0060 ] && echo 0x60 > $SYSFS/i2c-58/delete_device
    [ -d $SYSFS/59-0061 ] && echo 0x61 > $SYSFS/i2c-59/delete_device
    [ -d $SYSFS/60-0064 ] && echo 0x64 > $SYSFS/i2c-60/delete_device
    [ -d $SYSFS/61-0040 ] && echo 0x40 > $SYSFS/i2c-61/delete_device
fi
