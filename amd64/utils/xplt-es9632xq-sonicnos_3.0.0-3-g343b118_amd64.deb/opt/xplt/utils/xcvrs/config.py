# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import argparse
import sys
import os

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

config_modes = [
    'One config for all at once',
    'All configs one by one'
]
parser = argparse.ArgumentParser(description='Scan ports for optical modules presence',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type = int,
                    nargs = '?',
                    default= 1,
                    help = 'the front panel first port number to scan')

parser.add_argument('last',
                    type = int,
                    nargs = '?',
                    default= 32,
                    help = 'the front panel last port number to scan')

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

parser.add_argument('-s',
                    '--servertype',
                    type = int,
                    choices = [i for i in range(1, (len(server_types) + 1))],
                    help = ''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

parser.add_argument('-m',
                    '--mode',
                    type = int,
                    choices = [i for i in range(1, (len(config_modes) + 1))],
                    help = ''.join('[{}] - {}\n'.format(i + 1, config_modes[i])
                                   for i in range(len(config_modes))))

parser.add_argument('-v',
                    '--verbose',
                    action='store_true',
                    help='more verbose print')

args = parser.parse_args()

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url != None:
        oomlib.setshim("oomjsonshim", args.url)

part_numbers = [
    '1064281000',
    'T-DP4CNH-N00', 'T-OP8CDT-H00'
]

pyton = "/opt/xplt/venv/bin/python"
calib = "/opt/xplt/utils/xcvrs/calib.debug2.py"


def main():
    first = args.first
    last  = args.last
    ports = 32
    if first < 1 or first > ports or last < first or last > ports:
        print("Invalid port number")
        sys.exit(1)

    first -= 1

    portlist = oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        exit()

    if args.mode == 1:
        a = os.popen("sudo {} {} 1 -R 32 --PN 1 2 3 -u 1".format(pyton, calib)).read()
        if args.verbose: print(a)
        a = os.popen("sudo {} {} 1 -R 32 --PN 1 2 3 -p 50 9".format(pyton, calib)).read()
        if args.verbose: print(a)
        a = os.popen("sudo {} {} 1 -R 32 --PN 1 2 3 -l 4 0xff off".format(pyton, calib)).read()
        if args.verbose: print(a)
    else:
        for i in range (first, last):
            port = portlist[i]
            modtype = type_to_str(port.port_type)
            if modtype == 'UNKNOWN':
                modtype = 'No Module'

            pi = i + 1
            PN = oom_get_keyvalue(port, 'VENDOR_PN')
            for pn in part_numbers:
                if pn.split() == PN.split():
                    a = os.popen("sudo {} {} {} -u 1".format(pyton, calib, pi)).read()
                    if args.verbose: print(a)
                    a = os.popen("sudo {} {} {} -p 50 9".format(pyton, calib, pi)).read()
                    if args.verbose: print(a)
                    a = os.popen("sudo {} {} {} -l 4 0xff off".format(pyton, calib, pi)).read()
                    if args.verbose: print(a)

if __name__ == "__main__":
    main()
