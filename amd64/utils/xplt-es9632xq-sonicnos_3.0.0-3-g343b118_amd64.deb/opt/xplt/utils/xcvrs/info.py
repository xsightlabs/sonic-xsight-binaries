# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.


from __future__ import print_function
import sys
import argparse
from cmis_local import *

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

info_types = [
    'Port Name', 'Vendor', 'Type', 'Part #', 'Serial #', 'Temp,(C)', 'Voltage,(V)', 'Custom'
]

info_len = len(info_types)

info_regs = [
    '', 'VENDOR_NAME', '', 'VENDOR_PN', 'VENDOR_SN', 'TEMPERATURE', 'SUPPLY_VOLTAGE'
]

info_formats = [
    '{:10}', '{:16}', '{:13}', '{:16}', '{:16}', '{:14}', '{:12}', '{:16}'
]

class PortAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if not 1 <= values <= 32:
            raise argparse.ArgumentError(self, "Port number must be between 1 and 32")
        setattr(namespace, self.dest, values)

class InfoAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        for val in values:
            if not 1 <= val <= info_len:
                raise argparse.ArgumentError(self,
                    "info type must be between 1 and {}".format(info_len))
        setattr(namespace, self.dest, values)

parser = argparse.ArgumentParser(description='Prints optical modules information',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type = int,
                    nargs = '?',
                    default= 1,
                    action = PortAction,
                    help = 'the front panel first port number to scan')

parser.add_argument('last',
                    type = int,
                    nargs = '?',
                    default= 32,
                    action = PortAction,
                    help = 'the front panel last port number to scan')

parser.add_argument('-c',
                    '--compact',
                    action = 'store_true',
                    help ='do not print empty ports')

parser.add_argument('-i',
                    '--info',
                    metavar = "{{1..{}}}".format(info_len),
                    action = InfoAction,
                    nargs = '+',
                    type = int,
                    help = ''.join('[{}] - {}\n'.format(i+1, info_types[i])
                                for i in range(info_len)))

parser.add_argument('-n',
                    '--noheader',
                    action = 'store_false',
                    help ='do not print a table header row')

parser.add_argument('-r',
                    metavar = 'arg',
                    type = str,
                    help = 'Read value by user defined key, e.g. -r HST_GEN_EN')

parser.add_argument('-s',
                    '--servertype',
                    type = int,
                    choices = [i for i in range(1, (len(server_types) + 1))],
                    help = ''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

args = parser.parse_args()


if args.info == None:
    info = list(range(1, info_len))
else:
    info = args.info
    info.sort()

if args.r and info_len not in info:
    info.append(info_len)

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url != None:
        oomlib.setshim("oomjsonshim", args.url)


def main():
    first = args.first - 1
    last  = args.last

    portlist = oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        exit()

    if args.noheader:
        for i in info:
            field = i - 1
            custom = info_len - 1
            value = info_types[field]
            if field == custom:
                value = args.r
            print(info_formats[field].format(value), end=""),
        print("")

    for p in range (first, last):
        port = portlist[p]
        modtype = type_to_str(port.port_type)
        if modtype == 'UNKNOWN':
            if args.compact:
                continue
            modtype = 'No Module'

        add_QSFPDD_keys(port)

        for i in info:
            field = i - 1 
            custom = info_len - 1
            if field == 0:
                print(info_formats[field].format(port.port_name), end=""),
            elif field == 2:
                print(info_formats[field].format(modtype), end=""),
            elif field == custom:
                val = oom_get_keyvalue(port, args.r)
                print(info_formats[field].format(val), end=""),
            else:
                print(info_formats[field].format(str(oom_get_keyvalue(port,
                                             info_regs[field]))), end=""),
        print("")

if __name__ == "__main__":
    main()
