# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import os
import csv
import argparse
from cmis_local import *
from oom.decode import mod_id

loopback_types = [
    'Media Side Output Loopback (TP2 to TP3)',
    'Media Side Input Loopback  (TP3 to TP2)',
    'Host Side Output Loopback  (TP1 to TP4)',
    'Host Side Input Loopback   (TP4 to TP1)'
]

generator_types = [
    'Host Side Generator  (TP4)',
    'Media Side Generator (TP2)'
]

capability_types = [
    'All capabilities',
    'Loopbacks capabilities',
    'General Pattern capabilities',
    'Diagnostic Reporting capabilities',
    'Generators & Checkers capabilities',
]

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

opts_offon = ['off', 'on']

parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)

parser.add_argument('--version', action='version',
                    version='%(prog)s 2.0')

parser.add_argument('port',
                    type = int,
                    help = 'the front panel port number (starts from 1)')

parser.add_argument('-R',
                    '--range',
                    type = int,
                    help = 'number of ports to handle starting from "port" argument')

parser.add_argument('-v',
                    '--verbose',
                    action = 'store_true',
                    help = 'more verbose print')

parser.add_argument('-a',
                    '--aardvark',
                    action = 'store_true',
                    help = 'use Aardvark USB to I2C adapter')

parser.add_argument('-s',
                    '--servertype',
                    type = int,
                    choices = [i for i in range(1, (len(server_types) + 1))],
                    help = ''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

group = parser.add_mutually_exclusive_group()
group.add_argument('-p',
                   '--profile',
                   metavar = 'profile',
                   type = int,
                   help = 'write calibration profile into optical module lines')

group.add_argument('-l',
                   '--loopback',
                   type = str,
                   nargs = 3,
                   metavar = 'arg',
                   help = ''.join('[{} lanes-bitmap {{on|off}}] - {}\n'.\
                                format(i+1, loopback_types[i])
                                for i in range(len(loopback_types))))

group.add_argument('-g',
                   '--generator',
                   type = str,
                   nargs = 4,
                   metavar = 'arg',
                   help = ''.join('[{} pattern lanes {{on|off}}] - {}\n'.\
                                format(i+1, generator_types[i])
                                for i in range(len(generator_types))))

group.add_argument('-c',
                   '--capabilities',
                   type = int,
                   choices = [i for i in range(1,(len(capability_types)+1))],
                   help = ''.join('[{}] - {}\n'.format(i+1, capability_types[i])
                                   for i in range(len(capability_types))))

group.add_argument('-w',
                   metavar = 'arg',
                   nargs = 2,
                   type = str,
                   help = 'Write value by key, e.g. -w HST_GEN_EN 0xff')

group.add_argument('-r',
                   metavar = 'arg',
                   type = str,
                   help = 'Read value by key,  e.g. -r HST_GEN_EN')

args = parser.parse_args()

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url != None:
        oomlib.setshim("oomjsonshim", args.url)

#TODO: Pass the full file name as parameter
SI_MAP_FILE = 'calib_dust-photonics-dsp-si-map.csv'

si_line_cfg_err_keys = [
    'SI_L1_2_CFGERR_CODE',
    'SI_L3_4_CFGERR_CODE',
    'SI_L5_6_CFGERR_CODE',
    'SI_L7_8_CFGERR_CODE',
]

si_rx_explicit_keys = [
    'SI_RX1_EXPLICIT',
    'SI_RX2_EXPLICIT',
    'SI_RX3_EXPLICIT',
    'SI_RX4_EXPLICIT',
    'SI_RX5_EXPLICIT',
    'SI_RX6_EXPLICIT',
    'SI_RX7_EXPLICIT',
    'SI_RX8_EXPLICIT'
]

si_rx_pre_cursor_keys = [
    'SI_RX1_2_PRE_CURSOR',
    'SI_RX3_4_PRE_CURSOR',
    'SI_RX5_6_PRE_CURSOR',
    'SI_RX7_8_PRE_CURSOR'
]

si_rx_post_cursor_keys = [
    'SI_RX1_2_POST_CURSOR',
    'SI_RX3_4_POST_CURSOR',
    'SI_RX5_6_POST_CURSOR',
    'SI_RX7_8_POST_CURSOR'
]

si_rx_main_cursor_keys = [
    'SI_RX1_2_O_AMPLITUDE',
    'SI_RX3_4_O_AMPLITUDE',
    'SI_RX5_6_O_AMPLITUDE',
    'SI_RX7_8_O_AMPLITUDE'
]

cl_ss0_explicit_keys = [
    'CL_SS0_L1_EXPLICIT',
    'CL_SS0_L2_EXPLICIT',
    'CL_SS0_L3_EXPLICIT',
    'CL_SS0_L4_EXPLICIT',
    'CL_SS0_L5_EXPLICIT',
    'CL_SS0_L6_EXPLICIT',
    'CL_SS0_L7_EXPLICIT',
    'CL_SS0_L8_EXPLICIT'
]

cl_ss0_rx_pre_cursor_keys = [
    'CL_SS0_RX1_2_PRE_CURSOR',
    'CL_SS0_RX3_4_PRE_CURSOR',
    'CL_SS0_RX5_6_PRE_CURSOR',
    'CL_SS0_RX7_8_PRE_CURSOR'
]

cl_ss0_rx_post_cursor_keys = [
    'CL_SS0_RX1_2_POST_CURSOR',
    'CL_SS0_RX3_4_POST_CURSOR',
    'CL_SS0_RX5_6_POST_CURSOR',
    'CL_SS0_RX7_8_POST_CURSOR'
]

cl_ss0_rx_main_cursor_keys = [
    'CL_SS0_RX1_2_O_AMPLITUDE',
    'CL_SS0_RX3_4_O_AMPLITUDE',
    'CL_SS0_RX5_6_O_AMPLITUDE',
    'CL_SS0_RX7_8_O_AMPLITUDE'
]

loopback_capabilities_keys = [
    'LOOPBACK_CAP',
    'LB_HST_MED_LB_CAP',
    'LB_MED_PER_LANE_LB_CAP',
    'LB_HST_PER_LANE_LB_CAP',
    'LB_HST_INP_LB_CAP',
    'LB_HST_OUT_LB_CAP',
    'LB_MED_INP_LB_CAP',
    'LB_MED_OUT_LB_CAP'
]

general_pattern_capabilities_keys = [
    'GENERAL_PATTERN_CAP',
    'GP_GATING_SUPPORTED_CAP',
    'GP_LATCHED_ERR_INFO_CAP',
    'GP_RT_BER_POLLING_CAP',
    'GP_LANE_GATING_TMR_CAP',
    'GP_AUTO_RESTART_IMP_CAP'
]

diagnostic_reporting_capabilities_keys = [
    'DIAG_REPORT_CAP',
    'DR_MED_FEC_CAP',
    'DR_HST_FEC_CAP',
    'DR_MED_INP_SNR_CAP',
    'DR_HST_INP_SNR_CAP',
    'DR_MED_INP_PICK_DETECT_CAP',
    'DR_HST_INP_PICK_DETECT_CAP',
    'DR_BER_COUNT_CAP',
    'DR_BER_REGISTER_CAP'
]

generator_capabilities_keys = [
    'GEN_LOCATION_CAP',
    'GL_MED_PRE_FEC_GEN_CAP',
    'GL_MED_PST_FEC_GEN_CAP',
    'GL_MED_PRE_FEC_CHK_CAP',
    'GL_MED_PST_FEC_CHK_CAP',
    'GL_HST_PRE_FEC_GEN_CAP',
    'GL_HST_PST_FEC_GEN_CAP',
    'GL_HST_PRE_FEC_CHK_CAP',
    'GL_HST_PST_FEC_CHK_CAP',
    'HST_PRBS_PATTERN_CAP',
    'MED_PRBS_PATTERN_CAP',
    'HST_PAT_CHECKER_CAP',
    'MED_PAT_CHECKER_CAP',
    'PG1_SWAP_INVRT_CAP',
    'PG2_SWAP_INVRT_CAP',
    'PG3_SWAP_INVRT_CAP',
    'PG3_MED_CHK_LANE_EN_CAP',
    'PG3_MED_CHK_LANE_PT_CAP',
    'PG3_MED_GEN_LANE_EN_CAP',
    'PG3_MED_GEN_LANE_PT_CAP',
    'PG3_HST_CHK_LANE_EN_CAP',
    'PG3_HST_CHK_LANE_PT_CAP',
    'PG3_HST_GEN_LANE_EN_CAP',
    'PG3_HST_GEN_LANE_PT_CAP'
]

capabilities_keys = [
    loopback_capabilities_keys,
    general_pattern_capabilities_keys,
    diagnostic_reporting_capabilities_keys,
    generator_capabilities_keys
]

loopback_enable_keys = [
'MED_OUT_LOOPBACK_EN',
'MED_INP_LOOPBACK_EN',
'HST_OUT_LOOPBACK_EN',
'HST_INP_LOOPBACK_EN'
]

host_gen_init_keys = [
    'HST_GEN_L1_2',
    'HST_GEN_L3_4',
    'HST_GEN_L5_6',
    'HST_GEN_L7_8'
]

media_gen_init_keys = [
    'MED_GEN_L1_2',
    'MED_GEN_L3_4',
    'MED_GEN_L5_6',
    'MED_GEN_L7_8'
]

def load_csv_file(csv_file):
    skip = True

    with open(csv_file, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=",")
        dic = {}
        for row in reader:
            if skip:
                skip = False
                continue
            dic[int(row[:1][0])] = list(map(int, row[1:]))
    return dic


if args.verbose:
    def print_io(io, addr, val):
        print('{}: reg={} val={}'.format(io, hex(addr), hex(val)))
else:
    print_io = lambda *a: None      # do-nothing function


def print_keyval(port, key):
    reg = port.mmap[key]
    print('{:28} |{:4}|{:3}|  {}'.format(key, hex(reg[3]), reg[4], oom_get_keyvalue(port, key)))


def print_keyval_hex(port, key):
    reg = port.mmap[key]
    val = oom_get_keyvalue(port, key)
    print('{:28} |{:4}|{:3}|  {}'.format(key, hex(reg[3]), reg[4], hex(int(val))))


def set_keyval_list(port, lst, value):
    for key in range(0, len(lst)):
        oom_set_keyvalue(port, lst[key], value)


def get_keyval_list(port, lst):
    for key in range(0, len(lst)):
        print_keyval_hex(port, lst[key])


def oom_write_byte(port, addr, value):
    write = 1
    port.readcount = port.readcount + 1
    data = cast(create_string_buffer(1),POINTER(c_ubyte))
    data[0] = value
    oomsth.shim.aa_read_write(byref(port.c_port), write, addr << 1, 0, 1, data)
    print_io('wr', addr, data[0])


def verify_key(port, key):
    try:
        reg = port.mmap[key]
    except KeyError as e:
        print('Invalid key {}'.format(key))
        sys.exit(1)


def get_hexval(strval):
    try:
        val = int(strval, 16)
    except ValueError as e:
        print('Invalid hex value: {}'.format(strval))
        sys.exit(1)
    return val


def get_strarg(option, options):
    if option in options:
        return option
    else:
        print('Invalid option: {}. The valid options: {}'.format(option,
              ' '.join(map(str, options))))
        sys.exit(1)


def get_hexarg(strarg, minval, maxval):
    hexarg = get_hexval(strarg)
    if minval <= hexarg <= maxval:
        return hexarg
    else:
        print('Invalid arg: {}'.format(hex(hexarg)))
        sys.exit(1)


def oom_select_transceiver(handle, port):
    # shift rigth 1 bit because the aa_read_write shifts left 1 bit
    oom_write_byte(handle, 0x70, 0)
    oom_write_byte(handle, 0x70, 1 << (port // 8))
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x77, 1 << (port % 8))


def oom_deselect_transceiver(handle, port):
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x70, 0)


def get_module_identity(port):
    if port.port_type == 0:
        return
    print('\n{}'.format(mod_id(port.port_type)))
    print_keyval(port, 'VENDOR_NAME')
    print_keyval(port, 'VENDOR_PN')
    print_keyval(port, 'VENDOR_SN')
    print_keyval(port, 'MODULE_FW_REV_MAJOR')
    print_keyval(port, 'MODULE_FW_REV_MINOR')


def set_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val |= bitmap
    oom_set_keyvalue(port, reg, val)


def clr_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val &= ~bitmap & 0xff
    oom_set_keyvalue(port, reg, val)


def set_loopback(port, args):

    if len(args) != 3:
        print('Invalid arguments: {}'.format(args))
        sys.exit(1)

    ltype = get_hexarg(args[0], 1, len(loopback_types))
    lanes = get_hexarg(args[1], 0, 0xff)
    offon = get_strarg(args[2], opts_offon)

    get_module_identity(port)

    ltype -= 1
    if offon == 'on':
        print('\n{} : ON\n'.format(loopback_types[ltype]))
        set_reg_bits(port, loopback_enable_keys[ltype], lanes)
    else:
        print('\n{} : OFF\n'.format(loopback_types[ltype]))
        clr_reg_bits(port, loopback_enable_keys[ltype], lanes)
    print_keyval_hex(port, loopback_enable_keys[ltype])


def generator_init(port, pattern, lanes, action, init_keys, en_key):
    if action == 'on':
        print('Generator state  : ON\n')
        pattern = pattern * 16 + pattern
        set_keyval_list(port, init_keys, pattern)
        get_keyval_list(port, init_keys)
        set_reg_bits(port, en_key, lanes)
    else:
        print('Generator state  : OFF\n')
        clr_reg_bits(port, en_key, lanes)
    print_keyval_hex(port, en_key)


def get_capabilities(port, captype):
    get_module_identity(port)

    if captype > len(capability_types):
        print('Invalid capability type')
        sys.exit(1)

    if captype == 1:
        for i in range(0, len(capabilities_keys)):
            print('\n{}\n'.format(capability_types[i + 1]))
            get_keyval_list(port, capabilities_keys[i])
    else:
        print('\n{}\n'.format(capability_types[captype - 1]))
        get_keyval_list(port, capabilities_keys[captype - 2])


def set_generator(port, args):

    if len(args) != 4:
        print('Invalid arguments: {}'.format(args))
        sys.exit(1)

    gtype = get_hexarg(args[0], 1, len(generator_types))
    gpatt = get_hexarg(args[1], 0, 0xf)
    lanes = get_hexarg(args[2], 0, 0xff)
    offon = get_strarg(args[3], opts_offon)

    get_module_identity(port)

    patterns = {
        0x0 :  'PRBS31Q',
        0x1 :  'PRBS31' ,
        0x2 :  'PRBS23Q',
        0x3 :  'PRBS23' ,
        0x4 :  'PRBS15Q',
        0x5 :  'PRBS15' ,
        0x6 :  'PRBS13Q',
        0x7 :  'PRBS13' ,
        0x8 :  'PRBS9Q' ,
        0x9 :  'PRBS9'  ,
        0xA :  'PRBS7Q' ,
        0xB :  'PRBS7'  ,
        0xC :  'SSPRQ'  ,
        0xE :  'Custom' ,
        0xF :  'User'
    }

    print('')
    print('Generator type   : {}'.format(generator_types[gtype - 1]))
    print('Generator pattern: {}'.format(patterns[gpatt]))
    if gtype == 1:
        generator_init(port, gpatt, lanes, offon, host_gen_init_keys, 'HST_GEN_EN')
    elif gtype == 2:
        generator_init(port, gpatt, lanes, offon, media_gen_init_keys, 'MED_GEN_EN')
    else:
        print("Invalid generator type")
        sys.exit(1)


def calib(port, profile):

    get_module_identity(port)

    si_map_dic = load_csv_file(SI_MAP_FILE)
    (main, pre, post) = si_map_dic[profile]
    print("profile {}: main = {}, pre = {}, post = {}".format(profile, main, pre, post))

    print("\nSet staged set 0 explicit bits to 1 (page 0x10, regs 145-152, bit 0)")
    set_keyval_list(port, cl_ss0_explicit_keys, 0x11)
    get_keyval_list(port, cl_ss0_explicit_keys)

    print("Set Pre values (page 10, regs 162-165)")
    val = pre * 16 + pre
    set_keyval_list(port, cl_ss0_rx_pre_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_pre_cursor_keys)

    print("Set Post values (page 10, regs 166-169)")
    val = post * 16 + post
    set_keyval_list(port, cl_ss0_rx_post_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_post_cursor_keys)

    print("Set Main values (page 10, regs 170-173)")
    val = main * 16 + main
    set_keyval_list(port, cl_ss0_rx_main_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_main_cursor_keys)

    print("Apply new settings")
    oom_set_keyvalue(port, 'CL_APPLY_DP_INIT', 0xff)

    print("Verify new settings")
    get_keyval_list(port, si_line_cfg_err_keys)

    get_keyval_list(port, si_rx_explicit_keys)

    get_keyval_list(port, si_rx_pre_cursor_keys)
    get_keyval_list(port, si_rx_post_cursor_keys)
    get_keyval_list(port, si_rx_main_cursor_keys)

def set_keyvalue(port, pair):
    key = pair[0]
    verify_key(port, key)
    val = get_hexarg(pair[1], 0, 0xff)
    oom_set_keyvalue(port, key, val)
    print_keyval_hex(port, key)

def get_keyvalue(port, key):
    print_keyval_hex(port, key)

def main():
    ports = 32
    if args.port < 1 or args.port > ports:
        print("Invalid port number")
        sys.exit(1)

    first = args.port - 1
    if  args.range == None:
        last = first + 1
    else:
        last = first + args.range
        if last < args.port or last > ports:
            print("Invalid port range")
            sys.exit(1)
        print('\n===> Ports range: {}-{}'.format(args.port, last))

    portlist = oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        sys.exit(1)

    handle = portlist[0]

    for port in range (first, last):
        print("\n===> Port {}".format(port + 1))
        if args.aardvark:
            oom_select_transceiver(handle, port)
            handle = oom_get_portlist()[0]
        else:
            handle = portlist[port]
        modtype = type_to_str(handle.port_type)
        if modtype == 'UNKNOWN' or len(handle.mmap) == 0:
            continue

        add_QSFPDD_keys(handle)

        if  args.profile != None:
            calib(handle, args.profile)
        elif args.loopback != None:
            set_loopback(handle, args.loopback)
        elif args.generator != None:
            set_generator(handle, args.generator)
        elif args.capabilities != None:
            get_capabilities(handle, args.capabilities)
        elif args.w != None:
            set_keyvalue(handle, args.w)
        elif args.r != None:
            get_keyvalue(handle, args.r)
        else:
            get_module_identity(handle)
        if args.aardvark:
            oom_deselect_transceiver(handle, port)


if __name__ == "__main__":
    main()
