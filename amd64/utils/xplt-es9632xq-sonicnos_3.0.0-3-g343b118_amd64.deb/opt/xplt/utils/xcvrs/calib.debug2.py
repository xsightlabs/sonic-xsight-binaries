# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import os
import csv
import sys
import argparse
from oom.decode import mod_id
from cmis_local import *

from decimal import Decimal
import time
from datetime import datetime

loopback_types = [
    'Media Side Output Loopback (TP2 to TP3)',
    'Media Side Input Loopback  (TP3 to TP2)',
    'Host Side Output Loopback  (TP1 to TP4)',
    'Host Side Input Loopback   (TP4 to TP1)'
]

generator_types = [
    'Host Side Generator  (TP4)',
    'Media Side Generator (TP2)'
]

capability_types = [
    'All capabilities',
    'Loopbacks capabilities',
    'General Pattern capabilities',
    'Diagnostic Reporting capabilities',
    'Generators & Checkers capabilities',
]

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

pn_molex = [
    '1064281000'
]

pn_innolight = [
    'T-DP4CNH-N00', 'T-OP8CDT-H00'
]

#To keep backward compatibility, do not change the order in this list.
part_numbers = [
    '1064281000',
    'T-DP4CNH-N00', 'T-OP8CDT-H00'
]

opts_offon = ['off', 'on']

parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)

parser.add_argument('--version', action='version',
                    version='%(prog)s 2.0')

parser.add_argument('port',
                    type=int,
                    help='Front panel port number (starts from 1)')

parser.add_argument('-R',
                    '--range',
                    type=int,
                    help='Number of ports to handle starting from "port" argument')

parser.add_argument('--PN',
                    type=int,
                    nargs='+',
                    choices=range(1, (len(part_numbers) + 1)),
                    help='Use with -R option to select xcvrs PNs\n'+ \
                         'More than one PN separated by space can be specified:\n' + \
                         ''.join('[{}] - {}\n'.format(i + 1, part_numbers[i])
                                 for i in range(len(part_numbers))))

parser.add_argument('-v',
                    '--verbose',
                    action='store_true',
                    help='more verbose print')

parser.add_argument('-a',
                    '--aardvark',
                    action='store_true',
                    help='use Aardvark USB to I2C adapter')

parser.add_argument('-s',
                    '--servertype',
                    type=int,
                    choices=[i for i in range(1, (len(server_types) + 1))],
                    help=''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

parser.add_argument('-U',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

group = parser.add_mutually_exclusive_group()
group.add_argument('-p',
                   '--profile',
                   nargs='+',
                   metavar='arg',
                   type=int,
                   help='write calibration profile (arg 1) and optionally tx input ctle eq (arg 2)')

group.add_argument('-l',
                   '--loopback',
                   type=str,
                   nargs=3,
                   metavar='arg',
                   help=''.join('[{} lanes-bitmap {{on|off}}] - {}\n'.\
                                format(i + 1, loopback_types[i])
                                for i in range(len(loopback_types))))

group.add_argument('-g',
                   '--generator',
                   type=str,
                   nargs=4,
                   metavar='arg',
                   help=''.join('[{} pattern lanes {{on|off}}] - {}\n'.\
                                format(i + 1, generator_types[i])
                                for i in range(len(generator_types))))

group.add_argument('-c',
                   '--capabilities',
                   type=int,
                   choices=[i for i in range(1, (len(capability_types) + 1))],
                   help=''.join('[{}] - {}\n'.format(i + 1, capability_types[i])
                                for i in range(len(capability_types))))

group.add_argument('-w',
                   metavar='arg',
                   nargs=2,
                   type=str,
                   help='Write value by key, e.g. -w HST_GEN_EN 0xff')

group.add_argument('-r',
                   metavar='arg',
                   type=str,
                   help='Read value by key,  e.g. -r HST_GEN_EN')

group.add_argument('-d',
                   '--dump',
                   type=int,
                   help='dump port control/status (active set, ber, etc.) ')

group.add_argument('-b',
                   '--ber',
                   type=int,
                   help='set ber config')

group.add_argument('-u',
                   '--up',
                   type=int,
                   help='power up')

group.add_argument('-m',
                   '--mon',
                   type=int,
                   help='module monitor')

args = parser.parse_args()

if args.verbose:
    print(vars(args))

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url != None:
        oomlib.setshim("oomjsonshim", args.url)

# TODO: Pass the full file name as parameter
SI_MAP_FILE = 'calib_dust-photonics-dsp-si-map.csv'

ctle_lane_configuration = [
    'CTLE_REG_EN',
    'CTLE_L1L2',
    'CTLE_L3L4',
    'CTLE_L5L6',
    'CTLE_L7L8',
]

si_line_cfg_err_keys = [
    'SI_L1_2_CFGERR_CODE',
    'SI_L3_4_CFGERR_CODE',
    'SI_L5_6_CFGERR_CODE',
    'SI_L7_8_CFGERR_CODE',
]

si_rx_explicit_keys = [
    'SI_RX1_EXPLICIT',
    'SI_RX2_EXPLICIT',
    'SI_RX3_EXPLICIT',
    'SI_RX4_EXPLICIT',
    'SI_RX5_EXPLICIT',
    'SI_RX6_EXPLICIT',
    'SI_RX7_EXPLICIT',
    'SI_RX8_EXPLICIT'
]

si_rx_pre_cursor_keys = [
    'SI_RX1_2_PRE_CURSOR',
    'SI_RX3_4_PRE_CURSOR',
    'SI_RX5_6_PRE_CURSOR',
    'SI_RX7_8_PRE_CURSOR'
]

si_rx_post_cursor_keys = [
    'SI_RX1_2_POST_CURSOR',
    'SI_RX3_4_POST_CURSOR',
    'SI_RX5_6_POST_CURSOR',
    'SI_RX7_8_POST_CURSOR'
]

si_rx_main_cursor_keys = [
    'SI_RX1_2_O_AMPLITUDE',
    'SI_RX3_4_O_AMPLITUDE',
    'SI_RX5_6_O_AMPLITUDE',
    'SI_RX7_8_O_AMPLITUDE'
]

cl_ss0_explicit_keys = [
    'CL_SS0_L1_EXPLICIT',
    'CL_SS0_L2_EXPLICIT',
    'CL_SS0_L3_EXPLICIT',
    'CL_SS0_L4_EXPLICIT',
    'CL_SS0_L5_EXPLICIT',
    'CL_SS0_L6_EXPLICIT',
    'CL_SS0_L7_EXPLICIT',
    'CL_SS0_L8_EXPLICIT'
]

cl_ss0_rx_pre_cursor_keys = [
    'CL_SS0_RX1_2_PRE_CURSOR',
    'CL_SS0_RX3_4_PRE_CURSOR',
    'CL_SS0_RX5_6_PRE_CURSOR',
    'CL_SS0_RX7_8_PRE_CURSOR'
]

config_error_flag = [
    'CONFIG_ERROR_FLAG_L1L2',
    'CONFIG_ERROR_FLAG_L3L4',
    'CONFIG_ERROR_FLAG_L5L6',
    'CONFIG_ERROR_FLAG_L7L8'
]

cl_ss0_rx_post_cursor_keys = [
    'CL_SS0_RX1_2_POST_CURSOR',
    'CL_SS0_RX3_4_POST_CURSOR',
    'CL_SS0_RX5_6_POST_CURSOR',
    'CL_SS0_RX7_8_POST_CURSOR'
]

cl_ss0_rx_main_cursor_keys = [
    'CL_SS0_RX1_2_O_AMPLITUDE',
    'CL_SS0_RX3_4_O_AMPLITUDE',
    'CL_SS0_RX5_6_O_AMPLITUDE',
    'CL_SS0_RX7_8_O_AMPLITUDE'
]

loopback_capabilities_keys = [
    'LOOPBACK_CAP',
    'LB_HST_MED_LB_CAP',
    'LB_MED_PER_LANE_LB_CAP',
    'LB_HST_PER_LANE_LB_CAP',
    'LB_HST_INP_LB_CAP',
    'LB_HST_OUT_LB_CAP',
    'LB_MED_INP_LB_CAP',
    'LB_MED_OUT_LB_CAP'
]

general_pattern_capabilities_keys = [
    'GENERAL_PATTERN_CAP',
    'GP_GATING_SUPPORTED_CAP',
    'GP_LATCHED_ERR_INFO_CAP',
    'GP_RT_BER_POLLING_CAP',
    'GP_LANE_GATING_TMR_CAP',
    'GP_AUTO_RESTART_IMP_CAP'
]

diagnostic_reporting_capabilities_keys = [
    'DIAG_REPORT_CAP',
    'DR_MED_FEC_CAP',
    'DR_HST_FEC_CAP',
    'DR_MED_INP_SNR_CAP',
    'DR_HST_INP_SNR_CAP',
    'DR_MED_INP_PICK_DETECT_CAP',
    'DR_HST_INP_PICK_DETECT_CAP',
    'DR_BER_COUNT_CAP',
    'DR_BER_REGISTER_CAP'
]

generator_capabilities_keys = [
    'GEN_LOCATION_CAP',
    'GL_MED_PRE_FEC_GEN_CAP',
    'GL_MED_PST_FEC_GEN_CAP',
    'GL_MED_PRE_FEC_CHK_CAP',
    'GL_MED_PST_FEC_CHK_CAP',
    'GL_HST_PRE_FEC_GEN_CAP',
    'GL_HST_PST_FEC_GEN_CAP',
    'GL_HST_PRE_FEC_CHK_CAP',
    'GL_HST_PST_FEC_CHK_CAP',
    'HST_PRBS_PATTERN_CAP',
    'MED_PRBS_PATTERN_CAP',
    'HST_PAT_CHECKER_CAP',
    'MED_PAT_CHECKER_CAP',
    'PG1_SWAP_INVRT_CAP',
    'PG2_SWAP_INVRT_CAP',
    'PG3_SWAP_INVRT_CAP',
    'PG3_MED_CHK_LANE_EN_CAP',
    'PG3_MED_CHK_LANE_PT_CAP',
    'PG3_MED_GEN_LANE_EN_CAP',
    'PG3_MED_GEN_LANE_PT_CAP',
    'PG3_HST_CHK_LANE_EN_CAP',
    'PG3_HST_CHK_LANE_PT_CAP',
    'PG3_HST_GEN_LANE_EN_CAP',
    'PG3_HST_GEN_LANE_PT_CAP'
]

capabilities_keys = [
    loopback_capabilities_keys,
    general_pattern_capabilities_keys,
    diagnostic_reporting_capabilities_keys,
    generator_capabilities_keys
]

loopback_enable_keys = [
    'MED_OUT_LOOPBACK_EN',
    'MED_INP_LOOPBACK_EN',
    'HST_OUT_LOOPBACK_EN',
    'HST_INP_LOOPBACK_EN'
]

host_gen_init_keys = [
    'HST_GEN_L1_2',
    'HST_GEN_L3_4',
    'HST_GEN_L5_6',
    'HST_GEN_L7_8'
]

#TODO: Try to keep the module platform agnostic by moving it into Accton related file.
accton_dict = {
    'A_3': 1,
    'B_3': 2,
    'A_5': 3,
    'B_5': 4,
    'A_7': 5,
    'B_7': 6,
    'B_12': 7,
    'A_12': 8,
    'A_14': 9,
    'B_14': 10,
    'B_1': 11,
    'A_1': 12,
    'A_15': 13,
    'B_15': 14,
    'A_13': 15,
    'B_13': 16,
    'B_11': 17,
    'A_11': 18,
    'B_9': 19,
    'A_9': 20,
    'A_0': 21,
    'B_0': 22,
    'A_8': 23,
    'B_8': 24,
    'A_10': 25,
    'B_10': 26,
    'B_6': 27,
    'A_6': 28,
    'B_4': 29,
    'A_4': 30,
    'B_2': 31,
    'A_2': 32
}

media_gen_init_keys = [
    'MED_GEN_L1_2',
    'MED_GEN_L3_4',
    'MED_GEN_L5_6',
    'MED_GEN_L7_8'
]


def load_csv_file(csv_file):
    skip = True

    with open(csv_file, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=",")
        dic = {}
        for row in reader:
            if skip:
                skip = False
                continue
            dic[int(row[:1][0])] = list(map(int, row[1:]))
    return dic


if args.verbose:
    def print_io(io, addr, val):
        print("{}: reg={} val={}".format(io, hex(addr), hex(val)))
else:
    print_io = lambda *a: None  # do-nothing function


def print_keyval(port, key):
    reg = port.mmap[key]
    print('{:28} |{:4}|{:3}|  {}'.format(key, hex(reg[3]), reg[4], oom_get_keyvalue(port, key)))


def print_keyval_hex(port, key):
    reg = port.mmap[key]
    val = oom_get_keyvalue(port, key)
    print('{:28} |{:4}|{:3}|  {}'.format(key, hex(reg[3]), reg[4], hex(int(val))))


def set_keyval_list(port, lst, value):
    for key in range(0, len(lst)):
        oom_set_keyvalue(port, lst[key], value)


def get_keyval_list(port, lst):
    for key in range(0, len(lst)):
        print_keyval_hex(port, lst[key])


def oom_write_byte(port, addr, value):
    write = 1
    port.readcount = port.readcount + 1
    data = cast(create_string_buffer(1), POINTER(c_ubyte))
    data[0] = value
    oomsth.shim.aa_read_write(byref(port.c_port), write, addr << 1, 0, 1, data)
    print_io('wr', addr, data[0])


def verify_key(port, key):
    try:
        reg = port.mmap[key]
    except KeyError as e:
        print('Invalid key {}'.format(key))
        sys.exit(1)


def get_hexval(strval):
    try:
        val = int(strval, 16)
    except ValueError as e:
        print('Invalid hex value: {}'.format(strval))
        sys.exit(1)
    return val


def get_strarg(option, options):
    if option in options:
        return option
    else:
        print('Invalid option: {}. The valid options: {}'.format(option,
              ' '.join(map(str, options))))
        sys.exit(1)


def get_hexarg(strarg, minval, maxval):
    hexarg = get_hexval(strarg)
    if minval <= hexarg <= maxval:
        return hexarg
    else:
        print('Invalid arg: {}'.format(hex(hexarg)))
        sys.exit(1)


def oom_select_transceiver(handle, port):
    # shift rigth 1 bit because the aa_read_write shifts left 1 bit
    oom_write_byte(handle, 0x70, 0)
    oom_write_byte(handle, 0x70, 1 << (port // 8))
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x77, 1 << (port % 8))


def oom_deselect_transceiver(handle, port):
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x70, 0)


def get_module_identity(port):
    if port.port_type == 0:
        return
    print('\n{}'.format(mod_id(port.port_type)))
    print_keyval(port, 'VENDOR_NAME')
    print_keyval(port, 'VENDOR_PN')
    print_keyval(port, 'VENDOR_SN')
    print_keyval(port, 'MODULE_FW_REV_MAJOR')
    print_keyval(port, 'MODULE_FW_REV_MINOR')


def set_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val |= bitmap
    oom_set_keyvalue(port, reg, val)


def clr_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val &= ~bitmap & 0xff
    oom_set_keyvalue(port, reg, val)


def set_loopback(port, args):
    if len(args) != 3:
        print('Invalid arguments: {}'.format(args))
        sys.exit(1)

    ltype = get_hexarg(args[0], 1, len(loopback_types))
    lanes = get_hexarg(args[1], 0, 0xff)
    offon = get_strarg(args[2], opts_offon)

    get_module_identity(port)

    ltype -= 1
    if offon == 'on':
        print('\n{} : ON\n'.format(loopback_types[ltype]))
        set_reg_bits(port, loopback_enable_keys[ltype], lanes)
    else:
        print('\n{} : OFF\n'.format(loopback_types[ltype]))
        clr_reg_bits(port, loopback_enable_keys[ltype], lanes)
    print_keyval_hex(port, loopback_enable_keys[ltype])


def generator_init(port, pattern, lanes, action, init_keys, en_key):
    if action == 'on':
        print('Generator state  : ON\n')
        pattern = pattern * 16 + pattern
        set_keyval_list(port, init_keys, pattern)
        get_keyval_list(port, init_keys)
        set_reg_bits(port, en_key, lanes)
    else:
        print('Generator state  : OFF\n')
        clr_reg_bits(port, en_key, lanes)
    print_keyval_hex(port, en_key)


def get_capabilities(port, captype):
    get_module_identity(port)

    if captype > len(capability_types):
        print('Invalid capability type')
        sys.exit(1)

    if captype == 1:
        for i in range(0, len(capabilities_keys)):
            print('\n{}\n'.format(capability_types[i + 1]))
            get_keyval_list(port, capabilities_keys[i])
    else:
        print('\n{}\n'.format(capability_types[captype - 1]))
        get_keyval_list(port, capabilities_keys[captype - 2])


def set_generator(port, args):
    if len(args) != 4:
        print('Invalid arguments: {}'.format(args))
        sys.exit(1)

    gtype = get_hexarg(args[0], 1, len(generator_types))
    gpatt = get_hexarg(args[1], 0, 0xf)
    lanes = get_hexarg(args[2], 0, 0xff)
    offon = get_strarg(args[3], opts_offon)

    get_module_identity(port)

    patterns = {
        0x0: 'PRBS31Q',
        0x1: 'PRBS31',
        0x2: 'PRBS23Q',
        0x3: 'PRBS23',
        0x4: 'PRBS15Q',
        0x5: 'PRBS15',
        0x6: 'PRBS13Q',
        0x7: 'PRBS13',
        0x8: 'PRBS9Q',
        0x9: 'PRBS9',
        0xA: 'PRBS7Q',
        0xB: 'PRBS7',
        0xC: 'SSPRQ',
        0xE: 'Custom',
        0xF: 'User'
    }

    print('')
    print('Generator type   : {}'.format(generator_types[gtype - 1]))
    print('Generator pattern: {}'.format(patterns[gpatt]))
    if gtype == 1:
        generator_init(port, gpatt, lanes, offon, host_gen_init_keys, 'HST_GEN_EN')
    elif gtype == 2:
        generator_init(port, gpatt, lanes, offon, media_gen_init_keys, 'MED_GEN_EN')
    else:
        print("Invalid generator type")
        sys.exit(1)


def mon_collect(port):
    # tx
    print_keyval_hex(port, 'L_TX_FAULT')
    print_keyval_hex(port, 'L_TX_LOS')
    print_keyval_hex(port, 'L_TX_LOL')
    print_keyval_hex(port, 'L_TX_EQ_FAULT')
    # rx
    print_keyval_hex(port, 'L_RX_LOS')
    print_keyval_hex(port, 'L_RX_LOL')
    # module
    print_keyval_hex(port, 'MODULE_STATE')
    print_keyval_hex(port, 'TEMP_HI_ALRM')
    # diagnostics
    print_keyval_hex(port, 'L_LOL')
    print_keyval_hex(port, 'L_HST_CHKR_LOL')
    # cfg
    print_keyval_hex(port, 'HST_INP_LOOPBACK_EN')
    print_keyval_hex(port, 'HST_CHKR_EN')
    print_keyval_hex(port, 'HST_GEN_EN')
    print_keyval_hex(port, 'MED_INP_LOOPBACK_EN')
    print_keyval_hex(port, 'MED_CHKR_EN')
    print_keyval_hex(port, 'MED_GEN_EN')


def set_mon(port, args, pid):
    print("set module monitor :", args)
    mon_collect(port)


def set_power_up(port, args):
    print("set power up :", args)
    oom_set_keyvalue(port, 'MODULE_CTRL', 0x0)


def oom_get_keyvalue_wrap(port, key):
    value = oom_get_keyvalue(port, key)
    print("TRACE: get: key = {}, value = {:#x}".format(key, value))
    return value


def oom_set_keyvalue_wrap(port, key, value):
    print("TRACE: set: key = {}, value = {:#x}".format(key, value))
    oom_set_keyvalue(port, key, value)


def set_ber(port, args):
    print("set ber :", args)
    dp_50g = False
    if args > 0:
        for i in ['CHKR_']:
            for j in ['HST_', 'MED_']:
                for m in range(4):
                    ikey = "{}{}L{}_{}".format(j, i, 2 * m + 1, 2 * m + 2)
                    # PAM4 supports only *Q prbs patterns
                    # NRZ supports only w/o Q prbs patterns
                    #                    if dp_50g:
                    oom_set_keyvalue_wrap(port, ikey, 0x00)  # prbs31q

        oom_set_keyvalue_wrap(port, 'MED_PRBS_CHKR_CLK_SRC', 0x0)
        oom_set_keyvalue_wrap(port, 'MED_PRBS_GEN_CLK_SRC', 0x0)
        oom_set_keyvalue_wrap(port, 'RESET_ALL_LINES', 0x1)
        oom_set_keyvalue_wrap(port, 'RESET_ERROR_INFO', 0x0)
        oom_set_keyvalue_wrap(port, 'BER_COUNTER_UPDATE_TIME', 1)
        if args > 0x10:
            oom_set_keyvalue_wrap(port, 'AUTO_RESTART_GATE_TIME', 0)
            oom_set_keyvalue_wrap(port, 'GATE_TIME', 1)
        else:
            oom_set_keyvalue_wrap(port, 'GATE_TIME', 0)
        oom_set_keyvalue_wrap(port, 'HST_CHKR_EN', 0xff)
        oom_set_keyvalue_wrap(port, 'MED_CHKR_EN', 0xff)
    else:
        oom_set_keyvalue_wrap(port, 'RESET_ERROR_INFO', 0x1)
        oom_set_keyvalue_wrap(port, 'RESET_ALL_LINES', 0x1)
        oom_set_keyvalue_wrap(port, 'HST_CHKR_EN', 0x0)
        oom_set_keyvalue_wrap(port, 'MED_CHKR_EN', 0x0)


def fexp(number):
    (sign, digits, exponent) = Decimal(number).as_tuple()
    return len(digits) + exponent - 1


def fman(number):
    return Decimal(number).scaleb(-fexp(number)).normalize()


def get_ber_2B(port, pfx, lid):
    tmp_val = 0
    o_val = 0
    for i in range(2):
        tmp_key = "{}PEAK_L{}_B{}".format(pfx, lid, i)
        tmp_val = oom_get_keyvalue_wrap(port, tmp_key)
        o_val = o_val | (tmp_val << (1 - i) * 8)
    return o_val


def calc_ber(port, pfx, lid, pid, diag_sel):
    ikey = pfx + 'BER_L' + lid
    old_read = True
    if old_read:
        ival = oom_get_keyvalue(port, ikey)
    else:
        ival = get_ber_2B(port, pfx, lid)
    imant = ival & 0x7ff
    iexp = ival >> 11
    iexp = iexp - 24
    print("calc_ber: port = {}, ikey = {}, \nBER: {}".format(pid, ikey, imant * (10 ** iexp)))


def calc_ber2(port, pfx, lid, pid, lid_flat):
    ikey = pfx + 'TOT_CNTR_L' + lid
    err_cntr_64b = 0
    tot_cntr_64b = 0
    for j in range(1, 9):
        ikey1 = "{}_{}".format(ikey, j)
        ival = oom_get_keyvalue(port, ikey1)
        tot_cntr_64b += ival << (j - 1) * 8
    ikey = pfx + 'ERR_CNTR_L' + lid
    for j in range(1, 9):
        ikey1 = "{}_{}".format(ikey, j)
        ival = oom_get_keyvalue(port, ikey1)
        err_cntr_64b += ival << (j - 1) * 8
    itrust = 0 == (tot_cntr_64b & 0x1)
    if tot_cntr_64b == 0:
        itrust = False
        print("calc_ber2: port={}, lane={}, trust={}, ikey={}, err_cntr_64b={}, tot_cntr_64b={}, ZERO - BAD".format(
            pid, lid_flat, itrust, ikey1, hex(err_cntr_64b), hex(tot_cntr_64b)))
    else:
        imnt = fman(err_cntr_64b / float(tot_cntr_64b))
        iexp = fexp(err_cntr_64b / float(tot_cntr_64b))
        print("calc_ber2: port={}, lane={}, trust={}, ikey={}, err_cntr_64b={} tot_cntr_64b={}, \nBER: {:1.2f}e{}, {:1.20f}".format(
                pid, lid_flat, itrust,
                ikey1, hex(err_cntr_64b), hex(tot_cntr_64b)
                , imnt, iexp, err_cntr_64b / float(tot_cntr_64b)))


def display_ber(port, pid, diag_sel):
    if diag_sel == 1 or diag_sel == 0x11:
        for j in ['HST_']:
            for i in range(1, 9):
                calc_ber(port, j, lid="{}".format(i), pid=pid, diag_sel=diag_sel)
    elif diag_sel == 2 or diag_sel == 0x12:
        for k in range(1, 5):
            kstr = "{}".format(k);
            calc_ber2(port, 'HST_', lid=kstr, pid=pid, lid_flat=k)
    elif diag_sel == 3 or diag_sel == 0x13:
        for k in range(1, 5):
            kstr = "{}".format(k);
            calc_ber2(port, 'HST_', lid=kstr, pid=pid, lid_flat=4 + k)
    elif diag_sel == 4 or diag_sel == 0x14:
        for k in range(1, 5):
            kstr = "{}".format(k);
            calc_ber2(port, 'HST_', lid=kstr, pid=pid, lid_flat=k)
    elif diag_sel == 5 or diag_sel == 0x15:
        for k in range(1, 5):
            kstr = "{}".format(k);
            calc_ber2(port, 'HST_', lid=kstr, pid=pid, lid_flat=4 + k)
    else:
        print("ERROR: diag_sel unexpected value: {}".format(diag_sel))


def wait_tnack2(tdelay):
    print("wait_tnack2: tdelay = {}".format(tdelay))
    time.sleep(tdelay)


def wait_tnack():
    time.sleep(0.25)  # Allow volatile mem update


def read_compare(port, regname, val):
    wait_tnack()
    read_val = oom_get_keyvalue(port, regname)
    if read_val == val:
        print("read_compare: OK: regname={}, val={}").format(regname, val)
    else:
        print("read_compare: ERROR: regname={}, expected val={}, actual val={}").format(regname, val, read_val)


def dump(port):
    verbose_dump = True
    if verbose_dump:
        print("get active set settings: port ", args.port)
        get_keyval_list(port, si_rx_explicit_keys)
        get_keyval_list(port, si_rx_pre_cursor_keys)
        get_keyval_list(port, si_rx_post_cursor_keys)
        get_keyval_list(port, si_rx_main_cursor_keys)

        print("CHECKER ENABLE info:")
        print_keyval_hex(port, 'HST_CHKR_EN')
        print_keyval_hex(port, 'MED_CHKR_EN')
        print_keyval_hex(port, 'HST_PAT_CHECKER_CAP_P0_7')
        print_keyval_hex(port, 'HST_PRBS_PATTERN_CAP_P0_7')
        print("HST CHECKER PATTERN SEL info:")
        print_keyval_hex(port, 'HST_CHKR_L1_2')
        print_keyval_hex(port, 'HST_CHKR_L1_2')
        print_keyval_hex(port, 'HST_CHKR_L1_2')
        print_keyval_hex(port, 'HST_CHKR_L3_4')
        print_keyval_hex(port, 'HST_CHKR_L5_6')
        print_keyval_hex(port, 'HST_CHKR_L7_8')
        print("BER info:")
        print_keyval(port, 'RESET_ALL_LINES')  # check
        print_keyval(port, 'RESET_ERROR_INFO')
        print_keyval(port, 'AUTO_RESTART_GATE_TIME')
        print_keyval(port, 'GATE_TIME')
        print_keyval(port, 'BER_COUNTER_UPDATE_TIME')
        print_keyval_hex(port, 'DIAG_SEL')  # check
        print_keyval_hex(port, 'L_LOL')  # check
        print_keyval_hex(port, 'L_HST_CHKR_LOL')
        print_keyval_hex(port, 'L_MED_CHKR_LOL')
        print_keyval_hex(port, 'DPSTATE_L1_2')
        print_keyval_hex(port, 'DPSTATE_L3_4')
        print_keyval_hex(port, 'DPSTATE_L5_6')
        print_keyval_hex(port, 'DPSTATE_L7_8')
        print_keyval_hex(port, 'DPSTATE_CHNG')
        print_keyval_hex(port, 'L_TX_FAULT')  # check
        print_keyval_hex(port, 'L_TX_LOS')  # check
        print_keyval_hex(port, 'L_TX_LOL')  # check
        print_keyval_hex(port, 'L_TX_EQ_FAULT')  # check
        print_keyval_hex(port, 'L_TX_PWRH_ALRM')
        print_keyval_hex(port, 'L_TX_PWRL_ALRM')
        print_keyval_hex(port, 'L_TX_PWRH_WRN')
        print_keyval_hex(port, 'L_TX_PWRL_WRN')
        print_keyval_hex(port, 'L_TX_BIASH_ALRM')
        print_keyval_hex(port, 'L_TX_BIASL_ALRM')
        print_keyval_hex(port, 'L_TX_PWRH_WRN')
        print_keyval_hex(port, 'L_TX_PWRL_WRN')
        print_keyval_hex(port, 'L_TX_BIASH_ALRM')
        print_keyval_hex(port, 'L_TX_BIASL_ALRM')
        print_keyval_hex(port, 'L_TX_BIASH_WRN')
        print_keyval_hex(port, 'L_TX_BIASL_WRN')
        print_keyval_hex(port, 'L_RX_LOS')  # check
        print_keyval_hex(port, 'L_RX_LOL')  # check
        print_keyval_hex(port, 'L_RX_PWRH_ALRM')
        print_keyval_hex(port, 'L_RX_PWRL_ALRM')
        print_keyval_hex(port, 'L_RX_PWRH_WRN')
        print_keyval_hex(port, 'L_RX_PWRL_WRN')
        print_keyval_hex(port, 'L_HST_GATE_CMPLT')
        print_keyval_hex(port, 'L_MED_GATE_CMPLT')
        print_keyval_hex(port, 'HST_EID_A1')
        print_keyval_hex(port, 'HST_MID_A1')
        print_keyval_hex(port, 'LN_CNT_A1')
        print_keyval_hex(port, 'HST_EID_A2')
        print_keyval_hex(port, 'MODULE_STATE')  # check

        get_keyval_list(port, ctle_lane_configuration)
        get_keyval_list(port, si_line_cfg_err_keys)

        get_keyval_list(port, si_rx_explicit_keys)

        get_keyval_list(port, si_rx_pre_cursor_keys)
        get_keyval_list(port, si_rx_post_cursor_keys)
        get_keyval_list(port, si_rx_main_cursor_keys)

    diagnostics_support = False  # TODO: get this from page 1 , 142
    if args.dump == 2:
        diagnostics_support = True

    if diagnostics_support:
        mon_collect(port)
        if verbose_dump:
            idiag_sel = 0x1  # real time ber
            oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)  # latched BER
            read_compare(port, 'DIAG_SEL', idiag_sel)
            wait_tnack()
            print("----------- real time BER 1-8 ----------- ")
            display_ber(port, pid=args.port, diag_sel=idiag_sel)

        idiag_sel = 0x2  # real time host lanes 1-4
        oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)  # latched BER
        read_compare(port, 'DIAG_SEL', idiag_sel)
        wait_tnack()
        print("----------- real time HOST LANES 1-4  ----------- ")
        display_ber(port, pid=args.port, diag_sel=idiag_sel)

        idiag_sel = 0x3  # real time host lanes 5-8
        oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)  # latched BER
        read_compare(port, 'DIAG_SEL', idiag_sel)
        wait_tnack()
        print("----------- real time HOST LANES 5-8  ----------- ")
        display_ber(port, pid=args.port, diag_sel=idiag_sel)

        media_dump = True
        media_dump = False
        if media_dump:
            idiag_sel = 0x4  # media lanes 1-4
            oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)  # latched BER
            read_compare(port, 'DIAG_SEL', idiag_sel)
            wait_tnack()
            print("----------- real time MEDIA LANES 1-4  ----------- ")
            display_ber(port, pid=args.port, diag_sel=idiag_sel)
            idiag_sel = 0x5  # media lanes 1-4
            oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)  # latched BER
            read_compare(port, 'DIAG_SEL', idiag_sel)
            wait_tnack()
            print("----------- real time MEDIA LANES 5-8  ----------- ")
            display_ber(port, pid=args.port, diag_sel=idiag_sel)


def calib(port, part_number, cpf):
    profile = cpf[0]
    get_module_identity(port)
    si_map_dic = load_csv_file(SI_MAP_FILE)
    (main, pre, post) = si_map_dic[profile]
    print("profile {}: main = {}, pre = {}, post = {}".format(profile, main, pre, post))
    print("\nSet staged set 0 explicit bits to 1 (page 0x10, regs 145-152, bit 0)")
    ctle_50g = False
    dp_50g = True
    is_molex = part_number in '\t'.join(pn_molex)
    if len(cpf) > 1 and is_molex:
        ctle_50g = True
        ctle_profile = cpf[1]
        ctle_profile_hex_code = (ctle_profile << 4) + ctle_profile

    # deinit datapath
    oom_set_keyvalue(port, 'DP_INIT_CTRL', 0xff)
    get_keyval_list(port, ['DP_INIT_CTRL'])

    if dp_50g:
        oom_set_keyvalue(port, 'PAGE10_B153', 0x00)
        if is_molex:
            oom_set_keyvalue(port, 'CL_SS0_L1_EXPLICIT', 0x20)
            oom_set_keyvalue(port, 'CL_SS0_L2_EXPLICIT', 0x20)
            oom_set_keyvalue(port, 'CL_SS0_L3_EXPLICIT', 0x24)
            oom_set_keyvalue(port, 'CL_SS0_L4_EXPLICIT', 0x24)
            oom_set_keyvalue(port, 'CL_SS0_L5_EXPLICIT', 0x28)
            oom_set_keyvalue(port, 'CL_SS0_L6_EXPLICIT', 0x28)
            oom_set_keyvalue(port, 'CL_SS0_L7_EXPLICIT', 0x2C)
            oom_set_keyvalue(port, 'CL_SS0_L8_EXPLICIT', 0x2C)
        else:
            oom_set_keyvalue(port, 'CL_SS0_L1_EXPLICIT', 0x21)
            oom_set_keyvalue(port, 'CL_SS0_L2_EXPLICIT', 0x21)
            oom_set_keyvalue(port, 'CL_SS0_L3_EXPLICIT', 0x25)
            oom_set_keyvalue(port, 'CL_SS0_L4_EXPLICIT', 0x25)
            oom_set_keyvalue(port, 'CL_SS0_L5_EXPLICIT', 0x29)
            oom_set_keyvalue(port, 'CL_SS0_L6_EXPLICIT', 0x29)
            oom_set_keyvalue(port, 'CL_SS0_L7_EXPLICIT', 0x2D)
            oom_set_keyvalue(port, 'CL_SS0_L8_EXPLICIT', 0x2D)
    else:
        for i in range(len(cl_ss0_explicit_keys)):
            write_val = 0x11 + 2 * i
            oom_set_keyvalue(port, cl_ss0_explicit_keys[i], write_val)

    get_keyval_list(port, cl_ss0_explicit_keys)

    print("Set Pre values (page 10, regs 162-165)")
    val = pre * 16 + pre
    set_keyval_list(port, cl_ss0_rx_pre_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_pre_cursor_keys)

    print("Set Post values (page 10, regs 166-169)")
    val = post * 16 + post
    set_keyval_list(port, cl_ss0_rx_post_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_post_cursor_keys)

    print("Set Main values (page 10, regs 170-173)")
    val = main * 16 + main
    set_keyval_list(port, cl_ss0_rx_main_cursor_keys, val)
    get_keyval_list(port, cl_ss0_rx_main_cursor_keys)

    if not ctle_50g:
        print("Apply new settings")
        #oom_set_keyvalue(port, 'CL_APPLY_DP_INIT', 0xff)
        oom_set_keyvalue(port, 'CL_APPLY_IMMEDIATE', 0xff)
        # datapath init ater app sel code set
        oom_set_keyvalue(port, 'DP_INIT_CTRL', 0x0)
        get_keyval_list(port, ['CL_APPLY_DP_INIT', 'DP_INIT_CTRL', 'CL_APPLY_IMMEDIATE'])
        get_keyval_list(port, config_error_flag)

    print("Verify new settings")
    get_keyval_list(port, si_line_cfg_err_keys)

    get_keyval_list(port, si_rx_explicit_keys)

    get_keyval_list(port, si_rx_pre_cursor_keys)
    get_keyval_list(port, si_rx_post_cursor_keys)
    get_keyval_list(port, si_rx_main_cursor_keys)
    if ctle_50g:
        print('\nSet CTLE TX Input EQ to level: {} | {}'.format(ctle_profile, hex(ctle_profile_hex_code)))
        #oom_set_keyvalue(port, 'PAGE10_B143', 0x00)
        oom_set_keyvalue(port, 'PAGE10_B153', 0x00)
        oom_set_keyvalue(port, 'CTLE_L1L0', ctle_profile_hex_code)
        oom_set_keyvalue(port, 'CTLE_L3L2', ctle_profile_hex_code)
        oom_set_keyvalue(port, 'CTLE_L5L4', ctle_profile_hex_code)
        oom_set_keyvalue(port, 'CTLE_L7L6', ctle_profile_hex_code)
        oom_set_keyvalue(port, 'CL_APPLY_DP_INIT', 0xff)
        # datapath init ater app sel code set
        #oom_set_keyvalue(port, 'CL_APPLY_IMMEDIATE', 0xff)
        oom_set_keyvalue(port, 'DP_INIT_CTRL', 0x0)
        get_keyval_list(port, ctle_lane_configuration)
        print("Verifying new settings\n214 should return zero\n217-220 should return the custom level\n")


def set_keyvalue(port, pair):
    key = pair[0]
    verify_key(port, key)
    val = get_hexarg(pair[1], 0, 0xff)
    oom_set_keyvalue(port, key, val)
    print_keyval_hex(port, key)


def get_keyvalue(port, key):
    print_keyval_hex(port, key)


def main():
    fp_ports = 32  # TODO: make it dependent on FP ports cout
    if args.port < 1 or args.port > fp_ports:
        print("Invalid port number")
        sys.exit(1)

    first = args.port - 1
    if args.range == None:
        last = first + 1
    else:
        last = first + args.range
        if last < args.port or last > fp_ports:
            print("Invalid port range")
            sys.exit(1)
        print('\n===> Ports range: {}-{}'.format(args.port, last))

    portlist = oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        sys.exit(1)

    handle = portlist[0]

    for port in range(first, last):

        if args.aardvark:
            oom_select_transceiver(handle, port)
            handle = oom_get_portlist()[0]
        else:
            handle = portlist[port]
        modtype = type_to_str(handle.port_type)
        if modtype == 'UNKNOWN' or len(handle.mmap) == 0:
            continue

        pn = oom_get_keyvalue(handle, 'VENDOR_PN').split()
        if args.PN:
            pn_valid = False
            for pi in args.PN:
                PN = part_numbers[pi - 1].split()
                if pn == PN:
                    pn_valid = True

            if not pn_valid:
                continue

        print("\n===> Port {}".format(port + 1))

        add_QSFPDD_keys(handle)

        if args.profile != None:
            calib(handle, pn[0], args.profile)
        elif args.loopback != None:
            set_loopback(handle, args.loopback)
        elif args.generator != None:
            set_generator(handle, args.generator)
        elif args.capabilities != None:
            get_capabilities(handle, args.capabilities)
        elif args.w != None:
            set_keyvalue(handle, args.w)
        elif args.r != None:
            get_keyvalue(handle, args.r)
        elif args.dump != None:
            dump(handle)
        elif args.ber != None:
            set_ber(handle, args.ber)
        elif args.up != None:
            set_power_up(handle, args.up)
        elif args.mon != None:
            set_mon(handle, args.mon, args.port)
        else:
            get_module_identity(handle)
        if args.aardvark:
            oom_deselect_transceiver(handle, port)


if __name__ == "__main__":
    main()
