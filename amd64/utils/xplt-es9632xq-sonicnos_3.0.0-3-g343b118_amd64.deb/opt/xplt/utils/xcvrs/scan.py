# SPDX-License-Identifier: MIT
#
# Scan ports for optical modules presence via sysfs.
#
# Copyright (c) 2020 Xsightlabs Ltd.
#
# Based on oom/apps/inventory.py, Copyright (c) 2016 Finisar Inc.

import argparse
import sys

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

parser = argparse.ArgumentParser(description='Scan ports for optical modules presence',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type = int,
                    nargs = '?',
                    default= 1,
                    help = 'the front panel first port number to scan')

parser.add_argument('last',
                    type = int,
                    nargs = '?',
                    default= 32,
                    help = 'the front panel last port number to scan')

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

parser.add_argument('-s',
                    '--servertype',
                    type = int,
                    choices = [i for i in range(1, (len(server_types) + 1))],
                    help = ''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

args = parser.parse_args()

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url != None:
        oomlib.setshim("oomjsonshim", args.url)


def main():
    first = args.first
    last  = args.last
    ports = 32
    if first < 1 or first > ports or last < first or last > ports:
        print("Invalid port number")
        sys.exit(1)

    first -= 1

    portlist = oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        exit()

    fstr = '{0!s:10}{1!s:16}{2!s:13}{3!s:16}{4!s:16}'
    print("")
    print(fstr.format('Port Name', 'Vendor', 'Type', 'Part #', 'Serial #'))

    for i in range (first, last):
        port = portlist[i]
        modtype = type_to_str(port.port_type)
        if modtype == 'UNKNOWN':
            modtype = 'No Module'

        print(fstr.format(port.port_name,
                        oom_get_keyvalue(port, 'VENDOR_NAME'),
                        modtype,
                        oom_get_keyvalue(port, 'VENDOR_PN'),
                        oom_get_keyvalue(port, 'VENDOR_SN')))

if __name__ == "__main__":
    main()
