#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2022 Xsightlabs Ltd.

_IOC_NONE=1
_IOC_READ=2
_IOC_WRITE=4

_IOC_NRBITS=8
_IOC_TYPEBITS=8
_IOC_SIZEBITS=13
_IOC_DIRBITS=3

_IOC_NRSHIFT=0
_IOC_TYPESHIFT=$(( $_IOC_NRSHIFT   + $_IOC_NRBITS ))
_IOC_SIZESHIFT=$(( $_IOC_TYPESHIFT + $_IOC_TYPEBITS ))
_IOC_DIRSHIFT=$((  $_IOC_SIZESHIFT + $_IOC_SIZEBITS))

#define _IOC(dir,type,nr,size)
function _IOC()	{
    local a=$(($1<<${_IOC_DIRSHIFT}))
    local b=$(($2<<$_IOC_TYPESHIFT))
    local c=$(($3<<$_IOC_NRSHIFT))
    local d=$(($4<<$_IOC_SIZESHIFT))
    echo $(($a|$b|$c|$d))
}

#define _IO(type,nr)		_IOC(_IOC_NONE,(type),(nr),0)
function _IO()	{
    _IOC $_IOC_NONE $1 $2 $3
}

#define _IOR(type,nr,size)	_IOC(_IOC_READ,(type),(nr),sizeof(size))
function _IOR()	{
    _IOC $_IOC_READ $1 $2 $3
}

#define _IOW(type,nr,size)	_IOC(_IOC_WRITE,(type),(nr),sizeof(size))
function _IOW()	{
    _IOC $_IOC_WRITE $1 $2 $3
}

#define _IOWR(type,nr,size)	_IOC(_IOC_READ|_IOC_WRITE,(type),(nr),sizeof(size))
function _IOWR()	{
    _IOC $(($_IOC_READ|$_IOC_WRITE)) $1 $2 $3
}

