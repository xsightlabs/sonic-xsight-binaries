#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

if [ "$(id -u)" -ne 0 ] ; then
    echo "This script must be executed with root privileges"
    exit 1
fi

progname=$(basename $0)
verbose=0
nodered=0
polling=0
usercmd=''

function usage() {
    cat << help

Usage: $progname [-h] [-n] [-s RATE] [-v LEVEL] [-u CMD]
    -h, --help             Show this help message and exit
    -n, --nodered          Node-red formatted output
    -p, --polling RATE     Measure in loop at RATE seconds, ^C to exit
    -v, --verbose LEVEL    More verbose output, range 1..2
    -u, --usercmd CMD      user defined command string to use with -n
Examples:
    sudo /opt/xplt/utils/es9618x_x2_pw.sh
    sudo /opt/xplt/utils/es9618x_x2_pw.sh -v1
    sudo /opt/xplt/utils/es9618x_x2_pw.sh -n -p1
    sudo /opt/xplt/utils/es9618x_x2_pw.sh -n -p2 -u "nc -q 1 localhost 2233"

help
}

OPTS=$(getopt -o "hnp:v:u:" --long "help,nodered,polling:,verbose:,usercmd:" \
     -n "$progname" -- "$@")

eval set -- "$OPTS"

while true; do
    case "$1" in
        -h | --help ) usage; exit 0 ;;
        -n | --nodered ) nodered=1; shift ;;
        -p | --polling ) polling="$2"; shift 2 ;;
        -v | --verbose ) verbose="$2"; shift 2 ;;
        -u | --usercmd ) usercmd="$2"; shift 2 ;;
        -- ) shift; break ;;
        * ) break ;;
    esac
done

# Define rails as an associative array of "I2CBUS,I2C_ADDR,DEV_ADDR,DEV_IDX"
declare -A rails=(
    [VDD_CORE]="35 0x60 0060 0x00"
    [VDD_SD]="36 0x61 0061 0x00"
    [VDD_L1]="37 0x64 0064 0x00"
    [VDD_L2]="37 0x64 0064 0x01"
    [VDD_L3]="38 0x65 0065 0x00"
    [VDD_L4]="38 0x65 0065 0x01"
    [VDD_H1]="39 0x40 0040 0x00"
    [VDD_H2]="39 0x40 0040 0x01"
    [VDD_H3]="40 0x41 0041 0x00"
    [VDD_H4]="40 0x41 0041 0x01"
)

keys=(
    VDD_CORE
    VDD_SD
    VDD_L1
    VDD_L2
    VDD_L3
    VDD_L4
    VDD_H1
    VDD_H2
    VDD_H3
    VDD_H4
)

declare -A voltages
declare -A currents
declare -A powers

hw_rev=$(/opt/xplt/utils/hw_rev.sh)

driver=$(lsmod | grep _cpld | cut -d" " -f1)
if [[ "$driver" == *"cpld"* ]]; then
    [ $verbose -eq 2 ] && echo Mode: sysfs
    MODE=1
    SYSFS=/sys/bus/i2c/devices
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        dev_path="$SYSFS/${I2CBUS}-${DEV_ADDR}"
        bus_path="$SYSFS/i2c-${I2CBUS}/new_device"
        [ ! -d "$dev_path" ] && echo i2ctools "$I2C_ADDR" > "$bus_path"
    done
else
    [ $verbose -eq 2 ] && echo Mode: i2c-0
    MODE=2
fi

# Trap SIGINT (Ctrl+C) and cleanup sysfs I2C nodes
function cleanup_sysfs_nodes() {
    if (( $MODE == 1 )); then
        for key in "${keys[@]}"; do
            read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
            [ -d $SYSFS/${I2CBUS}-${DEV_ADDR} ] && echo $I2C_ADDR > $SYSFS/i2c-${I2CBUS}/delete_device || true
        done
    fi
    exit 0
}

trap cleanup_sysfs_nodes SIGINT

function collect_readings() {
    VX=$(i2cget -f -y $I2CBUS $I2C_ADDR 0x8b w)
    AX=$(i2cget -f -y $I2CBUS $I2C_ADDR 0x8c w)

    if [ "$hw_rev" == "R0A" ] || [ "$hw_rev" == "R0B" ]; then
        VD=$(echo $(($VX)))
        AD=$(awk "BEGIN {printf \"%.1f\",$(echo $(($AX))) / 10}")
    elif [ "$hw_rev" == "R0C" ]; then
        VD_E=$(($(i2cget -f -y $I2CBUS $I2C_ADDR 0x20 b) & 0x1F))
        [ "$VD_E" -gt 16 ] && ((VD_E=VD_E-32))
        VD=$(echo "$((VX)) * 1000 * (2 ^ $VD_E)" | bc -l | xargs printf "%.0f")
        AD_M=$((AX & 0x7FF))
        AD_E=$(((AX >> 11) & 0x1F))
        [ "$AD_E" -gt 16 ] && ((AD_E=AD_E-32))
        AD=$(echo "scale=4; $AD_M * (2 ^ $AD_E)" | bc -l | xargs printf "%.1f")
    else
        echo "Unknown HW revision: $hw_rev"
    fi

    PW=$(awk "BEGIN {printf \"%.2f\",$VD * $AD / 1000}")
    voltages[$key]=$VD
    currents[$key]=$AD
    powers[$key]=$PW
    TP=$(awk "BEGIN {printf \"%.2f\",$TP + $PW}")
}

function display_readings() {
    if [ $nodered -eq 1 ]; then
        if [ $(echo -n "$usercmd" | wc -m) -gt 0 ]; then
            echo $TP | eval $usercmd
        else
            printf '%s\n' $TP
        fi
        return
    else
        separator=$(printf '%.0s-' {1..86})
        format='%8s'
        [ $polling -eq 0 ] && printf '\n'
        printf '%s power(W) %11s' X2 $TP
    fi
    if [ $verbose -gt 0 ]; then
        printf '\n'$separator
        printf '\n      '
        for key in "${keys[@]}"; do
            printf $format ${key}
        done
        printf '\nP(W): '
        for key in "${keys[@]}"; do
            printf $format ${powers[$key]}
        done
    fi
    if [ $verbose -gt 1 ]; then
        printf '\nI(A): '
        for key in "${keys[@]}"; do
            printf $format ${currents[$key]}
        done
        printf '\nV(mV):'
        for key in "${keys[@]}"; do
            printf $format ${voltages[$key]}
        done
    fi
    printf '\n\n'
}

function read_power() {
    voltages=()
    currents=()
    powers=()
    TP=0

    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        if (( $MODE == 1 )); then
            :
        else
            I2CBUS=1
            case $key in
                VDD_CORE) i2cset -f -y $I2CBUS 0x76 0 0x2 ;;
                VDD_SD)   i2cset -f -y $I2CBUS 0x76 0 0x4 ;;
                VDD_L1|VDD_L2) i2cset -f -y $I2CBUS 0x76 0 0x8 ;;
                VDD_L3|VDD_L4) i2cset -f -y $I2CBUS 0x76 0 0x10 ;;
                VDD_H1|VDD_H2) i2cset -f -y $I2CBUS 0x76 0 0x20 ;;
                VDD_H3|VDD_H4) i2cset -f -y $I2CBUS 0x76 0 0x40 ;;
            esac
        fi
        i2cset -f -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX
        collect_readings
    done

    display_readings
}

if [ $polling -eq 0 ]; then
    read_power
else
    while :; do read_power; sleep $polling; done
fi

cleanup_sysfs_nodes