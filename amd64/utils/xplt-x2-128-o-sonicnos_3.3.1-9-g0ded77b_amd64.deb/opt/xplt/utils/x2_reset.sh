#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2024 Xsightlabs Ltd.


REPLACE_HOST=evb
grep $REPLACE_HOST /etc/hostname
if [ $? -ne 0 ]; then
    echo "ERROR: Incorrect hostname."
    exit 1
fi

IMX_BMC_HOST=$(sed "s/${REPLACE_HOST}/bmc/" /etc/hostname)

# Raise the X2 reset line
echo "{\"method\":\"x2_reset\", \"params\":[1]}" | nc $IMX_BMC_HOST 9087 -w 1
if [ $? -ne 0 ]; then
    echo "ERROR: Cannot connect to BMC JSON RPC server: $IMX_BMC_HOST ."
    exit 2
fi

# Pull down the X2 reset line
echo "{\"method\":\"x2_reset\", \"params\":[0]}" | nc $IMX_BMC_HOST 9087 -w 1
if [ $? -ne 0 ]; then
    echo "ERROR: Cannot connect to BMC JSON RPC server: $IMX_BMC_HOST ."
    exit 2
fi
