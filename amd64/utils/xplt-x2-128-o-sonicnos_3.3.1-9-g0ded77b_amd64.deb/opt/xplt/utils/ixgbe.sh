#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

(return 0 2>/dev/null) && sourced=1 || sourced=0

if [ $sourced == 1 ]; then
        er_exit="return"
        ok_exit="return"
else
        er_exit="exit 1"
        ok_exit="exit 0"
fi

DRV_VER="5.20.9_xs"
GCC_VER=/usr/bin/gcc-9
TAR_FILE=ixgbe-${DRV_VER}.tar.gz
TAR=http://x-nexus:8081/repository/xplt-x2evb/tar/$TAR_FILE

host_name=$(hostname)
echo "host: $host_name"
drv_ver=$(modinfo ixgbe | grep "version:      " | cut -d " " -f9)
echo "drv ver: $drv_ver"
if [ "${drv_ver}" == "${DRV_VER}" ]; then
    echo "ixgbe driver is of the latest ${DRV_VER} version"
else
    echo "Updating ixgbe-${drv_ver} driver to ${DRV_VER} version"
    curl -s $TAR -o ./$TAR_FILE
    if [ ! -f "$TAR_FILE" ]; then
        echo "Cannot find $TAR_FILE"
        eval "$er_exit"
    fi
    [ -d ixgbe ] && rm -rf ixgbe
    tar -xzvf $TAR_FILE >/dev/null 2>&1
    cd ixgbe/src
    make CC=$GCC_VER || eval "$er_exit"
    make CC=$GCC_VER install || eval "$er_exit"
    cd ../..
    rm -rf ixgbe $TAR_FILE
    echo "Please reboot the system"
fi
