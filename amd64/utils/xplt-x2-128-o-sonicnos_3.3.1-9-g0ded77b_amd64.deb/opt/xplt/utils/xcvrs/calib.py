#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import csv
from sys import exit
import argparse
from oom.decode import mod_id
from cmis_local import *
from vendor_info import pn_molex, pn_innolight, part_numbers, app_dict

from decimal import Decimal
import time

loopback_types = [
    'Media Side Output Loopback (TP2 to TP3)',
    'Media Side Input Loopback  (TP3 to TP2)',
    'Host Side Output Loopback  (TP1 to TP4)',
    'Host Side Input Loopback   (TP4 to TP1)'
]

generator_types = [
    'Host Side Generator  (TP4)',
    'Media Side Generator (TP2)'
]

checker_types = [
    'Host Side Checker (TP1)',
    'Media Side Checker (TP3)'
]

error_cnt_types = [
    'Host Side (TP1) BER Counters',
    'Media Side (TP3) BER Counters'
]

capability_types = [
    'All capabilities',
    'Loopbacks capabilities',
    'General Pattern capabilities',
    'Diagnostic Reporting capabilities',
    'Generators & Checkers capabilities',
    'Equalizer capabilities',
    'Supported applications list'
]

server_types = [
    'OOM lightweight server',
    'OOM JSON server'
]

pre_code = {
        0: 'No Equalization',
        1: '0.5 dB',
        2: '1.0 dB',
        3: '1.5 dB',
        4: '2.0 dB',
        5: '2.5 dB',
        6: '3.0 dB',
        7: '3.5 dB',
    }

# Table 4-7 (SFF-8024)
smf_media_id = {
    0xf:  '100G PSM4 MSA Spec',
    0x14: '100GBASE-DR',
    0x17: '200GBASE-DR4 (Clause 121)',
    0x1c: '400GBASE-DR4',
}

mmf_media_id = {
    0: 'Undefined',
    0x7: '50GBASE-SR (Clause 138)',
    0xe: '200GBASE-SR4 (Clause 138)',
    0xf: '400GBASE-SR16 (Clause 123)',
    0x10: '400GBASE-SR8 (Clause 138)',
    0x11: '400GBASE-SR4 (Clause 167)',
    0x12: '800G-SR8',
    0x1b: '200GBASE-SR2 (Clause 167)',
    0xd: '100GBASE-SR (Clause 167)',
}

act_cop_media_id = {
    0x0: 'Undefined',
    0x1: 'Active Cable assembly with BER < 10^-12',
    0x2: 'Active Cable assembly with BER < 5x10^-5',
    0x3: 'Active Cable assembly with BER < 2.6x10^-4',
    0x4: 'Active Cable assembly with BER < 10-6',
}

pas_cop_media_id = {
    0x0: 'Undefined',
    0x1: 'Copper Cable',
    0xbf: 'Passive Loopback module',
}

# Table 4-5 (SFF-8024)
host_eid_code = {
    0xf: '200GAUI-4 C2M (Annex 120E)',
    0x11: '400GAUI-8 C2M',
    0xd: '100GAUI-2 C2M',
    0xe: '200GAUI-8 C2M (Annex 120C)',
    0x42: 'CAUI-4 C2M (Annex 83E)',
    0x4b: '100GAUI-1-S C2M',
    0x4c: '100GAUI-1-S C2M',
    0x4d: '200GAUI-2-S C2M (Annex 120G)',
    0x4e: '200GAUI-2-L C2M (Annex 120G)',
    0x4f: '400GAUI-4-S C2M',
    0x31: 'IB HDR',
    0x32: 'IB NDR',
    0x50: '400GAUI-4-L C2M (Annex 120G)',
    0x51: '800G S C2M',
    0x52: '800G L C2M',
}

patterns = {
    '31q': 0x0,
    '31': 0x1,
    '23q': 0x2,
    '23': 0x3,
    '15q': 0x4,
    '15': 0x5,
    '13q': 0x6,
    '13': 0x7,
    '9q': 0x8,
    '9': 0x9,
    '7q': 0xA,
    '7': 0xB,
    'ssprq': 0xC,
    'custom': 0xE,
    'user': 0xF
}

opts_offon = ['off', 'on']

parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)

parser.add_argument('--version', action='version',
                    version='%(prog)s 2.0')

parser.add_argument('port',
                    type=int,
                    help='Front panel port number (starts from 1)')

parser.add_argument('-R',
                    '--range',
                    type=int,
                    help='Number of ports to handle starting from "port" argument')

parser.add_argument('--PN',
                    type=int,
                    nargs='+',
                    choices=range(1, (len(part_numbers) + 1)),
                    help='Use with -R option to select xcvrs PNs\n'+ \
                         'More than one PN separated by space can be specified:\n' + \
                         ''.join('[{}] - {}\n'.format(i + 1, part_numbers[i])
                                 for i in range(len(part_numbers))))

parser.add_argument('-v',
                    '--verbose',
                    action='store_true',
                    help='More verbose print')

parser.add_argument('-a',
                    '--aardvark',
                    action='store_true',
                    help='Use Aardvark USB to I2C adapter')

parser.add_argument('-s',
                    '--servertype',
                    type=int,
                    choices=[i for i in range(1, (len(server_types) + 1))],
                    help=''.join('[{}] - {}\n'.format(i + 1, server_types[i])
                                   for i in range(len(server_types))))

parser.add_argument('-U',
                    '--url',
                    type=str,
                    help ='Hostname or IP address of the oomjsonsvr server')

group = parser.add_mutually_exclusive_group()
group.add_argument('-p',
                   '--profile',
                   nargs='+',
                   metavar='arg',
                   type=int,
                   help='Write calibration profile (arg 1) and optionally tx input ctle eq (arg 2)')

group.add_argument('--rx_out_eq',
                   type=int,
                   help='Write Rx output eq profile')

group.add_argument('-l',
                   '--loopback',
                   type=str,
                   nargs=3,
                   metavar='arg',
                   help=''.join('[{} lanes-bitmap {{on|off}}] - {}\n'.\
                                format(i + 1, loopback_types[i])
                                for i in range(len(loopback_types))))

group.add_argument('-g',
                   '--generator',
                   type=str,
                   nargs=4,
                   metavar='arg',
                   help=''.join('[{} pattern lanes {{on|off}}] - {}\n'.
                                format(i + 1, generator_types[i])
                                for i in range(len(generator_types))) +
                        '* pattern - 31q/31/23q/23/15q/15/13q/13/9q/9/7q/7\n' +
                        '** lanes - two bytes hexadecimal bit mask'
                   )

group.add_argument('-b',
                   '--ber_checker',
                   type=str,
                   nargs=3,
                   metavar='arg',
                   help=''.join('[{} pattern on|off] - {}\n'.format(i + 1, checker_types[i])
                                for i in range(len(checker_types))) +
                        '* pattern - 31q/31/23q/23/15q/15/13q/13/9q/9/7q/7\n'
                   )
group.add_argument('-c',
                   '--capabilities',
                   type=int,
                   choices=[i for i in range(1, (len(capability_types) + 1))],
                   help=''.join('[{}] - {}\n'.format(i + 1, capability_types[i])
                                for i in range(len(capability_types))))

group.add_argument('--show_ber',
                   metavar='arg',
                   type=int,
                   help=''.join('{} - {}\n'.format(i + 1, error_cnt_types[i])
                                for i in range(len(error_cnt_types))))

group.add_argument('--show_apps',
                   action='store_true',
                   help='Show module\'s supported applications')

group.add_argument('--set_app',
                   metavar='arg',
                   type=int,
                   help='Set module\'s application ID')

group.add_argument('-w',
                   metavar='arg',
                   nargs=2,
                   type=str,
                   help='Write value by key, e.g. -w HST_GEN_EN 0xff')

group.add_argument('-r',
                   metavar='arg',
                   type=str,
                   help='Read value by key,  e.g. -r HST_GEN_EN')

group.add_argument('-d',
                   '--dump',
                   action='store_true',
                   help='Dump port control/status (active set, ber, etc.) ')

group.add_argument('-u',
                   '--up',
                   action='store_true',
                   help='Power up module')

group.add_argument('-m',
                   '--mon',
                   action='store_true',
                   help='Dump set of registers to monitor')

group.add_argument('--reset',
                   action='store_true',
                   help='Reset module')

group.add_argument('--ber_clr',
                   action='store_true',
                   help='Clear BER Counters')

group.add_argument('--opt_pwr',
                   action='store_true',
                   help='Show Tx and Rx Power per each lane')

args = parser.parse_args()

if args.verbose:
    print(vars(args))

if args.servertype == 1:
    from oomlwclient import *
    oomlwclient_init(args.url)
else:
    from oom import *
    from oom.oomlib import type_to_str
    if args.url is not None:
        oomlib.setshim("oomjsonshim", args.url)

# requires the csv file to be in the same path as this script
SI_MAP_FILE = 'calib_dust-photonics-dsp-si-map.csv'

tx_act_eq_control = [
    'ACT_TX_ADAPT_EQ_EN',
    'ACT_TX_EQ_CTRL_LN1_2',
    'ACT_TX_EQ_CTRL_LN3_4',
    'ACT_TX_EQ_CTRL_LN5_6',
    'ACT_TX_EQ_CTRL_LN7_8',
]

cfg_err_code_keys = [
    'CFGERR_CODE_LN1_2',
    'CFGERR_CODE_LN3_4',
    'CFGERR_CODE_LN5_6',
    'CFGERR_CODE_LN7_8',
]

appsel_ctrl_keys_act = [
    'ACT_APPSEL_CTRL_LN1',
    'ACT_APPSEL_CTRL_LN2',
    'ACT_APPSEL_CTRL_LN3',
    'ACT_APPSEL_CTRL_LN4',
    'ACT_APPSEL_CTRL_LN5',
    'ACT_APPSEL_CTRL_LN6',
    'ACT_APPSEL_CTRL_LN7',
    'ACT_APPSEL_CTRL_LN8'
]

rx_out_pre_act_keys = [
    'ACT_RX_OUT_PRE_LN1_2',
    'ACT_RX_OUT_PRE_LN3_4',
    'ACT_RX_OUT_PRE_LN5_6',
    'ACT_RX_OUT_PRE_LN7_8'
]

rx_out_post_act_keys = [
    'ACT_RX_OUT_POST_LN1_2',
    'ACT_RX_OUT_POST_LN3_4',
    'ACT_RX_OUT_POST_LN5_6',
    'ACT_RX_OUT_POST_LN7_8'
]

rx_out_amp_act_keys = [
    'ACT_RX_OUT_AMP_LN1_2',
    'ACT_RX_OUT_AMP_LN3_4',
    'ACT_RX_OUT_AMP_LN5_6',
    'ACT_RX_OUT_AMP_LN7_8'
]

rx_out_pre_ss0_keys = [
    'SS0_RX_OUT_PRE_LN1_2',
    'SS0_RX_OUT_PRE_LN3_4',
    'SS0_RX_OUT_PRE_LN5_6',
    'SS0_RX_OUT_PRE_LN7_8'
]

rx_out_post_ss0_keys = [
    'SS0_RX_OUT_POST_LN1_2',
    'SS0_RX_OUT_POST_LN3_4',
    'SS0_RX_OUT_POST_LN5_6',
    'SS0_RX_OUT_POST_LN7_8'
]

rx_out_amp_ss0_keys = [
    'SS0_RX_OUT_AMP_LN1_2',
    'SS0_RX_OUT_AMP_LN3_4',
    'SS0_RX_OUT_AMP_LN5_6',
    'SS0_RX_OUT_AMP_LN7_8'
]

ss0_appsel_ctrl_keys = [
    'SS0_APPSEL_CTRL_LN1',
    'SS0_APPSEL_CTRL_LN2',
    'SS0_APPSEL_CTRL_LN3',
    'SS0_APPSEL_CTRL_LN4',
    'SS0_APPSEL_CTRL_LN5',
    'SS0_APPSEL_CTRL_LN6',
    'SS0_APPSEL_CTRL_LN7',
    'SS0_APPSEL_CTRL_LN8'
]

ss0_appsel_ctrl_exp_keys = [
    'SS0_APPSEL_CTRL_EXP_LN1',
    'SS0_APPSEL_CTRL_EXP_LN2',
    'SS0_APPSEL_CTRL_EXP_LN3',
    'SS0_APPSEL_CTRL_EXP_LN4',
    'SS0_APPSEL_CTRL_EXP_LN5',
    'SS0_APPSEL_CTRL_EXP_LN6',
    'SS0_APPSEL_CTRL_EXP_LN7',
    'SS0_APPSEL_CTRL_EXP_LN8'
]

loopback_capabilities_keys = [
    'LOOPBACK_CAP',
    'SIMUL_HST_MED_LB_CAP',
    'MED_PER_LANE_LB_CAP',
    'HST_PER_LANE_LB_CAP',
    'HST_INP_LB_CAP',
    'HST_OUT_LB_CAP',
    'MED_INP_LB_CAP',
    'MED_OUT_LB_CAP'
]

general_pattern_capabilities_keys = [
    'GENERAL_PATTERN_CAP',
    'GP_GATING_SUPPORTED_CAP',
    'GP_LATCHED_ERR_INFO_CAP',
    'GP_RT_BER_POLLING_CAP',
    'GP_LANE_GATING_TMR_CAP',
    'GP_AUTO_RESTART_IMP_CAP'
]

diagnostic_reporting_capabilities_keys = [
    'DIAG_REPORT_CAP',
    'DR_MED_FEC_CAP',
    'DR_HST_FEC_CAP',
    'DR_MED_INP_SNR_CAP',
    'DR_HST_INP_SNR_CAP',
    'DR_MED_INP_PICK_DETECT_CAP',
    'DR_HST_INP_PICK_DETECT_CAP',
    'DR_BER_COUNT_CAP',
    'DR_BER_REGISTER_CAP'
]

generator_capabilities_keys = [
    'GL_MED_PRE_FEC_GEN_CAP',
    'GL_MED_PST_FEC_GEN_CAP',
    'GL_MED_PRE_FEC_CHK_CAP',
    'GL_MED_PST_FEC_CHK_CAP',
    'GL_HST_PRE_FEC_GEN_CAP',
    'GL_HST_PST_FEC_GEN_CAP',
    'GL_HST_PRE_FEC_CHK_CAP',
    'GL_HST_PST_FEC_CHK_CAP',
    'HST_PRBS_PATTERN_CAP',
    'MED_PRBS_PATTERN_CAP',
    'HST_PAT_CHECKER_CAP',
    'MED_PAT_CHECKER_CAP',
    'PAT_GEN_RECOVER_CLK_CAP',
    'PAT_REF_CLK_CAP',
    'USER_PAT_SUPPORT_LEN_CAP',
    'MED_CHK_DATA_INV_CAP',
    'MED_GEN_DATA_SWAP_CAP',
    'MED_GEN_DATA_INV_CAP',
    'MED_CHK_DATA_SWAP_CAP',
    'HST_CHK_DATA_SWAP_CAP',
    'HST_CHK_DATA_INV_CAP',
    'HST_GEN_DATA_SWAP_CAP',
    'HST_GEN_DATA_INV_CAP',
    'MED_CHK_PER_LANE_EN_CAP',
    'MED_CHK_PAT_PER_LANE_CAP',
    'MED_GEN_PER_LANE_EN_CAP',
    'MED_GEN_PAT_PER_LANE_CAP',
    'HST_CHK_PER_LANE_EN_CAP',
    'HST_CHK_PAT_PER_LANE_CAP',
    'HST_GEN_PER_LANE_EN_CAP',
    'HST_GEN_PAT_PER_LANE_CAP',
]

eq_capabilities = [
    'RX_OUT_EQ_TYPE',
    'RX_OUT_AMP_CODE_IMP',
    'TX_MAX_INPUT_EQ',
    'RX_MAX_OUTPUT_POST',
    'RX_MAX_OUTPUT_PRE',
    'TX_IN_EQ_STORE_REC_BUF',
    'TX_IN_FREEZE',
    'ADAPT_TX_IN_EQ_IMP',
    'TX_ADAPT_FAIL_FLAG_IMP',
    'TX_IN_FIX_MAN_CTRL_IMP',
    'RX_OUT_EQ_CTRL',
    'RX_OUT_AMP_CTRL'
]

capabilities_keys = [
    loopback_capabilities_keys,
    general_pattern_capabilities_keys,
    diagnostic_reporting_capabilities_keys,
    generator_capabilities_keys,
    eq_capabilities
]

loopback_enable_keys = [
    'MED_OUT_LOOPBACK_EN',
    'MED_INP_LOOPBACK_EN',
    'HST_OUT_LOOPBACK_EN',
    'HST_INP_LOOPBACK_EN'
]

host_gen_init_keys = [
    'HST_GEN_LN1_2',
    'HST_GEN_LN3_4',
    'HST_GEN_LN5_6',
    'HST_GEN_LN7_8'
]

media_gen_init_keys = [
    'MED_GEN_LN1_2',
    'MED_GEN_LN3_4',
    'MED_GEN_LN5_6',
    'MED_GEN_LN7_8'
]

dp_state_keys = [
    'DPSTATE_LN1_2',
    'DPSTATE_LN3_4',
    'DPSTATE_LN5_6',
    'DPSTATE_LN7_8',
    'DPSTATE_CHNG'
]

media_checker_keys = [
    'L_MED_CHKR_LOL',
    'MED_CHKR_LN1_2',
    'MED_CHKR_LN3_4',
    'MED_CHKR_LN5_6',
    'MED_CHKR_LN7_8'
]

host_checker_keys = [
    'L_HST_CHKR_LOL',
    'HST_CHKR_LN1_2',
    'HST_CHKR_LN3_4',
    'HST_CHKR_LN5_6',
    'HST_CHKR_LN7_8'
]

tx_mon_keys = [
    'L_TX_FAULT',
    'L_TX_LOS',
    'L_TX_LOL',
    'L_TX_EQ_FAULT',
    'L_TX_PWRH_ALARM',
    'L_TX_PWRL_ALARM',
    'L_TX_PWRH_WRN',
    'L_TX_PWRL_WRN',
    'L_TX_BIASH_ALARM',
    'L_TX_BIASL_ALARM',
    'L_TX_BIASH_WRN',
    'L_TX_BIASL_WRN'
]

rx_mon_keys = [
    'L_RX_LOS',
    'L_RX_LOL',
    'L_RX_PWRH_ALARM',
    'L_RX_PWRL_ALARM',
    'L_RX_PWRH_WRN',
    'L_RX_PWRL_WRN'
]

app_adv_keys = [
    'HST_EID_A1',
    'MOD_MID_A1',
    'LN_CNT_A1',
    'HST_EID_A2',
    'MOD_MID_A2',
    'LN_CNT_A2'
]

cl_ss0_explicit_keys = [
    'SS0_APPSEL_CTRL_EXP_LN1',
    'SS0_APPSEL_CTRL_EXP_LN2',
    'SS0_APPSEL_CTRL_EXP_LN3',
    'SS0_APPSEL_CTRL_EXP_LN4',
    'SS0_APPSEL_CTRL_EXP_LN5',
    'SS0_APPSEL_CTRL_EXP_LN6',
    'SS0_APPSEL_CTRL_EXP_LN7',
    'SS0_APPSEL_CTRL_EXP_LN8'
]

cl_ss0_rx_pre_cursor_keys = [
    'SS0_RX_OUT_PRE_LN1_2',
    'SS0_RX_OUT_PRE_LN3_4',
    'SS0_RX_OUT_PRE_LN5_6',
    'SS0_RX_OUT_PRE_LN7_8'
]

cl_ss0_rx_post_cursor_keys = [
    'SS0_RX_OUT_POST_LN1_2',
    'SS0_RX_OUT_POST_LN3_4',
    'SS0_RX_OUT_POST_LN5_6',
    'SS0_RX_OUT_POST_LN7_8'
]

cl_ss0_rx_main_cursor_keys = [
    'SS0_RX_OUT_AMP_LN1_2',
    'SS0_RX_OUT_AMP_LN3_4',
    'SS0_RX_OUT_AMP_LN5_6',
    'SS0_RX_OUT_AMP_LN7_8'
]

si_line_cfg_err_keys = [
    'CFGERR_CODE_LN1_2',
    'CFGERR_CODE_LN3_4',
    'CFGERR_CODE_LN5_6',
    'CFGERR_CODE_LN7_8',
]

si_rx_explicit_keys = [
    'SS0_APPSEL_CTRL_EXP_LN1',
    'SS0_APPSEL_CTRL_EXP_LN2',
    'SS0_APPSEL_CTRL_EXP_LN3',
    'SS0_APPSEL_CTRL_EXP_LN4',
    'SS0_APPSEL_CTRL_EXP_LN5',
    'SS0_APPSEL_CTRL_EXP_LN6',
    'SS0_APPSEL_CTRL_EXP_LN7',
    'SS0_APPSEL_CTRL_EXP_LN8'
]

si_rx_pre_cursor_keys = [
    'ACT_RX_OUT_PRE_LN1_2',
    'ACT_RX_OUT_PRE_LN3_4',
    'ACT_RX_OUT_PRE_LN5_6',
    'ACT_RX_OUT_PRE_LN7_8'
]

si_rx_post_cursor_keys = [
    'ACT_RX_OUT_POST_LN1_2',
    'ACT_RX_OUT_POST_LN3_4',
    'ACT_RX_OUT_POST_LN5_6',
    'ACT_RX_OUT_POST_LN7_8'
]

si_rx_main_cursor_keys = [
    'ACT_RX_OUT_AMP_LN1_2',
    'ACT_RX_OUT_AMP_LN3_4',
    'ACT_RX_OUT_AMP_LN5_6',
    'ACT_RX_OUT_AMP_LN7_8'
]

def load_csv_file(csv_file):
    skip = True

    with open(csv_file, 'r') as csv_file:
        reader = csv.reader(csv_file, delimiter=",")
        dic = {}
        for row in reader:
            if skip:
                skip = False
                continue
            dic[int(row[:1][0])] = list(map(int, row[1:]))
    return dic


if args.verbose:
    def print_io(io, addr, val):
        print("{}: reg={} val={}".format(io, hex(addr), hex(val)))
else:
    print_io = lambda *a: None  # do-nothing function


def get_keyval(port, key):
    try:
        register_definition = port.mmap[key]
    except KeyError:
        print(f"Invalid register name - {key}")
        exit(1)

    decode_type = register_definition[1]
    page = register_definition[3]
    byte = register_definition[4]

    returned_value = oom_get_keyvalue(port, key)
    if decode_type == 'get_bits':
        field_start = register_definition[6]
        field_width = register_definition[7]

        if field_width > 1:
            result = '{:28} |{:4}|{:3}|  bit {}-{} {}'.format(key, hex(page), byte, field_start,
                                                              field_start-(field_width-1),
                                                              hex(int(returned_value)))
        else:
            result = '{:28} |{:4}|{:3}|  bit {}   {}'.format(key, hex(page), byte, field_start,
                                                             returned_value)
    elif decode_type == 'get_string':
        result = '{:28} |{:4}|{:3}|  {}'.format(key, hex(page), byte, returned_value)
    else:
        result = '{:28} |{:4}|{:3}|  {}'.format(key, hex(page), byte, hex(int(returned_value)))

    return result


def print_keyval(port, key):
    keyval = get_keyval(port, key)
    print(keyval)


def set_keyval_list(port, lst, value):
    for key in range(0, len(lst)):
        oom_set_keyvalue(port, lst[key], value)


def print_keyval_list(port, lst):
    for key in range(0, len(lst)):
        print_keyval(port, lst[key])


def oom_write_byte(port, addr, value):
    write = 1
    port.readcount = port.readcount + 1
    data = cast(create_string_buffer(1), POINTER(c_ubyte))
    data[0] = value
    oomsth.shim.aa_read_write(byref(port.c_port), write, addr << 1, 0, 1, data)
    print_io('wr', addr, data[0])


def verify_key(port, key):
    try:
        port.mmap[key]
    except KeyError as e:
        print('Invalid key {}'.format(key))
        exit(1)


def get_hexval(strval):
    val = None
    try:
        val = int(strval, 16)
    except ValueError as e:
        print('Invalid hex value: {}'.format(strval))
        print(e)
        exit(1)
    return val


def get_strarg(option, options):
    if option in options:
        return option
    else:
        print('Invalid option: {}. The valid options: {}'.format(option,
              ' '.join(map(str, options))))
        exit(1)


def get_hexarg(strarg, minval, maxval):
    hexarg = get_hexval(strarg)
    if minval <= hexarg <= maxval:
        return hexarg
    else:
        print('Invalid arg: {}'.format(hex(hexarg)))
        exit(1)


def oom_select_transceiver(handle, port):
    # shift rigth 1 bit because the aa_read_write shifts left 1 bit
    oom_write_byte(handle, 0x70, 0)
    oom_write_byte(handle, 0x70, 1 << (port // 8))
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x77, 1 << (port % 8))


def oom_deselect_transceiver(handle):
    oom_write_byte(handle, 0x77, 0)
    oom_write_byte(handle, 0x70, 0)


def get_module_identity(port):
    if port.port_type == 0:
        return
    print('\n{}'.format(mod_id(port.port_type)))
    print_keyval(port, 'VENDOR_NAME')
    print_keyval(port, 'VENDOR_PN')
    print_keyval(port, 'VENDOR_SN')
    print_keyval(port, 'MODULE_FW_REV_MAJOR')
    print_keyval(port, 'MODULE_FW_REV_MINOR')


def set_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val |= bitmap
    oom_set_keyvalue(port, reg, val)


def clr_reg_bits(port, reg, bitmap):
    val = int(oom_get_keyvalue(port, reg))
    val &= ~bitmap & 0xff
    oom_set_keyvalue(port, reg, val)


def set_loopback(port, args):
    if len(args) != 3:
        print('Invalid arguments: {}'.format(args))
        exit(1)

    ltype = get_hexarg(args[0], 1, len(loopback_types))
    lanes = get_hexarg(args[1], 0, 0xff)
    offon = get_strarg(args[2], opts_offon)

    get_module_identity(port)

    ltype -= 1
    if offon == 'on':
        print('\n{} : ON\n'.format(loopback_types[ltype]))
        set_reg_bits(port, loopback_enable_keys[ltype], lanes)
    else:
        print('\n{} : OFF\n'.format(loopback_types[ltype]))
        clr_reg_bits(port, loopback_enable_keys[ltype], lanes)
    print_keyval(port, loopback_enable_keys[ltype])


def generator_init(port, pattern, lanes, action, init_keys, en_key):
    if action == 'on':
        print('Generator state  : ON\n')
        pattern = pattern * 16 + pattern
        set_keyval_list(port, init_keys, pattern)
        print_keyval_list(port, init_keys)
        set_reg_bits(port, en_key, lanes)
    else:
        print('Generator state  : OFF\n')
        clr_reg_bits(port, en_key, lanes)
    print_keyval(port, en_key)


def get_capabilities(port, captype):
    get_module_identity(port)

    if captype > len(capability_types):
        print('Invalid capability type')
        exit(1)

    if captype == 1:
        for i in range(0, len(capabilities_keys)):
            print('\n{}:\n'.format(capability_types[i + 1]))
            print_keyval_list(port, capabilities_keys[i])
        print('\nSupported applications: ')
        module_supported_apps(port)
    elif captype == 7:
        print('\nSupported applications: ')
        module_supported_apps(port)
    else:
        print('\n{}:\n'.format(capability_types[captype - 1]))
        print_keyval_list(port, capabilities_keys[captype - 2])


def set_generator(port, args):
    """
    Planned to support pattern ids 0 - 11 CMIS 5.0 Table 8-93 Pattern IDs
    """
    if len(args) != 4:
        print('Invalid arguments: {}'.format(args))
        exit(1)

    gtype = get_hexarg(args[0], 1, len(generator_types))
    user_pattern = args[1]
    gpatt_id = patterns.get(user_pattern, None)
    if gpatt_id is None:
        print('Invalid pattern: {}'.format(args))
        exit(1)
    else:
        gpatt_msg = 'Generator pattern: PRBS{}'.format(user_pattern.upper())
    lanes = get_hexarg(args[2], 0, 0xff)
    offon = get_strarg(args[3], opts_offon)

    get_module_identity(port)

    print('Generator type: {}'.format(generator_types[gtype - 1]))
    print('Generator pattern: {}'.format(gpatt_msg))

    if gtype == 1:
        generator_init(port, gpatt_id, lanes, offon, host_gen_init_keys, 'HST_GEN_EN')
    elif gtype == 2:
        generator_init(port, gpatt_id, lanes, offon, media_gen_init_keys, 'MED_GEN_EN')
    else:
        print("Invalid generator type")
        exit(1)


def mon_collect(port):
    # module
    print_keyval(port, 'MODULE_STATE')
    print_keyval(port, 'L_TEMP_HIGH_ALARM')
    # tx
    print_keyval(port, 'L_TX_FAULT')
    print_keyval(port, 'L_TX_LOS')
    print_keyval(port, 'L_TX_LOL')
    print_keyval(port, 'TX_ADAPT_FAIL_FLAG_IMP')
    print_keyval(port, 'L_TX_EQ_FAULT')
    print_keyval(port, 'L_TX_PWRH_ALARM')
    print_keyval(port, 'L_TX_PWRL_ALARM')
    # rx
    print_keyval(port, 'L_RX_LOS')
    print_keyval(port, 'L_RX_LOL')
    print_keyval(port, 'L_RX_PWRH_ALARM')
    print_keyval(port, 'L_RX_PWRL_ALARM')
    # diagnostics
    print_keyval(port, 'L_LOL')
    print_keyval(port, 'L_HST_CHKR_LOL')
    print_keyval(port, 'L_MED_CHKR_LOL')
    print_keyval(port, 'HST_INP_LOOPBACK_EN')
    print_keyval(port, 'HST_CHKR_EN')
    print_keyval(port, 'HST_GEN_EN')
    print_keyval(port, 'MED_INP_LOOPBACK_EN')
    print_keyval(port, 'MED_CHKR_EN')
    print_keyval(port, 'MED_GEN_EN')


def power_up_module(port):
    print("Action - Module Power Up")
    oom_set_keyvalue(port, 'MODULE_CTRL', 0x0)
    for _ in range(60):
        val = hex(oom_get_keyvalue(port, 'MODULE_STATE'))
        if val == hex(2):
            print('Module in ModulePwrUp state')
            time.sleep(2)
        if val == hex(3):
            print('Module in ModuleReady state')
            break


def oom_get_keyvalue_wrap(port, key):
    value = oom_get_keyvalue(port, key)
    print("TRACE: get: key = {}, value = {:#x}".format(key, value))
    return value


def oom_set_keyvalue_wrap(port, key, value):
    print("TRACE: set: key = {}, value = {:#x}".format(key, value))
    oom_set_keyvalue(port, key, value)


def set_checker(port, chk_params):
    """
    All lanes are activated as checkers
    chk_params[0] - 1=Host, 2=Media
    chk_params[1] - pattern: 0x0 - 0xf
    chk_params[2] - action: on/off
    """
    print(chk_params)
    ctype = get_hexarg(chk_params[0], 1, len(checker_types))
    cpatt = patterns.get(chk_params[1])
    offon = get_strarg(chk_params[2], opts_offon)

    pattern = cpatt * 16 + cpatt
    print("Pattern Argument - {} Checker Pattern - 0x{:02X}".format(hex(cpatt),
                                                                    pattern))

    if ctype == 1:
        key_tgt = 'HST_CHKR_L{idx1}_{idx2}'
    elif ctype == 2:
        key_tgt = 'MED_CHKR_L{idx1}_{idx2}'

    if offon == 'off':
        print('{}: OFF\n'.format(checker_types[ctype - 1]))
        oom_set_keyvalue_wrap(port, 'RESET_ALL_LANES', 0x1)
        oom_set_keyvalue_wrap(port, 'RESET_ERROR_INFO', 0x1)
        oom_set_keyvalue_wrap(port, 'HST_CHKR_EN', 0x0)
        oom_set_keyvalue_wrap(port, 'MED_CHKR_EN', 0x0)
    elif offon == 'on':
        print('{}: ON\n'.format(checker_types[ctype - 1]))
        for i in range(4):
            key = key_tgt.format(idx1=i * 2 + 1, idx2=i * 2 + 2)
            oom_set_keyvalue_wrap(port, key, pattern)

        oom_set_keyvalue_wrap(port, 'HST_PRBS_CHKR_CLK_SRC', 0x0)  # 0 - recovered clock , 1 - int clock, 2 - refclk
        oom_set_keyvalue_wrap(port, 'MED_PRBS_CHKR_CLK_SRC', 0x0)  # 0 - recovered clock , 1 - int clock, 2 - refclk
        oom_set_keyvalue_wrap(port, 'HST_PRBS_GEN_CLK_SRC', 0x0)  # 0 - int clock, 1 - refclk, f - recovered
        oom_set_keyvalue_wrap(port, 'MED_PRBS_GEN_CLK_SRC', 0x0)  # 0 - int clock, 1 - refclk, f - recovered
        oom_set_keyvalue_wrap(port, 'RESET_ALL_LANES', 0x1)
        oom_set_keyvalue_wrap(port, 'RESET_ERROR_INFO', 0x0)
        oom_set_keyvalue_wrap(port, 'BER_COUNTER_UPDATE_TIME', 1)
        if ctype == 1:
            oom_set_keyvalue_wrap(port, 'HST_CHKR_EN', 0xff)
        elif ctype == 2:
            oom_set_keyvalue_wrap(port, 'MED_CHKR_EN', 0xff)


def clear_ber_counters(port):
    """
    Explicitly clear BER counters for all the lanes
    """
    oom_set_keyvalue(port, 'RESET_ERROR_INFO', 0x1)
    wait_tnack()
    oom_set_keyvalue(port, 'RESET_ERROR_INFO', 0x0)
    print('\nClear BER Counters - Done!')


def fexp(number):
    (sign, digits, exponent) = Decimal(number).as_tuple()
    return len(digits) + exponent - 1


def fman(number):
    return Decimal(number).scaleb(-fexp(number)).normalize()


def calc_ber(port, pfx, lid, pid, l_lol_key):

    lane_lol = oom_get_keyvalue(port, l_lol_key)
    ikey = pfx + 'BER_LN' + lid
    ival = int(oom_get_keyvalue(port, ikey))
    imant = ival & 0x7ff
    iexp = ival >> 11
    iexp = iexp - 24
    print("calc_ber: port = {}, ikey = {}, \nBER: {:.2e}, lol = {}".format(pid + 1,
                                                                           ikey,
                                                                           imant * (10 ** iexp),
                                                                           lane_lol))


def calc_ber2(port, lid, pid, lid_flat):
    ikey = 'TOT_CNTR_L' + lid
    err_cntr_64b = 0
    tot_cntr_64b = 0
    for j in range(1, 9):
        ikey1 = "{}_{}".format(ikey, j)
        ival = oom_get_keyvalue(port, ikey1)
        tot_cntr_64b += ival << (j - 1) * 8
    ikey = 'ERR_CNTR_L' + lid
    for j in range(1, 9):
        ikey1 = "{}_{}".format(ikey, j)
        ival = oom_get_keyvalue(port, ikey1)
        err_cntr_64b += ival << (j - 1) * 8
    itrust = 0 == (tot_cntr_64b & 0x1)
    if tot_cntr_64b == 0:
        itrust = False
        print("calc_ber2: port={}, lane={}, trust={}, err_cntr_64b={}, tot_cntr_64b={}, ZERO - BAD".format(
            pid + 1, lid_flat, itrust, hex(err_cntr_64b), hex(tot_cntr_64b)))
    else:
        imnt = fman(err_cntr_64b / float(tot_cntr_64b))
        iexp = fexp(err_cntr_64b / float(tot_cntr_64b))
        print("calc_ber2: port={}, lane={}, trust={}, err_cntr_64b={} tot_cntr_64b={}, \nBER: {:1.2f}e{}, {:1.20f}".format(
                pid + 1, lid_flat, itrust,
                hex(err_cntr_64b), hex(tot_cntr_64b),
                imnt, iexp, err_cntr_64b / float(tot_cntr_64b)))


def display_ber(port, pid, diag_sel, host=False, media=False):
    side = 'HST_' if host else 'MED_' if media else ''
    lol_prefix = '_HST_' if host else '_MED_' if media else ''
    lane_lol = 'LN{idx}' + lol_prefix + 'CHKR_LOL'
    if diag_sel == 1 or diag_sel == 0x11:
        for i in range(1, 9):
            calc_ber(port=port, pfx=side, lid="{}".format(i), pid=pid, l_lol_key=lane_lol.format(idx=i))
    elif diag_sel == 2 or diag_sel == 0x12:
        for k in range(1, 5):
            calc_ber2(port, lid=str(k), pid=pid, lid_flat=k)
    elif diag_sel == 3 or diag_sel == 0x13:
        for k in range(1, 5):
            calc_ber2(port, lid=str(k), pid=pid, lid_flat=4 + k)
    elif diag_sel == 4 or diag_sel == 0x14:
        for k in range(1, 5):
            calc_ber2(port, lid=str(k), pid=pid, lid_flat=k)
    elif diag_sel == 5 or diag_sel == 0x15:
        for k in range(1, 5):
            calc_ber2(port, lid=str(k), pid=pid, lid_flat=4 + k)
    else:
        print("ERROR: diag_sel unexpected value: {}".format(diag_sel))


def host_real_time_ber_16bytes(port, pid):
    idiag_sel = 0x1  # 16Bytes ber
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("\n----------- HOST 16Bytes BER 1-8 ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel, host=True)


def media_real_time_ber_16bytes(port, pid):
    idiag_sel = 0x1  # 16Bytes ber
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("\n----------- MEDIA 16Bytes BER 1-8 ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel, media=True)


def host_real_time_ber_64bytes(port, pid):
    idiag_sel = 0x2  # 64Bytes host lanes 1-4
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("----------- HOST 64Bytes LANES 1-4  ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel)

    idiag_sel = 0x3  # 64Bytes host lanes 5-8
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("----------- HOST 64Bytes LANES 5-8  ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel)


def media_real_time_ber_64bytes(port, pid):
    idiag_sel = 0x4  # 64Bytes media lanes 1-4
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("----------- MEDIA 64Bytes LANES 1-4  ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel)

    idiag_sel = 0x5  # 64Bytes media lanes 5-8
    oom_set_keyvalue(port, 'DIAG_SEL', idiag_sel)
    wait_tnack()
    print("----------- MEDIA 64Bytes LANES 5-8  ----------- ")
    display_ber(port, pid, diag_sel=idiag_sel)


def wait_tnack():
    time.sleep(0.25)  # Allow volatile mem update


def read_compare(port, regname, val):
    wait_tnack()
    read_val = oom_get_keyvalue(port, regname)
    if read_val == val:
        print("read_compare: OK: regname={}, val={}".format(regname, val))
    else:
        print("read_compare: ERROR: regname={}, expected val={}, actual val={}".format(regname, val, read_val))


def dump(port, pid):
    get_module_identity(port)
    print_keyval(port, 'MODULE_STATE')
    print("\nEQ settings: port {}\n".format(pid))
    print_keyval_list(port, rx_out_pre_act_keys)
    print_keyval_list(port, rx_out_post_act_keys)
    print_keyval_list(port, rx_out_amp_act_keys)
    print_keyval_list(port, cfg_err_code_keys)

    print_keyval_list(port, tx_act_eq_control)

    print("\nApp. Advertisment info:\n")
    print_keyval_list(port, app_adv_keys)
    # Active application
    active_application(port)

    print("\nCHECKER ENABLE info:\n")
    print_keyval(port, 'HST_CHKR_EN')
    print_keyval(port, 'MED_CHKR_EN')
    print_keyval(port, 'HST_PAT_CHECKER_CAP_P0_7')
    print_keyval(port, 'HST_PRBS_PATTERN_CAP_P0_7')
    print("\nHOST CHECKER PATTERN SEL info:\n")
    print_keyval_list(port, host_checker_keys)
    print("\nMEDIA CHECKER PATTERN SEL info:\n")
    print_keyval_list(port, media_checker_keys)
    print("\nBER info:\n")
    print_keyval(port, 'RESET_ALL_LINES')
    print_keyval(port, 'RESET_ERROR_INFO')
    print_keyval(port, 'AUTO_RESTART_GATE_TIME')
    print_keyval(port, 'GATE_TIME')
    print_keyval(port, 'BER_COUNTER_UPDATE_TIME')
    print_keyval(port, 'DIAG_SEL')
    print_keyval(port, 'L_LOL')
    print("\nModule Monitoring:\n")
    print_keyval_list(port, dp_state_keys)
    print_keyval_list(port, tx_mon_keys)
    print_keyval_list(port, rx_mon_keys)
    print_keyval(port, 'L_HST_GATE_CMPLT')
    print_keyval(port, 'L_MED_GATE_CMPLT')


def common_eq_settings(port, main, pre, post):
    """
    Eq settings that are common to rx_out_eq() and calib()
    """
    print("Set Pre values (page 10, regs 162-165)")
    val = pre * 16 + pre
    set_keyval_list(port, rx_out_pre_ss0_keys, val)
    print_keyval_list(port, rx_out_pre_ss0_keys)

    print("Set Post values (page 10, regs 166-169)")
    val = post * 16 + post
    set_keyval_list(port, rx_out_post_ss0_keys, val)
    print_keyval_list(port, rx_out_post_ss0_keys)

    print("Set Main values (page 10, regs 170-173)")
    val = main * 16 + main
    set_keyval_list(port, rx_out_amp_ss0_keys, val)
    print_keyval_list(port, rx_out_amp_ss0_keys)


def rx_out_eq(port, part_number, profile):
    """
    tune Rx Output main/post/pre cursors
    """
    get_module_identity(port)
    si_map_dic = load_csv_file(SI_MAP_FILE)
    (main, pre, post) = si_map_dic[profile]
    is_molex = part_number in pn_molex
    print("profile {}: main = {}, pre = {}, post = {}".format(profile, main, pre, post))

    # deinit datapath
    oom_set_keyvalue(port, 'DP_DEINIT', 0xff)
    print_keyval_list(port, ['DP_DEINIT'])

    print("\nSet staged set 0 explicit bits to 1 (page 0x10, regs 145-152, bit 0)")
    for i in range(len(ss0_appsel_ctrl_exp_keys)):
        if is_molex:
            oom_set_keyvalue(port, ss0_appsel_ctrl_exp_keys[i], 0)
        else:
            oom_set_keyvalue(port, ss0_appsel_ctrl_exp_keys[i], 1)

    print_keyval_list(port, ss0_appsel_ctrl_exp_keys)

    common_eq_settings(port, main, pre, post)

    print("\nApply new settings\n")
    if is_molex:
        oom_set_keyvalue(port, 'SS0_APPLY_DPINIT_ALL_LN', 0xff)
    else:
        oom_set_keyvalue(port, 'SS0_APPLY_CTRL_IMMD', 0xff)
    # datapath init ater app sel code set
    oom_set_keyvalue(port, 'DP_DEINIT', 0x0)
    print_keyval_list(port, ['SS0_APPLY_DPINIT_ALL_LN', 'DP_DEINIT', 'SS0_APPLY_CTRL_IMMD'])
    print_keyval_list(port, cfg_err_code_keys)

    print("\nVerify new settings\n")
    print_keyval_list(port, appsel_ctrl_keys_act)

    print_keyval_list(port, rx_out_pre_act_keys)
    print_keyval_list(port, rx_out_post_act_keys)
    print_keyval_list(port, rx_out_amp_act_keys)


def calib(port, profile, cpf):
    profile = cpf[0]
    get_module_identity(port)
    si_map_dic = load_csv_file(SI_MAP_FILE)
    (main, pre, post) = si_map_dic[profile]
    print("profile {}: main = {}, pre = {}, post = {}".format(profile, main, pre, post))

    print("\nSet staged set 0 explicit bits to 1 (page 0x10, regs 145-152, bit 0)")
    set_keyval_list(port, cl_ss0_explicit_keys, 0x1)
    print_keyval_list(port, cl_ss0_explicit_keys)

    print("Set Pre values (page 10, regs 162-165)")
    val = pre * 16 + pre
    set_keyval_list(port, cl_ss0_rx_pre_cursor_keys, val)
    print_keyval_list(port, cl_ss0_rx_pre_cursor_keys)

    print("Set Post values (page 10, regs 166-169)")
    val = post * 16 + post
    set_keyval_list(port, cl_ss0_rx_post_cursor_keys, val)
    print_keyval_list(port, cl_ss0_rx_post_cursor_keys)

    print("Set Main values (page 10, regs 170-173)")
    val = main * 16 + main
    set_keyval_list(port, cl_ss0_rx_main_cursor_keys, val)
    print_keyval_list(port, cl_ss0_rx_main_cursor_keys)

    print("Apply new settings")
    oom_set_keyvalue(port, 'SS0_APPLY_CTRL_IMMD', 0xff)

    print("Verify new settings")
    print_keyval_list(port, si_line_cfg_err_keys)

    print_keyval_list(port, si_rx_explicit_keys)

    print_keyval_list(port, si_rx_pre_cursor_keys)
    print_keyval_list(port, si_rx_post_cursor_keys)
    print_keyval_list(port, si_rx_main_cursor_keys)


def set_keyvalue(port, pair):
    key = pair[0]
    verify_key(port, key)
    val = get_hexarg(pair[1], 0, 0xff)
    oom_set_keyvalue(port, key, val)
    print_keyval(port, key)


def module_reset(port):
    """
    Module SW reset
    """
    oom_set_keyvalue(port, 'SW_RESET', 1)
    for _ in range(180):
        val = oom_get_keyvalue(port, 'SW_RESET')
        if val == 0:
            break

    print('\nSW Reset - Done')


def print_opt_power(port):
    """
    Prints the measured optical power of all the module lanes
    """
    for index in range(1, 9):
        rx_pwr = oom_get_keyvalue(port, 'RX{}_POWER_DBM'.format(index))
        tx_pwr = oom_get_keyvalue(port, 'TX{}_POWER_DBM'.format(index))
        print('Lane {} Rx Power - {:.2f}dBm'.format(index, rx_pwr))
        print('Lane {} Tx Power - {:.2f}dBm'.format(index, tx_pwr))


def module_supported_apps(port):
    """
    Search the first 5 advertised applications and
    print the valid ones
    Note: this function is based on SNIA's SFF-8024 definitions
    according to CMIS 4.0
    """
    key = 'MOD_MED_TYPE_ENC'
    val = int(oom_get_keyvalue(port, key))
    media_id = None
    if val == 0x1:
        media_id = eval('mmf_media_id')
    elif val == 0x2:
        media_id = eval('smf_media_id')
    elif val == 0x3:
        media_id = eval('pas_cop_media_id')
    elif val == 0x4:
        media_id = eval('act_cop_media_id')
    else:
        print('Invalid Module Type')
        exit(1)

    for index in range(1, 16):
        hst_eid_key = 'HST_EID_A{}'.format(index)
        mod_mid_key = 'MOD_MID_A{}'.format(index)
        lane_count_key = 'LN_CNT_A{}'.format(index)
        host_eid_val = int(oom_get_keyvalue(port, hst_eid_key))
        mod_mid_val = int(oom_get_keyvalue(port, mod_mid_key))
        lane_count_val = int(oom_get_keyvalue(port, lane_count_key))
        host_ln_cnt = (lane_count_val >> 4) & 0xf
        media_ln_cnt = lane_count_val & 0xf

        if host_eid_val != 0xff and host_eid_val != 0x00:
            print('\nModule Application {}'.format(index))
            host_type = host_eid_code.get(host_eid_val, None)
            if not host_type:
                print('\tHost Electrical Interface ID - {}'.format(host_eid_val))
            else:
                print('\tHost Electrical Interface - {}'.format(host_type))
            media_code = media_id.get(mod_mid_val, None)
            if not media_code:
                print('\tModule Media Interface ID - {}'.format(mod_mid_val))
            else:
                print('\tModule Media Interface - {}'.format(media_code))
            print('\tHost Lane Count - {}'.format(host_ln_cnt))
            print('\tMedia Lane Count - {}'.format(media_ln_cnt))


def active_application(port):
    """
    Print the active application
    Note: function "module_applications" gives more
    details regarding the optional applications and
    their characteristics
    """
    print('\nActive Application per lane: \n')
    keys = 'ACT_APPSEL_CTRL_LN{}'
    for index in range(1, 9):
        print_keyval(port, keys.format(index))


def set_application(port, app_idx):
    """
    Set module application according to a known list per PN
    """
    pn = oom_get_keyvalue(port, 'VENDOR_PN').strip()
    apps_dict = app_dict.get(pn)
    if apps_dict is None:
        print('Invalid PN')
        exit(1)

    app_exists = apps_dict.get(int(app_idx), None)
    if app_exists is None:
        print('Invalid App #ID')
        exit(1)

    # Data Path Deinitialization - All Paths
    key = 'DP_DEINIT'
    oom_set_keyvalue(port, key, 0xff)

    # Set the application along with Data Path IDs
    print('\nSetting Application #{}'.format(app_idx))
    appsel_keys = 'SS0_APPSEL_CTRL_LN{idx}'
    for index in range(1, 9):
        val2set = app_exists.get(index)
        oom_set_keyvalue(port, appsel_keys.format(idx=index), int(val2set, 16))

    # Data Path Initialization - All Paths
    key = 'SS0_APPLY_DPINIT_ALL_LN'
    oom_set_keyvalue(port, key, 0xff)

    # Data Path Deinitialization - All Paths
    key = 'DP_DEINIT'
    oom_set_keyvalue(port, key, 0x00)


def main():
    portlist = oom_get_portlist()
    fp_ports = len(portlist)

    if fp_ports == 0:
        print("Empty portlist, configuration issue?")
        exit(1)

    if args.port < 1 or args.port > fp_ports:
        print("Invalid port number")
        exit(1)

    first = args.port - 1
    if args.range is None:
        last = first + 1
    else:
        last = first + args.range
        if last < args.port or last > fp_ports:
            print("Invalid port range")
            exit(1)
        print('\n===> Ports range: {}-{}'.format(args.port, last))

    handle = portlist[0]

    for port in range(first, last):

        if args.aardvark:
            oom_select_transceiver(handle, port)
            handle = oom_get_portlist()[0]
        else:
            handle = portlist[port]
        modtype = type_to_str(handle.port_type)
        if modtype == 'UNKNOWN' or len(handle.mmap) == 0:
            continue

        pn = oom_get_keyvalue(handle, 'VENDOR_PN').split()
        if args.PN:
            pn_valid = False
            for index in args.PN:
                listed_pn = part_numbers[index - 1].split()
                if pn == listed_pn:
                    pn_valid = True
                    break

            if not pn_valid:
                continue

        print("\n===> Port {}\n".format(port + 1))

        add_qsfpdd_keys(handle)
        if args.profile is not None:
            calib(handle, pn[0], args.profile)
        elif args.rx_out_eq is not None:
            rx_out_eq(handle, pn[0], args.rx_out_eq)
        elif args.loopback is not None:
            set_loopback(handle, args.loopback)
        elif args.generator is not None:
            set_generator(handle, args.generator)
        elif args.capabilities is not None:
            get_capabilities(handle, args.capabilities)
        elif args.w is not None:
            set_keyvalue(handle, args.w)
        elif args.r is not None:
            print_keyval(handle, args.r)
        elif args.dump:
            dump(handle, port)
        elif args.ber_checker is not None:
            set_checker(handle, args.ber_checker)
        elif args.show_ber == 1:
            host_real_time_ber_16bytes(handle, port)
        elif args.show_ber == 2:
            media_real_time_ber_16bytes(handle, port)
        elif args.ber_clr:
            clear_ber_counters(handle)
        elif args.up:
            power_up_module(handle)
        elif args.mon:
            mon_collect(handle)
        elif args.reset:
            module_reset(handle)
        elif args.opt_pwr:
            print_opt_power(handle)
        elif args.show_apps:
            module_supported_apps(handle)
        elif args.set_app:
            set_application(handle, args.set_app)
        else:
            get_module_identity(handle)
        if args.aardvark:
            oom_deselect_transceiver(handle)


if __name__ == "__main__":
    main()
