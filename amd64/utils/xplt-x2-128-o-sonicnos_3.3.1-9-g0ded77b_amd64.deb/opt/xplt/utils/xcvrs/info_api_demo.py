#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import info
from helpers import *

time_vbs = True

@decor(timer, time_vbs)
def print_table(args):
    portlist = info.get_port_list()
    data = info.get_ports_info(portlist, args)
    info.print_table_at_once(data, args.noheader)
    return portlist

@decor(timer, time_vbs)
def print_field(args):
    data = info.get_port_info(portlist[args.first - 1], args)
    info.print_port_info(data)

def example_1():
    """Print the default table and measure an execution time.
    """
    user_args = []

    # Convert argumets list into argparse.Namespace object
    args = info.set_info_args(user_args)
    portlist = print_table(args)
    return portlist

def example_2():
    """Print one field of one port, with no headers and measure the execution time.

    Provide the list of arguments for info.py as used via CLI in a standalone mode.
    Use -v option to print the argument list like:

    $ sudo ./py info.py 1 1 -n -i 1 2 -v
    CLI parameters: ['1', '1', '-n', '-i', '1', '2', '-v']
    """
    user_args = ['1', '1', '-n', '-i', '2']
    args = info.set_info_args(user_args)
    print_field(args)

if __name__ == "__main__":
    portlist = example_1()
    example_2()
