#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

if [ "$(id -u)" -ne 0 ] ; then
    echo "This script must be executed with root privileges"
    exit 1
fi

VDDH_SET_VALUE=1270
verbose=0

# Define rails as an associative array of "I2CBUS,I2C_ADDR,DEV_ADDR,DEV_IDX"
declare -A rails=(
    [VDD_H1]="39 0x40 0040 0x00"
    [VDD_H2]="39 0x40 0040 0x01"
    [VDD_H3]="40 0x41 0041 0x00"
    [VDD_H4]="40 0x41 0041 0x01"
)
keys=(
    VDD_H1
    VDD_H2
    VDD_H3
    VDD_H4
)

function display_voltage() {
    separator=$(printf '%.0s-' {1..86})
    format='%8s'
    printf '\nV(mV):'
    for key in "${keys[@]}"; do
        printf $format ${voltages[$key]}
    done
    printf '\n\n'
}

function read_vddh() {
    voltages=()
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        i2cset -f -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX

        VD=$(i2cget -f -y $I2CBUS $I2C_ADDR 0x8b w)
        [ $verbose -ge 1 ] && echo "VD=$((VD))"
        voltages[$key]=$((VD))
    done
}

function write_vddh() {
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        i2cset -f -y $I2CBUS $I2C_ADDR 0x00 $DEV_IDX

        [ $verbose -ge 1 ] && echo "Write voltage: $VDDH_SET_VALUE"
        i2cset -f -y $I2CBUS $I2C_ADDR 0x21 $VDDH_SET_VALUE w
    done
}

function write_and_verify_vddh() {
    write_vddh
    read_vddh
    [ $verbose -ge 1 ] && display_voltage

    # Track overall success
    success=1
    for key in "${keys[@]}"; do
        if [ "${voltages[$key]}" -ne "$VDDH_SET_VALUE" ]; then
            [ $verbose -ge 1 ] && echo "[$key] Verification of the written voltage FAILED: ${voltages[$key]} mV (expected $VDDH_SET_VALUE)"
            success=0
        fi
    done

    if [ $success -eq 1 ]; then
        echo "Vddh updated for R0B to: $VDDH_SET_VALUE mV"
    else
        echo "Vddh update for R0B FAILED."
    fi
}

# Trap SIGINT (Ctrl+C) and cleanup sysfs I2C nodes
function cleanup_sysfs_nodes() {
    for key in "${keys[@]}"; do
        read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
        [ -d $SYSFS/${I2CBUS}-${DEV_ADDR} ] && echo $I2C_ADDR > $SYSFS/i2c-${I2CBUS}/delete_device || true
    done
}

declare -A voltages
hw_rev=$(/opt/xplt/utils/hw_rev.sh)
if [ $verbose -ge 1 ] ; then
    echo "verbose is: $verbose"
    echo "HW revision: $hw_rev"
fi
# Test HW revision
if [ "$hw_rev" != "R0B" ]; then
    [ $verbose -ge 1 ] && echo "VDDH set is not required. Exiting."
    exit 0
fi
[ $verbose -ge 1 ] && echo "Set value: $VDDH_SET_VALUE"
trap cleanup_sysfs_nodes SIGINT

# Instantiate i2c devices
SYSFS=/sys/bus/i2c/devices
for key in "${keys[@]}"; do
    read I2CBUS I2C_ADDR DEV_ADDR DEV_IDX <<< "${rails[$key]}"
    dev_path="$SYSFS/${I2CBUS}-${DEV_ADDR}"
    bus_path="$SYSFS/i2c-${I2CBUS}/new_device"
    [ ! -d "$dev_path" ] && echo i2ctools "$I2C_ADDR" > "$bus_path"
done

[ $verbose -ge 1 ] && read_vddh
write_and_verify_vddh
cleanup_sysfs_nodes
if [ $success -eq 1 ]; then
    exit 0
else
    exit 1
fi