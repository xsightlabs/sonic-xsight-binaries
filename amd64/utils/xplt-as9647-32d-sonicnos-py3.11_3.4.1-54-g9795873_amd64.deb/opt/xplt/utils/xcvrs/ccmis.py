# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.
#
# C-CMIS (Coherent Common Management Interface Specification) support module.
# Provides functions for laser frequency management, TX power control,
# tuning status monitoring, and performance monitoring (PM) for coherent
# optical modules (ZR/ZR+).
#
# Reference: OIF C-CMIS Rev 1.1, sonic-buildimage CCmisApi

import helpers
import time

# Frequency grid encoding (C-CMIS Page 0x12 Byte 128, bits 7:4)
GRID_SPACING_MAP = {
    0: 3.125,
    1: 6.25,
    2: 12.5,
    3: 25,
    4: 50,
    5: 100,
    6: 33,
    7: 75,
}

# Grid spacing value to register encoding (bits 7:4)
GRID_SPACING_TO_REG = {
    75: 7,
    100: 5,
    50: 4,
    33: 6,
    25: 3,
}

# Laser tuning detail bit definitions (C-CMIS Page 0x12 Byte 231)
TUNING_DETAIL_FLAGS = [
    (5, 'TargetOutputPowerOOR'),
    (4, 'FineTuningOutOfRange'),
    (3, 'TuningNotAccepted'),
    (2, 'InvalidChannel'),
    (1, 'WavelengthUnlocked'),
    (0, 'TuningComplete'),
]


def _get_oom():
    """Get the registered OOM object."""
    return helpers.get_registered("oom")


def _get_keyval_int(port, key):
    """Read an EEPROM key and return as integer."""
    oom = _get_oom()
    val = oom.oom_get_keyvalue(port, key)
    try:
        return int(val)
    except (ValueError, TypeError):
        return None


def _get_keyval_64(port, key_hi, key_lo):
    """Read a 64-bit value from two 32-bit EEPROM keys (big-endian)."""
    hi = _get_keyval_int(port, key_hi)
    lo = _get_keyval_int(port, key_lo)
    if hi is None or lo is None:
        return None
    return (hi << 32) | lo


def _to_signed16(val):
    """Convert unsigned 16-bit integer to signed."""
    if val is None:
        return None
    if val >= 0x8000:
        val -= 0x10000
    return val


def _to_signed32(val):
    """Convert unsigned 32-bit integer to signed."""
    if val is None:
        return None
    if val >= 0x80000000:
        val -= 0x100000000
    return val


# ============================================================
# Laser Frequency Management
# ============================================================

def get_freq_grid(port):
    """
    Read the configured frequency grid spacing.

    Returns:
        float: Grid spacing in GHz, or None on error.
    """
    val = _get_keyval_int(port, 'CCMIS_TX1_GRID_SPACING')
    if val is None:
        return None
    return GRID_SPACING_MAP.get(val)


def get_laser_config_freq(port):
    """
    Read the configured laser frequency.

    Returns:
        float: Configured laser frequency in GHz, or None on error.
    """
    freq_grid = get_freq_grid(port)
    if freq_grid is None:
        return None
    channel = _get_keyval_int(port, 'CCMIS_TX1_CHANNEL_NUMBER')
    if channel is None:
        return None
    channel = _to_signed16(channel)
    if freq_grid == 75:
        return 193100 + channel * freq_grid / 3
    else:
        return 193100 + channel * freq_grid


def get_current_laser_freq(port):
    """
    Read the monitored (actual) laser frequency.

    Returns:
        float: Current laser frequency in GHz, or None on error.
    """
    val = _get_keyval_int(port, 'CCMIS_TX1_CURRENT_LASER_FREQ')
    if val is None:
        return None
    # Register value is in units of 0.001 GHz (MHz)
    return val / 1000.0


def get_supported_freq_config(port):
    """
    Read the supported frequency configuration from Page 0x04.

    Returns:
        dict with keys:
            'grid_supported': raw grid support byte
            'low_channel': lowest supported channel number
            'high_channel': highest supported channel number
            'low_freq_ghz': lowest supported frequency in GHz
            'high_freq_ghz': highest supported frequency in GHz
        or None on error.
    """
    grid_supported = _get_keyval_int(port, 'CCMIS_GRID_SUPPORTED')
    low_ch = _get_keyval_int(port, 'CCMIS_LOW_CHANNEL')
    high_ch = _get_keyval_int(port, 'CCMIS_HIGH_CHANNEL')
    if any(v is None for v in (grid_supported, low_ch, high_ch)):
        return None
    low_ch = _to_signed16(low_ch)
    high_ch = _to_signed16(high_ch)
    low_freq = 193100 + low_ch * 25
    high_freq = 193100 + high_ch * 25
    return {
        'grid_supported': grid_supported,
        'grid_75ghz': bool((grid_supported >> 7) & 0x1),
        'grid_100ghz': bool((grid_supported >> 5) & 0x1),
        'grid_50ghz': bool((grid_supported >> 4) & 0x1),
        'grid_33ghz': bool((grid_supported >> 6) & 0x1),
        'grid_25ghz': bool((grid_supported >> 3) & 0x1),
        'low_channel': low_ch,
        'high_channel': high_ch,
        'low_freq_ghz': low_freq,
        'high_freq_ghz': high_freq,
    }


def set_laser_freq(port, freq, grid=75):
    """
    Set the laser frequency.

    Args:
        port: OOM port object
        freq: Target frequency in GHz
        grid: Frequency grid to use (75 or 100 GHz)

    Returns:
        True on success, False on failure.
    """
    oom = _get_oom()
    freq_config = get_supported_freq_config(port)
    if freq_config is None:
        print("Error: Cannot read supported frequency configuration")
        return False

    if grid == 75:
        if not freq_config['grid_75ghz']:
            print("Error: 75 GHz grid not supported by module")
            return False
        grid_reg = GRID_SPACING_TO_REG[75]
        channel_number = int(round((freq - 193100) / 25))
        if channel_number % 3 != 0:
            print("Error: Frequency not aligned to 75 GHz grid")
            return False
    elif grid == 100:
        if not freq_config['grid_100ghz']:
            print("Error: 100 GHz grid not supported by module")
            return False
        grid_reg = GRID_SPACING_TO_REG[100]
        channel_number = int(round((freq - 193100) / 100))
    else:
        print(f"Error: Unsupported grid spacing: {grid} GHz")
        return False

    if channel_number < freq_config['low_channel'] or channel_number > freq_config['high_channel']:
        print(f"Error: Frequency {freq} GHz out of range "
              f"({freq_config['low_freq_ghz']}-{freq_config['high_freq_ghz']} GHz)")
        return False

    oom.oom_set_keyvalue(port, 'CCMIS_TX1_GRID_SPACING', grid_reg)
    oom.oom_set_keyvalue(port, 'CCMIS_TX1_CHANNEL_NUMBER', channel_number)
    return True


# ============================================================
# TX Power Management
# ============================================================

def get_supported_power_config(port):
    """
    Read the supported TX output power range from Page 0x04.

    Returns:
        dict with keys:
            'min_power_dbm': minimum programmable output power in dBm
            'max_power_dbm': maximum programmable output power in dBm
        or None on error.
    """
    min_pwr = _get_keyval_int(port, 'CCMIS_MIN_PROG_OUTPUT_POWER')
    max_pwr = _get_keyval_int(port, 'CCMIS_MAX_PROG_OUTPUT_POWER')
    if min_pwr is None or max_pwr is None:
        return None
    return {
        'min_power_dbm': _to_signed16(min_pwr) / 100.0,
        'max_power_dbm': _to_signed16(max_pwr) / 100.0,
    }


def get_tx_config_power(port):
    """
    Read the configured TX output power.

    Returns:
        float: Configured TX power in dBm, or None on error.
    """
    val = _get_keyval_int(port, 'CCMIS_TX1_TARGET_OUTPUT_POWER')
    if val is None:
        return None
    return _to_signed16(val) / 100.0


def set_tx_power(port, tx_power):
    """
    Set the TX output power.

    Args:
        port: OOM port object
        tx_power: Target TX power in dBm

    Returns:
        True on success, False on failure.
    """
    oom = _get_oom()
    pwr_config = get_supported_power_config(port)
    if pwr_config is not None:
        if tx_power < pwr_config['min_power_dbm'] or tx_power > pwr_config['max_power_dbm']:
            print(f"Error: TX power {tx_power} dBm outside supported range "
                  f"({pwr_config['min_power_dbm']}-{pwr_config['max_power_dbm']} dBm)")
            return False

    # Convert dBm to register value (signed 16-bit, scale 100)
    reg_val = int(round(tx_power * 100))
    if reg_val < 0:
        reg_val += 0x10000
    oom.oom_set_keyvalue(port, 'CCMIS_TX1_TARGET_OUTPUT_POWER', reg_val)
    time.sleep(1)
    return True


# ============================================================
# Tuning Status
# ============================================================

def get_tuning_in_progress(port):
    """
    Read the tuning-in-progress flag.

    Returns:
        bool: True if tuning is in progress, False otherwise.
    """
    val = _get_keyval_int(port, 'CCMIS_TX_TUNING_IN_PROGRESS')
    return bool(val) if val is not None else None


def get_wavelength_unlocked(port):
    """
    Read the wavelength unlocked status.

    Returns:
        bool: True if wavelength is unlocked, False if locked.
    """
    val = _get_keyval_int(port, 'CCMIS_TX_WAVELENGTH_UNLOCKED')
    return bool(val) if val is not None else None


def wait_for_tuning(port, timeout=30):
    """
    Poll until laser tuning completes or timeout expires.
    Waits for tuning to start first, then for it to finish.

    Args:
        port: OOM port object
        timeout: Maximum wait time in seconds (default 30)

    Returns:
        True if tuning completed, False on timeout.
    """
    import time as _time
    _time.sleep(1)
    elapsed = 1
    while elapsed < timeout:
        tuning = get_tuning_in_progress(port)
        wl_unlocked = get_wavelength_unlocked(port)
        if tuning is False and wl_unlocked is False:
            return True
        _time.sleep(2)
        elapsed += 2
    return False


def configure_coherent(port, laser_freq=None, grid=75, tx_power=None):
    """
    Configure coherent controls for CMIS modules.

    Returns:
        bool: True if all requested operations succeeded, False otherwise.
    """
    ok = True

    if laser_freq is not None:
        print(f"  Setting laser frequency to {laser_freq} GHz (grid: {grid} GHz)...")
        if set_laser_freq(port, laser_freq, grid):
            print("  Waiting for tuning to complete...")
            if wait_for_tuning(port):
                print("  Laser frequency set successfully")
            else:
                print("  Laser frequency set (tuning still in progress)")
        else:
            print("  Failed to set laser frequency")
            ok = False

    if tx_power is not None:
        print(f"  Setting TX power to {tx_power} dBm...")
        if set_tx_power(port, tx_power):
            print("  TX power set successfully")
        else:
            print("  Failed to set TX power")
            ok = False

    return ok


def handle_laser_freq(port, freq_arg, grid=75):
    """Get or set laser frequency. freq_arg==0 means get, otherwise set."""
    if freq_arg == 0:
        config_freq = get_laser_config_freq(port)
        current_freq = get_current_laser_freq(port)
        cur_grid = get_freq_grid(port)
        if config_freq:
            print(f"\n  Configured Frequency : {config_freq:.3f} GHz")
        else:
            print("\n  Configured Frequency : N/A")
        if current_freq:
            print(f"  Current Frequency    : {current_freq:.3f} GHz")
        else:
            print("  Current Frequency    : N/A")
        if cur_grid:
            print(f"  Frequency Grid       : {cur_grid} GHz")
        else:
            print("  Frequency Grid       : N/A")
    else:
        print(f"\nSetting laser frequency to {freq_arg} GHz (grid: {grid} GHz)...")
        if set_laser_freq(port, freq_arg, grid):
            print("  Waiting for tuning to complete...")
            if wait_for_tuning(port):
                print("  Done")
            else:
                print("  Done (tuning still in progress)")
        else:
            print("  Failed")


def handle_tx_power(port, power_arg):
    """Get or set TX output power. power_arg is None means get, otherwise set."""
    if power_arg is None:
        tx_pwr = get_tx_config_power(port)
        pwr_config = get_supported_power_config(port)
        if tx_pwr is not None:
            print(f"\n  Configured TX Power  : {tx_pwr:.2f} dBm")
        else:
            print("\n  Configured TX Power  : N/A")
        if pwr_config:
            print(f"  TX Power Range       : "
                  f"{pwr_config['min_power_dbm']:.2f} to "
                  f"{pwr_config['max_power_dbm']:.2f} dBm")
    else:
        print(f"\nSetting TX power to {power_arg} dBm...")
        if set_tx_power(port, power_arg):
            print("  Done")
        else:
            print("  Failed")


def get_laser_tuning_summary(port):
    """
    Read the laser tuning detail flags.

    Returns:
        list: List of active tuning status flag strings.
    """
    result = _get_keyval_int(port, 'CCMIS_TX_TUNING_DETAIL')
    if result is None:
        return []
    flags = []
    for bit, name in TUNING_DETAIL_FLAGS:
        if (result >> bit) & 0x1:
            flags.append(name)
    return flags


# ============================================================
# Performance Monitoring (Pages 0x34 and 0x35)
# ============================================================

def get_pm_all(port):
    """
    Read all C-CMIS performance monitoring data from Pages 0x34 and 0x35.

    Returns:
        dict: Dictionary of PM parameters with avg/min/max values.
            Units: CD (ps/nm), DGD (ps), SOPMD (ps^2), PDL (dB),
            OSNR (dB), eSNR (dB), CFO (MHz), EVM (%),
            TX/RX power (dBm), SOP ROC (krad/s), MER (dB),
            preFEC_BER (ratio), preFEC_uncorr_frame_ratio (ratio).
    """
    pm = {}

    # FEC PM from Page 0x34
    rx_bits = _get_keyval_64(port, 'CCMIS_RX_BITS_PM_HI', 'CCMIS_RX_BITS_PM_LO')
    rx_bits_subint = _get_keyval_64(port, 'CCMIS_RX_BITS_SUBINT_PM_HI', 'CCMIS_RX_BITS_SUBINT_PM_LO')
    rx_corr_bits = _get_keyval_64(port, 'CCMIS_RX_CORR_BITS_PM_HI', 'CCMIS_RX_CORR_BITS_PM_LO')
    rx_min_corr = _get_keyval_64(port, 'CCMIS_RX_MIN_CORR_BITS_SUBINT_PM_HI', 'CCMIS_RX_MIN_CORR_BITS_SUBINT_PM_LO')
    rx_max_corr = _get_keyval_64(port, 'CCMIS_RX_MAX_CORR_BITS_SUBINT_PM_HI', 'CCMIS_RX_MAX_CORR_BITS_SUBINT_PM_LO')

    if rx_bits_subint and rx_bits:
        pm['preFEC_BER_avg'] = rx_corr_bits / rx_bits if rx_corr_bits is not None else 1.0
        pm['preFEC_BER_min'] = rx_min_corr / rx_bits_subint if rx_min_corr is not None else 1.0
        pm['preFEC_BER_max'] = rx_max_corr / rx_bits_subint if rx_max_corr is not None else 1.0
    else:
        pm['preFEC_BER_avg'] = 1.0
        pm['preFEC_BER_min'] = 1.0
        pm['preFEC_BER_max'] = 1.0

    rx_frames = _get_keyval_int(port, 'CCMIS_RX_FRAMES_PM')
    rx_frames_subint = _get_keyval_int(port, 'CCMIS_RX_FRAMES_SUBINT_PM')
    rx_uncorr = _get_keyval_int(port, 'CCMIS_RX_FRAMES_UNCORR_ERR_PM')
    rx_min_uncorr = _get_keyval_int(port, 'CCMIS_RX_MIN_FRAMES_UNCORR_SUBINT_PM')
    rx_max_uncorr = _get_keyval_int(port, 'CCMIS_RX_MAX_FRAMES_UNCORR_SUBINT_PM')

    if rx_frames_subint and rx_frames:
        pm['preFEC_uncorr_frame_ratio_avg'] = rx_uncorr / rx_frames if rx_uncorr is not None else 0
        pm['preFEC_uncorr_frame_ratio_min'] = rx_min_uncorr / rx_frames_subint if rx_min_uncorr is not None else 0
        pm['preFEC_uncorr_frame_ratio_max'] = rx_max_uncorr / rx_frames_subint if rx_max_uncorr is not None else 0
    else:
        pm['preFEC_uncorr_frame_ratio_avg'] = 0
        pm['preFEC_uncorr_frame_ratio_min'] = 0
        pm['preFEC_uncorr_frame_ratio_max'] = 0

    # Link PM from Page 0x35
    # CD: signed 32-bit, ps/nm
    pm['rx_cd_avg'] = _to_signed32(_get_keyval_int(port, 'CCMIS_RX_AVG_CD_PM'))
    pm['rx_cd_min'] = _to_signed32(_get_keyval_int(port, 'CCMIS_RX_MIN_CD_PM'))
    pm['rx_cd_max'] = _to_signed32(_get_keyval_int(port, 'CCMIS_RX_MAX_CD_PM'))

    # DGD: unsigned 16-bit / 100, ps
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_DGD_PM')
        pm[f'rx_dgd_{stat}'] = val / 100.0 if val is not None else None

    # SOPMD: unsigned 16-bit / 100, ps^2
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_SOPMD_PM')
        pm[f'rx_sopmd_{stat}'] = val / 100.0 if val is not None else None

    # PDL: unsigned 16-bit / 10, dB
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_PDL_PM')
        pm[f'rx_pdl_{stat}'] = val / 10.0 if val is not None else None

    # OSNR: unsigned 16-bit / 10, dB
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_OSNR_PM')
        pm[f'rx_osnr_{stat}'] = val / 10.0 if val is not None else None

    # eSNR: unsigned 16-bit / 10, dB
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_ESNR_PM')
        pm[f'rx_esnr_{stat}'] = val / 10.0 if val is not None else None

    # CFO: signed 16-bit, MHz
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_CFO_PM')
        pm[f'rx_cfo_{stat}'] = _to_signed16(val) if val is not None else None

    # EVM: unsigned 16-bit / 655.35, %
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_EVM_PM')
        pm[f'rx_evm_{stat}'] = val / 655.35 if val is not None else None

    # TX power: signed 16-bit / 100, dBm
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_TX_{stat.upper()}_POWER_PM')
        pm[f'tx_power_{stat}'] = _to_signed16(val) / 100.0 if val is not None else None

    # RX total power: signed 16-bit / 100, dBm
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_POWER_PM')
        pm[f'rx_power_{stat}'] = _to_signed16(val) / 100.0 if val is not None else None

    # RX signal power: signed 16-bit / 100, dBm
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_SIG_POWER_PM')
        pm[f'rx_sigpwr_{stat}'] = _to_signed16(val) / 100.0 if val is not None else None

    # SOP ROC: unsigned 16-bit, krad/s
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_SOPROC_PM')
        pm[f'rx_soproc_{stat}'] = val if val is not None else None

    # MER: unsigned 16-bit / 10, dB
    for stat in ('avg', 'min', 'max'):
        val = _get_keyval_int(port, f'CCMIS_RX_{stat.upper()}_MER_PM')
        pm[f'rx_mer_{stat}'] = val / 10.0 if val is not None else None

    return pm


# ============================================================
# Display Helpers
# ============================================================

def print_coherent_status(port):
    """Print a formatted summary of coherent module status."""
    if not helpers.is_coherent_module(port):
        print("  Not a coherent module")
        return

    print("\n--- Coherent Module Status ---\n")

    # Laser frequency
    config_freq = get_laser_config_freq(port)
    current_freq = get_current_laser_freq(port)
    freq_grid = get_freq_grid(port)
    print(f"  Configured Frequency : {config_freq:.3f} GHz" if config_freq else "  Configured Frequency : N/A")
    print(f"  Current Frequency    : {current_freq:.3f} GHz" if current_freq else "  Current Frequency    : N/A")
    print(f"  Frequency Grid       : {freq_grid} GHz" if freq_grid else "  Frequency Grid       : N/A")

    # Supported frequency range
    freq_config = get_supported_freq_config(port)
    if freq_config:
        grids = []
        for g in ('75ghz', '100ghz', '50ghz', '33ghz', '25ghz'):
            if freq_config.get(f'grid_{g}'):
                grids.append(g.replace('ghz', ' GHz'))
        print(f"  Supported Grids      : {', '.join(grids) if grids else 'None'}")
        print(f"  Frequency Range      : {freq_config['low_freq_ghz']}-{freq_config['high_freq_ghz']} GHz")

    # TX power
    tx_config_pwr = get_tx_config_power(port)
    print(f"  Configured TX Power  : {tx_config_pwr:.2f} dBm" if tx_config_pwr is not None else "  Configured TX Power  : N/A")

    pwr_config = get_supported_power_config(port)
    if pwr_config:
        print(f"  TX Power Range       : {pwr_config['min_power_dbm']:.2f} to {pwr_config['max_power_dbm']:.2f} dBm")

    # Tuning status
    tuning = get_tuning_in_progress(port)
    wl_unlocked = get_wavelength_unlocked(port)
    tuning_flags = get_laser_tuning_summary(port)
    print(f"  Tuning In Progress   : {tuning}" if tuning is not None else "  Tuning In Progress   : N/A")
    print(f"  Wavelength Unlocked  : {wl_unlocked}" if wl_unlocked is not None else "  Wavelength Unlocked  : N/A")
    if tuning_flags:
        print(f"  Tuning Flags         : {', '.join(tuning_flags)}")


def print_pm_summary(port):
    """Print a formatted summary of all C-CMIS performance monitoring data."""
    if not helpers.is_coherent_module(port):
        print("  Not a coherent module")
        return

    pm = get_pm_all(port)
    if not pm:
        print("  No PM data available")
        return

    print("\n--- C-CMIS Performance Monitoring ---\n")

    def _fmt(val, fmt='.4f'):
        if val is None:
            return 'N/A'
        return f'{val:{fmt}}'

    def _fmt_sci(val):
        if val is None:
            return 'N/A'
        return f'{val:.2e}'

    print(f"  {'Parameter':<30} {'Avg':>14} {'Min':>14} {'Max':>14}")
    print(f"  {'-'*30} {'-'*14} {'-'*14} {'-'*14}")

    print(f"  {'Pre-FEC BER':<30} {_fmt_sci(pm.get('preFEC_BER_avg')):>14} "
          f"{_fmt_sci(pm.get('preFEC_BER_min')):>14} {_fmt_sci(pm.get('preFEC_BER_max')):>14}")
    print(f"  {'Uncorr Frame Ratio':<30} {_fmt_sci(pm.get('preFEC_uncorr_frame_ratio_avg')):>14} "
          f"{_fmt_sci(pm.get('preFEC_uncorr_frame_ratio_min')):>14} {_fmt_sci(pm.get('preFEC_uncorr_frame_ratio_max')):>14}")

    pm_params = [
        ('CD [ps/nm]',         'rx_cd',      '.1f'),
        ('DGD [ps]',           'rx_dgd',     '.4f'),
        ('SOPMD [ps^2]',       'rx_sopmd',   '.4f'),
        ('PDL [dB]',           'rx_pdl',     '.2f'),
        ('OSNR [dB]',          'rx_osnr',    '.2f'),
        ('eSNR [dB]',          'rx_esnr',    '.2f'),
        ('CFO [MHz]',          'rx_cfo',     '.1f'),
        ('EVM [%]',            'rx_evm',     '.4f'),
        ('TX Power [dBm]',     'tx_power',   '.2f'),
        ('RX Power [dBm]',     'rx_power',   '.2f'),
        ('RX Sig Power [dBm]', 'rx_sigpwr',  '.2f'),
        ('SOP ROC [krad/s]',   'rx_soproc',  '.1f'),
        ('MER [dB]',           'rx_mer',     '.2f'),
    ]

    for label, prefix, fmt in pm_params:
        avg = pm.get(f'{prefix}_avg')
        mn = pm.get(f'{prefix}_min')
        mx = pm.get(f'{prefix}_max')
        print(f"  {label:<30} {_fmt(avg, fmt):>14} {_fmt(mn, fmt):>14} {_fmt(mx, fmt):>14}")
