# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import os

class XcvrPins:
	"""
	A class used to set/get xcvr discrete signal state.

	Attributes:
		ports_num: integer indicates number of ports.
	"""


	_cpld_mapping = {
		0:  "13-0061",
		1:  "15-0062",
	}

	def _get_cpld(self, port):
		"""
		Returns CPLD index for given logical port (1-based).
		"""
		if 0 <= port <= 15:
			return 0
		elif 16 <= port <= 31:
			return 1
		else:
			raise ValueError("Port number {} is out of range[1,{}]".format(port, self.ports_num))

	def _get_sysfs_path(self, cpld_idx):
		return f"/sys/bus/i2c/devices/{self._cpld_mapping[cpld_idx]}/"


	def __init__(self, ports_num):
		self.ports_num = ports_num
		self.ports_mask = 0
		for port in range(0, ports_num):
			self.ports_mask |= (1 << port)
		self.sysfs_path_present = "module_present_"
		self.sysfs_path_low_power = "module_lpmode_"
		self.sysfs_path_reset = "module_reset_"

	def __get_xcvr_pin_state(self, pin_name_base, port_num):
		"""Get xcvr pin state for a single port.

		Args:
			pin_name_base: string of xcvr pin filename excluding port number.
			port_num : integer representing port number (1-based).
		Returns:
			Integer representing pin state (0 or 1) for the specified port
			number or None in case of error.

		Notes:
			The pins description can be found at:
			https://bbk.xsightlabs.com/projects/XS/repos/xplatform/browse/device/accton/as9647-32d/modules/x86-64-as9647-32d-cpld.c
		"""
		if port_num < 1 or port_num > self.ports_num:
			print(f"Error: port number {port_num} is out of range [1, {self.ports_num}]")
			return None
		port_idx = port_num - 1
		cpld_idx = self._get_cpld(port_idx)
		sysfs_path = self._get_sysfs_path(cpld_idx)
		filename = sysfs_path + pin_name_base + str(port_num)
		if os.path.isfile(filename):
			with open(filename, "r") as file:
				return int(file.readline()) & 1
		else:
			print("File {} doesn't exist.".format(filename))
			return None

	def __get_xcvr_pins_state(self, pin_name_base):
		"""Get xcvr pin state for input `pin_name_base` for all ports.

		Args:
			pin_name_base: string of xcvr pin filename excluding port number.

		Returns:
			Integer representing bitmap of pin state for each port
			number or None in case of error.

		Notes:
			The returned pin state value depends on the specific pin.
			The pins description can be found at:
			https://bbk.xsightlabs.com/projects/XS/repos/xplatform/browse/device/accton/as9647-32d/modules/x86-64-as9647-32d-cpld.c

		"""
		bitmap = 0
		for port in range(0, self.ports_num):
			pin_state = self.__get_xcvr_pin_state(pin_name_base, port + 1)
			if pin_state is None:
				return None
			bitmap |= (pin_state << port)
		return bitmap


	def __set_xcvr_pin_state(self, pin_name_base, port_bitmap, state):
		"""Set xcvr pin state for input `pin_path` for all ports.

		Args:
			pin_name_base: string of xcvr pin filename excluding port number.
			port_bitmap: integer representing bitmap of port numbers.
			state: integer representing the pin state to change for.

		Returns:
			None.

		Notes:
			The input pin state value depends on the specific pin.
			The pins description can be found at:
			https://bbk.xsightlabs.com/projects/XS/repos/xplatform/browse/device/accton/as9647-32d/modules/x86-64-as9647-32d-cpld.c

		"""
		for port in range(0, self.ports_num):
			if port_bitmap & (1 << port):
				cpld_idx = self._get_cpld(port)
				sysfs_path = self._get_sysfs_path(cpld_idx)
				filename = sysfs_path + pin_name_base + str(port + 1)
				if os.path.isfile(filename):
					with open(filename, "w") as file:
						file.write(str(state))
				else:
					print("File {} doesn't exist.".format(filename))
					break

	def get_xcvr_interrupt_pins(self):
		"""Get xcvr interrupt pin state for all ports.

		Args:
			None.

		Returns:
			Integer representing bitmap of interrupt pin state for each port
			number starting from port 1 or None in case of error.
			Interrupt pin state description:
				1: Interrupt.
				0: No interrupt.
		"""
		print("Error: Not implemented for this module.")
		return None

	def get_xcvr_present_pins(self):
		"""Get xcvr present pin state for all ports.

		Args:
			None.

		Returns:
			Integer representing bitmap of present pin state for each port
			number starting from port 1 or None in case of error
			Present pin state description:
				1: Present.
				0: Not Present.
		"""
		return self.__get_xcvr_pins_state(self.sysfs_path_present)

	def get_xcvr_lowpower_pins(self):
		"""Get xcvr low power pin state for all ports.

		Args:
			None.

		Returns:
			Integer representing bitmap of low power pin state for each port
			number starting from port 1 or None in case of error.
			Low power pin state description:
				1: Low power mode.
				0: High power mode.
		"""
		return self.__get_xcvr_pins_state(self.sysfs_path_low_power)

	def get_xcvr_lowpower_pin(self, port):
		"""Get xcvr low power pin state for port number `port`

		Args:
			port: integer indicates port number (1-based) to get its pin state.

		Returns:
			Integer representing low power pin state for the specified port
			number or None if port is out of range.
			Low power pin state description:
				1: Low power mode.
				0: High power mode.
		"""
		return self.__get_xcvr_pin_state(self.sysfs_path_low_power, port)

	def get_xcvr_reset_pins(self):
		"""Get xcvr reset pin state for all ports.

		Args:
			None.

		Returns:
			Integer representing bitmap of reset pin state for each port
			number starting from port 1 or None in case of error.
			Reset pin state description:
				1: Reset
				0: No Reset.
		"""
		return self.__get_xcvr_pins_state(self.sysfs_path_reset)

	def set_xcvr_lowpower_pins(self, port_bitmap, state):
		"""Set xcvr low power pin state to `state` for each port number
		which is indicated by set bit position in `port_bitmap`

		Args:
			port_bitmap: integer representing bitmap of port numbers.
			state: integer representing the pin state to change for.
			low power pin state description:
				1: Low power mode.
				0: High power mode.

		Returns:
			None.
		"""
		self.__set_xcvr_pin_state(self.sysfs_path_low_power, port_bitmap, state)

	def set_xcvr_lowpower_pin(self, port, state):
		"""Set xcvr low power pin state to `state` for port number `port`

		Args:
			port: integer indicates port number to change its pin state.
			state: integer representing the pin state to change for.
			low power pin state description:
				1: Low power mode.
				0: High power mode.

		Returns:
			None.
		"""
		if 1 <= port <= self.ports_num:
			port_bitmap = 1 << (port-1)
			self.set_xcvr_lowpower_pins(port_bitmap, state)
		else:
			print("Error: port number {} is out of range[{},{}]".format(
				port, 1, self.ports_num))

	def set_xcvr_reset_pins(self, port_bitmap, state):
		"""Set xcvr reset pin state to `state` for each port number
		which is indicated by set bit position in `port_bitmap`

		Args:
			port_bitmap: integer representing bitmap of port numbers.
			state: integer representing the pin state to change for.
			reset pin state description:
				1: Reset.
				0: No Reset.

		Returns:
			None.
		"""
		self.__set_xcvr_pin_state(self.sysfs_path_reset, port_bitmap, state)

	def set_xcvr_reset_pin(self, port, state):
		"""Set xcvr reset pin state to `state` for port number `port`

		Args:
			port: integer indicates port number to change its pin state.
			state: integer representing the pin state to change for.
			reset pin state description:
				1: Reset.
				0: No Reset.

		Returns:
			None.
		"""
		if 1 <= port <= self.ports_num:
			port_bitmap = 1 << (port-1)
			self.set_xcvr_reset_pins(port_bitmap, state)
		else:
			print("Error: port number {} is out of range[{},{}]".format(
				port, 1, self.ports_num))
