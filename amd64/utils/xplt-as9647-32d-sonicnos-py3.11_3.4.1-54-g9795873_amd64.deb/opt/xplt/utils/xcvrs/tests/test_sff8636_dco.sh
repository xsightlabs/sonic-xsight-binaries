#!/bin/bash
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.
#
# SFF-8636 DCO regression test suite.
# Exercises DCO wavelength control via calib.py / config.py and produces
# plain-text results + JUnit XML for CI.
#
# Requires an SFF-8636 DCO module (e.g. FTLC3351R3PL1) to be physically
# present in the specified port.  The script validates this at startup
# and exits with code 2 if no suitable module is detected.  Must be run
# on real hardware from the deployed /opt/xplt/ installation.
#
# Usage: sudo ./test_sff8636_dco.sh <dco_port> [non_coherent_port]
#   dco_port          - port with an SFF-8636 DCO module (required)
#   non_coherent_port - port with a non-coherent module (optional;
#                       when omitted, non-coherent rejection tests
#                       are skipped)

set -u

CALIB="/opt/xplt/utils/xcvrs/calib.py"
CONFIG="/opt/xplt/utils/xcvrs/config.py"

PORT="${1:?Usage: $0 <dco_port> [non_coherent_port]}"
NC_PORT="${2:-}"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG="test_sff8636_dco_port${PORT}_${TIMESTAMP}.log"
XML="test_sff8636_dco_port${PORT}_${TIMESTAMP}.xml"

TUNING_TIMEOUT=30

# Verify the specified port has an SFF-8636 DCO module
probe=$($CALIB "$PORT" --coherent_status 2>&1)
if echo "$probe" | grep -q "Not a coherent module"; then
    echo "ERROR: Port $PORT does not have a coherent module. Cannot run SFF-8636 DCO tests."
    echo "Usage: $0 <dco_port> [non_coherent_port]"
    exit 2
fi
if echo "$probe" | grep -q "UNKNOWN\|No Module"; then
    echo "ERROR: Port $PORT has no module inserted. Cannot run SFF-8636 DCO tests."
    exit 2
fi
# DCO modules always report "Current Frequency    : N/A"
if ! echo "$probe" | grep -q "Current Frequency.*N/A"; then
    echo "ERROR: Port $PORT does not appear to be an SFF-8636 DCO module"
    echo "  (has current frequency readback)."
    echo "Use test_ccmis.sh for CMIS coherent modules."
    exit 2
fi

pass_count=0
fail_count=0
total_count=0

test_names=()
test_statuses=()
test_outputs=()
test_times=()

ORIG_FREQ=""
ORIG_GRID=""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

log() {
    echo "$@" | tee -a "$LOG"
}

wait_dco_freq_settle() {
    log "  (waiting for frequency to apply, timeout ${TUNING_TIMEOUT}s)"
    local target="$1"
    local elapsed=0
    while [ "$elapsed" -lt "$TUNING_TIMEOUT" ]; do
        local out
        out=$($CALIB "$PORT" --laser_freq 2>&1)
        if echo "$out" | grep -q "Configured Frequency.*${target}"; then
            log "  (frequency applied after ${elapsed}s)"
            return 0
        fi
        sleep 2
        elapsed=$((elapsed + 2))
    done
    log "  (frequency did not apply within ${TUNING_TIMEOUT}s)"
    return 1
}

run_test() {
    local name="$1"; shift
    local should_match="$1"; shift
    local pattern="$1"; shift
    local cmd="$*"

    total_count=$((total_count + 1))

    log ""
    log "--- [$total_count] $name ---"
    log "CMD: $cmd"
    log "CHECK: pattern '${pattern}' should be $([ "$should_match" -eq 1 ] && echo 'PRESENT' || echo 'ABSENT')"

    local start_s
    start_s=$(date +%s%N)

    local output
    output=$(eval "$cmd" 2>&1)
    local rc=$?

    local end_s
    end_s=$(date +%s%N)
    local elapsed_ms=$(( (end_s - start_s) / 1000000 ))

    echo "$output" >> "$LOG"

    local matched=0
    if echo "$output" | grep -qE "$pattern"; then
        matched=1
    fi

    local status="FAIL"
    if [ "$should_match" -eq 1 ] && [ "$matched" -eq 1 ]; then
        status="PASS"
    elif [ "$should_match" -eq 0 ] && [ "$matched" -eq 0 ]; then
        status="PASS"
    fi

    if [ "$status" = "PASS" ]; then
        pass_count=$((pass_count + 1))
        log "RESULT: PASS (${elapsed_ms}ms)"
    else
        fail_count=$((fail_count + 1))
        log "RESULT: FAIL (${elapsed_ms}ms)"
        log "  Expected pattern $([ "$should_match" -eq 1 ] && echo 'PRESENT' || echo 'ABSENT'): $pattern"
    fi

    test_names+=("$name")
    test_statuses+=("$status")
    test_outputs+=("$(echo "$output" | head -30)")
    test_times+=("$elapsed_ms")
}

run_test_multi() {
    local name="$1"; shift
    local cmd="$1"; shift
    local patterns=("$@")

    total_count=$((total_count + 1))

    log ""
    log "--- [$total_count] $name ---"
    log "CMD: $cmd"
    log "CHECK: all patterns must be PRESENT:"
    for pat in "${patterns[@]}"; do
        log "  - '${pat}'"
    done

    local start_s
    start_s=$(date +%s%N)

    local output
    output=$(eval "$cmd" 2>&1)

    local end_s
    end_s=$(date +%s%N)
    local elapsed_ms=$(( (end_s - start_s) / 1000000 ))

    echo "$output" >> "$LOG"

    local status="PASS"
    local missing=""
    for pat in "${patterns[@]}"; do
        if ! echo "$output" | grep -qE "$pat"; then
            status="FAIL"
            missing="$missing  Missing: $pat"$'\n'
        fi
    done

    if [ "$status" = "PASS" ]; then
        pass_count=$((pass_count + 1))
        log "RESULT: PASS (${elapsed_ms}ms)"
    else
        fail_count=$((fail_count + 1))
        log "RESULT: FAIL (${elapsed_ms}ms)"
        log "$missing"
    fi

    test_names+=("$name")
    test_statuses+=("$status")
    test_outputs+=("$(echo "$output" | head -30)")
    test_times+=("$elapsed_ms")
}

xml_escape() {
    local s="$1"
    s="${s//&/&amp;}"
    s="${s//</&lt;}"
    s="${s//>/&gt;}"
    s="${s//\"/&quot;}"
    s="${s//\'/&apos;}"
    echo "$s"
}

generate_junit_xml() {
    local total=$total_count
    local failures=$fail_count

    {
        echo '<?xml version="1.0" encoding="UTF-8"?>'
        echo "<testsuite name=\"sff8636_dco\" tests=\"$total\" failures=\"$failures\" timestamp=\"$(date -Iseconds)\">"

        for i in "${!test_names[@]}"; do
            local tname="${test_names[$i]}"
            local tstatus="${test_statuses[$i]}"
            local toutput="${test_outputs[$i]}"
            local ttime="${test_times[$i]}"
            local ttime_sec
            ttime_sec=$(echo "scale=3; $ttime / 1000" | bc)

            echo "  <testcase name=\"$tname\" classname=\"sff8636_dco\" time=\"$ttime_sec\">"
            if [ "$tstatus" = "FAIL" ]; then
                echo "    <failure message=\"Test $tname failed\">"
                echo "      <![CDATA["
                echo "$(echo "$toutput" | head -30)"
                echo "      ]]>"
                echo "    </failure>"
            fi
            echo "    <system-out>"
            echo "      <![CDATA["
            echo "$(echo "$toutput" | head -30)"
            echo "      ]]>"
            echo "    </system-out>"
            echo "  </testcase>"
        done

        echo "</testsuite>"
    } > "$XML"

    log ""
    log "JUnit XML written to: $XML"
}

save_originals() {
    log ""
    log "=== Saving original laser frequency and grid ==="

    local freq_out
    freq_out=$($CALIB "$PORT" --laser_freq 2>&1)
    ORIG_FREQ=$(echo "$freq_out" | grep "Configured Frequency" | grep -oE '[0-9]+\.[0-9]+' | head -1)
    ORIG_GRID=$(echo "$freq_out" | grep "Frequency Grid" | grep -oE '[0-9]+' | head -1)

    log "  Original Frequency : ${ORIG_FREQ:-N/A} GHz"
    log "  Original Grid      : ${ORIG_GRID:-N/A} GHz"
}

restore_and_settle() {
    if [ -n "$ORIG_FREQ" ]; then
        local grid="${ORIG_GRID:-100}"
        local freq_int="${ORIG_FREQ%%.*}"
        $CALIB "$PORT" --laser_freq "$freq_int" --grid "$grid" > /dev/null 2>&1
        log "  (restored frequency to $freq_int GHz, grid $grid GHz)"
        wait_dco_freq_settle "$freq_int"
    fi
}

# ---------------------------------------------------------------------------
# Test groups
# ---------------------------------------------------------------------------

group1_dco_detection() {
    log ""
    log "========================================"
    log "  Group 1: DCO Detection"
    log "========================================"

    run_test_multi "dco_coherent_status" \
        "$CALIB $PORT --coherent_status" \
        "Configured Frequency" \
        "Current Frequency.*N/A"

    if [ -n "$NC_PORT" ]; then
        run_test "reject_non_coherent_status" \
            1 'Not a coherent module' \
            "$CALIB $NC_PORT --coherent_status"
    else
        log ""
        log "  SKIP: reject_non_coherent_status (no non-coherent port specified)"
    fi
}

group2_coherent_status() {
    log ""
    log "========================================"
    log "  Group 2: Coherent Status (read-only)"
    log "========================================"

    run_test_multi "coherent_status_fields" \
        "$CALIB $PORT --coherent_status" \
        "Configured Frequency" \
        "Current Frequency.*N/A" \
        "Frequency Grid"

    # Current Frequency must always be N/A for DCO modules
    run_test "current_freq_always_na" \
        1 'Current Frequency.*N/A' \
        "$CALIB $PORT --coherent_status"
}

group3_laser_frequency() {
    log ""
    log "========================================"
    log "  Group 3: Laser Frequency"
    log "========================================"

    # Get frequency
    run_test_multi "laser_freq_get" \
        "$CALIB $PORT --laser_freq" \
        "Configured Frequency" \
        "Current Frequency.*N/A" \
        "Frequency Grid"

    # Set frequency on 100 GHz grid
    log ""
    log "  SET: $CALIB $PORT --laser_freq 193400 --grid 100"
    $CALIB "$PORT" --laser_freq 193400 --grid 100 2>&1 | tee -a "$LOG"
    wait_dco_freq_settle "193400"

    run_test "laser_freq_set_100g_verify" \
        1 '193400' \
        "$CALIB $PORT --laser_freq"

    run_test "laser_freq_grid_100g_verify" \
        1 'Frequency Grid.*100' \
        "$CALIB $PORT --laser_freq"

    restore_and_settle
}

group4_laser_freq_50g_grid() {
    log ""
    log "========================================"
    log "  Group 4: Laser Frequency (50 GHz grid)"
    log "========================================"

    # Set frequency on 50 GHz grid (193150 = base + 1*50)
    log ""
    log "  SET: $CALIB $PORT --laser_freq 193150 --grid 50"
    $CALIB "$PORT" --laser_freq 193150 --grid 50 2>&1 | tee -a "$LOG"
    wait_dco_freq_settle "193150"

    run_test "laser_freq_set_50g_verify" \
        1 '193150' \
        "$CALIB $PORT --laser_freq"

    run_test "laser_freq_grid_50g_verify" \
        1 'Frequency Grid.*50' \
        "$CALIB $PORT --laser_freq"

    restore_and_settle
}

group5_tx_power_rejection() {
    log ""
    log "========================================"
    log "  Group 5: TX Power Rejection"
    log "========================================"

    run_test "tx_power_get_rejected" \
        1 'TX power control is not supported' \
        "$CALIB $PORT --tx_power"

    run_test "tx_power_set_rejected" \
        1 'TX power control is not supported' \
        "$CALIB $PORT --tx_power -3.0"
}

group6_pm_rejection() {
    log ""
    log "========================================"
    log "  Group 6: PM Rejection"
    log "========================================"

    run_test "pm_rejected" \
        1 'PM is not supported for SFF-8636 DCO' \
        "$CALIB $PORT --pm"
}

group7_config_integration() {
    log ""
    log "========================================"
    log "  Group 7: Config.py Integration"
    log "========================================"

    run_test "config_laser_freq" \
        1 'set successfully' \
        "$CONFIG $PORT --laser_freq 193400 --grid 100"

    wait_dco_freq_settle "193400"

    run_test "config_laser_freq_verify" \
        1 '193400' \
        "$CALIB $PORT --laser_freq"

    # TX power via config.py should report not supported
    run_test "config_tx_power_rejected" \
        1 'TX power control is not supported' \
        "$CONFIG $PORT --tx_power -3.0"

    restore_and_settle
}

group8_negative_tests() {
    log ""
    log "========================================"
    log "  Group 8: Negative Tests"
    log "========================================"

    if [ -n "$NC_PORT" ]; then
        run_test "reject_non_coherent_laser_freq" \
            1 'Not a coherent module' \
            "$CALIB $NC_PORT --laser_freq"
    else
        log ""
        log "  SKIP: reject_non_coherent_laser_freq (no non-coherent port specified)"
    fi

    # Out of range frequency
    run_test "reject_out_of_range_freq" \
        1 'Error|Failed' \
        "$CALIB $PORT --laser_freq 180000 --grid 100"

    # Frequency not aligned to grid
    run_test "reject_unaligned_freq" \
        1 'Error|Failed' \
        "$CALIB $PORT --laser_freq 193150 --grid 100"

    # Unsupported grid (75 GHz is CMIS-only)
    run_test "reject_unsupported_grid" \
        1 'Error|Failed' \
        "$CALIB $PORT --laser_freq 193400 --grid 75"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    log "========================================"
    log "  SFF-8636 DCO Regression Test Suite"
    log "  Port: $PORT  |  NC Port: ${NC_PORT:-none}"
    log "  Date: $(date)"
    log "========================================"

    save_originals

    group1_dco_detection
    group2_coherent_status
    group3_laser_frequency
    group4_laser_freq_50g_grid
    group5_tx_power_rejection
    group6_pm_rejection
    group7_config_integration
    group8_negative_tests

    log ""
    log "========================================"
    log "  SUMMARY"
    log "========================================"
    log "  Total : $total_count"
    log "  Passed: $pass_count"
    log "  Failed: $fail_count"
    log "========================================"
    log "  Log file : $LOG"

    generate_junit_xml

    if [ "$fail_count" -gt 0 ]; then
        exit 1
    fi
    exit 0
}

main
