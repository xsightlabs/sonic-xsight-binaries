#!/bin/bash
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.
#
# C-CMIS regression test suite.
# Exercises coherent module functionality via calib.py / info.py / config.py
# and produces plain-text results + JUnit XML for CI.
#
# Requires a coherent (ZR/ZR+) module to be physically present in the
# specified port.  The script validates this at startup and exits with
# code 2 if no coherent module is detected.  Must be run on real hardware
# from the deployed /opt/xplt/ installation.
#
# Usage: sudo ./test_ccmis.sh <coherent_port> [non_coherent_port]
#   coherent_port     - port number with a C-CMIS coherent module (required)
#   non_coherent_port - port number with a non-coherent module (optional;
#                       when omitted, two non-coherent validation tests are skipped)

set -u

CALIB="/opt/xplt/utils/xcvrs/calib.py"
INFO="/opt/xplt/utils/xcvrs/info.py"
CONFIG="/opt/xplt/utils/xcvrs/config.py"

PORT="${1:?Usage: $0 <coherent_port> [non_coherent_port]}"
NC_PORT="${2:-}"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG="test_ccmis_port${PORT}_${TIMESTAMP}.log"
XML="test_ccmis_port${PORT}_${TIMESTAMP}.xml"

TUNING_TIMEOUT=30

# Verify the specified port has a coherent module before running tests
probe=$($CALIB "$PORT" --coherent_status 2>&1)
if echo "$probe" | grep -q "Not a coherent module"; then
    echo "ERROR: Port $PORT does not have a coherent module. Cannot run C-CMIS tests."
    echo "Usage: $0 <coherent_port> [non_coherent_port]"
    exit 2
fi
if echo "$probe" | grep -q "UNKNOWN\|No Module"; then
    echo "ERROR: Port $PORT has no module inserted. Cannot run C-CMIS tests."
    exit 2
fi

pass_count=0
fail_count=0
total_count=0

# Parallel arrays for JUnit XML generation
test_names=()
test_statuses=()
test_outputs=()
test_times=()

ORIG_FREQ=""
ORIG_TX_PWR=""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

log() {
    echo "$@" | tee -a "$LOG"
}

wait_tuning_settle() {
    log "  (waiting for tuning to settle, timeout ${TUNING_TIMEOUT}s)"
    local elapsed=0
    while [ "$elapsed" -lt "$TUNING_TIMEOUT" ]; do
        local out
        out=$($CALIB "$PORT" --laser_freq 2>&1)
        if echo "$out" | grep -q "Current Frequency" && \
           ! echo "$out" | grep -q "Current Frequency.*N/A"; then
            log "  (tuning settled after ${elapsed}s)"
            return 0
        fi
        sleep 2
        elapsed=$((elapsed + 2))
    done
    log "  (tuning did not settle within ${TUNING_TIMEOUT}s)"
    return 1
}

# run_test <name> <should_match:1|0> <pattern> <command...>
#   Runs command, captures output, greps for pattern.
#   should_match=1: PASS if pattern found; should_match=0: PASS if pattern NOT found.
run_test() {
    local name="$1"; shift
    local should_match="$1"; shift
    local pattern="$1"; shift
    local cmd="$*"

    total_count=$((total_count + 1))

    log ""
    log "--- [$total_count] $name ---"
    log "CMD: $cmd"
    log "CHECK: pattern '${pattern}' should be $([ "$should_match" -eq 1 ] && echo 'PRESENT' || echo 'ABSENT')"

    local start_s
    start_s=$(date +%s%N)

    local output
    output=$(eval "$cmd" 2>&1)
    local rc=$?

    local end_s
    end_s=$(date +%s%N)
    local elapsed_ms=$(( (end_s - start_s) / 1000000 ))

    echo "$output" >> "$LOG"

    local matched=0
    if echo "$output" | grep -qE "$pattern"; then
        matched=1
    fi

    local status="FAIL"
    if [ "$should_match" -eq 1 ] && [ "$matched" -eq 1 ]; then
        status="PASS"
    elif [ "$should_match" -eq 0 ] && [ "$matched" -eq 0 ]; then
        status="PASS"
    fi

    if [ "$status" = "PASS" ]; then
        pass_count=$((pass_count + 1))
        log "RESULT: PASS (${elapsed_ms}ms)"
    else
        fail_count=$((fail_count + 1))
        log "RESULT: FAIL (${elapsed_ms}ms)"
        log "  Expected pattern $([ "$should_match" -eq 1 ] && echo 'PRESENT' || echo 'ABSENT'): $pattern"
    fi

    test_names+=("$name")
    test_statuses+=("$status")
    test_outputs+=("$(echo "$output" | head -30)")
    test_times+=("$elapsed_ms")
}

# run_test_multi <name> <command> <pattern1> <pattern2> ...
#   PASS only if ALL patterns are found in the output.
run_test_multi() {
    local name="$1"; shift
    local cmd="$1"; shift
    local patterns=("$@")

    total_count=$((total_count + 1))

    log ""
    log "--- [$total_count] $name ---"
    log "CMD: $cmd"
    log "CHECK: all patterns must be PRESENT:"
    for pat in "${patterns[@]}"; do
        log "  - '${pat}'"
    done

    local start_s
    start_s=$(date +%s%N)

    local output
    output=$(eval "$cmd" 2>&1)

    local end_s
    end_s=$(date +%s%N)
    local elapsed_ms=$(( (end_s - start_s) / 1000000 ))

    echo "$output" >> "$LOG"

    local status="PASS"
    local missing=""
    for pat in "${patterns[@]}"; do
        if ! echo "$output" | grep -qE "$pat"; then
            status="FAIL"
            missing="$missing  Missing: $pat"$'\n'
        fi
    done

    if [ "$status" = "PASS" ]; then
        pass_count=$((pass_count + 1))
        log "RESULT: PASS (${elapsed_ms}ms)"
    else
        fail_count=$((fail_count + 1))
        log "RESULT: FAIL (${elapsed_ms}ms)"
        log "$missing"
    fi

    test_names+=("$name")
    test_statuses+=("$status")
    test_outputs+=("$(echo "$output" | head -30)")
    test_times+=("$elapsed_ms")
}

xml_escape() {
    local s="$1"
    s="${s//&/&amp;}"
    s="${s//</&lt;}"
    s="${s//>/&gt;}"
    s="${s//\"/&quot;}"
    s="${s//\'/&apos;}"
    echo "$s"
}

generate_junit_xml() {
    local total=$total_count
    local failures=$fail_count

    {
        echo '<?xml version="1.0" encoding="UTF-8"?>'
        echo "<testsuite name=\"ccmis\" tests=\"$total\" failures=\"$failures\" timestamp=\"$(date -Iseconds)\">"

        for i in "${!test_names[@]}"; do
            local tname="${test_names[$i]}"
            local tstatus="${test_statuses[$i]}"
            local toutput="${test_outputs[$i]}"
            local ttime="${test_times[$i]}"
            local ttime_sec
            ttime_sec=$(echo "scale=3; $ttime / 1000" | bc)

            echo "  <testcase name=\"$tname\" classname=\"ccmis\" time=\"$ttime_sec\">"
            if [ "$tstatus" = "FAIL" ]; then
                echo "    <failure message=\"Test $tname failed\">"
                echo "      <![CDATA["
                echo "$(echo "$toutput" | head -30)"
                echo "      ]]>"
                echo "    </failure>"
            fi
            echo "    <system-out>"
            echo "      <![CDATA["
            echo "$(echo "$toutput" | head -30)"
            echo "      ]]>"
            echo "    </system-out>"
            echo "  </testcase>"
        done

        echo "</testsuite>"
    } > "$XML"

    log ""
    log "JUnit XML written to: $XML"
}

save_originals() {
    log ""
    log "=== Saving original laser frequency and TX power ==="

    local freq_out
    freq_out=$($CALIB "$PORT" --laser_freq 2>&1)
    ORIG_FREQ=$(echo "$freq_out" | grep "Configured Frequency" | grep -oE '[0-9]+\.[0-9]+' | head -1)

    local pwr_out
    pwr_out=$($CALIB "$PORT" --tx_power 2>&1)
    ORIG_TX_PWR=$(echo "$pwr_out" | grep "Configured TX Power" | grep -oE '[-]?[0-9]+\.[0-9]+' | head -1)

    log "  Original Frequency : ${ORIG_FREQ:-N/A} GHz"
    log "  Original TX Power  : ${ORIG_TX_PWR:-N/A} dBm"
}

restore_and_settle() {
    if [ -n "$ORIG_FREQ" ]; then
        $CALIB "$PORT" --laser_freq "$ORIG_FREQ" > /dev/null 2>&1
        log "  (restored frequency to $ORIG_FREQ GHz)"
    fi
    if [ -n "$ORIG_TX_PWR" ]; then
        $CALIB "$PORT" --tx_power "$ORIG_TX_PWR" > /dev/null 2>&1
        log "  (restored TX power to $ORIG_TX_PWR dBm)"
    fi
    wait_tuning_settle
}

# ---------------------------------------------------------------------------
# Test groups
# ---------------------------------------------------------------------------

group1_coherent_detection() {
    log ""
    log "========================================"
    log "  Group 1: Coherent Detection"
    log "========================================"

    run_test "coherent_info_table" \
        1 '[0-9]+\.[0-9]' \
        "$INFO $PORT --coherent -n"

    if [ -n "$NC_PORT" ]; then
        run_test "non_coherent_info_dashes" \
            1 '  -  ' \
            "$INFO $NC_PORT --coherent -n"
    else
        log ""
        log "  SKIP: non_coherent_info_dashes (no non-coherent port specified)"
    fi
}

group2_coherent_status() {
    log ""
    log "========================================"
    log "  Group 2: Coherent Status (read-only)"
    log "========================================"

    run_test_multi "coherent_status" \
        "$CALIB $PORT --coherent_status" \
        "Configured Frequency" \
        "TX Power Range" \
        "Tuning In Progress"
}

group3_laser_frequency() {
    log ""
    log "========================================"
    log "  Group 3: Laser Frequency"
    log "========================================"

    run_test_multi "laser_freq_get" \
        "$CALIB $PORT --laser_freq" \
        "Configured Frequency" \
        "Current Frequency" \
        "Frequency Grid"

    log ""
    log "  SET: $CALIB $PORT --laser_freq 193400"
    $CALIB "$PORT" --laser_freq 193400 2>&1 | tee -a "$LOG"
    wait_tuning_settle

    run_test "laser_freq_set_verify" \
        1 '193400' \
        "$CALIB $PORT --laser_freq"

    restore_and_settle
}

group4_tx_power() {
    log ""
    log "========================================"
    log "  Group 4: TX Power"
    log "========================================"

    run_test_multi "tx_power_get" \
        "$CALIB $PORT --tx_power" \
        "Configured TX Power" \
        "TX Power Range"

    log ""
    log "  SET: $CALIB $PORT --tx_power -3.0"
    $CALIB "$PORT" --tx_power -3.0 2>&1 | tee -a "$LOG"

    run_test "tx_power_set_verify" \
        1 '\-3\.00' \
        "$CALIB $PORT --tx_power"

    restore_and_settle
}

group5_combined_calib() {
    log ""
    log "========================================"
    log "  Group 5: Combined Calib.py Operations"
    log "========================================"

    run_test_multi "combined_set_freq_power_grid" \
        "$CALIB $PORT --laser_freq 193400 --tx_power -3.0 --grid 100 --coherent_status" \
        "Setting laser frequency to 193400.0 GHz" \
        "grid: 100 GHz" \
        "Setting TX power to -3.0 dBm" \
        "Configured Frequency.*193400" \
        "Current Frequency.*193400" \
        "Configured TX Power.*-3.00" \
        "Tuning In Progress.*False"

    run_test_multi "combined_get_freq_power" \
        "$CALIB $PORT --laser_freq --tx_power" \
        "Configured Frequency.*193400" \
        "Current Frequency.*193400" \
        "Configured TX Power.*-3.00"

    restore_and_settle
}

group6_pm() {
    log ""
    log "========================================"
    log "  Group 6: Performance Monitoring"
    log "========================================"

    run_test_multi "pm_display" \
        "$CALIB $PORT --pm" \
        "C-CMIS Performance Monitoring" \
        "CD \[ps/nm\]" \
        "DGD \[ps\]" \
        "OSNR \[dB\]" \
        "TX Power \[dBm\]"
}

group7_config_integration() {
    log ""
    log "========================================"
    log "  Group 7: Config.py Integration"
    log "========================================"

    run_test "config_laser_freq" \
        1 'set successfully' \
        "$CONFIG $PORT --laser_freq 193400"

    run_test "config_tx_power" \
        1 'set successfully' \
        "$CONFIG $PORT --tx_power -3.0"

    run_test "config_grid_100" \
        1 'set successfully' \
        "$CONFIG $PORT --laser_freq 193500 --grid 100"

    restore_and_settle

    run_test_multi "config_combined_set" \
        "$CONFIG $PORT --laser_freq 193400 --tx_power -3.0 --grid 100" \
        "Laser frequency set successfully" \
        "TX power set successfully"

    run_test_multi "config_combined_verify" \
        "$CALIB $PORT --laser_freq --tx_power --coherent_status" \
        "Configured Frequency.*193400" \
        "Current Frequency.*193400" \
        "Frequency Grid.*100" \
        "Configured TX Power.*-3.00" \
        "Tuning In Progress.*False"

    restore_and_settle
}

group8_config_dispatch() {
    log ""
    log "========================================"
    log "  Group 8: Config.py Dispatch Logic"
    log "========================================"

    # Table defaults applied without explicit coherent CLI flags.
    # main() prints "Selected breakout mode:" with -vv; configure_coherent()
    # prints "Setting TX power to -2.0 dBm" from the coherent_defaults table.
    run_test_multi "config_defaults_auto_apply" \
        "$CONFIG $PORT $PORT -vv" \
        "Selected breakout mode:" \
        "Setting TX power to -2.0 dBm"

    # Coherent-only CLI flag: main() skipped (no "Selected breakout mode:"),
    # only coherent path runs.
    run_test "config_coherent_only_skips_main" \
        0 'Selected breakout mode:' \
        "$CONFIG $PORT --tx_power -2.0 -vv"

    # Verify coherent path actually ran in the coherent-only case
    run_test "config_coherent_only_runs_coherent" \
        1 'TX power set successfully' \
        "$CONFIG $PORT --tx_power -2.0"

    restore_and_settle
}

group9_dump_monitor() {
    log ""
    log "========================================"
    log "  Group 9: Dump and Monitor"
    log "========================================"

    run_test "dump_coherent" \
        1 'Coherent Module Status' \
        "$CALIB $PORT -d"

    run_test "monitor_coherent" \
        1 'Laser Config Freq' \
        "$CALIB $PORT -m"
}

group10_negative_tests() {
    log ""
    log "========================================"
    log "  Group 10: Negative Tests"
    log "========================================"

    if [ -n "$NC_PORT" ]; then
        run_test "reject_non_coherent_status" \
            1 'Not a coherent module' \
            "$CALIB $NC_PORT --coherent_status"
    else
        log ""
        log "  SKIP: reject_non_coherent_status (no non-coherent port specified)"
    fi

    run_test_multi "reject_out_of_range_power" \
        "$CALIB $PORT --tx_power 99.0" \
        "Error" \
        "Failed"

    run_test "reject_out_of_range_freq" \
        1 'Failed|Error' \
        "$CALIB $PORT --laser_freq 180000"
}

# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

main() {
    log "========================================"
    log "  C-CMIS Regression Test Suite"
    log "  Port: $PORT  |  NC Port: ${NC_PORT:-none}"
    log "  Date: $(date)"
    log "========================================"

    save_originals

    group1_coherent_detection
    group2_coherent_status
    group3_laser_frequency
    group4_tx_power
    group5_combined_calib
    group6_pm
    group7_config_integration
    group8_config_dispatch
    group9_dump_monitor
    group10_negative_tests

    log ""
    log "========================================"
    log "  SUMMARY"
    log "========================================"
    log "  Total : $total_count"
    log "  Passed: $pass_count"
    log "  Failed: $fail_count"
    log "========================================"
    log "  Log file : $LOG"

    generate_junit_xml

    if [ "$fail_count" -gt 0 ]; then
        exit 1
    fi
    exit 0
}

main
