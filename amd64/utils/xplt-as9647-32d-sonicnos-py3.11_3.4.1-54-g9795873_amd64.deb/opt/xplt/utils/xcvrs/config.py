#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import argparse
import time
import sys
import os
from vendor_info import part_numbers, app_dict, fec_modes, profiles, set_fir_modules, coherent_defaults
import helpers
from helpers import is_sff_8636_module
import ccmis
import sff8636
import qsfp_local

config_modes = [
    'One config for all at once',
    'All configs one by one',
]

breakout_modes = [
    '8H800-8M800',
    '4H400-4M400',
    '2H200-2M200',
    '1H100-1M100',
    '8H400-8M400',
    '4H200-4M200',
    '2H100-2M100',
    '1H50-1M50',
    '4H100-4M100',
]

parser = argparse.ArgumentParser(description='Configure supported optical modules',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type=int,
                    nargs='?',
                    default=None,
                    action=helpers.PortAction,
                    help=f'Starting port. If given alone, only this port is processed; otherwise, all ports are processed')

parser.add_argument('last',
                    type=int,
                    nargs='?',
                    default=None,
                    action=helpers.PortAction,
                    help=f'Ending port number. If provided, ports from first to last (inclusive) are processed')

parser.add_argument('-u',
                    '--url',
                    type=str,
                    help='Hostname or IP address of the oomjsonsvr server')

parser.add_argument('-s',
                    '--standalone',
                    action='store_true',
                    help='Standalone mode')

parser.add_argument('-a',
                    '--autoconfig',
                    action='store_true',
                    help='Automatically select and configure the application based on the selected breakout mode.')

parser.add_argument('--skipfir',
                    action='store_true',
                    help='Skip FIR profile configuration for the modules. Useful for modules that do not require FIR configuration.')

parser.add_argument('-m',
                    '--mode',
                    type=int,
                    choices=[i for i in range(1, (len(config_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, config_modes[i])
                                   for i in range(len(config_modes))))

parser.add_argument('-b',
                    '--breakout',
                    default=4,
                    type=int,
                    choices=[i for i in range(1, (len(breakout_modes) + 1))],
                    help =''.join('[{}] - {}\n'.format(i + 1, breakout_modes[i])
                                   for i in range(len(breakout_modes))))

parser.add_argument('--PN',
                    type=str,
                    choices=part_numbers,
                    default="T-OS8CNS-N00",
                    help=(
                        'Specify the part number to use when running in "One config for all at once" mode (-m 1).\n'
                        'Choose from the supported part numbers below (default: T-OS8CNS-N00):\n' +
                        ''.join('[{}] - {}\n'.format(i + 1, part_numbers[i])
                                for i in range(len(part_numbers)))
                    ))

parser.add_argument('-v',
                    '--verbose',
                    action='count',
                    default=0,
                    help='Increase verbosity level (e.g., -v, -vv, -vvv). Default is 0 (no verbosity).')

coherent_group = parser.add_argument_group(
    'coherent module options',
    'These options can be combined in a single call')

coherent_group.add_argument('--laser_freq',
                    type=float,
                    default=None,
                    metavar='FREQ_GHZ',
                    help='Set laser frequency in GHz for coherent modules (e.g., --laser_freq 193100)')

coherent_group.add_argument('--tx_power',
                    type=float,
                    default=None,
                    metavar='POWER_DBM',
                    help='Set TX output power in dBm for coherent modules (e.g., --tx_power -10.0)')

coherent_group.add_argument('--grid',
                    type=int,
                    default=75,
                    choices=[50, 75, 100],
                    help='Frequency grid in GHz for laser frequency '
                         '(SFF-8636 DCO: 50/100, CMIS: 75/100; default: 75)')


args = parser.parse_args()

if args.standalone:
    import oom
    if args.url != None:
        oom.oomlib.setshim("oomjsonshim", args.url)
else:
    try:
        import oomlwclient as oom
        oom.oomlwclient_init(args.url)
    except:
        if args.verbose > 1:
            print("Running in standalone mode")
        import oom
        if args.url != None:
            oom.oomlib.setshim("oomjsonshim", args.url)

def configure_fec(pi, v_pn, brkout):
    if v_pn in fec_modes:
        fecm = fec_modes[v_pn].get(brkout)
        if fecm is not None:
            if args.verbose > 1:
                print(f"Configuring FEC mode: {fecm}")
            config_fec = f"sudo {calib} {pi} --set_fec {fecm}"

            a = os.popen(config_fec).read()
            if args.verbose > 1: print(a)
        else:
            if args.verbose > 1:
                print(f"FEC mode not found for {v_pn} with breakout mode {brkout}")
    else:
        if args.verbose > 1:
            print(f"FEC mode not found for {v_pn}")

calib = "/opt/xplt/utils/xcvrs/calib.py"

if args.standalone:
    calib = calib + " -s"

def main():
    portlist, max_ports = helpers.get_port_list(oom)
    first, last = helpers.check_port_max_number(args.first, args.last, max_ports)

    brkout = breakout_modes[args.breakout - 1]
    if args.verbose > 1:
        print(f"Selected breakout mode: [{args.breakout}] - {brkout}")

    if args.mode == 1:
        pn = args.PN
        try:
            pni = part_numbers.index(pn) + 1  # P/N index in part_numbers list, starting from 1
        except ValueError:
            print(f"Part number {pn} not found in part_numbers list.")
            sys.exit(1)

        print(f"Configuring ports {first} to {last} with breakout mode: {brkout}")
        if not args.autoconfig and pn in profiles and brkout in profiles[pn]:
            app_id = profiles[pn][brkout][1]
            set_app = f"sudo {calib} {first} {last} --PN {pni} --set_app {app_id}"
        else:
            set_app = f"sudo {calib} {first} {last} --PN {pni} --set_app {brkout}"

        # Build FEC configuration command if FEC mode is available
        fecm = fec_modes.get(pn, {}).get(brkout)
        if fecm is not None:
            if args.verbose > 1:
                print(f"PN: {pn}, Breakout: {brkout}, FEC mode: {fecm}")
            config_fec = f"sudo {calib} {first} {last} --PN {pni} --set_fec {fecm}"
        else:
            if args.verbose > 1:
                print(f"FEC mode not found for {pn}")
            config_fec = None

        cmds = [f"sudo {calib} {first} {last} --PN {pni} -u"]
        if config_fec is not None:
            cmds.append(config_fec)
        if args.skipfir or pn not in set_fir_modules:
            if args.verbose > 1:
                print(f"Skipping FIR configuration for {pn}")
        else:
            cmds.append(f"sudo {calib} {first} {last} --PN {pni} -p {profiles[pn][brkout][0]}")
        cmds.append(set_app)
        cmds.append(f"sudo {calib} {first} {last} --PN {pni} -l 4 0xff off")

        for idx, cmd in enumerate(cmds):
            if args.verbose > 1: print(cmd)
            a = os.popen(cmd).read()
            if idx == 0: time.sleep(1)
            if args.verbose > 0: print(a)
    else:
        first -= 1
        for i in range (first, last):
            port = portlist[i]
            pi = i + 1

            modtype = oom.type_to_str(port.port_type)
            if modtype == 'UNKNOWN':
                modtype = 'No Module'
                continue

            v_pn = oom.oom_get_keyvalue(port, 'VENDOR_PN').strip()
            if args.autoconfig or v_pn not in part_numbers:
                a = os.popen(f"sudo {calib} {pi} -u").read()
                if args.verbose > 1: print(a)
                time.sleep(1)
                if not is_sff_8636_module(port):
                    a = os.popen(f"sudo {calib} {pi} --set_app {brkout}").read()
                    if args.verbose > 0: print(a)
                    a = os.popen(f"sudo {calib} {pi} -l 4 0xff off").read()
                    if args.verbose > 1: print(a)
                else:
                    configure_fec(pi, v_pn, brkout)
                continue

            for pn in part_numbers:
                if pn == v_pn:
                    a = os.popen(f"sudo {calib} {pi} -u").read()
                    if args.verbose > 1: print(a)
                    time.sleep(1)
                    if not args.skipfir and pn in set_fir_modules:
                        a = os.popen(f"sudo {calib} {pi} -p {profiles[pn][brkout][0]}").read()
                        if args.verbose > 1: print(a)
                    if not is_sff_8636_module(port):
                        if pn in profiles and profiles[pn][brkout][1] != 0:
                            a = os.popen(f"sudo {calib} {pi} --set_app {profiles[pn][brkout][1]}").read()
                            if args.verbose > 0: print(a)
                        a = os.popen(f"sudo {calib} {pi} -l 4 0xff off").read()
                        if args.verbose > 1: print(a)
                    else:
                        configure_fec(pi, v_pn, brkout)
                    break

def configure_coherent(portlist, first, last):
    """Configure laser frequency and TX power for coherent/DCO modules."""
    helpers.register("oom", oom)
    import cmis_local

    for i in range(first - 1, last):
        port = portlist[i]
        pi = i + 1

        modtype = oom.type_to_str(port.port_type)
        if modtype == 'UNKNOWN':
            continue

        cmis_local.add_qsfpdd_keys(port)
        qsfp_local.add_qsfp_keys(port)

        is_cmis_coherent = helpers.is_coherent_module(port)
        is_sff_dco = sff8636.supports_dco_wavelength_ctrl(port)
        if not is_cmis_coherent and not is_sff_dco:
            if args.verbose > 1:
                print(f"Port {pi}: Not a coherent/DCO module, skipping")
            continue

        v_pn = oom.oom_get_keyvalue(port, 'VENDOR_PN').strip()
        defaults = coherent_defaults.get(v_pn, {})

        print(f"\n===> Port {pi} (Coherent, PN: {v_pn})")

        laser_freq = args.laser_freq if args.laser_freq is not None else defaults.get('laser_freq')
        grid = args.grid if args.laser_freq is not None else defaults.get('grid', 75)
        tx_power = args.tx_power if args.tx_power is not None else defaults.get('tx_power')

        if is_sff_dco:
            sff8636.configure_coherent(port, laser_freq, grid, tx_power)
        else:
            ccmis.configure_coherent(port, laser_freq, grid, tx_power)


def has_explicit_coherent_args():
    """User passed coherent CLI flags explicitly."""
    return args.laser_freq is not None or args.tx_power is not None

def should_run_coherent():
    """Coherent config needed: explicit CLI args or table defaults exist."""
    return has_explicit_coherent_args() or len(coherent_defaults) > 0

def has_app_config_args():
    return args.mode is not None or args.autoconfig

if __name__ == "__main__":
    # main() runs unless the user passed coherent-only CLI flags (no --mode/--autoconfig).
    # Table defaults in coherent_defaults never suppress main().
    if has_app_config_args() or not has_explicit_coherent_args():
        main()
    if should_run_coherent():
        portlist, max_ports = helpers.get_port_list(oom)
        first, last = helpers.check_port_max_number(args.first, args.last, max_ports)
        configure_coherent(portlist, first, last)
