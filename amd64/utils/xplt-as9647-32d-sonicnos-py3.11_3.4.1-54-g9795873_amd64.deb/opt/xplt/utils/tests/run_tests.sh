#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

# Run tests on XsightOS or SONIC platforms
#
# Can be run from the git tree or from /opt/xplt/utils/tests after install.
#

SONIC_CONFIG="/etc/sonic/config_db.json"

# Script directory (git tree or /opt/xplt/utils/tests)
TESTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UTILS_DIR="$(cd "$TESTS_DIR/.." && pwd)"
PACKAGES_DIR="$UTILS_DIR/packages"

# Installed layout: /opt/xplt/utils/tests and /opt/xplt/venv
if [[ "$TESTS_DIR" == /opt/xplt/* ]]; then
    INSTALLED=1
    PYTHON_PREFIX="/opt/xplt/venv/bin"
    CONTAINER_TESTS_DIR="/opt/xplt/utils/tests"
    CONTAINER_PACKAGES_DIR="/opt/xplt/utils/packages"
else
    INSTALLED=""
    PYTHON_PREFIX=""   # use PATH (python3 -m pytest or pytest)
    CONTAINER_TESTS_DIR="/opt/xplt/utils/tests"
    CONTAINER_PACKAGES_DIR="/opt/xplt/utils/packages"
fi

if [ "$EUID" -ne 0 ]; then
    echo "Error: This script must be run as root (sudo)"
    exit 1
fi

is_sonic_platform() {
    [ -f "$SONIC_CONFIG" ]
}

cleanup_xsightos() {
    echo "Caught signal, restarting services..."
    systemctl start xmon.service
    systemctl start xled.service
    exit 1
}

cleanup_sonic() {
    echo "Caught signal, restarting services..."
    docker exec pmon supervisorctl start thermalctld
    systemctl start system-health.service
    exit 1
}

run_xsightos_tests() {
    echo "Running tests on XsightOS"

    echo "Stopping xled.service..."
    systemctl stop xled.service

    echo "Stopping xmon.service..."
    systemctl stop xmon.service

    trap cleanup_xsightos EXIT

    if [ -n "$INSTALLED" ]; then
        echo "Checking if pytest is installed..."
        local pip_cmd="/opt/xplt/venv/bin/pip"
        $pip_cmd show pytest > /dev/null 2>&1 || $pip_cmd install pytest
        $pip_cmd show pytest-cov > /dev/null 2>&1 || $pip_cmd install pytest-cov
        local pytest_cmd="/opt/xplt/venv/bin/pytest"
    else
        local pytest_cmd
        if [ -x /opt/xplt/venv/bin/pytest ]; then
            pytest_cmd="/opt/xplt/venv/bin/pytest"
        elif command -v pytest >/dev/null 2>&1; then
            pytest_cmd="$(command -v pytest)"
        elif python3 -m pytest --version >/dev/null 2>&1; then
            pytest_cmd="python3 -m pytest"
        else
            echo "Error: pytest not found. Install with: pip install pytest pytest-cov, or install xplt to /opt/xplt (venv has pytest)."
            trap - EXIT
            systemctl start xmon.service
            systemctl start xled.service
            return 1
        fi
    fi

    echo "Running thermal control tests..."
    cd "$TESTS_DIR"
    if [ -n "$INSTALLED" ]; then
        $pytest_cmd test_thermal_control.py
    else
        # Use installed sonic_platform from venv (has chassis); use repo xmon for daemon under test
        export THERMAL_DAEMON_SRC="$UTILS_DIR/xmon.py"
        $pytest_cmd test_thermal_control.py
    fi
    test_result=$?

    trap - EXIT

    echo "Starting xmon.service..."
    systemctl start xmon.service

    echo "Starting xled.service..."
    systemctl start xled.service

    return $test_result
}

run_sonic_tests() {
    echo "Running tests on SONIC"

    echo "Stopping system-health.service..."
    systemctl stop system-health.service

    echo "Stopping thermalctld in pmon container..."
    docker exec pmon supervisorctl stop thermalctld

    trap cleanup_sonic EXIT

    echo "Checking if pytest is installed in pmon container..."
    docker exec pmon pip show pytest > /dev/null 2>&1 || docker exec pmon pip install pytest
    docker exec pmon pip show pytest-cov > /dev/null 2>&1 || docker exec pmon pip install pytest-cov

    echo "Running thermal control tests..."
    if [ -n "$INSTALLED" ]; then
        docker exec -w "$CONTAINER_TESTS_DIR" pmon pytest test_thermal_control.py
    else
        docker exec -v "$TESTS_DIR:$CONTAINER_TESTS_DIR" -v "$PACKAGES_DIR:$CONTAINER_PACKAGES_DIR" \
            -e PYTHONPATH="$CONTAINER_PACKAGES_DIR" -w "$CONTAINER_TESTS_DIR" \
            pmon pytest test_thermal_control.py
    fi
    test_result=$?

    trap - EXIT

    echo "Starting thermalctld in pmon container..."
    docker exec pmon supervisorctl start thermalctld

    echo "Starting system-health.service..."
    systemctl start system-health.service

    return $test_result
}

if is_sonic_platform; then
    run_sonic_tests
else
    run_xsightos_tests
fi

