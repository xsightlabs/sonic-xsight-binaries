# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

import os
import sys
import time
import copy
import logging
import pytest
import shutil
import importlib.util
from unittest import mock
from sonic_platform import helper

pylogger = logging.getLogger(__name__)

api_helper = helper.APIHelper()
is_sonic = api_helper.is_sonic()

# Allow override for running from git (e.g. THERMAL_DAEMON_SRC=/path/to/xmon.py)
try:
    if is_sonic:
        pylogger.info("SONiC NOS detected")
        thermalctld_src_file = os.environ.get("THERMAL_DAEMON_SRC") or "/usr/local/bin/thermalctld"
        thermalctld_dst_file = "/tmp/thermalctld.py"
    else:
        pylogger.info("XsightOS NOS detected")
        thermalctld_src_file = os.environ.get("THERMAL_DAEMON_SRC") or "/opt/xplt/utils/xmon.py"
        thermalctld_dst_file = "/tmp/xmon.py"
    shutil.copy(thermalctld_src_file, thermalctld_dst_file)
except Exception as e:
    raise Exception(f"An error occurred while copying {thermalctld_src_file} to {thermalctld_dst_file}: {e}")

try:
    spec = importlib.util.spec_from_file_location("thermalctld", thermalctld_dst_file)
    thermalctld = importlib.util.module_from_spec(spec)
    sys.modules["thermalctld"] = thermalctld
    spec.loader.exec_module(thermalctld)
except Exception as e:
    raise Exception(f"An error occurred while importing thermalctld: {e}")

thermalctld.ThermalMonitor = mock.MagicMock()

FAN_DEFAULT_DELAY = 20
NEGATIVE_TEMPERATURE_VALUE_TEST = -5.0
LOW_TH_PAIR_IDX = 0
HIGH_TH_PAIR_IDX = 1
FAN_MAX_SPEED = 100
DEFAULT_COOLING_LEVEL = 0

COOL_LEVEL_CHANGE_MSG = "Cooling level index has changed from {} to {}"
FAULTY_SENSOR_AVERAGE_MSG = "Thermal faulty sensor detected on `{}` sensor due to average deviation: value={}, samples={}, average={}"
FAULTY_SENSOR_INVALID_MSG = "Thermal faulty sensor detected due to an invalid sample on `{}` sensor: value={}"
SET_FAN_SPEED_TO_100_MSG = "Set all Fan's speed to 100.0%"
WARN_OVERHEAT_MSG = "Thermal warning overheat detected by '{}' sensor: temperature = {}, threshold = {}"
CRIT_OVERHEAT_MSG = "Thermal critical overheat detected by '{}' sensor: temperature = {}, threshold = {}"
CRIT_REBOOT_MSG = "Thermal critical overheat detected. Rebooting the device."
XCVR_WARN_OVERHEAT_MSG = "XCVR warning overheat: '{}' temperature = {}, threshold = {}"
XCVR_CRIT_OVERHEAT_MSG = "XCVR critical overheat: '{}' temperature = {}, threshold = {}"
XCVR_EVAL_FAILURE_MSG = "Failure in XCVR temperature evaluation: {}"

DEFAULT_CHASSIS_TEMPS = [17.5, 17.5, 4.5, 8.0, 17.0, 22.5, 23.0, 21.5, 18.3, 30.0, 34.0, 27.0]
DEFAULT_CHASSIS_HIGH_THS = [70.0, 59.0, 48.0, 51.0, 70.0, 70.0, 70.0, 70.0, 76.0, 76.0, 76.0, 66.0]
DEFAULT_CHASSIS_CRIT_HIGH_THS = [80.0, 64.0, 53.0, 56.0, 80.0, 80.0, 80.0, 80.0, 81.0, 81.0, 81.0, 71.0]

DEFAULT_XCVR_TEMP = 12.6
DEFAULT_XCVR_HIGH_TH = 75.0
DEFAULT_XCVR_CRIT_HIGH_THS = 80.0

DEFAULT_EXPECTED_LOGS_DICT = {
    "debug": {'cnt': None, 'strs': []},
    "info": {'cnt': 1, 'strs': None},
    "notice": {'cnt': 0, 'strs': []},
    "warning": {'cnt': 0, 'strs': []},
    "error": {'cnt': 0, 'strs': []}
}

# Place this code before importing any platform-related modules to ensure the
# logger is set up for mock functions
from sonic_platform import thermal
thermal.logger = mock.MagicMock()
log_mocks_dict = {
    "debug": thermal.logger.log_debug,
    "info": thermal.logger.log_info,
    "notice": thermal.logger.log_notice,
    "warning": thermal.logger.log_warning,
    "error": thermal.logger.log_error
}

from sonic_platform import thermal_manager

from sonic_platform import platform
chassis = platform.Platform().get_chassis()
num_thermals = len(chassis.get_all_thermals())
num_sfps = len(chassis.get_all_sfps())
num_fans = len(chassis.get_all_fans())
sensor_idx_list = range(0, num_thermals + num_sfps)

default_xcvr_temps = [DEFAULT_XCVR_TEMP] * num_sfps
default_xcvr_high_ths = [DEFAULT_XCVR_HIGH_TH] * num_sfps
default_xcvr_crit_high_ths = [DEFAULT_XCVR_CRIT_HIGH_THS] * num_sfps
default_temps = DEFAULT_CHASSIS_TEMPS + default_xcvr_temps
default_high_ths = DEFAULT_CHASSIS_HIGH_THS + default_xcvr_high_ths
default_crit_high_ths = DEFAULT_CHASSIS_CRIT_HIGH_THS + default_xcvr_crit_high_ths

from sonic_platform import thermal_infos
pcb_sensor_idx_list = thermal_infos.ThermalInfo.PCB_SENSOR_IDX_LIST
asic_sensor_idx_list = thermal_infos.ThermalInfo.ASIC_SENSOR_IDX_LIST
cpu_sensor_idx_list = thermal_infos.ThermalInfo.CPU_SENSOR_IDX_LIST
avg_sensor_idx_list = thermal_infos.ThermalInfo.AVG_SENSOR_IDX_LIST
tc_sensor_idx_list = thermal_infos.ThermalInfo.TC_SENSOR_IDX_LIST
xcvr_sensor_idx_list = thermal_infos.ThermalInfo.XCVR_SENSOR_IDX_LIST
chassis_sensor_idx_list = pcb_sensor_idx_list + asic_sensor_idx_list + cpu_sensor_idx_list

from sonic_platform.thermal_actions import ThermalCriticalAction
ThermalCriticalAction.reboot_device = mock.MagicMock(return_value=True)

from sonic_platform.thermal_device_data import DEVICE_DATA
fan_speed_list = DEVICE_DATA['fan_speed']
thermal_thresholds_list = [None] * len(sensor_idx_list)
sensor_thresholds_list = DEVICE_DATA['thresholds']
for idx, thresholds_list in enumerate(sensor_thresholds_list):
    thresholds = []
    for threshold_pair in thresholds_list:
        low = threshold_pair.split(':')[LOW_TH_PAIR_IDX]
        if low != "NA":
            low = round(float(low), 1)
        high = threshold_pair.split(':')[HIGH_TH_PAIR_IDX]
        if high != "NA":
            high = round(float(high), 1)
        thresholds.append([low, high])
    thermal_thresholds_list[idx] = thresholds


def log_test_header(test_desc):
    pylogger.info("=" * 75)
    pylogger.info(f"Test {test_desc}")
    pylogger.info("=" * 75)


def get_thermal_list(tc_daemon):
    thermal_list = []
    for idx in sensor_idx_list:
        if idx in xcvr_sensor_idx_list:
            sfp_idx = idx - num_thermals + 1
            thermal_list.append(tc_daemon.chassis.get_sfp(sfp_idx).get_thermal(0))
        else:
            thermal_list.append(tc_daemon.chassis.get_thermal(idx))
    return thermal_list


def mock_temps(tc_daemon, temps):
    for idx in range(num_thermals):
        tc_daemon.chassis.get_thermal(idx).get_temperature = mock.MagicMock(return_value=temps[idx])
    for idx in range(num_sfps):
        sfp_thermal = tc_daemon.chassis.get_sfp(idx + 1).get_thermal(0)
        sfp_thermal.get_temperature = mock.MagicMock(return_value=temps[idx + num_thermals])


def setup_xcvr_mocks(tc_daemon, high_ths, crit_high_ths):
    for idx in range(num_sfps):
        sfp = tc_daemon.chassis.get_sfp(idx + 1)
        sfp.get_presence = mock.MagicMock(return_value=True)
        sfp.get_lpmode = mock.MagicMock(return_value=False)
        sfp_thermal = sfp.get_thermal(0)
        sfp_thermal.get_high_threshold = mock.MagicMock(return_value=high_ths[idx])
        sfp_thermal.get_high_critical_threshold = mock.MagicMock(return_value=crit_high_ths[idx])


def clear_logger_mocks():
    for log in log_mocks_dict.values():
        log.reset_mock()


def print_logger_mocks():
    log_printed = False
    pylogger.info("Logs:")
    for log_name, log_mock in log_mocks_dict.items():
        cnts = log_mock.call_count
        if cnts > 0:
            log_printed = True
            pylogger.info(f"  {log_name}:")
            for cnt in range(cnts):
                pylogger.info(f"  - {log_mock.call_args_list[cnt]}")
    if not log_printed:
        pylogger.info("  None")


def assert_logger_mocks(logs_dict):
    for key, value in logs_dict.items():
        logger = log_mocks_dict[key]
        log_count = value['cnt']
        log_strs = value['strs']
        if log_count is not None:
            assert logger.call_count == log_count
            if log_count == 1:
                if log_strs is not None:
                    logger.assert_called_with(log_strs[0])
            elif log_count > 1:
                if log_strs is not None:
                    expected_calls = [mock.call(log_srt) for log_srt in log_strs]
                    logger.assert_has_calls(expected_calls)


def run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_target_speed, fan_current_speed=None,
                            fan_is_under_speed=False, fan_is_over_speed=False):
    mock_temps(tc_daemon, temps)
    clear_logger_mocks()
    pylogger.info("Run thermal control logic")
    tc_daemon.run()
    print_logger_mocks()
    assert_logger_mocks(logs_builder.build())
    check_fan_speed(tc_daemon, fan_target_speed, fan_current_speed, fan_is_under_speed, fan_is_over_speed)


def check_fan_speed(tc_daemon, target_speed, current_speed, is_under_speed, is_over_speed):
    is_fan_speed_ready = True
    fans = tc_daemon.chassis.get_all_fans()
    for _ in range(FAN_DEFAULT_DELAY):
        is_fan_speed_ready = True
        for fan in fans:
            if fan.is_under_speed() != is_under_speed:
                is_fan_speed_ready = False
            if fan.is_over_speed() != is_over_speed:
                is_fan_speed_ready = False
        if is_fan_speed_ready:
            break
        time.sleep(1)

    if not is_fan_speed_ready:
        pylogger.warning("Timeout expired while waiting for fan speed to be ready for testing")

    for fan in fans:
        fan_name = fan.get_name()
        fan_presence = fan.get_presence()
        fan_status = fan.get_status()
        fan_speed = fan.get_speed()
        fan_tolerance = fan.get_speed_tolerance()
        fan_target_speed = fan.get_target_speed()
        fan_is_under_speed = fan.is_under_speed()
        fan_is_over_speed = fan.is_over_speed()

        pylogger.debug(f"Fan info: name = {fan_name}, presence = {fan_presence}, status = {fan_status}, "
                       f"speed = {fan_speed}, target_speed = {fan_target_speed}, "
                       f"is_under_speed = {fan_is_under_speed}, is_over_speed = {fan_is_over_speed}")

        expected_target_speed = int(target_speed) if fan_presence else 0
        assert fan_target_speed == expected_target_speed
        assert fan_is_under_speed == is_under_speed
        assert fan_is_over_speed == is_over_speed

        if is_under_speed and current_speed is not None:
            assert fan_speed < int(current_speed) * (100 + fan_tolerance) / 100
        if is_over_speed and current_speed is not None:
            assert fan_speed > int(current_speed) * (100 - fan_tolerance) / 100


def simulate_faulty_sensor(sensor_idx, temp_deviation, tol_deviation):
    temps = default_temps.copy()
    cool_level = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
    faulty_temp = thermal_thresholds_list[sensor_idx][cool_level][HIGH_TH_PAIR_IDX] + temp_deviation
    tolerance = round(float(thermal_infos.ThermalInfo.THERMAL_FAULT_SENSOR_TOLERANCE), 1)
    expected_average = round(faulty_temp - (tolerance + tol_deviation), 1)
    temps[sensor_idx] = faulty_temp
    temp_list = []
    for idx in avg_sensor_idx_list:
        if idx != sensor_idx:
            temps[idx] = (expected_average * len(avg_sensor_idx_list) - temps[sensor_idx]) / (len(avg_sensor_idx_list) - 1)
        temp_list.append(temps[idx])
    return temps, temp_list, expected_average


def avoid_faulty_sensor(temps, sensor_idx, cool_lvl, th_pair_idx):
    if sensor_idx in avg_sensor_idx_list:
        for avg_sensor_idx in avg_sensor_idx_list:
            if avg_sensor_idx != sensor_idx:
                th = thermal_thresholds_list[avg_sensor_idx][cool_lvl][th_pair_idx]
                temps[avg_sensor_idx] = th


class LogBuilder:
    """Helper class for building expected log dictionaries"""
    def __init__(self):
        self.logs_dict = copy.deepcopy(DEFAULT_EXPECTED_LOGS_DICT)

    def error(self, msg):
        self.logs_dict['error']['cnt'] += 1
        self.logs_dict['error']['strs'].append(msg)
        return self

    def warning(self, msg):
        self.logs_dict['warning']['cnt'] += 1
        self.logs_dict['warning']['strs'].append(msg)
        return self

    def notice(self, msg):
        self.logs_dict['notice']['cnt'] += 1
        self.logs_dict['notice']['strs'].append(msg)
        return self

    def info_count(self, count):
        self.logs_dict['info']['cnt'] = count
        return self

    def build(self):
        return self.logs_dict


@pytest.fixture(scope='module', autouse=True)
def verify_thermal_control_stopped():
    if is_sonic:
        # Check that `thermalctld` daemon is stopped
        cmd = "supervisorctl status thermalctld"
        sts, res = api_helper.run_command(cmd)
        if sts and 'RUNNING' in res:
            msg = "'thermalctld' daemon is still running. Please stop the daemon before running the tests."
            pylogger.error(msg)
            pytest.exit(msg, returncode=1)
    else:
        # Check that `xmon` service is stopped
        cmd = "systemctl is-active xmon.service"
        sts, res = api_helper.run_command(cmd)
        res = res.decode()
        if sts and res == 'active':
            msg = "'xmon' service is still active. Please stop the service before running the tests."
            pylogger.error(msg)
            pytest.exit(msg, returncode=1)


def init_test():
    pylogger.info("Initialize test setup")
    try:
        tc_daemon = thermalctld.ThermalControlDaemon()
        tc_daemon.stop_event.wait = mock.MagicMock(return_value=False)
        cool_lvl = DEFAULT_COOLING_LEVEL
        fan_speed = fan_speed_list[cool_lvl]
        temps = default_temps.copy()
        logs_builder = LogBuilder()
        thermal_list = get_thermal_list(tc_daemon)
        setup_xcvr_mocks(tc_daemon, default_xcvr_high_ths, default_xcvr_crit_high_ths)
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)
    except Exception as e:
        msg = f"Error initializing test: {e}"
        pylogger.error(msg)
        pytest.exit(msg, returncode=1)

    return tc_daemon, thermal_list, cool_lvl


def cleanup_test(tc_daemon):
    pylogger.info("Clean up test setup")
    if tc_daemon:
        tc_daemon.deinit()


@pytest.fixture
def setup_test():
    tc_daemon, thermal_list, cool_lvl = None, None, None
    try:
        pylogger.info("Fixture setup")
        tc_daemon, thermal_list, cool_lvl = init_test()
        yield tc_daemon, thermal_list, cool_lvl
    finally:
        pylogger.info("Fixture teardown")
        cleanup_test(tc_daemon)


def test_cooling_levels(setup_test):
    tc_daemon, thermal_list, cool_lvl = setup_test

    temps = default_temps.copy()
    for sensor_idx in sensor_idx_list:
        log_test_header(f"cooling levels, sensor number = {sensor_idx}")

        if sensor_idx in tc_sensor_idx_list:
            temps = default_temps.copy()
            for cool_lvl in range(1, 4):
                logs_builder = LogBuilder()
                for tmp_idx in tc_sensor_idx_list:
                    temps[tmp_idx] = thermal_thresholds_list[tmp_idx][cool_lvl - 1][HIGH_TH_PAIR_IDX]

                for temp_deviation in [0, 1]:
                    pylogger.info(f"Test cooling level {cool_lvl}")
                    temps[sensor_idx] += temp_deviation
                    fan_speed = fan_speed_list[cool_lvl - 1]
                    if temp_deviation == 1:
                        fan_speed = fan_speed_list[cool_lvl]
                        logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(cool_lvl - 1, cool_lvl))
                    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

            for cool_lvl in range(3, 0, -1):
                logs_builder = LogBuilder()
                for tmp_idx in tc_sensor_idx_list:
                    temps[tmp_idx] = thermal_thresholds_list[tmp_idx][cool_lvl - 1][LOW_TH_PAIR_IDX]
                temps[sensor_idx] += 1

                for temp_deviation in [0, 1]:
                    pylogger.info(f"Test cooling level {cool_lvl}")
                    temps[sensor_idx] -= temp_deviation
                    fan_speed = fan_speed_list[cool_lvl]
                    if temp_deviation == 1:
                        fan_speed = fan_speed_list[cool_lvl - 1]
                        logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(cool_lvl, cool_lvl - 1))
                    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)
        else:
            logs_builder = LogBuilder()
            logs_builder.info_count(0)
            cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
            fan_speed = fan_speed_list[cool_lvl]

            if sensor_idx in xcvr_sensor_idx_list:
                sfp_idx = sensor_idx - num_thermals + 1
                sfp_thermal = tc_daemon.chassis.get_sfp(sfp_idx).get_thermal(0)
                th = default_high_ths[sensor_idx]
                sfp_thermal.get_high_threshold = mock.MagicMock(return_value=th)
            else:
                tmp_cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_3.value
                th = thermal_thresholds_list[sensor_idx][tmp_cool_lvl][HIGH_TH_PAIR_IDX]

            temps[sensor_idx] = th
            run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

            temps[sensor_idx] = default_temps[sensor_idx]
            run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_faulty_sensor(setup_test):
    tc_daemon, thermal_list, cool_lvl = setup_test

    # tolerance deviation, temperature deviation, cooling level
    test_cases = [
        (0, 0, thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value),
        (1, 0, thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value),
        (1, 1, thermal_infos.ThermalInfo.CoolingLevel.LEVEL_1.value),
        (0, 1, thermal_infos.ThermalInfo.CoolingLevel.LEVEL_1.value),
        (None, None, thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value),
    ]

    for sensor_idx in avg_sensor_idx_list:
        log_test_header(f"faulty sensor, sensor number = {sensor_idx}")

        name = thermal_list[sensor_idx].get_name()
        last_cool_lvl = cool_lvl

        for tol_deviation, temp_deviation, cool_lvl in test_cases:
            logs_builder = LogBuilder()
            avg_temp_list = []
            avg_temp = 0

            if tol_deviation is None and temp_deviation is None:
                temps = default_temps.copy()
            else:
                temps, avg_temp_list, avg_temp = simulate_faulty_sensor(sensor_idx, temp_deviation, tol_deviation)

            if cool_lvl != last_cool_lvl:
                logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(last_cool_lvl, cool_lvl))

            if tol_deviation:
                fan_speed = FAN_MAX_SPEED
                logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
                logs_builder.error(FAULTY_SENSOR_AVERAGE_MSG.format(name, temps[sensor_idx], avg_temp_list, avg_temp))
            else:
                fan_speed = fan_speed_list[cool_lvl]

            run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)
            last_cool_lvl = cool_lvl


@pytest.mark.parametrize("temp", [None, -1.0])
def test_temper(setup_test, temp):
    tc_daemon, thermal_list, cool_lvl = setup_test

    for sensor_idx in sensor_idx_list:
        log_test_header(f"temperature value {temp}, sensor number = {sensor_idx}")

        logs_builder = LogBuilder()
        temps = default_temps.copy()
        temps[sensor_idx] = temp
        name = thermal_list[sensor_idx].get_name()
        cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
        fan_speed = fan_speed_list[cool_lvl]
        if sensor_idx in tc_sensor_idx_list:
            if temp is None:
                logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
                logs_builder.error(FAULTY_SENSOR_INVALID_MSG.format(name, temp))
                fan_speed = FAN_MAX_SPEED
        else:
            logs_builder.info_count(0)

        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

        pylogger.info("Recovery test")
        logs_builder = LogBuilder()
        temps[sensor_idx] = default_temps[sensor_idx]
        cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
        fan_speed = fan_speed_list[cool_lvl]

        if sensor_idx not in tc_sensor_idx_list:
            logs_builder.info_count(0)

        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_warning_overheat(setup_test):
    tc_daemon, thermal_list, cool_lvl = setup_test

    temps = default_temps.copy()
    for sensor_idx in sensor_idx_list:
        log_test_header(f"warning overheat, sensor number = {sensor_idx}")

        logs_builder = LogBuilder()
        name = thermal_list[sensor_idx].get_name()
        th = thermal_list[sensor_idx].get_high_threshold()
        temps[sensor_idx] = th + 1.0
        if sensor_idx in tc_sensor_idx_list:
            last_cool_lvl = cool_lvl
            cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_4.value
            avoidance_cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_3.value
            avoid_faulty_sensor(temps, sensor_idx, avoidance_cool_lvl, HIGH_TH_PAIR_IDX)
            logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(last_cool_lvl, cool_lvl))
        elif sensor_idx in xcvr_sensor_idx_list:
            pass
        else:
            cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
            logs_builder.info_count(0)

        if sensor_idx in tc_sensor_idx_list:
            logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
            logs_builder.warning(WARN_OVERHEAT_MSG.format(name, temps[sensor_idx], th))
        elif sensor_idx in xcvr_sensor_idx_list:
            logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
            logs_builder.warning(XCVR_WARN_OVERHEAT_MSG.format(name, temps[sensor_idx], th))

        fan_speed = FAN_MAX_SPEED if sensor_idx in xcvr_sensor_idx_list else fan_speed_list[cool_lvl]
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

        pylogger.info("Recovery test")
        logs_builder = LogBuilder()
        temps[sensor_idx] = default_temps[sensor_idx]
        if sensor_idx in tc_sensor_idx_list:
            last_cool_lvl = cool_lvl
            cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
            avoidance_cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
            avoid_faulty_sensor(temps, sensor_idx, avoidance_cool_lvl, LOW_TH_PAIR_IDX)
            logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(last_cool_lvl, cool_lvl))
        elif sensor_idx in xcvr_sensor_idx_list:
            pass
        else:
            cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value
            logs_builder.info_count(0)

        fan_speed = fan_speed_list[cool_lvl]
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_critical_overheat(setup_test):
    tc_daemon, thermal_list, cool_lvl = setup_test

    for sensor_idx in sensor_idx_list:
        log_test_header(f"critical overheat, sensor number = {sensor_idx}")

        tc_daemon, thermal_list, cool_lvl = init_test()
        temps = default_temps.copy()
        logs_builder = LogBuilder()
        ThermalCriticalAction.reboot_device.reset_mock()
        th = thermal_list[sensor_idx].get_high_critical_threshold()
        temps[sensor_idx] = th + 1.0
        if sensor_idx in tc_sensor_idx_list:
            avoidance_cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_3.value
            avoid_faulty_sensor(temps, sensor_idx, avoidance_cool_lvl, HIGH_TH_PAIR_IDX)
            if cool_lvl == thermal_infos.ThermalInfo.CoolingLevel.LEVEL_0.value:
                last_cool_lvl = cool_lvl
                cool_lvl = thermal_infos.ThermalInfo.CoolingLevel.LEVEL_5.value
                logs_builder.notice(COOL_LEVEL_CHANGE_MSG.format(last_cool_lvl, cool_lvl))
            name = thermal_list[sensor_idx].get_name()
            logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
            logs_builder.error(CRIT_OVERHEAT_MSG.format(name, temps[sensor_idx], th))
            logs_builder.error(CRIT_REBOOT_MSG)
        elif sensor_idx in xcvr_sensor_idx_list:
            name = thermal_list[sensor_idx].get_name()
            warn_th = thermal_list[sensor_idx].get_high_threshold()
            logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
            logs_builder.warning(XCVR_WARN_OVERHEAT_MSG.format(name, temps[sensor_idx], warn_th))
            logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
            logs_builder.error(XCVR_CRIT_OVERHEAT_MSG.format(name, temps[sensor_idx], th))
        else:
            logs_builder.info_count(0)

        if sensor_idx in tc_sensor_idx_list or sensor_idx in xcvr_sensor_idx_list:
            fan_speed = FAN_MAX_SPEED
        else:
            fan_speed = fan_speed_list[cool_lvl]
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

        if sensor_idx in tc_sensor_idx_list:
            ThermalCriticalAction.reboot_device.assert_called_once()
        else:
            ThermalCriticalAction.reboot_device.assert_not_called()
        cleanup_test(tc_daemon)


@pytest.mark.parametrize("presence,status", [(False, True), (True, False)])
def test_fan_failure(setup_test, presence, status):
    tc_daemon, thermal_list, cool_lvl = setup_test

    temps = default_temps.copy()

    for fan_idx in range(num_fans):
        fan = tc_daemon.chassis.get_fan(fan_idx)
        fan.get_presence = mock.MagicMock(return_value=True)
        fan.get_status = mock.MagicMock(return_value=True)

    for fan_idx in range(num_fans):
        log_test_header(f"fan failure, fan number = {fan_idx}, presence = {presence}, status = {status}")

        fan = tc_daemon.chassis.get_fan(fan_idx)

        logs_builder = LogBuilder().notice(SET_FAN_SPEED_TO_100_MSG)
        fan.get_presence = mock.MagicMock(return_value=presence)
        fan.get_status = mock.MagicMock(return_value=status)
        fan_speed = FAN_MAX_SPEED
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

        pylogger.info("Recovery test")
        logs_builder = LogBuilder()
        fan.get_presence = mock.MagicMock(return_value=True)
        fan.get_status = mock.MagicMock(return_value=True)
        fan_speed = fan_speed_list[cool_lvl]
        run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_fan_watchdog(setup_test):
    tc_daemon, thermal_list, cool_lvl = setup_test

    log_test_header("fan watchdog")

    time.sleep(thermal_manager.WD_TIMEOUT + FAN_DEFAULT_DELAY)

    logs_builder = LogBuilder()
    temps = default_temps.copy()
    fan_speed = fan_speed_list[cool_lvl]

    logs_builder.info_count(0)
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed, fan_current_speed=FAN_MAX_SPEED,
        fan_is_under_speed=False, fan_is_over_speed=True)

    pylogger.info("Recovery test")
    logs_builder.info_count(1)
    temps[tc_sensor_idx_list[0]] += 1.0 # Simulate temperature change
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

    fan_wd = tc_daemon.chassis.get_fan_watchdog()
    assert fan_wd.is_armed()
    remaining_time1 = fan_wd.get_remaining_time()
    time.sleep(5)
    remaining_time2 = fan_wd.get_remaining_time()
    assert remaining_time1 > 0
    assert remaining_time2 > 0
    assert remaining_time2 < remaining_time1


def test_xcvr_exception_isolation(setup_test):
    """Verify that a transient exception on one SFP does not prevent
    evaluation of remaining modules. Port 1 raises, port 2 overheats."""
    tc_daemon, thermal_list, cool_lvl = setup_test

    log_test_header("xcvr exception isolation")

    if num_sfps < 2:
        pytest.skip("Need at least 2 SFPs for isolation test")

    temps = default_temps.copy()
    sfp1 = tc_daemon.chassis.get_sfp(1)
    sfp2 = tc_daemon.chassis.get_sfp(2)

    sfp1.get_presence = mock.MagicMock(side_effect=RuntimeError("I2C read error"))

    overheat_temp = DEFAULT_XCVR_HIGH_TH + 5.0
    sfp2_thermal = sfp2.get_thermal(0)
    temps[num_thermals + 1] = overheat_temp

    logs_builder = LogBuilder()
    logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
    logs_builder.warning(XCVR_WARN_OVERHEAT_MSG.format(
        sfp2_thermal.get_name(), overheat_temp, DEFAULT_XCVR_HIGH_TH))
    logs_builder.error(XCVR_EVAL_FAILURE_MSG.format("I2C read error"))

    fan_speed = FAN_MAX_SPEED
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

    pylogger.info("Recovery test")
    sfp1.get_presence = mock.MagicMock(return_value=True)
    temps[num_thermals + 1] = DEFAULT_XCVR_TEMP
    logs_builder = LogBuilder()
    fan_speed = fan_speed_list[cool_lvl]
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_xcvr_failsafe_on_read_failure(setup_test):
    """Verify fail-safe: when a module that was overheating has a subsequent
    read failure, the previous overheat state is retained (fans stay at max)
    rather than being cleared to normal."""
    tc_daemon, thermal_list, cool_lvl = setup_test

    log_test_header("xcvr failsafe on read failure")

    if num_sfps < 1:
        pytest.skip("Need at least 1 SFP")

    temps = default_temps.copy()
    sfp = tc_daemon.chassis.get_sfp(1)
    sfp_thermal = sfp.get_thermal(0)

    overheat_temp = DEFAULT_XCVR_HIGH_TH + 5.0
    temps[num_thermals] = overheat_temp

    logs_builder = LogBuilder()
    logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
    logs_builder.warning(XCVR_WARN_OVERHEAT_MSG.format(
        sfp_thermal.get_name(), overheat_temp, DEFAULT_XCVR_HIGH_TH))
    fan_speed = FAN_MAX_SPEED
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

    pylogger.info("Fail-safe test: read failure while overheating")
    sfp.get_presence = mock.MagicMock(side_effect=RuntimeError("I2C timeout"))
    logs_builder = LogBuilder()
    logs_builder.info_count(0)
    logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
    logs_builder.warning(XCVR_WARN_OVERHEAT_MSG.format(
        sfp_thermal.get_name(), overheat_temp, DEFAULT_XCVR_HIGH_TH))
    logs_builder.error(XCVR_EVAL_FAILURE_MSG.format("I2C timeout"))
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, FAN_MAX_SPEED)

    pylogger.info("Recovery test: read restored, temp normal")
    sfp.get_presence = mock.MagicMock(return_value=True)
    temps[num_thermals] = DEFAULT_XCVR_TEMP
    logs_builder = LogBuilder()
    fan_speed = fan_speed_list[cool_lvl]
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_xcvr_critical_without_warning_threshold(setup_test):
    """Verify that fan boost is triggered on XCVR critical overheat even
    when the warning threshold is unavailable (None)."""
    tc_daemon, thermal_list, cool_lvl = setup_test

    log_test_header("xcvr critical without warning threshold")

    if num_sfps < 1:
        pytest.skip("Need at least 1 SFP")

    temps = default_temps.copy()
    sfp = tc_daemon.chassis.get_sfp(1)
    sfp_thermal = sfp.get_thermal(0)

    sfp_thermal.get_high_threshold = mock.MagicMock(return_value=None)
    overheat_temp = DEFAULT_XCVR_CRIT_HIGH_THS + 5.0
    temps[num_thermals] = overheat_temp

    logs_builder = LogBuilder()
    logs_builder.notice(SET_FAN_SPEED_TO_100_MSG)
    logs_builder.error(XCVR_CRIT_OVERHEAT_MSG.format(
        sfp_thermal.get_name(), overheat_temp, DEFAULT_XCVR_CRIT_HIGH_THS))

    fan_speed = FAN_MAX_SPEED
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

    pylogger.info("Recovery test")
    sfp_thermal.get_high_threshold = mock.MagicMock(return_value=DEFAULT_XCVR_HIGH_TH)
    temps[num_thermals] = DEFAULT_XCVR_TEMP
    logs_builder = LogBuilder()
    fan_speed = fan_speed_list[cool_lvl]
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)


def test_xcvr_chassis_level_failure(setup_test):
    """Verify that a chassis-level failure in get_all_sfps() is caught and
    does not prevent the rest of the collect() method from completing."""
    tc_daemon, thermal_list, cool_lvl = setup_test

    log_test_header("xcvr chassis-level failure")

    temps = default_temps.copy()
    original_get_all_sfps = tc_daemon.chassis.get_all_sfps

    tc_daemon.chassis.get_all_sfps = mock.MagicMock(
        side_effect=RuntimeError("SFP subsystem unavailable"))

    logs_builder = LogBuilder()
    logs_builder.info_count(0)
    logs_builder.error(XCVR_EVAL_FAILURE_MSG.format("SFP subsystem unavailable"))
    fan_speed = fan_speed_list[cool_lvl]
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

    pylogger.info("Recovery test")
    tc_daemon.chassis.get_all_sfps = original_get_all_sfps
    logs_builder = LogBuilder()
    logs_builder.info_count(0)
    run_and_test_tc_logic(tc_daemon, logs_builder, temps, fan_speed)

