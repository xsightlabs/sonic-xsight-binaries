#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) Xsight Labs Ltd.

fname=$(basename $0)

function klog {
	echo "$fname:" "$@" | tee /dev/kmsg
}

adapter='SMBus I801 adapter'
found=0
for I2CBUS in 0 1; do
	devname=`cat /sys/bus/i2c/devices/i2c-$I2CBUS/name`
	if [[ $devname == $adapter* ]]; then
		klog "$adapter = $I2CBUS"
		found=1
		break
	fi
done
if [ $found -eq 0 ]; then
	klog "Cannot find $adapter"
	exit 1
fi

reload=0
lsmod | grep xpci > /dev/null
if [ $? -eq 0 ]; then
	klog "Unload xpci module"
	systemctl list-unit-files | grep xmon > /dev/null
	if [ $? -eq 0 ]; then
		systemctl stop xmon.service
		sleep 3
	fi
	rmmod xpci
	res=$?
	sleep 3
	if [ $res -eq 1 ]; then
		klog "Failed to unload xpci module"
		exit 1
	fi
	reload=1
fi

klog "Resetting X2 ..."

trap 'echo -e "\nIgnore Ctrl-C"' SIGINT

# Disable PCIe reset during X2 chip reset
i2cset -f -y $I2CBUS 0x68 0x71 0x3
if [ $? -ne 0 ]; then
	klog "Failed to disable PCIe reset"
	exit 1
fi


# MAC_HW_RSTN bit = 0, (assert X2 chip reset)
i2cset -f -y $I2CBUS 0x68 0x8 0x3f
if [ $? -ne 0 ]; then
	klog "Failed to assert X2 reset"
	exit 1
fi

sleep 0.5

# MAC_HW_RSTN bit = 1, (deassert X2 chip reset)
i2cset -f -y $I2CBUS 0x68 0x8 0xbf
if [ $? -ne 0 ]; then
	klog "Failed to deassert X2 reset"
	exit 1
fi

# Prevent PCI HW Error at high CPU loads
sleep 1

# Enable PCIe reset during X2 chip reset
i2cset -f -y $I2CBUS 0x68 0x71 0x1
if [ $? -ne 0 ]; then
	klog "$fname: Failed to re-enable PCIe reset"
	exit 1
fi

trap SIGINT

if [ $reload -eq 1 ]; then
	sleep 5
	klog "Load xpci module"
	modprobe xpci
	if [ $? -eq 1 ]; then
		klog "Failed to load xpci module"
		exit 1
	fi
	systemctl list-unit-files | grep xmon > /dev/null
	if [ $? -eq 0 ]; then
		systemctl start xmon.service
	fi
fi
