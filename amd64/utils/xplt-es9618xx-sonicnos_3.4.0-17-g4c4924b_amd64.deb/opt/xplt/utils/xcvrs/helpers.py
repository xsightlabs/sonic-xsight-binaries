# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.

import functools
import time

def timer(func):
    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start = time.perf_counter()
        value = func(*args, **kwargs)
        stop = time.perf_counter()
        elapsed_time = stop - start
        print(f"{func.__name__}(): {elapsed_time:.4f} secs")
        return value
    return wrapper_timer

def decor(dec, condition):
    def decorator(func):
        if not condition:
            # Return the function unchanged, not decorated.
            return func
        return dec(func)
    return decorator