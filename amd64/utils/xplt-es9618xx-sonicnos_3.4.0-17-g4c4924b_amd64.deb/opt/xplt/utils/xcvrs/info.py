#!/opt/xplt/venv/bin/python
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2020 Xsightlabs Ltd.


from __future__ import print_function
import sys
import argparse
from cmis_local import *
from helpers import *

media_types = [
    'Undef',
    'MMF',
    'SMF',
    'PCC',
    'AC',
    'BASE-T'
]

module_state = [
    'N/A',
    'LowPwr',
    'PwrUp',
    'Ready',
    'PwrDn',
    'Fault'
]

column = [
    ('Port',    8, ''),
    ('Vendor', 17, 'VENDOR_NAME'),
    ('Type',   10, ''),
    ('Media',   9, 'MOD_MED_TYPE_ENC'),
    ('P/N',    17, 'VENDOR_PN'),
    ('S/N',    22, 'VENDOR_SN'),
    ('FW Ver',  9, 'MODULE_FW_REV_MAJOR'),
    ('Temp,C',  9, 'TEMPERATURE'),
    ('Volt,V',  9, 'SUPPLY_VOLTAGE'),
    ('State',   9, 'MODULE_STATE'),
    ('Custom', 20, '')
]

name = 0
size = 1
reg = 2

info_len = len(column)
custom = info_len - 1

# Execution time measurement verbosity
time_vbs1 = False
time_vbs2 = False

class PortAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        if not 1 <= values <= 32:
            raise argparse.ArgumentError(self, "Port number must be between 1 and 32")
        setattr(namespace, self.dest, values)

class InfoAction(argparse.Action):
    def __call__(self, parser, namespace, values, option_string=None):
        for val in values:
            if not 1 <= val <= info_len:
                raise argparse.ArgumentError(self,
                    "info type must be between 1 and {}".format(info_len))
        setattr(namespace, self.dest, values)

parser = argparse.ArgumentParser(description='Prints optical modules information',
                                 formatter_class=argparse.RawTextHelpFormatter)
parser.add_argument('first',
                    type = int,
                    nargs = '?',
                    default= 1,
                    action = PortAction,
                    help = 'the front panel first port number to scan')

parser.add_argument('last',
                    type = int,
                    nargs = '?',
                    default= 16,
                    action = PortAction,
                    help = 'the front panel last port number to scan')

parser.add_argument('-c',
                    '--compact',
                    action = 'store_true',
                    help ='do not print empty ports')

parser.add_argument('-i',
                    '--info',
                    metavar = "{{1..{}}}".format(info_len),
                    action = InfoAction,
                    nargs = '+',
                    type = int,
                    help = ''.join('[{}] - {}\n'.format(i + 1, column[i][name])
                                for i in range(info_len)))

parser.add_argument('-n',
                    '--noheader',
                    action = 'store_true',
                    help ='do not print a table header row')

parser.add_argument('-r',
                    metavar = 'arg',
                    type = str,
                    help = 'read value by user defined key, e.g. -r HST_GEN_EN')

parser.add_argument('-s',
                    '--standalone',
                    action='store_true',
                    help='standalone mode')

parser.add_argument('-u',
                    '--url',
                    type = str,
                    help ='hostname or IP address of the oomjsonsvr server')

parser.add_argument('-v',
                    '--verbose',
                    action='store_true',
                    help='more verbose print')


def set_info_args(user_args=None):
    """Set info arguments API.

     Args:
        user_args: list of arguments as generated via CLI in a standalone mode.
        Is printed to console when run with -v option.
        See info_api_demo.py example.
     Returns:
        argparse.Namespace object
    """
    if user_args == None:
        raise Exception("No argumens were provided!")

    args = parser.parse_args(user_args, argparse.Namespace())
    parse_info_args(args)
    return args


def parse_info_args(args):
    """Parse info arguments API.

     Args: argparse.Namespace object
     Returns: None
    """
    global oom
    global info
    global oomlwclient

    if args.info == None:
        info = list(range(1, info_len))
    else:
        info = args.info
        info.sort()

    if args.r and info_len not in info:
        info.append(info_len)

    if not args.standalone:
        try:
            import oomlwclient as oom
            oom.oomlwclient_init(args.url)
            return
        except:
            if args.verbose:
                print("Running in standalone mode")

    import oom
    if args.url != None:
        oom.setshim("oomjsonshim", args.url)


def get_port_info(port, args):
    """Get port information.

     Args:
        port: port object from OMM portlist.
        args: argparse.Namespace object

     Returns:
        tuple of strings from info_regs according to the indexes in the info list.
    """
    data = ()
    modtype = oom.type_to_str(port.port_type)
    if modtype == 'UNKNOWN':
        if args.compact:
            return data
        modtype = 'No Module'
    add_qsfpdd_keys(port)
    for i in info:
        idx = i - 1
        if idx == 0:
            data += (port.port_name,)
        elif idx == 2:
            data += (modtype,)
        elif idx == custom:
            val = str(oom.oom_get_keyvalue(port, args.r))
            if val.isdigit():
                data += ("{:X}".format(int(val)),)
            else:
                data += (val,)
        else:
            val = str(oom.oom_get_keyvalue(port, column[idx][reg]))
            if idx == 3:
                if not val:
                    val = '0'
                val = val + ':' + media_types[int(val)]
            elif idx == 6:
                minor = str(oom.oom_get_keyvalue(port, 'MODULE_FW_REV_MINOR'))
                if minor:
                    val = val + '.' + minor
            elif idx == 9:
                state = oom.oom_get_keyvalue(port, 'MODULE_STATE')
                if state is not None:
                    try:
                        val = module_state[int(state)]
                    except (ValueError, IndexError):
                        pass
            data += (val,)
    return data


@decor(timer, time_vbs2)
def get_ports_info(portlist, args):
    """Get all requested ports information.

     Args:
        portlist: OMM portlist object
        args: argparse.Namespace object

     Returns:
        Dictionary of tuples returned by get_port_info().
    """

    data = {}
    for p in range (args.first - 1, args.last):
        port = portlist[p]
        data[p] = get_port_info(port, args)
    return data


def print_port_info(data):
    """Print port information.

     Args:
        data: a tuple of strings returned by get_port_info().

     Returns: None
    """
    if data:
        for idx, i in enumerate(info):
            i -= 1
            print('{:{}}'.format(data[idx][:column[i][size]-1], column[i][size]), end=""),
        print("")


def print_table_caption(noheader):
    """Print table caption.

     Args:
        noheader: args.noheader

     Returns: None
    """
    if not noheader:
        for i in info:
            i -= 1
            value = column[i][name]
            if i == custom:
                value = args.r
            print('{:{}}'.format(value[:column[i][size]-1], column[i][size]), end=""),
        print("")


def print_table_port_by_port(portlist, args):
    """Prints the port table quering a port information one by one.

     Args:
        portlist: OMM portlist object
        args: argparse.Namespace object

     Returns: None
    """
    print_table_caption(args.noheader)

    for p in range (args.first - 1, args.last):
        port = portlist[p]
        data = get_port_info(port, args)
        print_port_info(data)


def print_table_at_once(data, noheader):
    """Prints the port table from dictionary returned by get_ports_info().

     Args:
        data: dictionary of port tuples returned by get_ports_info()
        args: argparse.Namespace object

     Returns: None
    """
    print_table_caption(noheader)
    for key in data:
        print_port_info(data[key])


@decor(timer, time_vbs2)
def get_port_list():
    """Get list of ports.

     Args: None
     Returns: Returns list of ports or exits if list is empty.
    """
    portlist = oom.oom_get_portlist()
    if len(portlist) == 0:
        print("Empty portlist, configuration issue?")
        exit()
    return portlist

@decor(timer, time_vbs1)
def main(args):
    portlist = get_port_list()
    #print_table_port_by_port(portlist, args)
    data = get_ports_info(portlist, args)
    print_table_at_once(data, args.noheader)

if __name__ == "__main__":
    args = parser.parse_args()
    if args.verbose:
        print("CLI parameters: {}".format(sys.argv[1:]))
    parse_info_args(args)
    main(args)

