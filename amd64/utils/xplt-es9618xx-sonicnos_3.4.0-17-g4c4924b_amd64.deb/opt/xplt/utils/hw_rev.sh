#!/bin/bash
#
# SPDX-License-Identifier: MIT
#
# Copyright (c) 2025 Xsightlabs Ltd.

fname=$(basename $0)

function klog {
        echo "$fname:" "$@" | tee /dev/kmsg
}

adapter='SMBus I801 adapter'
found=0
for I2CBUS in 0 1; do
        devname=`cat /sys/bus/i2c/devices/i2c-$I2CBUS/name`
        if [[ $devname == $adapter* ]]; then
                found=1
                break
        fi
done
if [ $found -eq 0 ]; then
        klog "Cannot find $adapter"
        exit 1
fi


rev=$(i2cget -y -f $I2CBUS 0x68 0x0)
rev=$((rev & 0x07))

if [ $? -ne 0 ]; then
        klog "Failed to access FPGA"
        exit 1
fi

hwrevs=("R0A"
        "R0B"
        "R0C"
        "R01")

index=$(printf "%d\n" $rev)
case "$index" in
        0|1|2|3 ) echo "${hwrevs[$index]}" ;;
        * ) echo "Error: Invalid HW Rev value - $rev"; exit 1 ;;
esac

